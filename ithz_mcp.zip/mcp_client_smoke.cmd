@echo off
set "PYTHONPATH=%~dp0;%~dp0src;%PYTHONPATH%"
python mcp_client_smoke.py
