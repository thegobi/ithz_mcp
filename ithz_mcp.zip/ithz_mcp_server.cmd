@echo off
set "PYTHONPATH=%~dp0;%~dp0src;%PYTHONPATH%"
set "ITHZ_PYTHON=python"
where python >nul 2>nul
if errorlevel 1 set "ITHZ_PYTHON=py -3"
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "ITHZ_PYTHON=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
%ITHZ_PYTHON% -m ithz_mcp %*
