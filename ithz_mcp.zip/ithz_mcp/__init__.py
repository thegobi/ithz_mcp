from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

VERSION = "0.1.0-alpha"
BUILD_ID = "product-candidate-mcp28-ubuntu-fallback.20260608.2"
PACKAGE_NAME = "ithz_mcp-v0.1-product-candidate"
PACKAGE_FILENAME = "ithz_mcp.zip"
PRODUCT = "ITHZ-MCP / ITHZ ContextDB"

_ROOT = Path(__file__).resolve().parent.parent
_SRC = _ROOT / "src" / "ithz_mcp"
if _SRC.exists():
    __path__.insert(0, str(_SRC))


def _git_commit(root: Path) -> str:
    try:
        result = subprocess.run(
            ["git", "-C", str(root), "rev-parse", "--short=12", "HEAD"],
            text=True,
            capture_output=True,
            check=False,
        )
    except (FileNotFoundError, OSError):
        return ""
    return result.stdout.strip() if result.returncode == 0 else ""


def _git_dirty(root: Path) -> bool | None:
    try:
        result = subprocess.run(
            ["git", "-C", str(root), "status", "--porcelain", "--", str(root)],
            text=True,
            capture_output=True,
            check=False,
        )
    except (FileNotFoundError, OSError):
        return None
    if result.returncode != 0:
        return None
    return bool(result.stdout.strip())


def version_info() -> dict[str, Any]:
    info: dict[str, Any] = {
        "product": PRODUCT,
        "version": VERSION,
        "build_id": BUILD_ID,
        "package_name": PACKAGE_NAME,
        "package_filename": PACKAGE_FILENAME,
        "mode": "local-first",
        "claims": ["not_git_replacement", "not_production_database", "not_cloud_sync"],
    }
    manifest = _ROOT / "VERSION.json"
    if manifest.exists():
        try:
            loaded = json.loads(manifest.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                info.update(loaded)
        except json.JSONDecodeError:
            info["version_manifest_error"] = "invalid_json"
    commit = info.get("source_git_commit") or _git_commit(_ROOT)
    if commit:
        info["source_git_commit"] = commit
    dirty = _git_dirty(_ROOT)
    if dirty is not None:
        info["source_tree_dirty"] = dirty
    return info
