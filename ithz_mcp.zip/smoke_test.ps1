$ErrorActionPreference='Stop'
python -m ithz_mcp version
python -m ithz_mcp self-test --verbose
python -m ithz_mcp install-project --project sample_project --apply --agent-intake deterministic-only --no-git-driver | Out-Null
python -m ithz_mcp archive-finalize-task --project sample_project --task "product package smoke" --summary-text "Package smoke completed." --docs-impact not-needed --memory-impact handoff-created --gate "Gate: package smoke passed" | Out-Null
python -m ithz_mcp ithz-add-claim --project sample_project --claim-id package_smoke_claim --text "Package smoke passed as a scoped test result." --scope package-smoke --supporting-gate package-smoke --status allowed_scoped | Out-Null
python -m ithz_mcp ithz-block-claim --project sample_project --claim-id package_git_replacement_block --text "Git replacement claim" --reason "Git remains the code history transport." --blocking-gate package-smoke | Out-Null
python -m ithz_mcp ithz-can-i-claim --project sample_project --claim "Git replacement claim" | Out-Null
python -m ithz_mcp archive-get-context-pack --project sample_project --query "package smoke gate" --out archive_pack.md | Out-Null
python -m ithz_mcp mcp-config-validate --config codex_mcp_config.sample.json | Out-Null
python mcp_client_smoke.py | Out-Null
