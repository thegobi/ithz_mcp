# README FIRST

Build: `product-candidate-mcp28-ubuntu-fallback.20260608.2`

1. Run `smoke_test.ps1`.
2. On macOS/Linux run `chmod +x *.sh host_installers_macos/*.sh` then `./smoke_test.sh`.
3. Run `python mcp_client_smoke.py` or `./mcp_client_smoke.sh`.
4. Copy `install_ithz.md` into another project and ask the local agent to follow it.
5. Review `host_installers/README_HOST_INSTALLERS.md` and `host_installers_macos/README_HOST_INSTALLERS.md`.
6. Install Windows host config with `install_*_mcp.ps1 -Apply`; install macOS host config with `install_*_mcp.sh --apply`.
7. Use `project.md` as bootstrap and `project.ithz` as the memory zone when native `ithz-native` is available.
8. On macOS, the Python MCP server works through stdio; this package uses `legacy` storage in generated macOS host configs.
   Native `project.ithz` storage requires `native/ithz-native` or `ITHZ_NATIVE_EXE` pointing to a compatible macOS binary.
9. First install runs agent intake with Codex CLI when available; if not, the host agent must finish intake from `install_ithz.md`.
10. Use durable instruction and Project Ledger tools when the user gives lasting workflow, decision, gate, risk, claim or reviewer-note rules.
11. Track `project.md` and `project.ithz` in Git; use the ITHZ merge driver for parallel work.
12. This is not a Git replacement, cloud sync product, production database, or general token-saving claim.
