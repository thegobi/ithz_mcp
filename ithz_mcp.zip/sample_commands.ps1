$ErrorActionPreference='Stop'
python -m ithz_mcp install-project --project sample_project --apply --agent-intake deterministic-only --no-git-driver
python -m ithz_mcp ithz-add-claim --project sample_project --claim-id sample_scoped_claim --text "Sample package smoke has a scoped ledger claim." --scope package-smoke --supporting-gate package-smoke --status allowed_scoped
python -m ithz_mcp ithz-block-claim --project sample_project --claim-id sample_blocked_claim --text "Sample package replaces Git" --reason "ITHZ-MCP does not replace Git." --blocking-gate package-smoke
python -m ithz_mcp ithz-can-i-claim --project sample_project --claim "Sample package replaces Git"
python -m ithz_mcp archive-get-context-pack --project sample_project --query "decision gate" --out archive_pack.md
python -m ithz_mcp mcp-config-validate --config codex_mcp_config.sample.json
python mcp_client_smoke.py
