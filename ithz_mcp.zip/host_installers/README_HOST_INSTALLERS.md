# ITHZ-MCP Host Installers

These scripts prepare local MCP config files for Codex, Claude Code, Cursor, Antigravity and generic JSON-RPC clients.

- Windows PowerShell scripts default to dry-run. Pass `-Apply` to write config files.
- macOS/Linux POSIX scripts default to dry-run. Pass `--apply` to write config files.
- Codex config includes `ithz_mcp` for read-only startup and `ithz_mcp_write` for explicit native auto-checkpoint writes.
- Read-only config is the default. The write-enabled profile exposes `ithz_archive_auto_checkpoint` for end-of-task memory writes.
- Generated configs use storage profile `native-archive`. On macOS, use `legacy` unless a macOS `ithz-native` binary is available.
- External host UIs and config formats may change; validate with `python -m ithz_mcp mcp-config-validate --config <file>` and `python -m ithz_mcp mcp-client-smoke --config <file>`.
- ITHZ-MCP does not replace Git, a production database, cloud sync or every retrieval system.
