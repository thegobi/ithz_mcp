﻿# Implementation Status

| Stage | Status | Summary |
| --- | --- | --- |
| Stage 0 | done | ZIP imported, checksums verified, skeleton created. |
| MCP0 | done | Local context archive CLI passed. |
| MCP1 | done | Read-only MCP/server shim passed. |
| MCP2 | done | Append-only write-back checkpoints passed. |
| MCP3 | done | Memory benchmark and beta adoption smoke passed. |
| MCP4 | done | Context VCS timeline smoke passed. |
| MCP5 | done | Git metadata integration smoke passed; optional capture now includes commit subject/title, short hash and ref names. |
| MCP6 | done | Team memory sync local shared-dir smoke passed. |
| MCP7 | done | Productization and dogfooding package smoke passed. |
| MCP8 | done | Shim hardening, beta fixtures, corruption tests, sync conflict/redaction, RC2 package and light refactor passed. |
| MCP9F | done | Read-only native ITHZ result ingestion and dogfood packs passed. |
| MCP10 | done | Markdown-minimal mode, `.ithz-context`, context compiler benchmark, migration dry-run, bootstrap contract and RC3 package passed. |
| MCP11 | done | MCP/Codex config validation, scripted stdio client smoke, scoring v2, native dogfood query suite v2, quality regression and RC4 package passed. |
| MCP12 | done | Explicit prompt/response memory capture, summary default, redaction, context commit linking and local-only sync skip passed. |
| MCP13 | done | Real MCP-style initialize/tools/list/tools/call shim and native `project.ithz` archive memory workflow passed scripted compatibility tests. |
| MCP13 zone policy | done | Nearest `project.ithz` discovery, nested child-zone detection, explicit parent/sibling zone access, and archive write lock/hash precondition were added. |
| MCP13 cross-zone registry | done | Active archives can link parent/sibling/manual memory zones, build cross-zone context packs and record cross-zone task events inside `project.ithz`. |
| MCP16 | done | ITHZ-aware Git diff/merge driver for `project.ithz` passed: independent append-only memory events merge, local-only prompt memory is skipped, secret-like payloads are blocked, and merge reports are written. |
| MCP17 | done | Append-only memory events, deterministic current index rebuild, searchable event evidence, optional read-only Git commit subject metadata and snapshot creation were added inside `project.ithz`. |
| Memory-first bootstrap | done | `project.md` is the new-thread bootstrap manifest; generated MCP configs declare `agent_policy.bootstrap_file=project.md` and the server initialize instructions point agents to ITHZ-MCP status/context packs before broad codebase reads. |
| MCP icon metadata | done | ITHZ-MCP now ships an SVG icon asset and publishes best-effort branding metadata in MCP `initialize` and generated host configs; visible UI support still depends on the host. |
| macOS install playbook fallback | done | Added `install_ithz.md` as the one-file agent install playbook and documented the macOS safe default: install host config/Git driver/Drive fallback and report the native-binary gap instead of asking an A/B/C/D question when `ithz-native` is missing. |
| MCP18 | done | Project workflow intake and explicit end-of-task checkpointing were added: read-only MCP profiles stay write-free, write-enabled profiles can append sanitized decisions/gates/risks/next steps/prompt summaries and snapshots into `project.ithz`. |
| MCP19 | done | Workflow branch profiles were added: existing Markdown structures and onboarding prompts can be mined into named profiles in `project.ithz`, and the merge driver auto-merges independent profiles while flagging same-profile divergence. |
| MCP20 | done | Optional local agent-history import was added: project-matched Codex/Claude/Cursor/Antigravity-style prompt/response logs can be discovered dry-run and imported summary-only into `project.ithz` with explicit apply, author identity and time provenance. Existing Git-provided archives are appended, not replaced. |
| MCP21 | done | Production-readiness scenario tests and packaging were added: fresh/adopted/shared project smokes, host installer bundle generation for Codex/Claude Code/Cursor/Antigravity/generic JSON-RPC, and `dist/ithz_mcp-v0.1-product-candidate`. |
| MCP22 | done | Automatic native checkpointing was added for write-enabled MCP hosts: read-only profiles stay write-free, while the explicit write profile exposes `ithz_archive_auto_checkpoint` for end-of-task writes into `project.ithz`. |
| MCP23 | done | One-command `install-project` was added with current-directory root semantics, scoped Git diff/merge driver setup, host installer generation and compact native archive indexes. |
| MCP23.1 | done | First-install agent intake was added: `--agent-intake auto` uses Codex CLI read-only when available, otherwise records deterministic fallback and asks the host agent via `ithz_mcp.md` to complete manual intake. |
| MCP23.2 | done | LLM-assisted first intake now builds a bounded repo dossier first, then prompts Codex CLI to select important files/sections from sanitized docs/configs/source excerpts. Verified on `C:\work\afroplants.eu`; `project.ithz` stayed compact at about 125 KB after LLM intake. |
| Native writer API | done | `ithz-native --update-file` updates one logical archive file; `ithz-native --update-files` updates multiple logical archive files in one memory-backed archive rewrite without restored-tree staging. |
| Native runtime selector | done | ITHZ-MCP selects AVX2 only when runtime CPU detection reports AVX2 support, otherwise scalar is selected when bundled; explicit `--native-exe` and `ITHZ_NATIVE_EXE` remain overrides. |
| MCP25 macOS MCP package | done | Product candidate package now includes POSIX launchers, macOS/Linux host installer scripts and `docs/MACOS_MCP_SETUP.md`. macOS MCP uses Python stdio; native `project.ithz` storage still needs a macOS `ithz-native` binary. |
| MCP26 | done | Deterministic current-memory synthesis, fast archive lock contention handling, auto-deferred large-archive snapshots, UTF-8 surrogate sanitization, compact MCP write responses and queued checkpoint finalization for large memory zones were added and packaged. |
| MCP27 | done | `project_ledger_v1` added first-class claim, blocked-claim, replication-pack and reviewer-note projections inside `project.ithz`, plus `ithz_can_i_claim` and write-enabled ledger tools. Windows native archive subprocesses now use `CREATE_NO_WINDOW`. |
| MCP28 Ubuntu MCP package | done | Dedicated Ubuntu/Linux package runner creates `dist/ithz-mcp-ubuntu.tar.gz` and `dist/ithz-mcp-ubuntu.deb` with Python stdio MCP runtime, Linux host installers, smoke scripts, a Linux `ithz-native` source build kit and extraction-backed archive fallback commands. A prebuilt Linux native binary and Linux Drive/FUSE provider are not bundled yet. |

Latest gates:

- `python -m unittest discover`: passed.
- `python -m ithz_mcp run-ci-fast`: passed.
- `python -m ithz_mcp run-ci-full`: passed.
- `python -m ithz_mcp run-mcp8-hardening`: passed.
- `python -m ithz_mcp run-mcp9f-native-ithz`: passed.
- `python -m ithz_mcp run-mcp10-markdown-minimal`: passed.
- `python -m ithz_mcp run-context-quality-regression`: passed.
- `python -m ithz_mcp run-mcp11-external-client`: passed.
- `python -m ithz_mcp run-mcp12-prompt-memory`: passed.
- `python -m ithz_mcp run-mcp13-host-compat`: passed.
- MCP13 nested-zone discovery/parent/sibling access smoke: passed.
- MCP13 cross-zone registry smoke: passed.
- `python -m ithz_mcp run-mcp22-auto-checkpoint`: passed, including surrogate Unicode checkpoint, compact MCP `tools/call` response smoke and async checkpoint worker smoke.
- `python -m ithz_mcp run-mcp23-install-project`: passed.
- Real Codex CLI intake smoke on `C:\work\afroplants.eu`: passed.
- `python -m ithz_mcp run-mcp16-git-merge-driver`: passed.
- `python -m ithz_mcp run-mcp17-append-index-snapshot`: passed.
- `python -m ithz_mcp run-mcp18-end-task-checkpoint`: passed.
- `python -m ithz_mcp run-mcp19-workflow-branches`: passed.
- `python -m ithz_mcp run-mcp20-agent-history-import`: passed.
- `python -m ithz_mcp run-mcp21-production-readiness`: passed.
- Native `--update-file` and `--update-files` smoke: passed.
- Manual smoke commands: passed.
- Product candidate package uses stable artifact name `ithz_mcp.zip`; build identity is carried by `VERSION.json` and `python -m ithz_mcp version`.
- `python -m ithz_mcp run-mcp25-macos-package`: passed.
- `python -m ithz_mcp run-mcp26-memory-synthesis`: passed.
- `python -m ithz_mcp run-mcp27-project-ledger`: passed.
- `python -m ithz_mcp run-mcp28-ubuntu-package`: passed.
No stage makes a Git-replacement, production-database, cloud-sync, vector-DB-dismissal or general token-saving claim.
