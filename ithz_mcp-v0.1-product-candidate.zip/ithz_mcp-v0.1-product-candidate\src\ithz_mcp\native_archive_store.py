from __future__ import annotations

import base64
import csv
import ctypes
from contextlib import contextmanager
from dataclasses import asdict, dataclass
import json
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from .bootstrap_contract import PROJECT_BOOTSTRAP
from .canonical_json import dump_pretty, dumps
from .context_index import search_index
from .events import git_status
from .hashing import sha256_file, stable_json_hash
from .prompt_memory import _summarize_text, redact_text, redaction_status
from .project_scan import scan_project
from .safety import ignore_reason, normalize_rel, redaction_block_reason
from .storage import read_json, write_json

ARCHIVE_NAME = "project.ithz"
BOOTSTRAP_NAME = "project.md"
ARCHIVE_SCHEMA = "ithz_mcp_native_archive_v1"
INDEX_MODE_FULL = "full"
INDEX_MODE_COMPACT = "compact-v2"
PF_AVX2_INSTRUCTIONS_AVAILABLE = 40
EVENT_LOG_PATH = "events/events.jsonl"
CONTEXT_COMMIT_INDEX_PATH = "context-commits/commit_index.json"
DECISION_LOG_PATH = "decisions/decision_log.jsonl"
PROMPT_LOG_PATH = "prompts/prompt_log.jsonl"
REF_HEAD_PATH = "refs/HEAD"
REF_MAIN_PATH = "refs/main"
REF_INDEX_PATH = "refs/ref_index.json"
BRANCH_MAIN_PATH = "branches/main.json"
CURRENT_INDEX_PATH = "indexes/current_index.json"
SEARCH_INDEX_PATH = "indexes/search_index.json"
GATE_INDEX_PATH = "indexes/gate_index.json"
RISK_INDEX_PATH = "indexes/risk_index.json"
PROMPT_SUMMARY_INDEX_PATH = "indexes/prompt_summary_index.json"
SNAPSHOT_INDEX_PATH = "snapshots/snapshot_index.json"
WORKFLOW_INDEX_PATH = "workflows/workflow_index.json"
WORKFLOW_PROMPT_LOG_PATH = "workflows/workflow_prompt_log.jsonl"

COMMON_TOKEN_STOPWORDS = {
    "the", "and", "for", "with", "from", "this", "that", "have", "will", "not", "are", "was", "were", "you", "your",
    "ako", "pre", "ale", "toto", "tento", "tieto", "som", "sme", "bude", "bolo", "nie", "tam", "este", "ktor", "ktore",
    "function", "return", "const", "class", "public", "private", "static", "array", "string", "null", "true", "false",
}


@dataclass(frozen=True)
class NativeSelection:
    path: str
    selected_build: str
    reason: str
    cpu_avx2_supported: bool
    explicit: bool = False


@dataclass(frozen=True)
class MemoryZone:
    requested_project: str
    active_root: str
    active_archive: str
    discovery_mode: str
    active_memory_zone: str
    explicit_zone_path: str | None
    parent_zones: list[str]
    child_zones: list[str]
    sibling_zones: list[str]
    child_zones_included_by_default: bool = False


def _repo_roots() -> list[Path]:
    here = Path(__file__).resolve()
    roots: list[Path] = []
    for idx in (2, 3):
        try:
            candidate = here.parents[idx]
        except IndexError:
            continue
        if candidate not in roots:
            roots.append(candidate)
    return roots


def cpu_supports_avx2() -> bool:
    override = os.environ.get("ITHZ_MCP_ASSUME_AVX2")
    if override is not None:
        return override.strip().lower() in {"1", "true", "yes", "on"}
    if os.name == "nt":
        try:
            return bool(ctypes.windll.kernel32.IsProcessorFeaturePresent(PF_AVX2_INSTRUCTIONS_AVAILABLE))
        except Exception:
            return False
    cpuinfo = Path("/proc/cpuinfo")
    if cpuinfo.exists():
        try:
            return " avx2 " in (" " + cpuinfo.read_text(encoding="utf-8", errors="ignore").lower() + " ")
        except OSError:
            return False
    return False


def _first_existing(paths: list[Path]) -> Path | None:
    for path in paths:
        if path.exists():
            return path.resolve()
    return None


def _selection_for_explicit(path: Path, reason: str) -> NativeSelection:
    if not path.exists():
        raise FileNotFoundError(f"ithz-native.exe not found at {path}")
    return NativeSelection(str(path.resolve()), "explicit", reason, cpu_supports_avx2(), True)


def select_native_ithz(explicit: str | None = None) -> NativeSelection:
    if explicit:
        return _selection_for_explicit(Path(explicit), "explicit_cli")
    env = os.environ.get("ITHZ_NATIVE_EXE")
    if env:
        return _selection_for_explicit(Path(env), "explicit_env_ITHZ_NATIVE_EXE")

    avx2_supported = cpu_supports_avx2()
    scalar_candidates: list[Path] = []
    avx2_candidates: list[Path] = []
    generic_candidates: list[Path] = []
    for root in _repo_roots():
        native_dir = root / "native"
        avx2_candidates.extend(
            [
                native_dir / "ithz-native-avx2.exe",
                root / "native_ithz" / "build_avx2" / "Release" / "ithz-native.exe",
                root / "dist" / "ithz-native-v0.1-alpha-rc1-win64-avx2" / "ithz-native.exe",
            ]
        )
        scalar_candidates.extend(
            [
                native_dir / "ithz-native-scalar.exe",
                root / "native_ithz" / "build_scalar" / "Release" / "ithz-native.exe",
                root / "dist" / "ithz-native-v0.1-alpha-rc1-win64-scalar" / "ithz-native.exe",
            ]
        )
        generic_candidates.append(native_dir / "ithz-native.exe")

    if avx2_supported:
        path = _first_existing(generic_candidates + avx2_candidates + scalar_candidates)
        if path:
            selected_build = "scalar" if "scalar" in str(path).lower() else "avx2"
            return NativeSelection(str(path), selected_build, "auto_avx2_supported", avx2_supported)
    else:
        path = _first_existing(scalar_candidates)
        if path:
            return NativeSelection(str(path), "scalar", "auto_scalar_cpu_no_avx2", avx2_supported)

    path = _first_existing(generic_candidates)
    if path and avx2_supported:
        return NativeSelection(str(path), "avx2", "auto_generic_avx2_supported", avx2_supported)
    raise FileNotFoundError("ithz-native.exe not found; set ITHZ_NATIVE_EXE or build native_ithz scalar/AVX2")


def locate_native_ithz(explicit: str | None = None) -> Path:
    return Path(select_native_ithz(explicit).path)


def project_archive_path(project: Path) -> Path:
    return project.resolve() / ARCHIVE_NAME


def _path_is_relative_to(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _zone_root_from_path(path: Path) -> Path:
    resolved = path.resolve()
    if resolved.name.lower() == ARCHIVE_NAME.lower():
        return resolved.parent
    return resolved


def _nearest_archive_root(project: Path) -> Path | None:
    cur = project.resolve()
    candidates = [cur, *cur.parents]
    for candidate in candidates:
        if (candidate / ARCHIVE_NAME).exists():
            return candidate
    return None


def _parent_zone_roots(active_root: Path) -> list[Path]:
    return [p for p in active_root.resolve().parents if (p / ARCHIVE_NAME).exists()]


def _sibling_zone_roots(active_root: Path) -> list[Path]:
    parent = active_root.resolve().parent
    if not parent.exists():
        return []
    roots = []
    for child in sorted((p for p in parent.iterdir() if p.is_dir()), key=lambda p: str(p).lower()):
        if child.resolve() == active_root.resolve():
            continue
        if (child / ARCHIVE_NAME).exists():
            roots.append(child.resolve())
    return roots


def _discover_child_zone_roots(project: Path) -> list[Path]:
    project = project.resolve()
    roots: list[Path] = []
    for archive in sorted(project.rglob(ARCHIVE_NAME), key=lambda p: normalize_rel(p.relative_to(project))):
        root = archive.parent.resolve()
        if root == project:
            continue
        try:
            rel = normalize_rel(root.relative_to(project))
        except ValueError:
            continue
        parts = {part.lower() for part in Path(rel).parts}
        if parts.intersection({".git", ".ithz-context", ".ithz_mcp", "node_modules", "vendor", "dist", "build", "__pycache__"}):
            continue
        roots.append(root)
    return roots


def _zone_path_list(paths: list[Path]) -> list[str]:
    return [str((p / ARCHIVE_NAME).resolve()) for p in paths]


def resolve_memory_zone(project: Path, memory_zone: str = "nearest", memory_zone_path: str | None = None) -> MemoryZone:
    requested = project.resolve()
    if memory_zone_path:
        active_root = _zone_root_from_path(Path(memory_zone_path))
        mode = "explicit_path"
        explicit = str(Path(memory_zone_path).resolve())
    elif memory_zone == "current":
        active_root = requested
        mode = "current_project"
        explicit = None
    elif memory_zone == "parent":
        nearest = _nearest_archive_root(requested)
        base = nearest or requested
        parents = _parent_zone_roots(base)
        if not parents:
            raise FileNotFoundError(f"no parent {ARCHIVE_NAME} found above {base}")
        active_root = parents[0]
        mode = "parent"
        explicit = None
    elif memory_zone == "nearest":
        active_root = _nearest_archive_root(requested) or requested
        mode = "nearest"
        explicit = None
    else:
        raise ValueError("memory_zone must be nearest, current, or parent")
    active_root = active_root.resolve()
    archive = active_root / ARCHIVE_NAME
    return MemoryZone(
        requested_project=str(requested),
        active_root=str(active_root),
        active_archive=str(archive),
        discovery_mode=mode,
        active_memory_zone=str(archive),
        explicit_zone_path=explicit,
        parent_zones=_zone_path_list(_parent_zone_roots(active_root)),
        child_zones=_zone_path_list(_discover_child_zone_roots(active_root)),
        sibling_zones=_zone_path_list(_sibling_zone_roots(active_root)),
    )


def project_bootstrap_path(project: Path) -> Path:
    return project.resolve() / BOOTSTRAP_NAME


def ensure_project_bootstrap(project: Path) -> dict[str, Any]:
    project = project.resolve()
    path = project_bootstrap_path(project)
    created = False
    if not path.exists():
        path.write_text(PROJECT_BOOTSTRAP, encoding="utf-8", newline="\n")
        created = True
    return {"path": str(path), "created": created}


def _include_source_file(rel: str, size: int) -> bool:
    if rel in {ARCHIVE_NAME}:
        return False
    if rel in {ARCHIVE_NAME + ".lock"}:
        return False
    if rel.startswith(".git/") or rel.startswith(".ithz-context/tmp/") or rel.startswith(".ithz_mcp/tmp/"):
        return False
    if rel.startswith("dist/") or rel.startswith("build/") or rel.startswith("__pycache__/"):
        return False
    if rel.endswith(".ithz") or rel.endswith(".exe") or rel.endswith(".pyc"):
        return False
    return ignore_reason(rel, size) is None


def _rel_under_child_zone(rel: str, child_rel_roots: list[str]) -> bool:
    return any(rel == root or rel.startswith(root + "/") for root in child_rel_roots)


def _filter_scan_child_zones(scan: dict[str, Any], child_roots: list[Path], project: Path) -> dict[str, Any]:
    if not child_roots:
        return scan
    child_rel_roots = [normalize_rel(root.relative_to(project)) for root in child_roots]
    kept = []
    ignored = list(scan.get("ignored", []))
    for entry in scan.get("files", []):
        rel = entry["path"]
        if _rel_under_child_zone(rel, child_rel_roots):
            ignored.append({"path": rel, "size": entry.get("size"), "ignored_reason": "nested_child_memory_zone"})
        else:
            kept.append(entry)
    semantic = [
        {k: f[k] for k in ("path", "size", "sha256", "extension", "family_guess", "text", "line_count")}
        for f in kept
    ]
    filtered = dict(scan)
    filtered["files"] = kept
    filtered["ignored"] = ignored
    filtered["scan_hash"] = stable_json_hash({"files": semantic})
    return filtered


def _scan_ignored_summary(ignored: list[dict[str, Any]]) -> dict[str, Any]:
    by_reason: dict[str, int] = {}
    total_bytes = 0
    for row in ignored:
        reason = str(row.get("ignored_reason", "unknown"))
        by_reason[reason] = by_reason.get(reason, 0) + 1
        try:
            total_bytes += int(row.get("size", 0) or 0)
        except (TypeError, ValueError):
            pass
    return {
        "ignored_count": len(ignored),
        "ignored_bytes": total_bytes,
        "ignored_by_reason": dict(sorted(by_reason.items())),
        "ignored_sample": sorted(
            (
                {"path": str(row.get("path", "")), "ignored_reason": str(row.get("ignored_reason", "unknown"))}
                for row in ignored
            ),
            key=lambda r: (r["ignored_reason"], r["path"]),
        )[:100],
    }


def compact_scan_for_archive(scan: dict[str, Any]) -> dict[str, Any]:
    files = [
        {k: f.get(k) for k in ("path", "size", "sha256", "extension", "family_guess", "text", "line_count")}
        for f in scan.get("files", [])
    ]
    return {
        "schema": "ithz_mcp_scan_v1_compact",
        "project": scan.get("project", ""),
        "files": files,
        "scan_hash": scan.get("scan_hash", ""),
        **_scan_ignored_summary(list(scan.get("ignored", []))),
    }


def scan_project_for_archive(project: Path, include_child_zones: bool = False) -> dict[str, Any]:
    project = project.resolve()
    scan = scan_project(project)
    kept = []
    ignored = list(scan.get("ignored", []))
    for entry in scan.get("files", []):
        if _include_source_file(entry["path"], int(entry.get("size", 0))):
            kept.append(entry)
        else:
            ignored.append({"path": entry["path"], "size": entry.get("size"), "ignored_reason": "native_archive_source_excluded"})
    semantic = [
        {k: f[k] for k in ("path", "size", "sha256", "extension", "family_guess", "text", "line_count")}
        for f in kept
    ]
    scan = dict(scan)
    scan["files"] = kept
    scan["ignored"] = ignored
    scan["scan_hash"] = stable_json_hash({"files": semantic})
    if include_child_zones:
        return scan
    return _filter_scan_child_zones(scan, _discover_child_zone_roots(project), project)


def _copy_source_snapshot(project: Path, dataset: Path, scan: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    source_root = dataset / "source"
    for entry in sorted(scan.get("files", []), key=lambda f: f["path"]):
        rel = entry["path"]
        path = project / rel
        if not path.exists() or not path.is_file():
            continue
        size = path.stat().st_size
        if not _include_source_file(rel, size):
            continue
        dst = source_root / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dst)
        rows.append({"path": rel, "size": size, "sha256": sha256_file(path)})
    return rows


def _write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
                handle.write(dumps(row) + "\n")


def _jsonl_bytes(rows: list[dict[str, Any]]) -> bytes:
    return "".join(dumps(row) + "\n" for row in rows).encode("utf-8")


def _text_bytes(value: str) -> bytes:
    return (value.rstrip("\n") + "\n").encode("utf-8")


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    rows: list[dict[str, Any]] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            rows.append(json.loads(line))
    return rows


def _read_project_prompt_rows(project: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for store_name in (".ithz-context", ".ithz_mcp"):
        conversations = project / store_name / "conversations"
        if not conversations.exists():
            continue
        for path in sorted(conversations.glob("pr_*.json")):
            value = read_json(path, {})
            if isinstance(value, dict) and value:
                rows.append(value)
    return rows


def _line_kind_weight(stripped: str, raw_line: str) -> tuple[str, int]:
    kind = "line"
    weight = 1
    if re.match(r"^#{1,6}\s+", stripped):
        kind, weight = "heading", 5
    elif re.search(r"\b(decision|rozhodnutie)\b", stripped, re.I):
        kind, weight = "decision", 6
    elif re.search(r"\b(gate|test|passed|failed|verify)\b", stripped, re.I):
        kind, weight = "gate", 4
    elif re.search(r"\b(todo|next|risk|limitation)\b", stripped, re.I):
        kind, weight = "risk_or_next", 3
    elif re.match(r"\s*(def|class|function|const|let|var|public|private)\b", raw_line):
        kind, weight = "symbol", 4
    return kind, weight


def _token_summary(text: str, limit: int = 60) -> str:
    counts: dict[str, int] = {}
    for token in re.findall(r"[A-Za-z0-9_][A-Za-z0-9_.:-]{2,}", text.lower()):
        if token in COMMON_TOKEN_STOPWORDS or token.isdigit():
            continue
        counts[token] = counts.get(token, 0) + 1
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:limit]
    return " ".join(token for token, _count in ranked)


def _event_semantic_key(event: dict[str, Any]) -> str:
    existing = event.get("semantic_event_hash")
    if isinstance(existing, str) and existing:
        return existing
    return stable_json_hash({k: v for k, v in event.items() if k not in {"event_id", "merged_from_event_id"}})


def _prompt_semantic_key(row: dict[str, Any]) -> str:
    existing = row.get("semantic_prompt_hash")
    if isinstance(existing, str) and existing:
        return existing
    return stable_json_hash({k: v for k, v in row.items() if k not in {"record_id", "prompt_id", "response_id"}})


def _derive_prompt_summary_index(prompt_rows: list[dict[str, Any]]) -> dict[str, Any]:
    units = []
    for idx, row in enumerate(prompt_rows, start=1):
        if row.get("local_only"):
            continue
        text = " ".join(
            str(row.get(k, ""))
            for k in ("task", "prompt_summary", "response_summary", "redaction_status")
            if row.get(k)
        )
        units.append(
            {
                "record_id": row.get("record_id"),
                "prompt_id": row.get("prompt_id"),
                "response_id": row.get("response_id"),
                "line": idx,
                "task": row.get("task", ""),
                "text": text[:1000],
                "semantic_prompt_hash": _prompt_semantic_key(row),
            }
        )
    doc = {"schema": "ithz_mcp_prompt_summary_index_v1", "units": units, "prompt_count": len(units)}
    doc["prompt_summary_index_hash"] = stable_json_hash({"units": units})
    return doc


def _derive_context_commits(events: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any], dict[str, Any], str]:
    commits: list[dict[str, Any]] = []
    parent: str | None = None
    for idx, event in enumerate(events, start=1):
        cid = f"ctx_{idx:06d}"
        commit = {
            "schema": "ithz_mcp_archive_context_commit_v1",
            "context_commit_id": cid,
            "parent": parent,
            "parents": [parent] if parent else [],
            "event_id": event.get("event_id"),
            "kind": event.get("kind", "event"),
            "source": event.get("source", ""),
            "tags": event.get("tags", []),
            "text": str(event.get("text", ""))[:1000],
            "git": event.get("git", {}),
            "semantic_event_hash": _event_semantic_key(event),
        }
        commit["semantic_context_hash"] = stable_json_hash({k: v for k, v in commit.items() if k != "context_commit_id"})
        commits.append(commit)
        parent = cid
    head = commits[-1]["context_commit_id"] if commits else ""
    commit_index = {
        "schema": "ithz_mcp_archive_context_commit_index_v1",
        "commit_count": len(commits),
        "head": head,
        "commits": [
            {
                "context_commit_id": c["context_commit_id"],
                "parent": c["parent"],
                "semantic_context_hash": c["semantic_context_hash"],
                "event_id": c.get("event_id"),
                "kind": c.get("kind"),
            }
            for c in commits
        ],
    }
    commit_index["commit_index_hash"] = stable_json_hash({"commits": commit_index["commits"], "head": head})
    ref_index = {
        "schema": "ithz_mcp_archive_refs_v1",
        "HEAD": head,
        "refs": {"main": head},
        "branches": {"main": head},
        "tags": {},
    }
    ref_index["refs_hash"] = stable_json_hash({"HEAD": head, "refs": ref_index["refs"], "branches": ref_index["branches"], "tags": ref_index["tags"]})
    return commits, commit_index, ref_index, head


def build_ephemeral_index(project: Path, include_child_zones: bool = False, scan: dict[str, Any] | None = None, index_mode: str = INDEX_MODE_COMPACT) -> dict[str, Any]:
    scan = scan or scan_project_for_archive(project, include_child_zones)
    compact = index_mode != INDEX_MODE_FULL
    units: list[dict[str, Any]] = []
    for f in scan["files"]:
        if not f["text"]:
            continue
        try:
            lines = (project / f["path"]).read_text(encoding="utf-8").splitlines()
        except UnicodeDecodeError:
            lines = (project / f["path"]).read_text(encoding="utf-8", errors="replace").splitlines()
        if compact:
            units.append(
                {
                    "path": f["path"],
                    "line": 0,
                    "kind": "file_summary",
                    "text": " ".join(
                        part
                        for part in (
                            f["path"],
                            str(f.get("extension", "")),
                            str(f.get("family_guess", "")),
                            _token_summary("\n".join(lines)),
                        )
                        if part
                    )[:1000],
                    "weight": 2,
                }
            )
            kept_for_file = 0
        for lineno, line in enumerate(lines, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            kind, weight = _line_kind_weight(stripped, line)
            if compact:
                if kind == "line":
                    continue
                kept_for_file += 1
                if kept_for_file > 120:
                    continue
            units.append({"path": f["path"], "line": lineno, "kind": kind, "text": stripped[:500], "weight": weight})
    index = {
        "schema": "ithz_mcp_index_v1",
        "index_mode": index_mode,
        "project": str(project.resolve()),
        "scan_hash": scan["scan_hash"],
        "files": [
            {k: f.get(k) for k in ("path", "size", "sha256", "extension", "family_guess", "text", "line_count")}
            for f in scan["files"]
        ],
        "ignored": [] if compact else scan["ignored"],
        "ignored_summary": _scan_ignored_summary(list(scan.get("ignored", []))) if compact else {},
        "units": units,
    }
    index["project_semantic_hash"] = stable_json_hash(
        {"scan_hash": scan["scan_hash"], "units": [{k: u[k] for k in ("path", "line", "kind", "text")} for u in units]}
    )
    index["index_hash"] = stable_json_hash(
        {
            "schema": index["schema"],
            "scan_hash": index["scan_hash"],
            "files": [{k: f[k] for k in ("path", "size", "sha256", "extension", "family_guess", "text", "line_count")} for f in scan["files"]],
            "units": index["units"],
            "project_semantic_hash": index["project_semantic_hash"],
        }
    )
    return index


def _prepare_dataset(project: Path, work: Path, include_child_zones: bool = False, index_mode: str = INDEX_MODE_COMPACT) -> dict[str, Any]:
    project = project.resolve()
    dataset = work / "dataset"
    dataset.mkdir(parents=True, exist_ok=True)
    bootstrap = ensure_project_bootstrap(project)
    scan = scan_project_for_archive(project, include_child_zones)
    source_rows = _copy_source_snapshot(project, dataset, scan)
    index = build_ephemeral_index(project, include_child_zones, scan, index_mode)
    prompt_rows = _read_project_prompt_rows(project)
    zone = resolve_memory_zone(project, "current")
    scan_to_store = compact_scan_for_archive(scan) if index_mode != INDEX_MODE_FULL else scan
    manifest = {
        "schema": ARCHIVE_SCHEMA,
        "project_root": str(project),
        "bootstrap_file": BOOTSTRAP_NAME,
        "archive_file": ARCHIVE_NAME,
        "index_mode": index_mode,
        "scan_storage_mode": "compact" if index_mode != INDEX_MODE_FULL else "full",
        "context_units_storage_mode": "compact" if index_mode != INDEX_MODE_FULL else "full",
        "source_file_count": len(source_rows),
        "source_bytes": sum(int(r["size"]) for r in source_rows),
        "scan_hash": scan["scan_hash"],
        "index_hash": index["index_hash"],
        "project_semantic_hash": index["project_semantic_hash"],
        "prompt_record_count": len(prompt_rows),
        "bootstrap": bootstrap,
        "active_memory_zone": zone.active_memory_zone,
        "child_zones": zone.child_zones,
        "child_zones_included": bool(include_child_zones),
        "memory_layers": {
            "events": EVENT_LOG_PATH,
            "context_commits": "context-commits/",
            "decisions": DECISION_LOG_PATH,
            "prompts": PROMPT_LOG_PATH,
            "refs": "refs/",
            "branches": "branches/",
            "indexes": "indexes/",
            "snapshots": "snapshots/",
            "workflows": "workflows/",
        },
    }
    manifest["archive_semantic_hash"] = stable_json_hash(
        {
            "schema": ARCHIVE_SCHEMA,
            "source": source_rows,
            "index_hash": index["index_hash"],
            "prompt_rows": [
                {k: r.get(k) for k in ("prompt_id", "response_id", "task", "mode", "semantic_prompt_hash", "semantic_response_hash")}
                for r in prompt_rows
            ],
        }
    )
    write_json(dataset / "manifest.json", manifest)
    write_json(dataset / "index.json", index)
    write_json(dataset / "scan.json", scan_to_store)
    _write_jsonl(dataset / "context_units.jsonl", index["units"])
    _write_jsonl(dataset / PROMPT_LOG_PATH, prompt_rows)
    for rel, data in _layer_update_bytes([], prompt_rows).items():
        target = dataset / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    (dataset / BOOTSTRAP_NAME).write_text(project_bootstrap_path(project).read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
    return manifest


def _run_native(args: list[str], native_exe: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run([str(native_exe), *args], text=True, capture_output=True, check=False)


def _run_native_bytes(args: list[str], native_exe: Path) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run([str(native_exe), *args], capture_output=True, check=False)


def _run_native_stdin(args: list[str], native_exe: Path, data: bytes) -> subprocess.CompletedProcess[bytes]:
    return subprocess.run([str(native_exe), *args], input=data, capture_output=True, check=False)


def _parse_native_kv(output: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for line in output.splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    return values


@contextmanager
def _archive_write_lock(archive: Path):
    lock = archive.with_name(archive.name + ".lock")
    lock.parent.mkdir(parents=True, exist_ok=True)
    fd: int | None = None
    try:
        fd = os.open(str(lock), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, f"archive={archive}\n".encode("utf-8"))
        os.close(fd)
        fd = None
        yield lock
    except FileExistsError as exc:
        raise RuntimeError(f"archive write lock exists: {lock}") from exc
    finally:
        if fd is not None:
            os.close(fd)
        try:
            lock.unlink()
        except FileNotFoundError:
            pass


def native_version_info(native_exe: Path) -> dict[str, Any]:
    result = _run_native(["--version"], native_exe)
    if result.returncode != 0:
        return {"version_ok": False, "error": result.stderr.strip() or result.stdout.strip()}
    values = _parse_native_kv(result.stdout)
    return {
        "version_ok": True,
        "ithz_native_version": values.get("ithz_native_version"),
        "build_profile": values.get("build_profile"),
        "avx2_build": values.get("avx2_build"),
        "manifest_support_versions": values.get("manifest_support_versions"),
    }


def build_native_archive(project: Path, native_exe: str | None = None, verify: str = "safe", include_child_zones: bool = False, index_mode: str = INDEX_MODE_COMPACT) -> dict[str, Any]:
    project = project.resolve()
    if index_mode not in {INDEX_MODE_FULL, INDEX_MODE_COMPACT}:
        raise ValueError("unsupported_index_mode")
    exe = locate_native_ithz(native_exe)
    archive = project_archive_path(project)
    with _archive_write_lock(archive):
        with tempfile.TemporaryDirectory(prefix="ithz_mcp_archive_") as tmp:
            work = Path(tmp)
            manifest = _prepare_dataset(project, work, include_child_zones, index_mode)
            result = _run_native(["--pack-folder", str(work / "dataset"), "--archive", str(archive), "--verify=" + verify], exe)
            if result.returncode != 0:
                raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "ithz-native pack failed")
    verify_result = _run_native(["--verify", str(archive), "--verify=safe"], exe)
    if verify_result.returncode != 0:
        raise RuntimeError(verify_result.stderr.strip() or verify_result.stdout.strip() or "ithz-native verify failed")
    return {
        "archive": str(archive),
        "archive_bytes": archive.stat().st_size,
        "archive_sha256": sha256_file(archive),
        "native_exe": str(exe),
        "verified_safe": True,
        "active_memory_zone": str(archive.resolve()),
        "child_zones_included": bool(include_child_zones),
        **manifest,
    }


def extract_native_archive(project: Path, native_exe: str | None = None) -> tuple[Path, tempfile.TemporaryDirectory[str]]:
    project = project.resolve()
    archive = project_archive_path(project)
    if not archive.exists():
        raise FileNotFoundError(f"{archive} does not exist; run init-native-archive-memory first")
    exe = locate_native_ithz(native_exe)
    tmp = tempfile.TemporaryDirectory(prefix="ithz_mcp_read_")
    out = Path(tmp.name) / "extract"
    result = _run_native(["--extract", str(archive), "--output", str(out)], exe)
    if result.returncode != 0:
        tmp.cleanup()
        raise RuntimeError(result.stderr.strip() or result.stdout.strip() or "ithz-native extract failed")
    return out, tmp


def extract_archive_file_bytes(project: Path, archive_inner_path: str, native_exe: str | None = None) -> bytes:
    project = project.resolve()
    archive = project_archive_path(project)
    if not archive.exists():
        raise FileNotFoundError(f"{archive} does not exist; run init-native-archive-memory first")
    exe = locate_native_ithz(native_exe)
    result = _run_native_bytes(["--extract-file", str(archive), "--path", archive_inner_path, "--output", "-"], exe)
    if result.returncode != 0:
        detail = result.stderr.decode("utf-8", errors="replace") or result.stdout.decode("utf-8", errors="replace")
        raise RuntimeError(detail.strip() or f"ithz-native extract-file stdout failed for {archive_inner_path}")
    return result.stdout


def update_archive_file_bytes(project: Path, archive_inner_path: str, data: bytes, native_exe: str | None = None, verify: str = "safe", expected_archive_sha256: str | None = None) -> dict[str, Any]:
    project = project.resolve()
    archive = project_archive_path(project)
    if not archive.exists():
        raise FileNotFoundError(f"{archive} does not exist; run init-native-archive-memory first")
    exe = locate_native_ithz(native_exe)
    with _archive_write_lock(archive):
        archive_sha256_before = sha256_file(archive)
        if expected_archive_sha256 is not None and archive_sha256_before != expected_archive_sha256:
            raise RuntimeError("archive hash precondition failed")
        result = _run_native_stdin(
            ["--update-file", str(archive), "--path", archive_inner_path, "--input", "-", "--verify=" + verify],
            exe,
            data,
        )
    stdout = result.stdout.decode("utf-8", errors="replace")
    stderr = result.stderr.decode("utf-8", errors="replace")
    if result.returncode != 0:
        raise RuntimeError(stderr.strip() or stdout.strip() or f"ithz-native update-file failed for {archive_inner_path}")
    values = _parse_native_kv(stdout)
    return {
        "path": archive_inner_path,
        "input_bytes": len(data),
        "archive_sha256_before": archive_sha256_before,
        "archive_sha256_after": sha256_file(archive),
        "lock_acquired": True,
        "precondition_checked": expected_archive_sha256 is not None,
        "input_sha256": values.get("input_sha256"),
        "semantic_plan_hash": values.get("semantic_plan_hash"),
        "container_bytes_hash": values.get("container_bytes_hash"),
        "archive_bytes": int(values.get("archive_bytes", "0") or "0"),
        "verify_mode": values.get("verify_mode"),
        "update_mode": values.get("update_mode"),
        "raw_stdout": stdout,
    }


def update_archive_files_bytes(project: Path, updates: dict[str, bytes], native_exe: str | None = None, verify: str = "safe", expected_archive_sha256: str | None = None) -> dict[str, Any]:
    project = project.resolve()
    archive = project_archive_path(project)
    if not archive.exists():
        raise FileNotFoundError(f"{archive} does not exist; run init-native-archive-memory first")
    exe = locate_native_ithz(native_exe)
    payload = {
        "updates": [
            {"path": path, "data_base64": base64.b64encode(data).decode("ascii")}
            for path, data in sorted(updates.items())
        ]
    }
    with _archive_write_lock(archive):
        archive_sha256_before = sha256_file(archive)
        if expected_archive_sha256 is not None and archive_sha256_before != expected_archive_sha256:
            raise RuntimeError("archive hash precondition failed")
        result = _run_native_stdin(
            ["--update-files", str(archive), "--input", "-", "--verify=" + verify],
            exe,
            dump_pretty(payload).encode("utf-8"),
        )
    stdout = result.stdout.decode("utf-8", errors="replace")
    stderr = result.stderr.decode("utf-8", errors="replace")
    if result.returncode != 0:
        raise RuntimeError(stderr.strip() or stdout.strip() or "ithz-native update-files failed")
    values = _parse_native_kv(stdout)
    return {
        "paths": sorted(updates),
        "update_count": int(values.get("update_count", "0") or "0"),
        "replaced_existing_count": int(values.get("replaced_existing_count", "0") or "0"),
        "input_bytes": sum(len(data) for data in updates.values()),
        "archive_sha256_before": archive_sha256_before,
        "archive_sha256_after": sha256_file(archive),
        "lock_acquired": True,
        "precondition_checked": expected_archive_sha256 is not None,
        "semantic_plan_hash": values.get("semantic_plan_hash"),
        "container_bytes_hash": values.get("container_bytes_hash"),
        "archive_bytes": int(values.get("archive_bytes", "0") or "0"),
        "verify_mode": values.get("verify_mode"),
        "update_mode": values.get("update_mode"),
        "raw_stdout": stdout,
    }


def _load_archive_json_optional(project: Path, archive_inner_path: str, default: Any, native_exe: str | None = None) -> Any:
    try:
        return _load_archive_json(project, archive_inner_path, native_exe)
    except RuntimeError as exc:
        if "path not found" in str(exc):
            return default
        raise


def _load_archive_jsonl_optional(project: Path, archive_inner_path: str, native_exe: str | None = None) -> list[dict[str, Any]]:
    try:
        data = extract_archive_file_bytes(project, archive_inner_path, native_exe)
    except RuntimeError as exc:
        if "path not found" in str(exc):
            return []
        raise
    return [json.loads(line) for line in data.decode("utf-8-sig").splitlines() if line.strip()]


def _relationship_between(active_root: Path, target_root: Path) -> str:
    active = active_root.resolve()
    target = target_root.resolve()
    if active == target:
        return "self"
    if target in active.parents:
        return "parent"
    if active in target.parents:
        return "child"
    if active.parent == target.parent:
        return "sibling"
    return "external"


def _linked_zones_document(project: Path, native_exe: str | None = None) -> dict[str, Any]:
    zone = resolve_memory_zone(project, "current")
    default = {
        "schema": "ithz_mcp_linked_zones_v1",
        "owner_active_memory_zone": zone.active_memory_zone,
        "zones": [],
    }
    doc = _load_archive_json_optional(project, "zones/linked_zones.json", default, native_exe)
    if not isinstance(doc, dict):
        return default
    doc.setdefault("schema", "ithz_mcp_linked_zones_v1")
    doc.setdefault("owner_active_memory_zone", zone.active_memory_zone)
    doc.setdefault("zones", [])
    return doc


def archive_link_zone(
    project: Path,
    name: str,
    target_path: Path,
    native_exe: str | None = None,
    memory_zone: str = "nearest",
    memory_zone_path: str | None = None,
    relationship: str = "auto",
) -> dict[str, Any]:
    active_zone = resolve_memory_zone(project, memory_zone, memory_zone_path)
    active_root = Path(active_zone.active_root)
    if not project_archive_path(active_root).exists():
        build_native_archive(active_root, native_exe)
    target_root = _zone_root_from_path(target_path)
    target_archive = project_archive_path(target_root)
    if not target_archive.exists():
        raise FileNotFoundError(f"target memory zone archive does not exist: {target_archive}")
    rel = _relationship_between(active_root, target_root) if relationship == "auto" else relationship
    exe = locate_native_ithz(native_exe)
    current_hash = sha256_file(project_archive_path(active_root))
    doc = _linked_zones_document(active_root, str(exe))
    zones = [z for z in doc.get("zones", []) if z.get("name") != name]
    target_status = native_archive_status(target_root, str(exe), "current")
    entry = {
        "name": name,
        "root": str(target_root.resolve()),
        "archive": str(target_archive.resolve()),
        "relationship": rel,
        "read_allowed": True,
        "write_requires_explicit_target": True,
        "archive_exists": True,
        "archive_sha256": target_status.get("archive_sha256"),
        "archive_semantic_hash": target_status.get("archive_semantic_hash"),
    }
    zones.append(entry)
    zones.sort(key=lambda z: z["name"])
    doc["zones"] = zones
    doc["linked_zone_hash"] = stable_json_hash({"zones": zones})
    update = update_archive_files_bytes(
        active_root,
        {"zones/linked_zones.json": dump_pretty(doc).encode("utf-8")},
        str(exe),
        "safe",
        current_hash,
    )
    return {"linked": True, "active_memory_zone": active_zone.active_memory_zone, "zone": entry, "linked_zone_hash": doc["linked_zone_hash"], "update": update}


def archive_zone_status(project: Path, native_exe: str | None = None, memory_zone: str = "nearest", memory_zone_path: str | None = None) -> dict[str, Any]:
    status = native_archive_status(project, native_exe, memory_zone, memory_zone_path)
    if not status.get("exists"):
        status["linked_zones"] = []
        status["cross_zone_event_count"] = 0
        return status
    active_root = Path(status["project"])
    exe = locate_native_ithz(native_exe)
    linked = _linked_zones_document(active_root, str(exe))
    events = _load_archive_jsonl_optional(active_root, "zones/cross_zone_events.jsonl", str(exe))
    status["linked_zones"] = linked.get("zones", [])
    status["linked_zone_hash"] = linked.get("linked_zone_hash")
    status["cross_zone_event_count"] = len(events)
    return status


def archive_cross_zone_context_pack(
    project: Path,
    query: str,
    max_bytes: int = 20000,
    native_exe: str | None = None,
    memory_zone: str = "nearest",
    memory_zone_path: str | None = None,
    include_active: bool = True,
) -> dict[str, Any]:
    status = archive_zone_status(project, native_exe, memory_zone, memory_zone_path)
    active_root = Path(status["project"])
    exe = locate_native_ithz(native_exe)
    zone_entries: list[dict[str, Any]] = []
    if include_active:
        zone_entries.append({"name": "active", "root": str(active_root), "archive": status["active_memory_zone"], "relationship": "self"})
    for zone in status.get("linked_zones", []):
        if zone.get("read_allowed", True):
            zone_entries.append(zone)
    lines = [
        "# ITHZ Cross-Zone Context Pack",
        "",
        f"- query: {query}",
        f"- active_memory_zone: {status.get('active_memory_zone')}",
        f"- zone_count: {len(zone_entries)}",
        "",
    ]
    all_rows: list[dict[str, Any]] = []
    for zone in zone_entries:
        root = Path(zone["root"])
        try:
            result = native_archive_search(root, query, 10, str(exe), "current")
            rows = result["rows"]
            zone_hash = result.get("archive_semantic_hash")
            zone_error = None
        except Exception as exc:
            rows = []
            zone_hash = None
            zone_error = str(exc)
        lines.append(f"## Zone: {zone.get('name')}")
        lines.append(f"- relationship: {zone.get('relationship')}")
        lines.append(f"- archive: {zone.get('archive')}")
        if zone_hash:
            lines.append(f"- archive_semantic_hash: {zone_hash}")
        if zone_error:
            lines.append(f"- error: {zone_error}")
        if not rows:
            lines.append("- no matching evidence")
        for row in rows:
            all_rows.append({"zone": zone.get("name"), **row})
            lines.append(f"- `{row['path']}:{row['line']}` [{row['kind']}] score={row.get('score')} reason={row.get('why_selected')}: {row['text']}")
        lines.append("")
    text = "\n".join(lines)
    if len(text.encode("utf-8")) > max_bytes:
        text = text.encode("utf-8")[:max_bytes].decode("utf-8", errors="ignore") + "\n\n[truncated deterministically]\n"
    return {
        "text": text,
        "bytes": len(text.encode("utf-8")),
        "query": query,
        "active_memory_zone": status.get("active_memory_zone"),
        "zones": zone_entries,
        "rows": all_rows,
        "context_pack_hash": stable_json_hash({"query": query, "text": text, "active_memory_zone": status.get("active_memory_zone")}),
    }


def archive_record_cross_zone_event(
    project: Path,
    target_zone: str,
    event: str,
    native_exe: str | None = None,
    memory_zone: str = "nearest",
    memory_zone_path: str | None = None,
) -> dict[str, Any]:
    active_zone = resolve_memory_zone(project, memory_zone, memory_zone_path)
    active_root = Path(active_zone.active_root)
    if not project_archive_path(active_root).exists():
        build_native_archive(active_root, native_exe)
    exe = locate_native_ithz(native_exe)
    current_hash = sha256_file(project_archive_path(active_root))
    linked = _linked_zones_document(active_root, str(exe))
    target = next((z for z in linked.get("zones", []) if z.get("name") == target_zone), None)
    rows = _load_archive_jsonl_optional(active_root, "zones/cross_zone_events.jsonl", str(exe))
    event_id = f"xz_{len(rows) + 1:06d}"
    record = {
        "schema": "ithz_mcp_cross_zone_event_v1",
        "event_id": event_id,
        "active_memory_zone": active_zone.active_memory_zone,
        "target_zone": target_zone,
        "target_archive": target.get("archive") if target else None,
        "relationship": target.get("relationship") if target else "unlinked",
        "event": event,
        "semantic_event_hash": stable_json_hash({"target_zone": target_zone, "event": event, "target_archive": target.get("archive") if target else None}),
    }
    rows.append(record)
    update = update_archive_files_bytes(
        active_root,
        {"zones/cross_zone_events.jsonl": _jsonl_bytes(rows)},
        str(exe),
        "safe",
        current_hash,
    )
    return {"recorded": True, "active_memory_zone": active_zone.active_memory_zone, "record": record, "update": update}


def _memory_events(project: Path, native_exe: str | None = None) -> list[dict[str, Any]]:
    return _load_archive_jsonl_optional(project, EVENT_LOG_PATH, native_exe)


def _snapshot_index(project: Path, native_exe: str | None = None) -> dict[str, Any]:
    default = {"schema": "ithz_mcp_snapshot_index_v1", "snapshots": []}
    doc = _load_archive_json_optional(project, SNAPSHOT_INDEX_PATH, default, native_exe)
    if not isinstance(doc, dict):
        return default
    doc.setdefault("schema", "ithz_mcp_snapshot_index_v1")
    doc.setdefault("snapshots", [])
    return doc


def _derive_current_index(events: list[dict[str, Any]]) -> dict[str, Any]:
    normalized = []
    counts_by_kind: dict[str, int] = {}
    latest_by_kind: dict[str, str] = {}
    searchable_units = []
    for event in sorted(events, key=lambda e: e.get("event_id", "")):
        event_id = str(event.get("event_id", ""))
        kind = str(event.get("kind", "event"))
        text = str(event.get("text", ""))
        git = event.get("git") if isinstance(event.get("git"), dict) else {}
        git_text = " ".join(str(git.get(k, "")) for k in ("git_branch", "git_commit_short_hash", "git_commit_subject", "git_commit_ref_names"))
        source = str(event.get("source", ""))
        tags = [str(t) for t in event.get("tags", [])]
        semantic_hash = str(event.get("semantic_event_hash", ""))
        normalized.append(
            {
                "event_id": event_id,
                "kind": kind,
                "source": source,
                "tags": tags,
                "text": text,
                "git": {k: git.get(k) for k in ("available", "git_branch", "git_commit_hash", "git_commit_short_hash", "git_commit_subject", "git_commit_ref_names") if k in git},
                "semantic_event_hash": semantic_hash,
            }
        )
        counts_by_kind[kind] = counts_by_kind.get(kind, 0) + 1
        latest_by_kind[kind] = event_id
        searchable_units.append(
            {
                "event_id": event_id,
                "kind": kind,
                "source": source,
                "tags": tags,
                "text": text[:1000],
                "git": {k: git.get(k) for k in ("git_branch", "git_commit_short_hash", "git_commit_subject") if k in git},
                "git_text": git_text[:500],
                "weight": {"decision": 6, "workflow_rule": 6, "gate": 5, "risk": 5, "must_not_break": 6, "next": 4}.get(kind, 3),
            }
        )
    index = {
        "schema": "ithz_mcp_current_index_v1",
        "event_count": len(normalized),
        "counts_by_kind": dict(sorted(counts_by_kind.items())),
        "latest_by_kind": dict(sorted(latest_by_kind.items())),
        "searchable_units": searchable_units,
    }
    index["current_index_hash"] = stable_json_hash({"events": normalized, "schema": index["schema"]})
    return index


def _derive_layered_indexes(events: list[dict[str, Any]], prompt_rows: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    prompt_rows = prompt_rows or []
    current = _derive_current_index(events)
    search_units = list(current.get("searchable_units", []))
    search_index = {"schema": "ithz_mcp_search_index_v1", "units": search_units}
    search_index["search_index_hash"] = stable_json_hash({"units": search_units})
    gate_units = [unit for unit in search_units if unit.get("kind") == "gate"]
    gate_index = {"schema": "ithz_mcp_gate_index_v1", "units": gate_units, "gate_count": len(gate_units)}
    gate_index["gate_index_hash"] = stable_json_hash({"units": gate_units})
    risk_units = [unit for unit in search_units if unit.get("kind") in {"risk", "must_not_break"}]
    risk_index = {"schema": "ithz_mcp_risk_index_v1", "units": risk_units, "risk_count": len(risk_units)}
    risk_index["risk_index_hash"] = stable_json_hash({"units": risk_units})
    prompt_index = _derive_prompt_summary_index(prompt_rows)
    decisions = [
        {
            "schema": "ithz_mcp_decision_record_v1",
            "event_id": event.get("event_id"),
            "decision": event.get("text", ""),
            "source": event.get("source", ""),
            "tags": event.get("tags", []),
            "semantic_event_hash": _event_semantic_key(event),
        }
        for event in events
        if event.get("kind") == "decision"
    ]
    commits, commit_index, ref_index, head = _derive_context_commits(events)
    branch_main = {"schema": "ithz_mcp_archive_branch_v1", "name": "main", "head": head}
    return {
        "current_index": current,
        "search_index": search_index,
        "gate_index": gate_index,
        "risk_index": risk_index,
        "prompt_summary_index": prompt_index,
        "decisions": decisions,
        "context_commits": commits,
        "commit_index": commit_index,
        "ref_index": ref_index,
        "branch_main": branch_main,
        "head": head,
    }


def _layer_update_bytes(events: list[dict[str, Any]], prompt_rows: list[dict[str, Any]] | None = None) -> dict[str, bytes]:
    layers = _derive_layered_indexes(events, prompt_rows)
    updates: dict[str, bytes] = {
        EVENT_LOG_PATH: _jsonl_bytes(events),
        DECISION_LOG_PATH: _jsonl_bytes(layers["decisions"]),
        CONTEXT_COMMIT_INDEX_PATH: dump_pretty(layers["commit_index"]).encode("utf-8"),
        REF_HEAD_PATH: _text_bytes(layers["head"]),
        REF_MAIN_PATH: _text_bytes(layers["head"]),
        REF_INDEX_PATH: dump_pretty(layers["ref_index"]).encode("utf-8"),
        BRANCH_MAIN_PATH: dump_pretty(layers["branch_main"]).encode("utf-8"),
        CURRENT_INDEX_PATH: dump_pretty(layers["current_index"]).encode("utf-8"),
        SEARCH_INDEX_PATH: dump_pretty(layers["search_index"]).encode("utf-8"),
        GATE_INDEX_PATH: dump_pretty(layers["gate_index"]).encode("utf-8"),
        RISK_INDEX_PATH: dump_pretty(layers["risk_index"]).encode("utf-8"),
        PROMPT_SUMMARY_INDEX_PATH: dump_pretty(layers["prompt_summary_index"]).encode("utf-8"),
    }
    for commit in layers["context_commits"]:
        updates[f"context-commits/{commit['context_commit_id']}.json"] = dump_pretty(commit).encode("utf-8")
    return updates


def _archive_safe_git_metadata(git: dict[str, Any]) -> dict[str, Any]:
    allowed = (
        "available",
        "git_branch",
        "git_commit_hash",
        "git_commit_short_hash",
        "git_commit_subject",
        "git_commit_subject_hash",
        "git_commit_ref_names",
        "git_status_porcelain_hash",
    )
    return {key: git.get(key) for key in allowed if key in git}


def _validate_append_only_events(events: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    seen: dict[str, str] = {}
    for event in events:
        event_id = event.get("event_id")
        if not isinstance(event_id, str) or not event_id:
            errors.append("missing_event_id")
            continue
        semantic_hash = event.get("semantic_event_hash")
        if event_id in seen and seen[event_id] != semantic_hash:
            errors.append(f"duplicate_event_id_conflict:{event_id}")
        seen[event_id] = str(semantic_hash)
        if redaction_block_reason(json.dumps(event, sort_keys=True)):
            errors.append(f"secret_like_event_payload:{event_id}")
    return errors


def archive_append_event(
    project: Path,
    kind: str,
    text: str,
    source: str = "manual",
    tags: list[str] | None = None,
    native_exe: str | None = None,
    memory_zone: str = "nearest",
    memory_zone_path: str | None = None,
    include_git: bool = False,
) -> dict[str, Any]:
    result = archive_append_events(
        project,
        [{"kind": kind, "text": text, "source": source, "tags": sorted(tags or [])}],
        native_exe,
        memory_zone,
        memory_zone_path,
        include_git,
    )
    return {
        "appended": True,
        "active_memory_zone": result["active_memory_zone"],
        "event": result["events"][-1],
        "event_count": result["event_count"],
        "current_index_hash": result["current_index_hash"],
        "update": result["update"],
    }


def archive_append_events(
    project: Path,
    event_specs: list[dict[str, Any]],
    native_exe: str | None = None,
    memory_zone: str = "nearest",
    memory_zone_path: str | None = None,
    include_git: bool = False,
    extra_updates: dict[str, bytes] | None = None,
    manifest_extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not event_specs:
        raise ValueError("at_least_one_event_required")
    active_zone = resolve_memory_zone(project, memory_zone, memory_zone_path)
    active_root = Path(active_zone.active_root)
    if not project_archive_path(active_root).exists():
        build_native_archive(active_root, native_exe)
    exe = locate_native_ithz(native_exe)
    current_hash = sha256_file(project_archive_path(active_root))
    events = _memory_events(active_root, str(exe))
    before_errors = _validate_append_only_events(events)
    if before_errors:
        raise ValueError("append_only_event_log_invalid:" + ",".join(before_errors))
    git = _archive_safe_git_metadata(git_status(active_root)) if include_git else None
    appended: list[dict[str, Any]] = []
    for spec in event_specs:
        kind = str(spec.get("kind", "note"))
        text = str(spec.get("text", ""))
        source = str(spec.get("source", "manual"))
        tags = sorted(str(t) for t in spec.get("tags", []) if str(t))
        if not text.strip():
            raise ValueError("event text is required")
        if redaction_block_reason(text):
            raise ValueError("secret_like_event_text_blocked")
        event_id = f"evt_{len(events) + 1:06d}"
        event = {
            "schema": "ithz_mcp_memory_event_v1",
            "event_id": event_id,
            "kind": kind,
            "source": source,
            "tags": tags,
            "text": text,
            "supersedes": spec.get("supersedes"),
        }
        metadata = spec.get("metadata")
        if isinstance(metadata, dict) and metadata:
            event["metadata"] = metadata
        if git is not None:
            event["git"] = git
        event["semantic_event_hash"] = stable_json_hash(
            {
                "kind": kind,
                "source": source,
                "tags": tags,
                "text": text,
                "metadata": metadata if isinstance(metadata, dict) else None,
                "git": {
                    k: git.get(k) for k in ("available", "git_branch", "git_commit_hash", "git_commit_subject")
                } if isinstance(git, dict) else None,
            }
        )
        events.append(event)
        appended.append(event)
    prompt_rows = _load_archive_jsonl_optional(active_root, PROMPT_LOG_PATH, str(exe))
    index = _derive_current_index(events)
    manifest = _load_archive_json(active_root, "manifest.json", str(exe))
    manifest["memory_event_count"] = len(events)
    manifest["current_index_hash"] = index["current_index_hash"]
    manifest["memory_layers"] = {
        "events": EVENT_LOG_PATH,
        "context_commits": "context-commits/",
        "decisions": DECISION_LOG_PATH,
        "prompts": PROMPT_LOG_PATH,
        "refs": "refs/",
        "branches": "branches/",
        "indexes": "indexes/",
        "snapshots": "snapshots/",
        "workflows": "workflows/",
        "instructions": "instructions/",
    }
    if manifest_extra:
        manifest.update(manifest_extra)
    extra_updates_hash = (
        stable_json_hash({path: base64.b64encode(data).decode("ascii") for path, data in sorted(extra_updates.items())})
        if extra_updates
        else None
    )
    manifest["archive_semantic_hash"] = stable_json_hash(
        {
            "previous": manifest.get("archive_semantic_hash"),
            "memory_event_count": len(events),
            "current_index_hash": index["current_index_hash"],
            "extra_updates_hash": extra_updates_hash,
            "manifest_extra": manifest_extra or {},
        }
    )
    updates = _layer_update_bytes(events, prompt_rows)
    if extra_updates:
        updates.update(extra_updates)
    updates["manifest.json"] = dump_pretty(manifest).encode("utf-8")
    update = update_archive_files_bytes(
        active_root,
        updates,
        str(exe),
        "safe",
        current_hash,
    )
    return {
        "appended": True,
        "active_memory_zone": active_zone.active_memory_zone,
        "events": appended,
        "appended_count": len(appended),
        "event_count": len(events),
        "current_index_hash": index["current_index_hash"],
        "update": update,
    }


def archive_memory_index_status(project: Path, native_exe: str | None = None, memory_zone: str = "nearest", memory_zone_path: str | None = None) -> dict[str, Any]:
    status = archive_zone_status(project, native_exe, memory_zone, memory_zone_path)
    if not status.get("exists"):
        return {**status, "event_count": 0, "index_valid": False, "snapshot_count": 0}
    active_root = Path(status["project"])
    exe = locate_native_ithz(native_exe)
    events = _memory_events(active_root, str(exe))
    derived = _derive_current_index(events)
    stored = _load_archive_json_optional(active_root, CURRENT_INDEX_PATH, {}, str(exe))
    snapshots = _snapshot_index(active_root, str(exe)).get("snapshots", [])
    errors = _validate_append_only_events(events)
    return {
        **status,
        "event_count": len(events),
        "counts_by_kind": derived["counts_by_kind"],
        "latest_by_kind": derived["latest_by_kind"],
        "derived_current_index_hash": derived["current_index_hash"],
        "stored_current_index_hash": stored.get("current_index_hash") if isinstance(stored, dict) else None,
        "index_valid": isinstance(stored, dict) and stored.get("current_index_hash") == derived["current_index_hash"],
        "append_only_valid": not errors,
        "append_only_errors": errors,
        "snapshot_count": len(snapshots),
        "latest_snapshot": snapshots[-1] if snapshots else None,
    }


def archive_rebuild_derived_indexes(project: Path, native_exe: str | None = None, memory_zone: str = "nearest", memory_zone_path: str | None = None) -> dict[str, Any]:
    active_zone = resolve_memory_zone(project, memory_zone, memory_zone_path)
    active_root = Path(active_zone.active_root)
    if not project_archive_path(active_root).exists():
        raise FileNotFoundError(f"{project_archive_path(active_root)} does not exist")
    exe = locate_native_ithz(native_exe)
    current_hash = sha256_file(project_archive_path(active_root))
    events = _memory_events(active_root, str(exe))
    errors = _validate_append_only_events(events)
    if errors:
        raise ValueError("append_only_event_log_invalid:" + ",".join(errors))
    prompt_rows = _load_archive_jsonl_optional(active_root, PROMPT_LOG_PATH, str(exe))
    layers = _derive_layered_indexes(events, prompt_rows)
    index = layers["current_index"]
    manifest = _load_archive_json(active_root, "manifest.json", str(exe))
    manifest["memory_event_count"] = len(events)
    manifest["current_index_hash"] = index["current_index_hash"]
    updates = _layer_update_bytes(events, prompt_rows)
    updates["manifest.json"] = dump_pretty(manifest).encode("utf-8")
    update = update_archive_files_bytes(
        active_root,
        updates,
        str(exe),
        "safe",
        current_hash,
    )
    return {"rebuilt": True, "active_memory_zone": active_zone.active_memory_zone, "event_count": len(events), "current_index_hash": index["current_index_hash"], "update": update}


def archive_create_snapshot(project: Path, label: str = "manual", native_exe: str | None = None, memory_zone: str = "nearest", memory_zone_path: str | None = None) -> dict[str, Any]:
    active_zone = resolve_memory_zone(project, memory_zone, memory_zone_path)
    active_root = Path(active_zone.active_root)
    if not project_archive_path(active_root).exists():
        raise FileNotFoundError(f"{project_archive_path(active_root)} does not exist")
    exe = locate_native_ithz(native_exe)
    current_hash = sha256_file(project_archive_path(active_root))
    events = _memory_events(active_root, str(exe))
    prompt_rows = _load_archive_jsonl_optional(active_root, PROMPT_LOG_PATH, str(exe))
    index = _derive_current_index(events)
    snapshot_index = _snapshot_index(active_root, str(exe))
    snapshot_id = f"snapshot_{len(snapshot_index.get('snapshots', [])) + 1:06d}"
    snapshot = {
        "schema": "ithz_mcp_memory_snapshot_v1",
        "snapshot_id": snapshot_id,
        "label": label,
        "event_count": len(events),
        "current_index_hash": index["current_index_hash"],
        "counts_by_kind": index["counts_by_kind"],
        "latest_by_kind": index["latest_by_kind"],
        "snapshot_hash": stable_json_hash({"event_count": len(events), "current_index_hash": index["current_index_hash"], "label": label}),
    }
    snapshots = list(snapshot_index.get("snapshots", []))
    snapshots.append({k: snapshot[k] for k in ("snapshot_id", "label", "event_count", "current_index_hash", "snapshot_hash")})
    snapshot_index["snapshots"] = snapshots
    snapshot_index["snapshot_index_hash"] = stable_json_hash({"snapshots": snapshots})
    manifest = _load_archive_json(active_root, "manifest.json", str(exe))
    manifest["snapshot_count"] = len(snapshots)
    manifest["latest_snapshot_id"] = snapshot_id
    manifest["current_index_hash"] = index["current_index_hash"]
    updates = _layer_update_bytes(events, prompt_rows)
    updates.update(
        {
            f"snapshots/{snapshot_id}.json": dump_pretty(snapshot).encode("utf-8"),
            SNAPSHOT_INDEX_PATH: dump_pretty(snapshot_index).encode("utf-8"),
            "manifest.json": dump_pretty(manifest).encode("utf-8"),
        }
    )
    update = update_archive_files_bytes(
        active_root,
        updates,
        str(exe),
        "safe",
        current_hash,
    )
    return {"snapshot_created": True, "active_memory_zone": active_zone.active_memory_zone, "snapshot": snapshot, "snapshot_count": len(snapshots), "update": update}


def _search_memory_index(project: Path, query: str, limit: int, native_exe: str | None = None) -> list[dict[str, Any]]:
    current = _load_archive_json_optional(project, CURRENT_INDEX_PATH, {}, native_exe)
    if not isinstance(current, dict):
        return []
    terms = [t.lower() for t in query.split() if t.strip()]
    rows = []
    for idx, unit in enumerate(current.get("searchable_units", []), start=1):
        hay = " ".join(
            [
                str(unit.get("kind", "")),
                str(unit.get("source", "")),
                " ".join(str(t) for t in unit.get("tags", [])),
                str(unit.get("git_text", "")),
                str(unit.get("text", "")),
            ]
        ).lower()
        if terms and not any(term in hay for term in terms):
            continue
        score = int(unit.get("weight", 1))
        score += sum(3 for term in terms if term in str(unit.get("text", "")).lower())
        score += sum(2 for term in terms if term in str(unit.get("kind", "")).lower())
        score += sum(1 for term in terms if term in " ".join(str(t).lower() for t in unit.get("tags", [])))
        rows.append(
            {
                "score": score,
                "path": EVENT_LOG_PATH,
                "line": idx,
                "kind": "memory_" + str(unit.get("kind", "event")),
                "text": str(unit.get("text", "")),
                "event_id": unit.get("event_id"),
                "git": unit.get("git", {}),
                "why_selected": "append_only_memory_index",
            }
        )
    rows.sort(key=lambda r: (-int(r["score"]), r["path"], int(r["line"]), str(r.get("event_id", ""))))
    return rows[:limit]


def _load_archive_json(project: Path, archive_inner_path: str, native_exe: str | None = None) -> Any:
    data = extract_archive_file_bytes(project, archive_inner_path, native_exe)
    return json.loads(data.decode("utf-8-sig"))


def load_archive_payload(project: Path, native_exe: str | None = None) -> dict[str, Any]:
    manifest = _load_archive_json(project, "manifest.json", native_exe)
    index = _load_archive_json(project, "index.json", native_exe)
    scan = _load_archive_json(project, "scan.json", native_exe)
    return {"manifest": manifest, "index": index, "scan": scan, "extract_mode": "stdout_memory"}


def native_archive_status(project: Path, native_exe: str | None = None, memory_zone: str = "nearest", memory_zone_path: str | None = None) -> dict[str, Any]:
    zone = resolve_memory_zone(project, memory_zone, memory_zone_path)
    project = Path(zone.active_root)
    archive = project_archive_path(project)
    selection = select_native_ithz(native_exe)
    exe = Path(selection.path)
    version = native_version_info(exe)
    if not archive.exists():
        return {
            "project": str(project),
            "requested_project": zone.requested_project,
            "active_memory_zone": zone.active_memory_zone,
            "memory_zone": asdict(zone),
            "archive": str(archive),
            "exists": False,
            "native_exe": str(exe),
            "native_selection": asdict(selection),
            "native_selected_build": selection.selected_build,
            "native_selection_reason": selection.reason,
            "native_cpu_avx2_supported": selection.cpu_avx2_supported,
            "native_version": version,
        }
    result = _run_native(["--verify", str(archive), "--verify=safe"], exe)
    payload = load_archive_payload(project, str(exe))
    manifest = payload["manifest"]
    return {
        "project": str(project),
        "requested_project": zone.requested_project,
        "active_memory_zone": zone.active_memory_zone,
        "memory_zone": asdict(zone),
        "archive": str(archive),
        "exists": True,
        "archive_bytes": archive.stat().st_size,
        "archive_sha256": sha256_file(archive),
        "native_exe": str(exe),
        "native_selection": asdict(selection),
        "native_selected_build": selection.selected_build,
        "native_selection_reason": selection.reason,
        "native_cpu_avx2_supported": selection.cpu_avx2_supported,
        "native_version": version,
        "safe_verify_ok": result.returncode == 0,
        "schema": manifest.get("schema"),
        "index_mode": manifest.get("index_mode", "legacy-full"),
        "project_semantic_hash": manifest.get("project_semantic_hash"),
        "archive_semantic_hash": manifest.get("archive_semantic_hash"),
        "source_file_count": manifest.get("source_file_count"),
        "prompt_record_count": manifest.get("prompt_record_count"),
    }


def native_archive_search(project: Path, query: str, limit: int = 10, native_exe: str | None = None, memory_zone: str = "nearest", memory_zone_path: str | None = None) -> dict[str, Any]:
    zone = resolve_memory_zone(project, memory_zone, memory_zone_path)
    project = Path(zone.active_root)
    payload = load_archive_payload(project, native_exe)
    rows = search_index(payload["index"], query, limit)
    rows.extend(_search_memory_index(project, query, limit, native_exe))
    rows.sort(key=lambda r: (-int(r.get("score", 0)), r.get("path", ""), int(r.get("line", 0)), r.get("text", "")))
    rows = rows[:limit]
    return {
        "requested_project": zone.requested_project,
        "active_memory_zone": zone.active_memory_zone,
        "query": query,
        "rows": rows,
        "index_hash": payload["index"].get("index_hash"),
        "archive_semantic_hash": payload["manifest"].get("archive_semantic_hash"),
    }


def native_archive_context_pack(project: Path, query: str, max_bytes: int = 20000, native_exe: str | None = None, memory_zone: str = "nearest", memory_zone_path: str | None = None) -> dict[str, Any]:
    zone = resolve_memory_zone(project, memory_zone, memory_zone_path)
    project = Path(zone.active_root)
    payload = load_archive_payload(project, native_exe)
    index = payload["index"]
    rows = native_archive_search(project, query, 30, native_exe, "current")["rows"]
    lines = [
        "# ITHZ Native Archive Context Pack",
        "",
        f"- query: {query}",
        f"- requested_project: {zone.requested_project}",
        f"- active_memory_zone: {zone.active_memory_zone}",
        f"- project_semantic_hash: {index.get('project_semantic_hash')}",
        f"- archive_semantic_hash: {payload['manifest'].get('archive_semantic_hash')}",
        "",
        "## Selected Evidence",
    ]
    for row in rows:
        lines.append(f"- `{row['path']}:{row['line']}` [{row['kind']}] score={row.get('score')} reason={row.get('why_selected')}: {row['text']}")
    if not rows:
        lines.extend(["", "## Evidence Gaps", "- No archive evidence matched the query."])
    text = "\n".join(lines) + "\n"
    if len(text.encode("utf-8")) > max_bytes:
        marker = "\n\n[truncated deterministically]\n"
        marker_bytes = marker.encode("utf-8")
        budget = max(0, max_bytes - len(marker_bytes))
        encoded = text.encode("utf-8")[:budget]
        text = encoded.decode("utf-8", errors="ignore") + marker
    return {
        "text": text,
        "bytes": len(text.encode("utf-8")),
        "active_memory_zone": zone.active_memory_zone,
        "context_pack_hash": stable_json_hash({"query": query, "text": text, "archive_semantic_hash": payload["manifest"].get("archive_semantic_hash")}),
    }


def native_archive_record_prompt_response(
    project: Path,
    prompt_file: Path,
    response_file: Path,
    task: str,
    mode: str = "summary",
    native_exe: str | None = None,
    memory_zone: str = "nearest",
    memory_zone_path: str | None = None,
) -> dict[str, Any]:
    if mode == "off":
        return {"recorded": False, "mode": mode, "reason": "prompt_memory_off"}
    if mode not in {"summary", "full-redacted", "full-local-only"}:
        raise ValueError("unsupported_prompt_memory_mode")
    zone = resolve_memory_zone(project, memory_zone, memory_zone_path)
    project = Path(zone.active_root)
    exe = locate_native_ithz(native_exe)
    if not project_archive_path(project).exists():
        build_native_archive(project, str(exe))
    prompt_text = prompt_file.read_text(encoding="utf-8")
    response_text = response_file.read_text(encoding="utf-8")
    prompt_redaction = redact_text(prompt_text)
    response_redaction = redact_text(response_text)
    local_only = mode == "full-local-only"
    if local_only and (prompt_redaction["redacted"] or response_redaction["redacted"]):
        raise ValueError("local_only_prompt_memory_secret_like_content_blocked")
    archive_sha256_before = sha256_file(project_archive_path(project))
    try:
        prompt_log_bytes = extract_archive_file_bytes(project, PROMPT_LOG_PATH, str(exe))
        rows = [json.loads(line) for line in prompt_log_bytes.decode("utf-8-sig").splitlines() if line.strip()]
    except RuntimeError as exc:
        if "path not found" not in str(exc):
            raise
        rows = []
    record_id = f"pr_{len(rows) + 1:06d}"
    prompt_id = f"prompt_{record_id[3:]}"
    response_id = f"response_{record_id[3:]}"
    prompt_summary = _summarize_text(prompt_redaction["text"], "prompt")
    response_summary = _summarize_text(response_redaction["text"], "response")
    record = {
        "schema": "ithz_prompt_memory_record_v1",
        "record_id": record_id,
        "prompt_id": prompt_id,
        "response_id": response_id,
        "task": task,
        "mode": mode,
        "local_only": local_only,
        "prompt_hash": stable_json_hash({"prompt": prompt_text}),
        "response_hash": stable_json_hash({"response": response_text}),
        "semantic_prompt_hash": stable_json_hash({"task": task, "mode": mode, "prompt_summary": prompt_summary, "response_summary": response_summary}),
        "prompt_summary": prompt_summary,
        "response_summary": response_summary,
        "redaction_status": redaction_status(prompt_redaction, response_redaction),
        "redaction_hits": sorted(set(prompt_redaction["hits"] + response_redaction["hits"])),
        "team_sync_allowed": not local_only,
    }
    rows.append(record)
    events = _memory_events(project, str(exe))
    layer_updates = _layer_update_bytes(events, rows)
    manifest = _load_archive_json(project, "manifest.json", str(exe))
    manifest["prompt_record_count"] = len(rows)
    manifest["prompt_summary_index_hash"] = _derive_prompt_summary_index(rows)["prompt_summary_index_hash"]
    manifest["archive_semantic_hash"] = stable_json_hash({"previous": manifest.get("archive_semantic_hash"), "prompt_rows": rows})
    layer_updates["manifest.json"] = dump_pretty(manifest).encode("utf-8")
    layer_updates[PROMPT_LOG_PATH] = _jsonl_bytes(rows)
    batch_update = update_archive_files_bytes(
        project,
        layer_updates,
        str(exe),
        "safe",
        archive_sha256_before,
    )
    archive = native_archive_status(project, str(exe))
    return {"record": record, "archive": archive, "updates": [batch_update], "update_mode": "native_memory_update_files_batch", "active_memory_zone": zone.active_memory_zone}


def write_mcp13_outputs(project: Path, rows: list[dict[str, Any]], summary: str) -> None:
    out = project / "experiments" / "mcp13_native_archive"
    out.mkdir(parents=True, exist_ok=True)
    matrix = out / "mcp13_native_archive_matrix.csv"
    if rows:
        with matrix.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=sorted({k for row in rows for k in row}))
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
    (out / "mcp13_summary.md").write_text(summary, encoding="utf-8", newline="\n")
