VERSION = "0.1.0-alpha"
PRODUCT = "ITHZ-MCP / ITHZ ContextDB"

