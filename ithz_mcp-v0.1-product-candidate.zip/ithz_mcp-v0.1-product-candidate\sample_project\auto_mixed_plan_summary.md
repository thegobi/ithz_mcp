# ITHZ Native P9A Auto-Mixed Plan

Status: `passed`

Analyze-only plan for `C:/Users/thego/AppData/Local/Temp/ithz_mcp_archive_mzib5rh9/dataset`. No archive was written.

```text
selected_profile=auto_mixed_v1
input_bytes=83245
file_count=29
dataset_features_hash=0e79cc8e04aea546d75516c028254921fa1ac54e6b1de783b6d6a60d82685195
family_assignment_hash=9d7e0c654c3c0ced73f2f4818e326365c2214ccb60ac06f3ab575bdd150c9a03
semantic_plan_hash=296bf2d848c136f86ff4fe027b3847ae9aefddbfbf93cff996da1ad362d0384f
```

## Families

- `generic_cfc`: files=`8`, input_bytes=`8166`, method=`LZ_RANGE`
- `large_text_solid`: files=`1`, input_bytes=`42413`, method=`LZ_RANGE`
- `small_text_project_bundle`: files=`20`, input_bytes=`32666`, method=`P7B_solid`

Outputs:

- `C:/work/ITHKOR/ithz_mcp/dist/ithz_mcp-v0.1-product-candidate/sample_project/project.ithz.auto_mixed_plan.json`
- `C:/work/ITHKOR/ithz_mcp/dist/ithz_mcp-v0.1-product-candidate/sample_project/native_ithz_p9_auto_mixed_plan_matrix.csv`
