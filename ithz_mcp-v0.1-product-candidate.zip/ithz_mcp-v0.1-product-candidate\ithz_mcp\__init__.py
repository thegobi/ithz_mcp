from pathlib import Path

VERSION = "0.1.0-alpha"
PRODUCT = "ITHZ-MCP / ITHZ ContextDB"

_ROOT = Path(__file__).resolve().parent.parent
_SRC = _ROOT / "src" / "ithz_mcp"
if _SRC.exists():
    __path__.insert(0, str(_SRC))
