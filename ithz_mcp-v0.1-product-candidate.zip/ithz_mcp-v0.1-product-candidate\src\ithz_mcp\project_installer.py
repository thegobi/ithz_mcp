from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any

from .agent_history_import import archive_import_agent_history, detect_history_author
from .git_merge_driver import install_git_drivers
from .hashing import sha256_file, stable_json_hash
from .host_install import write_host_install_bundle
from .native_archive_store import INDEX_MODE_COMPACT, build_native_archive, native_archive_status, project_archive_path
from .workflow_profiles import archive_adopt_project_workflow


def _git_value(project: Path, args: list[str]) -> str:
    result = subprocess.run(["git", "-C", str(project), *args], text=True, capture_output=True, check=False)
    return result.stdout.strip() if result.returncode == 0 else ""


def detect_git(project: Path) -> dict[str, Any]:
    inside = _git_value(project, ["rev-parse", "--is-inside-work-tree"]) == "true"
    root = _git_value(project, ["rev-parse", "--show-toplevel"]) if inside else ""
    branch = _git_value(project, ["branch", "--show-current"]) if inside else ""
    return {
        "inside_git": inside,
        "git_root": root,
        "project_root_policy": "current_directory_not_git_root",
        "branch": branch,
    }


def _install_codex_config(snippet_path: Path, config_path: Path | None = None) -> dict[str, Any]:
    config_path = config_path or (Path.home() / ".codex" / "config.toml")
    snippet = snippet_path.read_text(encoding="utf-8")
    config_path.parent.mkdir(parents=True, exist_ok=True)
    existing = config_path.read_text(encoding="utf-8") if config_path.exists() else ""
    already_present = "[mcp_servers.ithz_mcp]" in existing and "[mcp_servers.ithz_mcp_write]" in existing
    if already_present:
        return {"config_path": str(config_path), "installed": False, "reason": "profiles_already_present"}
    backup = ""
    if config_path.exists():
        backup_path = config_path.with_suffix(config_path.suffix + ".bak-ithz-mcp23")
        backup_path.write_text(existing, encoding="utf-8")
        backup = str(backup_path)
    config_path.write_text(existing.rstrip() + "\n\n" + snippet.strip() + "\n", encoding="utf-8")
    return {"config_path": str(config_path), "installed": True, "backup": backup}


def install_project(
    project: Path,
    apply: bool = False,
    profile: str = "default",
    owner: str | None = None,
    native_exe: str | None = None,
    include_child_zones: bool = False,
    import_agent_history: bool = False,
    history_sources: list[str] | None = None,
    history_roots: list[Path] | None = None,
    install_codex_config: bool = False,
    install_git_driver: bool = True,
    index_mode: str = INDEX_MODE_COMPACT,
) -> dict[str, Any]:
    project = project.resolve()
    author = detect_history_author(project, owner)
    owner_name = owner or author["author"]
    git = detect_git(project)
    host_out = project / ".ithz-install" / "host_installers"
    result: dict[str, Any] = {
        "schema": "ithz_mcp_install_project_v1",
        "project": str(project),
        "apply": apply,
        "root_policy": "current_directory",
        "author": author,
        "git": git,
        "index_mode": index_mode,
        "actions": [],
    }
    if not apply:
        result["actions"].extend(
            [
                {"action": "would_build_project_ithz", "path": str(project_archive_path(project)), "index_mode": index_mode},
                {"action": "would_adopt_workflow_profile", "profile": profile, "owner": owner_name},
                {"action": "would_generate_host_installers", "out": str(host_out)},
            ]
        )
        if git["inside_git"] and install_git_driver:
            result["actions"].append({"action": "would_install_git_driver", "scope": str(project)})
        result["recommended_apply"] = "python -m ithz_mcp install-project --apply"
        return result

    archive = build_native_archive(project, native_exe, "safe", include_child_zones, index_mode)
    result["actions"].append({"action": "built_project_ithz", "archive": archive["archive"], "archive_bytes": archive["archive_bytes"], "index_mode": index_mode})
    adopted = archive_adopt_project_workflow(project, profile, owner_name, project / "project.md", include_existing_md=True, native_exe=native_exe)
    result["actions"].append({"action": "adopted_workflow_profile", "profile": adopted["profile"]["profile_id"], "source_count": adopted["source_count"]})
    history_result = None
    if import_agent_history:
        history_result = archive_import_agent_history(
            project,
            history_sources,
            history_roots,
            apply=True,
            author=owner_name,
            max_records=100,
            native_exe=native_exe,
        )
        result["actions"].append({"action": "imported_agent_history", "imported_count": history_result.get("imported_count", 0)})
    host = write_host_install_bundle(project, host_out)
    result["actions"].append({"action": "generated_host_installers", "out": host["out_dir"], "rows": len(host["rows"])})
    if install_codex_config:
        codex = _install_codex_config(host_out / "codex_config_snippet.toml")
        result["actions"].append({"action": "installed_codex_config", **codex})
    if git["inside_git"] and install_git_driver:
        driver = install_git_drivers(project, dry_run=False)
        result["actions"].append({"action": "installed_git_driver", "scope": str(project), "driver_actions": driver["actions"]})
    status = native_archive_status(project, native_exe)
    result["status"] = {
        "archive": status.get("archive"),
        "archive_bytes": status.get("archive_bytes"),
        "archive_sha256": status.get("archive_sha256"),
        "project_semantic_hash": status.get("project_semantic_hash"),
        "safe_verify_ok": status.get("safe_verify_ok"),
        "index_mode": status.get("index_mode"),
    }
    result["install_hash"] = stable_json_hash({"project": str(project), "actions": result["actions"], "status": result["status"]})
    result["recommended_git_add"] = ["project.md", "project.ithz"]
    if git["inside_git"] and install_git_driver:
        result["recommended_git_add"].append(".gitattributes")
    result["commit_is_automatic"] = False
    result["project_ithz_sha256"] = sha256_file(project_archive_path(project))
    return result
