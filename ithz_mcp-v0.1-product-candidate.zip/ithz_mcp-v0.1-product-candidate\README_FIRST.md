# README FIRST

1. Run `smoke_test.ps1`.
2. Run `python mcp_client_smoke.py`.
3. Review `host_installers/README_HOST_INSTALLERS.md`.
4. Install host config with the relevant `install_*_mcp.ps1 -Apply` only after dry-run review.
5. Use `project.md` as bootstrap and `project.ithz` as the memory zone.
6. Track `project.md` and `project.ithz` in Git; use the ITHZ merge driver for parallel work.
7. This is not a Git replacement, cloud sync product, production database, or general token-saving claim.
