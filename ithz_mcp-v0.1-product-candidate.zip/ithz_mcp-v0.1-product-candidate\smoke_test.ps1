$ErrorActionPreference='Stop'
python -m ithz_mcp version
python -m ithz_mcp self-test --verbose
python -m ithz_mcp init-native-archive-memory --project sample_project | Out-Null
python -m ithz_mcp archive-adopt-project-workflow --project sample_project --profile default --owner Tester --prompt project.md | Out-Null
python -m ithz_mcp archive-finalize-task --project sample_project --task "product package smoke" --summary-text "Package smoke completed." --docs-impact not-needed --memory-impact handoff-created --gate "Gate: package smoke passed" | Out-Null
python -m ithz_mcp archive-get-context-pack --project sample_project --query "package smoke gate" --out archive_pack.md | Out-Null
python -m ithz_mcp mcp-config-validate --config codex_mcp_config.sample.json | Out-Null
python mcp_client_smoke.py | Out-Null
