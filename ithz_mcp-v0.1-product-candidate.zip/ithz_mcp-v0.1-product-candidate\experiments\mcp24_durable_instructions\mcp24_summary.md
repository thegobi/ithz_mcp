# MCP24 Durable Instruction Capture Summary

- rows: 9
- passed: 9/9

- durable user instructions are stored as typed workflow/decision/gate/risk records inside `project.ithz`;
- typed records are mirrored into append-only memory events for search/context-pack retrieval;
- secret-like instructions are blocked before storage;
- the layer is explicit and write-enabled; read-only MCP profiles do not write it automatically.


No Git replacement, production database, or universal token guarantee claim is made.
