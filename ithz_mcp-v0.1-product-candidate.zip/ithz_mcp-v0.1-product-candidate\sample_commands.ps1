$ErrorActionPreference='Stop'
python -m ithz_mcp init-native-archive-memory --project sample_project
python -m ithz_mcp archive-adopt-project-workflow --project sample_project --profile default --owner Tester --prompt project.md
python -m ithz_mcp archive-get-context-pack --project sample_project --query "decision gate" --out archive_pack.md
python -m ithz_mcp mcp-config-validate --config codex_mcp_config.sample.json
python mcp_client_smoke.py
