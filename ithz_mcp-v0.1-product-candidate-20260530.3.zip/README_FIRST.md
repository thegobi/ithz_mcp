# README FIRST

Build: `product-candidate-agent-intake.20260530.3`

1. Run `smoke_test.ps1`.
2. Run `python mcp_client_smoke.py`.
3. Copy `ithz_mcp.md` into another project and ask the local agent to follow it.
4. Review `host_installers/README_HOST_INSTALLERS.md`.
5. Install host config with the relevant `install_*_mcp.ps1 -Apply` only after dry-run review.
6. Use `project.md` as bootstrap and `project.ithz` as the memory zone.
7. First install runs agent intake with Codex CLI when available; if not, the host agent must finish intake from `ithz_mcp.md`.
8. Use durable instruction tools when the user gives lasting workflow, decision, gate or risk rules.
9. Track `project.md` and `project.ithz` in Git; use the ITHZ merge driver for parallel work.
10. This is not a Git replacement, cloud sync product, production database, or general token-saving claim.
