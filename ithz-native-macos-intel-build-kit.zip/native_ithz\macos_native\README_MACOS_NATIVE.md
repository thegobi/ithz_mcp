# ITHZ Native macOS Build Kit

This folder contains the macOS build and packaging path for `ithz-native`.

The Windows `ithz-native.exe` payload cannot run on macOS. A real macOS Native
binary must be built and smoke-tested on macOS or by the repository GitHub
Actions macOS runner. This checkout does not produce a Mach-O binary from a
Windows-only build.

## What This Kit Does

- Builds `native_ithz` with CMake and the macOS C++ toolchain.
- Packages a macOS `ithz-native` CLI folder with docs, sample commands and a
  smoke test.
- Runs `--version`, `--self-test`, `--hw-status`, safe pack/verify/list/inspect,
  extract-file and full extract smoke checks on the built binary.
- Produces a zip named
  `ithz-native-preview-v0.1-alpha-rc2-macos-<arch>.zip`.
- Includes `install_macos_native.sh`, which copies `bin/ithz-native` to
  `~/.local/share/ithz-mcp/native/ithz-native` and validates it.

## What This Kit Does Not Claim

- It does not change archive format, compression methods, CFC planning, family
  assignment or P10 extraction safety.
- It does not make a ZIP, tar.gz or 7z superiority claim.
- It is not a signed or notarized macOS installer yet.
- It is not a macFUSE/FUSE-T zero-copy filesystem provider.

## Build On macOS

From the repository root on a Mac:

```bash
chmod +x native_ithz/macos_native/build_macos_native_package.sh
native_ithz/macos_native/build_macos_native_package.sh --arch native
```

For Intel Macs, build the explicit x86_64 package:

```bash
native_ithz/macos_native/build_macos_native_package.sh --arch x86_64
```

Optional architectures:

```bash
native_ithz/macos_native/build_macos_native_package.sh --arch arm64
native_ithz/macos_native/build_macos_native_package.sh --arch x86_64
native_ithz/macos_native/build_macos_native_package.sh --arch universal
```

The script writes packages under:

```text
native_ithz/dist/macos_native/
```

## Install On A Mac

After unpacking the `macos-x86_64` package:

```bash
chmod +x install_macos_native.sh smoke_test.sh sample_commands.sh bin/ithz-native
./smoke_test.sh
./install_macos_native.sh
export ITHZ_NATIVE_EXE="$HOME/.local/share/ithz-mcp/native/ithz-native"
```

Then install the MCP host config for Cursor/Codex/Claude with native archive
storage enabled:

```bash
ITHZ_NATIVE_EXE="$HOME/.local/share/ithz-mcp/native/ithz-native" \
ITHZ_MCP_STORAGE_PROFILE=native-archive \
/path/to/ithz-mcp-macos/host_installers_macos/install_cursor_mcp.sh --project "$PWD" --apply
```

Restart the host after changing MCP config. If `ITHZ_NATIVE_EXE` is not set or
the binary is missing, use the legacy MCP config only and do not rewrite
`project.ithz`.

## GitHub Actions

The repository workflow `.github/workflows/build-macos-native.yml` builds the
Intel package on `macos-13` with `--arch x86_64`, runs the native smoke test,
and uploads the zip plus SHA-256 manifest as CI artifacts. Use that artifact
for macOS Intel Cursor installs when a local Mac build is not available.

## Relationship To ITHZ Drive On macOS

The existing macOS Drive fallback opens archives as a temporary folder and can
extract them next to the archive. It needs a working macOS `ithz-native` binary
for real archive operations. This build kit is the missing native runtime step
for that fallback path.
