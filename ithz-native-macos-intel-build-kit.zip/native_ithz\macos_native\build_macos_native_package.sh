#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NATIVE_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(cd "$NATIVE_ROOT/.." && pwd)"

ARCH="native"
CONFIG="Release"
OUT_ROOT="$NATIVE_ROOT/dist/macos_native"
SKIP_TESTS=0

usage() {
  cat <<'EOF'
Usage: build_macos_native_package.sh [options]

Options:
  --arch native|arm64|x86_64|universal  Target architecture. Default: native.
  --config Release|Debug                 CMake build configuration. Default: Release.
  --out PATH                             Output root. Default: native_ithz/dist/macos_native.
  --skip-tests                           Package without running smoke tests.
  -h, --help                             Show this help.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --arch)
      ARCH="${2:-}"
      shift 2
      ;;
    --config)
      CONFIG="${2:-}"
      shift 2
      ;;
    --out)
      OUT_ROOT="${2:-}"
      shift 2
      ;;
    --skip-tests)
      SKIP_TESTS=1
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

case "$ARCH" in
  native) CMAKE_ARCH_ARGS=(); ARCH_SLUG="$(uname -m)" ;;
  arm64) CMAKE_ARCH_ARGS=(-DCMAKE_OSX_ARCHITECTURES=arm64); ARCH_SLUG="arm64" ;;
  x86_64) CMAKE_ARCH_ARGS=(-DCMAKE_OSX_ARCHITECTURES=x86_64); ARCH_SLUG="x86_64" ;;
  universal) CMAKE_ARCH_ARGS=(-DCMAKE_OSX_ARCHITECTURES="arm64;x86_64"); ARCH_SLUG="universal" ;;
  *)
    echo "Unsupported --arch: $ARCH" >&2
    exit 2
    ;;
esac

require_cmd() {
  if ! command -v "$1" >/dev/null 2>&1; then
    echo "Required command not found: $1" >&2
    exit 1
  fi
}

require_cmd cmake
require_cmd shasum
require_cmd zip
require_cmd uname

BUILD_DIR="$NATIVE_ROOT/build_macos_${ARCH_SLUG}"
PACKAGE_NAME="ithz-native-preview-v0.1-alpha-rc2-macos-${ARCH_SLUG}"
PACKAGE_DIR="$OUT_ROOT/$PACKAGE_NAME"
ZIP_PATH="$OUT_ROOT/$PACKAGE_NAME.zip"
SMOKE_ROOT="$OUT_ROOT/smoke_${ARCH_SLUG}"

rm -rf "$BUILD_DIR" "$PACKAGE_DIR" "$ZIP_PATH" "$SMOKE_ROOT"
mkdir -p "$BUILD_DIR" "$PACKAGE_DIR/bin" "$OUT_ROOT" "$SMOKE_ROOT"

cmake -S "$NATIVE_ROOT" -B "$BUILD_DIR" \
  -DCMAKE_BUILD_TYPE="$CONFIG" \
  -DITHZ_ENABLE_X64_AVX2=OFF \
  "${CMAKE_ARCH_ARGS[@]}"

cmake --build "$BUILD_DIR" --config "$CONFIG" --target ithz-native

BIN_PATH="$BUILD_DIR/ithz-native"
if [[ ! -x "$BIN_PATH" && -x "$BUILD_DIR/$CONFIG/ithz-native" ]]; then
  BIN_PATH="$BUILD_DIR/$CONFIG/ithz-native"
fi
if [[ ! -x "$BIN_PATH" ]]; then
  echo "Built binary not found: $BIN_PATH" >&2
  exit 1
fi

cp "$BIN_PATH" "$PACKAGE_DIR/bin/ithz-native"
chmod +x "$PACKAGE_DIR/bin/ithz-native"

cat > "$PACKAGE_DIR/README_FIRST.md" <<'EOF'
# ITHZ Native macOS Preview

1. Run `./smoke_test.sh`.
2. Run `./install_macos_native.sh` to install the CLI to
   `~/.local/share/ithz-mcp/native/ithz-native`.
3. Try `~/.local/share/ithz-mcp/native/ithz-native --version`.
4. Use `./sample_commands.sh` for a tiny archive workflow.

This is a developer preview CLI package. It is not a signed/notarized macOS
installer and it does not make a ZIP/tar.gz/7z superiority claim.
EOF

cat > "$PACKAGE_DIR/install_macos_native.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN="$ROOT/bin/ithz-native"
DEST_DIR="${ITHZ_NATIVE_INSTALL_DIR:-$HOME/.local/share/ithz-mcp/native}"
DEST="$DEST_DIR/ithz-native"

if [[ ! -x "$BIN" ]]; then
  echo "ithz-native binary not found or not executable: $BIN" >&2
  exit 1
fi

mkdir -p "$DEST_DIR"
cp "$BIN" "$DEST"
chmod +x "$DEST"

"$DEST" --version
"$DEST" --self-test

cat <<MSG
macos_native_install_ok=true
ithz_native_exe=$DEST

For this shell:
  export ITHZ_NATIVE_EXE="$DEST"

For Cursor/Codex/Claude host installers, run them with:
  ITHZ_NATIVE_EXE="$DEST" ITHZ_MCP_STORAGE_PROFILE=native-archive <installer> --project "\$PWD" --apply
MSG
EOF
chmod +x "$PACKAGE_DIR/install_macos_native.sh"

cat > "$PACKAGE_DIR/sample_commands.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="$ROOT/sample_work"
rm -rf "$WORK"
mkdir -p "$WORK/project/docs"
printf 'hello from ithz native macOS\n' > "$WORK/project/README.md"
printf 'gate=sample\n' > "$WORK/project/docs/gate.txt"

"$ROOT/bin/ithz-native" --pack-folder "$WORK/project" --archive "$WORK/sample.ithz" --verify=safe
"$ROOT/bin/ithz-native" --list "$WORK/sample.ithz"
"$ROOT/bin/ithz-native" --inspect "$WORK/sample.ithz" --families
"$ROOT/bin/ithz-native" --extract-file "$WORK/sample.ithz" --path README.md --output "$WORK/README.restored.md"
"$ROOT/bin/ithz-native" --extract "$WORK/sample.ithz" --output "$WORK/restored"
EOF
chmod +x "$PACKAGE_DIR/sample_commands.sh"

cat > "$PACKAGE_DIR/smoke_test.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
"$ROOT/bin/ithz-native" --version
"$ROOT/bin/ithz-native" --self-test
"$ROOT/bin/ithz-native" --hw-status
"$ROOT/sample_commands.sh"
echo "macos_native_smoke_ok=true"
EOF
chmod +x "$PACKAGE_DIR/smoke_test.sh"

cat > "$PACKAGE_DIR/VERSION.json" <<EOF
{
  "arch": "$ARCH_SLUG",
  "build_config": "$CONFIG",
  "package": "$PACKAGE_NAME",
  "platform": "macOS",
  "status": "developer-preview",
  "version": "ITHZ-CFC v0.1-alpha-rc2"
}
EOF

cp "$NATIVE_ROOT/README_NATIVE_ITHZ.md" "$PACKAGE_DIR/README_NATIVE_ITHZ.md"
cp "$SCRIPT_DIR/README_MACOS_NATIVE.md" "$PACKAGE_DIR/README_MACOS_NATIVE.md"

if [[ "$SKIP_TESTS" -eq 0 ]]; then
  "$PACKAGE_DIR/smoke_test.sh"
fi

(
  cd "$PACKAGE_DIR"
  find . -type f -print0 | sort -z | xargs -0 shasum -a 256 > SHA256SUMS.txt
)

(
  cd "$OUT_ROOT"
  zip -qr "$ZIP_PATH" "$PACKAGE_NAME"
)

SHA="$(shasum -a 256 "$ZIP_PATH" | awk '{print toupper($1)}')"
SIZE="$(wc -c < "$ZIP_PATH" | tr -d ' ')"

cat <<EOF
macos_native_package_ok=true
package=$ZIP_PATH
sha256=$SHA
bytes=$SIZE
EOF
