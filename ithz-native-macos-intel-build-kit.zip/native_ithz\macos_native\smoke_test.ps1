param(
    [string]$OutDir = "native_ithz\dist\macos_native",
    [string]$WebDownloadsDir = "C:\work\ithz.dev\downloads"
)

$ErrorActionPreference = "Stop"

$repo = Resolve-Path (Join-Path $PSScriptRoot "..\..")
$nativeRoot = Join-Path $repo "native_ithz"
$script = Join-Path $nativeRoot "macos_native\build_macos_native_package.sh"
$readme = Join-Path $nativeRoot "macos_native\README_MACOS_NATIVE.md"
$outAbs = Join-Path $repo $OutDir
$matrixDir = Join-Path $repo "experiments\06_ithz_archive\raw\native_ithz\macos_native"
$kitName = "ithz-native-macos-build-kit.zip"
$kitPath = Join-Path $outAbs $kitName
$webKitPath = Join-Path $WebDownloadsDir $kitName

New-Item -ItemType Directory -Force -Path $outAbs | Out-Null
New-Item -ItemType Directory -Force -Path $matrixDir | Out-Null

$scriptText = Get-Content -Raw -Path $script
$readmeText = Get-Content -Raw -Path $readme

$checks = [ordered]@{
    build_script_exists = (Test-Path $script)
    readme_exists = (Test-Path $readme)
    cmake_configure_present = ($scriptText -match "cmake -S")
    cmake_build_present = ($scriptText -match "cmake --build")
    version_gate_present = ($scriptText -match "--version")
    self_test_gate_present = ($scriptText -match "--self-test")
    hw_status_gate_present = ($scriptText -match "--hw-status")
    safe_verify_present = ($scriptText -match "--verify=safe")
    extract_file_present = ($scriptText -match "--extract-file")
    sha256_present = ($scriptText -match "shasum -a 256")
    zip_package_present = ($scriptText -match "zip -qr")
    no_superiority_claim = -not ($scriptText + $readmeText -match "(?i)(beats|better than|superior to).*(zip|tar\.gz|7z)")
    mac_binary_boundary_documented = ($readmeText -match "must be built and smoke-tested on macOS")
}

$failed = @($checks.GetEnumerator() | Where-Object { -not $_.Value })
if ($failed.Count -gt 0) {
    throw "macOS native build kit smoke failed: $($failed.Name -join ', ')"
}

$staging = Join-Path $outAbs "ithz-native-macos-build-kit"
Remove-Item -Recurse -Force -LiteralPath $staging -ErrorAction SilentlyContinue
Remove-Item -Force -LiteralPath $kitPath -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path $staging | Out-Null
Copy-Item -LiteralPath $script -Destination (Join-Path $staging "build_macos_native_package.sh")
Copy-Item -LiteralPath $readme -Destination (Join-Path $staging "README_MACOS_NATIVE.md")

@'
# ITHZ Native macOS Build Kit

Run this kit from a checked-out ITHKOR repository on macOS:

```bash
chmod +x native_ithz/macos_native/build_macos_native_package.sh
native_ithz/macos_native/build_macos_native_package.sh --arch native
```

This zip is not a ready macOS binary. It is the build/package script and
documentation for producing a real macOS `ithz-native` package on a Mac.
'@ | Set-Content -Encoding UTF8 -Path (Join-Path $staging "README_FIRST.md")

Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

function New-DeterministicZip {
    param(
        [Parameter(Mandatory=$true)][string]$SourceDir,
        [Parameter(Mandatory=$true)][string]$Destination
    )

    Remove-Item -Force -LiteralPath $Destination -ErrorAction SilentlyContinue
    $fixedTime = [DateTimeOffset]::Parse("2026-06-04T00:00:00Z")
    $files = Get-ChildItem -Recurse -File -LiteralPath $SourceDir |
        Sort-Object { $_.FullName.Substring($SourceDir.Length).Replace('\', '/') }

    $stream = [System.IO.File]::Open($Destination, [System.IO.FileMode]::CreateNew)
    try {
        $archive = [System.IO.Compression.ZipArchive]::new($stream, [System.IO.Compression.ZipArchiveMode]::Create)
        try {
            foreach ($file in $files) {
                $relative = $file.FullName.Substring($SourceDir.Length).TrimStart('\','/').Replace('\', '/')
                $entry = $archive.CreateEntry($relative, [System.IO.Compression.CompressionLevel]::Optimal)
                $entry.LastWriteTime = $fixedTime
                $inStream = [System.IO.File]::OpenRead($file.FullName)
                try {
                    $outStream = $entry.Open()
                    try {
                        $inStream.CopyTo($outStream)
                    } finally {
                        $outStream.Dispose()
                    }
                } finally {
                    $inStream.Dispose()
                }
            }
        } finally {
            $archive.Dispose()
        }
    } finally {
        $stream.Dispose()
    }
}

New-DeterministicZip -SourceDir $staging -Destination $kitPath

if (Test-Path $WebDownloadsDir) {
    Copy-Item -LiteralPath $kitPath -Destination $webKitPath -Force
}

$hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $kitPath).Hash.ToUpperInvariant()
$bytes = (Get-Item -LiteralPath $kitPath).Length
$sizeKb = [Math]::Ceiling($bytes / 1024)

$matrix = Join-Path $matrixDir "macos_native_matrix.csv"
$summary = Join-Path $matrixDir "macos_native_summary.md"

"case,status,notes" | Set-Content -Encoding UTF8 -Path $matrix
foreach ($item in $checks.GetEnumerator()) {
    "$($item.Name),$($item.Value),static_build_kit_check" | Add-Content -Encoding UTF8 -Path $matrix
}
"build_kit_zip,true,$kitName" | Add-Content -Encoding UTF8 -Path $matrix
"web_download_copy,$((Test-Path $webKitPath)),$webKitPath" | Add-Content -Encoding UTF8 -Path $matrix

$summaryLines = @(
    "# macOS Native Build Kit Summary",
    "",
    "Status: passed",
    "",
    "Windows-side static smoke created a macOS Native build kit:",
    "",
    '```text',
    "package=$kitPath",
    "sha256=$hash",
    "bytes=$bytes",
    "size_kb=$sizeKb",
    '```',
    "",
    "This is not a ready macOS binary. A real ithz-native macOS package must be",
    "built and smoke-tested on a Mac with:",
    "",
    '```bash',
    "native_ithz/macos_native/build_macos_native_package.sh --arch native",
    '```',
    "",
    "The build script is gated to run --version, --self-test, --hw-status,",
    "safe pack/verify/list/inspect, extract-file and full extract against the built",
    "binary. It does not change archive format, compression methods, CFC planning,",
    "family assignment or P10 extraction safety. No ZIP/tar.gz/7z superiority claim",
    "was added."
)
$summaryLines | Set-Content -Encoding UTF8 -Path $summary

[pscustomobject]@{
    macos_native_build_kit_ok = $true
    package = $kitPath
    web_package = $webKitPath
    sha256 = $hash
    bytes = $bytes
    size_kb = $sizeKb
    matrix = $matrix
    summary = $summary
} | ConvertTo-Json -Depth 3
