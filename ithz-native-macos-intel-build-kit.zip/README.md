﻿# ITHZ Native macOS Intel Build Kit

This kit contains the native_ithz source subset needed to build `ithz-native` on an Intel Mac.

Build:

```sh
chmod +x native_ithz/macos_native/build_macos_native_package.sh
native_ithz/macos_native/build_macos_native_package.sh --arch x86_64
```

Output:

```text
native_ithz/dist/macos_native/ithz-native-preview-v0.1-alpha-rc2-macos-x86_64.zip
```

Then unpack that package and run:

```sh
./smoke_test.sh
./install_macos_native.sh
export ITHZ_NATIVE_EXE="$HOME/.local/share/ithz-mcp/native/ithz-native"
```

This is a developer preview native CLI build kit. It does not replace Git, a production database or cloud sync, and it does not make a ZIP/tar.gz/7z superiority claim.
