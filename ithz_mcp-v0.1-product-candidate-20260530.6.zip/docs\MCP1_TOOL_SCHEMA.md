# MCP1 Tool Schema

All MCP1 tools accept JSON parameters and return bounded JSON responses.

The server does not execute shell commands, does not write context commits and does not mutate source files.

