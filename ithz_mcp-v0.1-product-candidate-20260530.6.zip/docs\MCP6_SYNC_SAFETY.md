# MCP6 Sync Safety

Team memory sync performs redaction checks before push and blocks secret-like content.

Conflicts are detected rather than destructively overwritten.

