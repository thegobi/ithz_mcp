# Safety Model

ITHZ-MCP defaults to local files and explicit operations.

It ignores `.env`, private keys, secret-like names, `.git` objects, dependency directories and build artifacts.

Prompt memory is explicit and conservative:

- default mode is `summary`;
- summary mode stores summaries and hashes, not raw prompt/response text;
- `full-redacted` stores redacted text only;
- `full-local-only` is skipped by team sync and still blocks secret-like content;
- team sync runs redaction checks before pushing context memory.

The MCP server is read-only by default.

MCP8 verifies that read-only server calls do not mutate project files, context commits or event logs. Team sync remains local/shared-dir only and blocks secret-like context content before push.

MCP9F native ingestion is read-only against `native_ithz` and `experiments/06_ithz_archive`; it indexes summary and matrix metadata, not `.ithz` binaries or decoded payload trees.

MCP10 migration commands are dry-run by default. Markdown files are not deleted or moved automatically.

MCP13 native archive memory keeps the intended long-term agent memory in `project.ithz`, built and safe-verified by `ithz-native.exe`. The human-facing `project.md` remains a short bootstrap file. Existing `.ithz-context` and `.ithz_mcp` data can still be used for compatibility, but new native archive commands exclude secrets, existing `.ithz` files, executables, build output and temporary payloads from the archive source snapshot.

End-of-task checkpointing uses an explicit write-enabled profile. Read-only MCP configs do not expose write tools. Project intake and task checkpoints redact or block secret-like payloads, skip secret-like source files and store prompt/response content only when explicitly requested.

Workflow branch profiles are stored in `project.ithz` under `workflows/`. Prompt-derived workflow facts are redacted before storage, and profile updates are scoped to a named profile such as `gobi` or `team-default`. This prevents one developer's workflow rules from silently overwriting another developer's workflow rules. The Git merge driver auto-merges independent profiles and returns `merge_needed` for same-profile divergence.

Agent-history import is opt-in. Discovery scans local Codex/Claude/Cursor/Antigravity-style history roots for records that mention the active project, but it does not write until `--apply` or `--import-agent-history` is used. Imported records are summary-only, redaction-gated and de-duplicated by semantic prompt hash plus author identity. If `project.ithz` already came from Git, import appends author/time-stamped records to that archive and leaves existing memory intact.

Native prompt-memory updates are explicit and redaction-gated. They use `ithz-native --update-files` to replace logical archive files from stdin after decoding existing archive contents in memory once, then safe-verify the rewritten archive. This avoids restored-tree staging and two separate archive rewrites while preserving path validation and SHA checks.

Memory-zone safety:

- default archive reads use the nearest `project.ithz`;
- nested `project.ithz` files are detected as child zones and are not folded into a parent archive by default;
- parent and sibling zones are accessible only through explicit `--memory-zone parent` or `--memory-zone-path`;
- archive writes acquire a local `project.ithz.lock`;
- write paths check the archive hash observed before modification and fail if the archive changed before rewrite.

Cross-zone registry safety:

- linking a zone records only its archive/root metadata in `zones/linked_zones.json`;
- cross-zone packs read linked zones but do not write them;
- cross-zone event records are written only to the explicitly active zone;
- sibling or parent archive writes require explicit zone targeting and use the same lock/hash precondition.

Append-only memory safety:

- memory events are appended, not edited in place;
- derived indexes are rebuildable from `events/events.jsonl`;
- snapshots are compact derived views, not replacements for the audit log;
- secret-like event text is blocked before it is written;
- search uses the derived current index while audit can still trace back to the raw event.
