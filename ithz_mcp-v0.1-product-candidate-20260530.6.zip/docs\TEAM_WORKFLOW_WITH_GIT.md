# Team Workflow With Git

The intended team model is:

```text
project.md   = normal text bootstrap
project.ithz = deterministic agent memory zone
Git          = transport and code history
ITHZ-MCP     = semantic memory merge
```

Normal workflow:

```powershell
git pull
python -m ithz_mcp archive-get-context-pack --project . --query "current task"
# work
python -m ithz_mcp archive-append-event --project . --kind decision --text "Decision: ..." --include-git
git add project.md project.ithz
git commit -m "Update project and agent memory"
git push
```

If two people update `project.ithz` in parallel, Git sees a binary file conflict. With the ITHZ merge driver installed, Git calls:

```powershell
python -m ithz_mcp git-merge-ithz --base %O --ours %A --theirs %B --out %A
```

The merge driver reads the archive internals rather than the raw binary bytes. Independent append-only memory events are merged, derived indexes are rebuilt, and private/local-only prompt memory is skipped.

If a conflict is unsafe or unclear, the driver returns `merge_needed` and writes a merge report. A human or agent then reviews the report.

This keeps the single-file product model:

```text
Markdown is the bootstrap.
ITHZ is the memory zone.
```

ITHZ-MCP does not replace Git. Git still owns code history, branches, commits, push and pull.
