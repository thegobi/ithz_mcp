# Automatic Native Checkpoints

ITHZ-MCP supports an explicit native end-of-task write tool:

```text
ithz_archive_auto_checkpoint
```

This is the preferred write-enabled MCP tool for normal agent work.

## Meaning

Automatic does not mean hidden.

It means the write-enabled MCP profile tells the host/model to call `ithz_archive_auto_checkpoint` at the end of every completed task before the final answer, unless the user explicitly opts out or the task produced no durable project memory.

Explicit means the write is still a visible MCP tool call.

Native means the tool writes directly to:

```text
project.ithz
```

using the native archive memory path.

## Profiles

Normal startup profile:

```text
ithz_mcp
```

Mode:

```text
read-only
```

End-of-task write profile:

```text
ithz_mcp_write
```

Mode:

```text
write-enabled
```

The read-only profile does not expose `ithz_archive_auto_checkpoint`.

## Tool Input

Minimum:

```json
{
  "task": "Short task name",
  "summary_text": "What was done, found or decided."
}
```

Recommended:

```json
{
  "task": "Short task name",
  "summary_text": "What was done, found or decided.",
  "decision": ["Decision and reason."],
  "gate": ["Tests or verification that passed."],
  "risk": ["Known risk or must-not-break rule."],
  "next": ["Next recommended step."],
  "changed_file": ["project.ithz"],
  "command": ["important command that was run"],
  "docs_impact": "updated",
  "memory_impact": "handoff-created",
  "include_git": true
}
```

## Host Instruction

Use this wording in new threads until the host enforces MCP startup policy itself:

```text
At the end of the task, before the final answer, write an ITHZ checkpoint through the write-enabled MCP profile by calling ithz_archive_auto_checkpoint. Include summary, decisions, gates, risks, next steps, changed files and commands when known.
```

## Safety

- The tool is unavailable in read-only mode.
- The tool redacts secret-like content.
- The tool writes to `project.ithz`.
- The tool does not replace Git commits.
- The tool does not push to a remote.

