# Durable Instruction Memory

ITHZ-MCP stores durable project instructions as typed memory inside `project.ithz`.

This layer is for user instructions that should survive the current chat:

- workflow rules;
- project decisions;
- gate/test rules;
- risk and must-not-break rules.

It is not raw chat capture. It is explicit write-enabled project memory.

## CLI

```powershell
python -m ithz_mcp record-workflow-rule --project . --profile gobi --text "After completed durable tasks, run tests, commit, and deploy through SSH."
python -m ithz_mcp record-project-decision --project . --profile gobi --text "Decision: use SSH deploy as the project deployment workflow."
python -m ithz_mcp record-gate-rule --project . --profile gobi --text "Gate: run tests and confirm no secrets are staged before commit."
python -m ithz_mcp record-risk-rule --project . --profile gobi --text "Risk: never store SSH private keys, API tokens, passwords or deployment secrets."
python -m ithz_mcp ingest-user-instruction --project . --profile gobi --text "Po dokonceni tasku commitni. Pred commitom spusti testy. Neskladuj SSH kluce."
python -m ithz_mcp durable-instruction-status --project .
```

## MCP Write-Enabled Tools

Read-only MCP profiles do not write durable instructions.

The explicit write-enabled profile exposes:

- `ithz_record_workflow_rule`
- `ithz_record_project_decision`
- `ithz_record_gate_rule`
- `ithz_record_risk_rule`
- `ithz_ingest_user_instruction`

If the user gives a durable project instruction during a task, the agent should store it with the typed tool before finishing.

## Storage

Inside `project.ithz`:

```text
instructions/workflow_rules.jsonl
instructions/project_decisions.jsonl
instructions/gate_rules.jsonl
instructions/risk_rules.jsonl
instructions/instruction_index.json
events/events.jsonl
indexes/current_index.json
indexes/search_index.json
indexes/gate_index.json
indexes/risk_index.json
```

Typed instruction records are mirrored into append-only memory events so context packs can retrieve them.

## Safety

- Secret-like instruction text is blocked before storage.
- Duplicate semantic instructions are deduplicated.
- Writes use native archive update, lock and hash precondition behavior.
- ITHZ-MCP does not commit or deploy code automatically. It only stores the durable workflow rule unless the agent is separately instructed and authorized to execute the workflow.

