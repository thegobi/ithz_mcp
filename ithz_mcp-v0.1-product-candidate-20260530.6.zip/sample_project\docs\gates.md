# Gates

MCP0 gate passed after deterministic hash check.
Risk: do not index secrets.
