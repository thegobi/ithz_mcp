param([string]$Project='',[string]$ConfigPath="$HOME\.codex\config.toml",[switch]$Apply)
$ErrorActionPreference='Stop'
if ([string]::IsNullOrWhiteSpace($Project)) { $Project = (Get-Location).ProviderPath }
$snippet = Get-Content -Raw -Path (Join-Path $PSScriptRoot 'codex_config_snippet.toml')
if (-not $Apply) { Write-Host 'DRY RUN: would append/update [mcp_servers.ithz_mcp] and [mcp_servers.ithz_mcp_write] in' $ConfigPath; Write-Host $snippet; exit 0 }
if (Test-Path $ConfigPath) { Copy-Item $ConfigPath "$ConfigPath.bak" -Force }
Add-Content -Path $ConfigPath -Value "`n$snippet"
Write-Host 'Installed ITHZ-MCP Codex read-only and write-enabled config. Backup:' "$ConfigPath.bak"
