# Prompt Memory

MCP12 adds explicit prompt/response memory capture for project-relevant agent work.

Prompt memory is not automatic chat-history capture. It is an explicit CLI workflow:

```powershell
python -m ithz_mcp record-prompt-response --project . --prompt prompt.md --response response.md --task "task label" --mode summary
python -m ithz_mcp prompt-log --project .
python -m ithz_mcp prompt-search --project . --query "task label"
python -m ithz_mcp prompt-context-pack --project . --query "task label" --out prompt_context_pack.md
```

Supported modes:

- `off`: record nothing.
- `summary`: default; store deterministic prompt/response summaries and hashes, not raw text.
- `full-redacted`: store redacted prompt/response text after redaction.
- `full-local-only`: store full clean prompt/response text locally only; secret-like content is still blocked and team sync skips it.

Storage lives under `.ithz-context/`:

- `prompts/`
- `responses/`
- `conversations/`
- `prompt-summaries/`

Context commits may reference prompt and response IDs. Team sync does not push local-only prompt memory and runs redaction checks before pushing context memory.

ITHZ-MCP does not replace ChatGPT or Codex history. It stores project-relevant agent work memory: decisions, reasons, gates, context, next steps and explicitly recorded prompt/response summaries.
