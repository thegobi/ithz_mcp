# MCP2 Context Commit Schema

Context commits are canonical JSON files named `ctx_000001.json`, `ctx_000002.json`, and so on.

They store task summary hashes, parent pointers, decisions, risks, next steps and semantic project state hashes.

