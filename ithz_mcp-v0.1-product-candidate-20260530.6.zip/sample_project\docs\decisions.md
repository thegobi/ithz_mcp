# Decisions

Decision: MCP0 is local and read-only first.
Next: add server only after CLI passes.
