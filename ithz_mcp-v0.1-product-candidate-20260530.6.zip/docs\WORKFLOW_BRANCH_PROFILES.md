# Workflow Branch Profiles

ITHZ-MCP supports project memory with only two required project files:

- `project.md`: human bootstrap manifest.
- `project.ithz`: deterministic memory zone.

Existing Markdown documentation can be mined into `project.ithz` during adoption. The adoption flow does not delete or move old Markdown files automatically.

## Why profiles exist

Different people can have different working habits:

- one developer may require docs-first checks and commit-after-each-task;
- another may use a different smoke-test sequence;
- a team may keep a shared default workflow.

Those differences should not overwrite each other. ITHZ-MCP stores them as separate workflow profiles under:

```text
workflows/
  workflow_index.json
  workflow_prompt_log.jsonl
  profiles/<profile>.json
```

## Commands

Adopt a project and mine existing Markdown plus an onboarding prompt:

```powershell
python -m ithz_mcp archive-adopt-project-workflow --project . --profile gobi --owner Gobi --prompt C:\work\tmp\new_project_prompt.txt
```

Update one workflow profile from a new prompt:

```powershell
python -m ithz_mcp workflow-ingest-prompt --project . --profile gobi --owner Gobi --prompt workflow_update.md
```

Inspect workflow profiles:

```powershell
python -m ithz_mcp workflow-profile-status --project .
```

Build a profile-scoped context pack:

```powershell
python -m ithz_mcp workflow-context-pack --project . --profile gobi --query "documentation impact and test workflow"
```

## Merge behavior

The ITHZ-aware Git merge driver auto-merges independent workflow profiles:

- `gobi` added on one side;
- `colleague` added on the other side;
- merged `project.ithz` keeps both.

The merge driver returns `merge_needed` for ambiguous same-profile divergence:

- both sides changed `gobi` differently from the same base;
- both sides added `shared` with different hashes;
- secret-like payloads are detected.

This keeps the single-file model intact while avoiding blind binary merges.

## Safety

- Raw prompt text is not stored as full chat history by default.
- Prompt-derived workflow facts are redacted before storage.
- Secret-like source paths are skipped.
- Secret-like payloads are blocked or redacted.
- ITHZ-MCP complements Git; it does not replace Git.
