# Memory-first Host Policy

Goal: when ITHZ-MCP is active, the agent should ask project memory before broad codebase reading.

The practical enforcement has two layers:

1. MCP/config contract:
   - `project.md` is the project bootstrap manifest;
   - a new agent thread should read `project.md` before broad source or Markdown scanning;
   - `initialize` returns memory-first instructions;
   - generated MCP configs include `agent_policy.memory_first=true` and `agent_policy.bootstrap_file=project.md`;
   - status exposes the expected first tools;
   - tool schemas describe `ithz_archive_get_context_pack` as the first broad-context step.

2. Host tool permissions:
   - a strict host profile should initially expose only ITHZ-MCP read tools;
   - broad filesystem/codebase tools should be enabled only after a context pack has been retrieved;
   - if a host exposes shell/filesystem tools immediately, the MCP server cannot technically prevent direct codebase reads by itself.

Recommended first sequence:

```text
read project.md
ithz_context_status
ithz_archive_get_context_pack(query=<task>)
inspect only candidate files / evidence gaps from the pack
```

This is not meant to hide the codebase from the agent forever. It is a staged context discipline: project memory first, source files second.

ITHZ-MCP does not replace Git, a production database, cloud sync, or all retrieval systems.
