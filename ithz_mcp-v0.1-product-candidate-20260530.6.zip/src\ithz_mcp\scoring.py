from __future__ import annotations

from functools import lru_cache
import re
import unicodedata
from typing import Any


GATE_PATTERNS = (
    "gate",
    "gates",
    "acceptance",
    "safety",
    "regression",
    "hard rules",
    "stop conditions",
    "must not break",
    "test",
    "tests",
    "passed",
    "failed",
    "prejst",
    "preslo",
    "zlyhalo",
    "brany",
    "tvrde pravidla",
    "bezpecnostne pravidla",
    "nesmie sa rozbit",
)

RISK_PATTERNS = (
    "risk",
    "risks",
    "known risks",
    "limitation",
    "limitations",
    "unsafe",
    "corrupt",
    "redaction",
    "secret",
    "stale",
    "rizika",
    "limity",
)

DECISION_PATTERNS = (
    "decision",
    "decisions",
    "decided",
    "reason",
    "because",
    "rozhodnutie",
    "dovod",
)

FORBIDDEN_PATTERNS = (
    "forbidden claim",
    "forbidden claims",
    "must not claim",
    "no general",
    "not a git replacement",
    "no git replacement",
    "does not replace git",
    "not production",
    "not cloud sync",
    "not a general token-saving claim",
    "vector db dismissal",
    "zakazane tvrdenia",
)

COMMAND_PATTERNS = (
    "unsafe_write_detected",
    "false_secret_inclusion_count",
    "schedule_hash_unique_count",
    "decoded_ok",
    "extract_file_sha_ok",
    "semantic_plan_hash",
    "family_assignment_hash",
    "run-ci-fast",
    "run-ci-full",
    "self-test",
    "hw-status",
)

CSV_COLUMN_PATTERNS = (
    "status",
    "gate",
    "passed",
    "failed",
    "risk",
    "unsafe",
    "secret",
    "schedule",
    "hash",
    "sha",
    "decoded_ok",
    "extract_file_sha_ok",
)

QUERY_STOPWORDS = {
    "a",
    "an",
    "and",
    "for",
    "from",
    "in",
    "of",
    "the",
    "to",
    "what",
    "which",
    "project",
    "context",
    "summary",
    "file",
    "files",
    "pack",
    "search",
    "najdi",
    "ake",
    "aky",
    "ako",
    "co",
    "ktore",
    "pre",
    "projekt",
    "subor",
    "subory",
}


def normalize_text(value: str) -> str:
    decomposed = unicodedata.normalize("NFKD", value)
    asciiish = "".join(ch for ch in decomposed if not unicodedata.combining(ch))
    return asciiish.lower()


@lru_cache(maxsize=1024)
def query_terms(query: str) -> list[str]:
    raw = [normalize_text(t) for t in re.findall(r"[A-Za-z0-9_./:-]+", query)]
    filtered = [t for t in raw if t and t not in QUERY_STOPWORDS]
    return filtered or raw


def _has_any(text: str, patterns: tuple[str, ...]) -> list[str]:
    return [p for p in patterns if normalize_text(p) in text]


def classify_text(text: str, path: str = "", kind: str = "") -> dict[str, Any]:
    hay = normalize_text(path + "\n" + kind + "\n" + text)
    categories: list[str] = []
    components: dict[str, int] = {}
    matched: dict[str, list[str]] = {}
    checks = (
        ("decision", DECISION_PATTERNS, 16),
        ("gate", GATE_PATTERNS, 18),
        ("risk", RISK_PATTERNS, 14),
        ("forbidden_claim", FORBIDDEN_PATTERNS, 20),
        ("command_result", COMMAND_PATTERNS, 10),
        ("matrix_signal", CSV_COLUMN_PATTERNS, 7),
    )
    for category, patterns, weight in checks:
        hits = _has_any(hay, patterns)
        if hits:
            categories.append(category)
            components[category] = weight + min(12, len(hits) * 2)
            matched[category] = hits[:6]
    if kind in {"decision", "gate", "risk_or_next"}:
        mapped = "risk" if kind == "risk_or_next" else kind
        if mapped not in categories:
            categories.append(mapped)
        components[f"index_kind_{kind}"] = components.get(f"index_kind_{kind}", 0) + 8
    return {"categories": sorted(set(categories)), "score_components": components, "matched_patterns": matched}


@lru_cache(maxsize=1024)
def _query_intent(query: str) -> frozenset[str]:
    hay = normalize_text(query)
    intent: set[str] = set()
    if _has_any(hay, DECISION_PATTERNS):
        intent.add("decision")
    if _has_any(hay, GATE_PATTERNS):
        intent.add("gate")
    if _has_any(hay, RISK_PATTERNS) or "must not" in hay:
        intent.add("risk")
    if _has_any(hay, FORBIDDEN_PATTERNS) or "claim" in hay:
        intent.add("forbidden_claim")
    return frozenset(intent)


def score_unit(unit: dict[str, Any], query: str) -> dict[str, Any] | None:
    path = str(unit.get("path", ""))
    text = str(unit.get("text", ""))
    kind = str(unit.get("kind", ""))
    hay_text = str(unit.get("search_text") or normalize_text(text))
    hay_path = str(unit.get("search_path") or normalize_text(path))
    terms = query_terms(query)
    components: dict[str, int] = {}
    reasons: list[str] = []
    for term in terms:
        if not term:
            continue
        if term in hay_path:
            components[f"path:{term}"] = components.get(f"path:{term}", 0) + 9
            reasons.append(f"path:{term}")
        if term in hay_text:
            weight = int(unit.get("weight", 1))
            components[f"text:{term}"] = components.get(f"text:{term}", 0) + max(2, weight)
            reasons.append(f"text:{term}")
    intent = _query_intent(query)
    high_signal_kind = kind in {"decision", "gate", "risk_or_next"}
    if not components and not high_signal_kind:
        return None
    if high_signal_kind or intent:
        classification = classify_text(text, path, kind)
        components.update(classification["score_components"])
    else:
        classification = {"categories": [], "score_components": {}, "matched_patterns": {}}
    categories = set(classification["categories"])
    for category in sorted(intent & categories):
        components[f"intent:{category}"] = components.get(f"intent:{category}", 0) + 22
        reasons.append(f"intent:{category}")
    if not components:
        return None
    if not reasons and not (intent & categories):
        return None
    score = sum(components.values())
    why = []
    for category in ("decision", "gate", "risk", "forbidden_claim", "command_result", "matrix_signal"):
        if category in categories:
            why.append(category)
    return {
        "score": score,
        "reasons": sorted(set(reasons + why)),
        "score_components": dict(sorted(components.items())),
        "why_selected": why or ["file relevance"],
        "categories": sorted(categories),
    }


def section_for_unit(unit: dict[str, Any]) -> str:
    categories = set(unit.get("categories", []))
    if "decision" in categories:
        return "Relevant Decisions"
    if "gate" in categories or "command_result" in categories:
        return "Relevant Gates"
    if "forbidden_claim" in categories:
        return "Forbidden Claims"
    if "risk" in categories:
        return "Known Risks / Must Not Break"
    return "Candidate Files"
