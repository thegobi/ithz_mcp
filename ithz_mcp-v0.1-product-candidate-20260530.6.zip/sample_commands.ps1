$ErrorActionPreference='Stop'
python -m ithz_mcp install-project --project sample_project --apply --agent-intake deterministic-only --no-git-driver
python -m ithz_mcp archive-get-context-pack --project sample_project --query "decision gate" --out archive_pack.md
python -m ithz_mcp mcp-config-validate --config codex_mcp_config.sample.json
python mcp_client_smoke.py
