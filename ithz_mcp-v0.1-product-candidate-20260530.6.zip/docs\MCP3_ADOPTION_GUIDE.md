# MCP3 Adoption Guide

Adoption initializes `.ithz_mcp`, creates minimal agent docs when missing and builds a local index.

It must not modify application source code.

