# Team Memory Usage

Local shared-dir remote example:

```powershell
python -m ithz_mcp context-remote add shared C:\tmp\ithz_mcp_remote --project fixtures\sample_project
python -m ithz_mcp context-push --project fixtures\sample_project --remote shared
python -m ithz_mcp context-pull --project fixtures\sample_project --remote shared
```

Team memory sync sends context commits and event logs, not source files.

