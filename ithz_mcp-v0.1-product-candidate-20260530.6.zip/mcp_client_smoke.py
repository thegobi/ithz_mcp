from ithz_mcp.cli import main
raise SystemExit(main(['mcp-client-smoke','--config','codex_mcp_config.sample.json','--out','product_client_transcript.jsonl']))
