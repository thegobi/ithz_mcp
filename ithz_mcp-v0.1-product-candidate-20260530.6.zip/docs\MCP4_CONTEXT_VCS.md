# MCP4 Context VCS

MCP4 adds a local context timeline for agent memory commits, branches and tags.

It is not Git and does not modify the Git working tree.

