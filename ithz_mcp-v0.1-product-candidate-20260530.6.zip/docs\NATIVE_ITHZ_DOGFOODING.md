# Native ITHZ Dogfooding

MCP9F imports native ITHZ result metadata as a read-only dogfood corpus.

It indexes summary Markdown, result docs and CSV matrix metadata from `C:\work\ITHKOR`, especially `experiments/06_ithz_archive/raw/native_ithz`.

It does not modify `native_ithz`, does not modify root ITHKOR docs, does not copy `.ithz` binaries into context packs and does not call `ithz-native.exe`.

MCP11 expands the dogfood suite to 15 questions covering current status, P15A/P16A/P17A evidence, P17B non-promotion, default verify mode, extraction safety, old golden archive gates, p9-v3 versus p9-v4 experimental status and forbidden claims. Context packs include selected phases, files, gates, risks and forbidden claims where available.

Outputs:

- `experiments/mcp9_native_ithz/mcp9f_native_ithz_phase_index.json`
- `experiments/mcp9_native_ithz/mcp9f_native_ithz_artifact_index.json`
- `experiments/mcp9_native_ithz/mcp9f_native_ithz_context_pack_examples.md`
