# Project Source Summary

ITHZ-MCP is a local deterministic context archive and agent work memory project.

## Stage Roles

- MCP0: local context archive CLI for deterministic project scanning, indexing, searching and context pack generation.
- MCP1: read-only MCP/server tool layer over MCP0.
- MCP2: explicit append-only write-back checkpoints and context commits.
- MCP3: memory benchmark and beta adoption tests.
- MCP4: local Git-like context timeline for agent memory, not a Git replacement.
- MCP5: read-only Git metadata integration.
- MCP6: local team memory sync that shares agent work memory, not source code.
- MCP7: productization, dogfooding and tester package.

## Sequencing

The project must pass each stage gate before the next stage is treated as complete.

## Boundaries

ITHZ-MCP does not replace Git, SQL, project management or all RAG systems. It does not guarantee lower token use for every task.

