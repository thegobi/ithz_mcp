# MCP Server Usage

Start the local read-only shim:

```powershell
python -m ithz_mcp mcp-server --project fixtures\sample_project --mode read-only
```

Smoke mode:

```powershell
python -m ithz_mcp mcp-server --project fixtures\sample_project --mode read-only --smoke
```

The current server is a stdio JSON-RPC compatible shim. It is local-first and read-only by default.

