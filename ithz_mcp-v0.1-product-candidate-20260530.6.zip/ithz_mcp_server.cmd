@echo off
set "PYTHONPATH=%~dp0;%~dp0src;%PYTHONPATH%"
"C:\Users\thego\AppData\Local\Programs\Python\Python312\python.exe" -m ithz_mcp %*
