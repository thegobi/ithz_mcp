# Sample Project

Decision: use deterministic context packs.
