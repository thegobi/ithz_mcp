# ITHZ Context Bootstrap

Long-term agent memory lives in `.ithz-context/`.

Use ITHZ-MCP context packs for task context. Markdown files are bootstrap and human-readable documentation, not the authoritative agent memory store when `.ithz-context/` exists.
