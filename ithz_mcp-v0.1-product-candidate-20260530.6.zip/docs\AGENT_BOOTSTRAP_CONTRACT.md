# Agent Bootstrap Contract

- Ask ITHZ-MCP before broad Markdown reading.
- Request a focused context pack.
- Inspect context status, decisions, gates and risks.
- After task completion, write a context commit.
- Do not create new status Markdown unless it is human-facing.
- Do not duplicate long-term memory in repo Markdown.
- Do not index secrets.
- ITHZ-MCP complements Git; it does not replace Git.
