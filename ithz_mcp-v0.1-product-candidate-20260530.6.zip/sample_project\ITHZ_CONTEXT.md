# ITHZ Context

Local agent work memory context for decisions, gates and next steps.
