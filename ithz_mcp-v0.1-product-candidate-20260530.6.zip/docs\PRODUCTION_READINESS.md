# Production Readiness

ITHZ-MCP is packaged as a local production-test candidate around two project files:

```text
project.md
project.ithz
```

`project.md` is the human and agent bootstrap. `project.ithz` is the deterministic memory zone containing workflow profiles, prompt summaries, decisions, gates, risks, context commits, indexes and snapshots.

## What Is Ready

- Fresh project initialization into `project.md` plus `project.ithz`.
- Adoption of Markdown-heavy projects into named workflow profiles.
- Optional import of local agent history summaries with author and time provenance.
- Explicit end-of-task checkpoints into `project.ithz`.
- Read-only MCP server profile for normal agent startup.
- Separate write-enabled MCP profile for explicit memory writes.
- Git diff/merge driver support for `project.ithz`.
- Host config and installer bundles for Codex, Claude Code, Cursor, Antigravity and generic JSON-RPC MCP clients.

## Product Candidate Gate

Run:

```powershell
python -m ithz_mcp run-mcp21-production-readiness
```

This gate covers:

- new project smoke;
- adopted project smoke;
- shared project semantic merge smoke;
- host config validation and scripted MCP stdio smoke;
- product candidate package smoke;
- secret exclusion check.

## Boundaries

ITHZ-MCP does not replace Git. Git still transports and versions `project.md` and `project.ithz`.

ITHZ-MCP does not replace a production database. It is a deterministic local project-memory tool.

ITHZ-MCP is not a cloud sync product. Team work uses Git plus the ITHZ-aware merge driver for `project.ithz`.

ITHZ-MCP does not make a general token-saving claim. Benchmarks are fixture-scoped unless explicitly stated.
