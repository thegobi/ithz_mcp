# Self Testing

Regression levels:

- `run-ci-fast`: py/CLI smoke for MCP0-MCP2.
- `run-ci-full`: all stage runners through MCP7.
- `run-mcp8-hardening`: MCP8A-MCP8E plus MCP8R.
- `run-mcp9f-native-ithz`: read-only native ITHZ dogfood import and question packs.
- `run-mcp10-markdown-minimal`: MCP10A-MCP10F plus MCP10R.
- `run-context-quality-regression`: expected decision/gate/risk/forbidden terms and secret absence checks.
- `run-mcp11-external-client`: MCP11A-MCP11E plus MCP11R, including scripted stdio client smoke and RC4 packaging.
- `run-mcp12-prompt-memory`: prompt/response memory summary, redaction, context commit linking and team sync local-only skip.
- `run-mcp13-host-compat`: MCP-style initialize/tools/list/tools/call scripted smoke plus native `project.ithz` archive build/search/context-pack checks.
- `run-mcp17-append-index-snapshot`: append-only event log, derived current index, searchable event evidence, snapshot creation and secret-like event blocking.
- `run-mcp20-agent-history-import`: project-scoped local agent-history import with author/time provenance.
- `run-mcp21-production-readiness`: fresh/adopted/shared project scenarios, host installer/config smokes and product candidate package smoke.
- `run-mcp22-auto-checkpoint`: write-enabled automatic native checkpointing and read-only write blocking.
- `run-mcp23-install-project`: one-command current-directory install semantics plus compact native archive index savings.

Stage summaries live under `experiments/`.

