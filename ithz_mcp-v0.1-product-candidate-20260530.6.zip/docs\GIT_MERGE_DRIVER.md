# ITHZ Git Merge Driver

`project.ithz` is a single binary memory-zone archive, so Git cannot safely merge it as text. The ITHZ-aware merge driver treats Git as transport and ITHZ-MCP as the semantic merge layer for agent work memory.

Install locally in a repository:

```powershell
python -m ithz_mcp install-git-drivers --repo .
python -m ithz_mcp git-driver-status --repo .
```

This configures:

```text
*.ithz merge=ithz diff=ithz binary
merge.ithz.driver = python -m ithz_mcp git-merge-ithz --base %O --ours %A --theirs %B --out %A
diff.ithz.textconv = python -m ithz_mcp git-diff-ithz --archive
```

Diff output is a stable text summary: archive hash, semantic hash, context commit count, latest context commit, refs, branches, prompt summary count, decision count, gate count, risk count and local-only count.

Merge behavior:

- validates base, ours and theirs archives;
- reads logical memory layers such as events, context commits, decisions, prompts, refs, branches, indexes and manifest;
- unions independent append-only memory events;
- unions independent workflow profiles such as `gobi` and `colleague`;
- flags same-profile workflow divergence as `merge_needed`;
- unions workflow prompt logs by deterministic prompt hash;
- skips private/local-only prompt memory;
- blocks secret-like event or prompt payloads;
- rebuilds derived indexes and refs;
- writes a merged `project.ithz`;
- writes an `ithz_merge_report.md` style report.

It refuses unclear merges:

- historical event modified;
- historical prompt record modified;
- same workflow profile changed differently on both sides;
- invalid/corrupted archive;
- secret-like payload detected;
- native safe verify failure.

ITHZ-MCP does not run `git commit`, `git push`, `git reset` or `git checkout`. Git remains the code-history transport. ITHZ-MCP merges the project memory zone.
