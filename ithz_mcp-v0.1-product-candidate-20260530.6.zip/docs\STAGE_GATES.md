# Stage Gates

Each stage writes a matrix CSV and summary Markdown under `experiments/`.

- Stage 0: ZIP import verified, skeleton exists and Python files compile.
- MCP0: deterministic scan, search and context pack self-test passes.
- MCP1: read-only tool smoke passes and write-back remains disabled.
- MCP2: append-only context commits and event log checks pass.
- MCP3: benchmark/adoption smoke passes without indexing secrets.
- MCP4: context DAG, branch, tag and read-only checkout smoke pass.
- MCP5: Git metadata capture is read-only and graceful outside Git.
- MCP6: local shared-dir push/pull syncs context memory only.
- MCP7: tester package and dogfood smoke pass.

