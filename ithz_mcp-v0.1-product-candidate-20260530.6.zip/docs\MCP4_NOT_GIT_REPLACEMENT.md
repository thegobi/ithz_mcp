# MCP4 Is Not Git

Git shares code history.

ITHZ-MCP shares agent work memory: decisions, reasons, gates, context and next steps.

