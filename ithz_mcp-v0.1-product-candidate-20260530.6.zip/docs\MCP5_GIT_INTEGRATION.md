# MCP5 Git Integration

MCP5 reads Git metadata such as current branch, commit hash, short hash, commit subject, ref names and dirty files.

When `context-commit --include-git` or `archive-append-event --include-git` is used, the memory record can store the current Git commit subject alongside the hash. This gives the agent a human-readable commit title while keeping Git as the source of code history.

It does not run `git add`, `git commit`, `git reset`, `git checkout`, `git push` or destructive operations.

