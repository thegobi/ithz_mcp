# Project Scenario Tests

The production-readiness runner validates three project shapes.

## New Project

Creates a blank project, adopts a workflow prompt, creates `project.md`, creates `project.ithz`, records a checkpoint and builds a context pack.

Expected result:

- `project.md` exists;
- `project.ithz` exists;
- workflow profile is stored in the archive;
- checkpoint is searchable;
- context pack stays deterministic.

## Adopted Project

Creates a Markdown-heavy project with project brief and workflow docs, plus a secret-like `.env` file and local agent-history fixture.

Expected result:

- existing Markdown is mined into `project.ithz`;
- local agent history is imported summary-only with author/time provenance;
- secret-like values are not searchable;
- no Markdown is deleted or moved.

## Shared Project

Creates base/ours/theirs archives, appends independent memory on both sides and merges with the ITHZ-aware Git merge driver.

Expected result:

- independent memory events merge automatically;
- merged `project.ithz` remains a single archive;
- both authors' memory is searchable;
- Git driver install plan includes `.gitattributes` and semantic merge config;
- unclear conflicts would return `merge_needed`.

Run:

```powershell
python -m ithz_mcp run-mcp21-production-readiness
```

Output:

```text
experiments/mcp21_production_readiness/
  mcp21_project_scenarios_matrix.csv
  mcp21_host_install_matrix.csv
  mcp21_package_matrix.csv
  mcp21_summary.md
```
