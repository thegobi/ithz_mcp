# Agent Instructions

- Work only inside this standalone `ithz_mcp` project unless the user explicitly asks otherwise.
- Load a focused context pack before non-trivial edits once MCP0 is available.
- Do not skip stage gates.
- After each stage, run the stage self-test and update implementation status.
- Do not index secrets, `.env`, private keys, `.git` objects, build artifacts or dependency caches.
- Do not implement cloud or team sync before local checkpoints and context commits.
- ITHZ-MCP complements Git; it does not replace Git.
- MCP8 hardening gates must stay green before MCP shim, write-back, VCS or sync changes.
- If `.ithz-context/` exists, treat repository Markdown as bootstrap/human docs, not authoritative long-term agent memory.
- Ask ITHZ-MCP for a focused context pack before broad Markdown reads.
- For MCP client changes, validate generated configs and run scripted stdio smoke before claiming compatibility.
- For scoring changes, run context quality regression and keep forbidden-claim/no-secret boundaries intact.
- Prompt/response memory is explicit, summary-first and redaction-gated; do not store raw chat by default.
- Local-only prompt memory must not be pushed to team sync.
- Prefer `project.md` as the short human bootstrap manifest and `project.ithz` as the long-term native archive memory source.
- Use ITHZ-MCP native archive commands to call `ithz-native.exe` for pack, safe verify, read/search and logical-file update workflows.
- Use named workflow profiles for personal or team workflow differences; update them with `workflow-ingest-prompt --profile <name>` instead of adding more long-term workflow Markdown.
- When adopting an existing Markdown-heavy project, use `archive-adopt-project-workflow` to mine existing docs into `project.ithz`; do not delete old docs automatically.
- Historical agent prompts/responses may be imported only through explicit `agent-history-discover` and `archive-import-agent-history --apply`; keep imports summary-only and redaction-gated. Use `--author` during team adoption so your local history appends to the shared `project.ithz` with clear provenance instead of overwriting another person's memory.

