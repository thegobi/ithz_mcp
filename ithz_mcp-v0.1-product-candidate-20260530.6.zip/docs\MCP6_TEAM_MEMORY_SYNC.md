# MCP6 Team Memory Sync

MCP6 syncs local context memory through an explicit local shared directory remote.

It does not sync source files and does not provide hidden cloud sync.

MCP8 adds deterministic conflict detection for divergent remote/local context commits and redaction checks before local shared-dir push.

