# MCP0 Spec

MCP0 implements a local deterministic context archive CLI:

- `python -m ithz_mcp init-project --project <path>`
- `python -m ithz_mcp scan-project --project <path> --out <json>`
- `python -m ithz_mcp build-index --project <path>`
- `python -m ithz_mcp search-context --project <path> --query "..."`
- `python -m ithz_mcp get-context-pack --project <path> --query "..." --max-bytes 20000 --out context_pack.md`
- `python -m ithz_mcp context-status --project <path>`
- `python -m ithz_mcp self-test --verbose`
- `python -m ithz_mcp run-mcp0`

MCP0 ignores secrets and build/dependency artifacts by default.

