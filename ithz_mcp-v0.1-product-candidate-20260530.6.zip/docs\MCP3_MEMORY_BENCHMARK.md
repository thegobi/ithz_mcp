# MCP3 Memory Benchmark

MCP3 compares full scan, keyword search and ITHZ-MCP context packs on fixture tasks.

Results are fixture-scoped and must not be generalized into a universal token-saving claim.

