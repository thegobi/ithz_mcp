# MCP7 Productization

MCP7 packages the CLI, docs, sample project and smoke tests into `dist/ithz_mcp-v0.1-alpha`.

This is a tester package, not a production cloud product.

