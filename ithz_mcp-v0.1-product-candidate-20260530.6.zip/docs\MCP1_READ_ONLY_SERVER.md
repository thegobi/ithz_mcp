# MCP1 Read-only Server

MCP1 exposes a stdio JSON-RPC compatible read-only shim when the MCP SDK is not required.

Supported read-only methods:

- `ithz_context_status`
- `ithz_search_context`
- `ithz_get_context_pack`
- `ithz_why_file`

Write tools are disabled in read-only mode.

MCP8 hardening covers line-delimited JSON-RPC input, invalid JSON, missing/unknown method errors, invalid params, request id preservation, notification behavior and deterministic response truncation limits.

