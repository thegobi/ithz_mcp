# Context Compiler Benchmark

MCP10C compares deterministic retrieval modes without an LLM:

- random chunks with fixed seed;
- keyword chunks;
- deterministic support pack;
- deterministic support pack plus context commits.

Metrics include context bytes, recall proxies, false secret inclusion count, duplicate context ratio and deterministic hash stability.

Interpretation is fixture-scoped. The benchmark does not claim that vector databases are useless and does not make a general token-saving claim.

MCP11 adds gate/risk scoring v2 and a context quality regression suite. Scoring remains deterministic: headings, gate/result terms, risk terms, forbidden-claim terms and matrix-column cues. It does not use embeddings, LLM scoring or vector search.
