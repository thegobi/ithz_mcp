# Quickstart

```powershell
python -m ithz_mcp version
python -m ithz_mcp init-project --project fixtures\sample_project
python -m ithz_mcp build-index --project fixtures\sample_project
python -m ithz_mcp search-context --project fixtures\sample_project --query "decision"
python -m ithz_mcp get-context-pack --project fixtures\sample_project --query "what decisions exist" --max-bytes 12000 --out experiments\mcp0_bootstrap\manual_context_pack.md
```

Use context packs before non-trivial edits. ITHZ-MCP complements Git by storing agent work memory.

