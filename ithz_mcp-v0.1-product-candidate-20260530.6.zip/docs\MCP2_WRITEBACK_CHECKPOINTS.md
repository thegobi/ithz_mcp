# MCP2 Write-back Checkpoints

MCP2 adds explicit append-only task summaries and context commits under `.ithz_mcp`.

Write-back is opt-in via CLI commands and is not enabled by the MCP1 read-only server.

