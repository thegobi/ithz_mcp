# MCP1 Codex Usage

Use ITHZ-MCP to fetch focused context packs before edits, but continue to inspect source files directly for final implementation decisions.

ITHZ-MCP is not a replacement for direct source review.

