param([string]$Project='',[switch]$Apply)
$ErrorActionPreference='Stop'
if ([string]::IsNullOrWhiteSpace($Project)) { $Project = (Get-Location).ProviderPath }
$target = Join-Path $Project '.cursor\mcp.json'
$source = Join-Path $PSScriptRoot 'cursor_mcp_config.sample.json'
if (-not $Apply) { Write-Host 'DRY RUN: would copy' $source 'to' $target; exit 0 }
New-Item -ItemType Directory -Force -Path (Split-Path $target) | Out-Null
Copy-Item $source $target -Force
Write-Host 'Installed ITHZ-MCP MCP config:' $target
