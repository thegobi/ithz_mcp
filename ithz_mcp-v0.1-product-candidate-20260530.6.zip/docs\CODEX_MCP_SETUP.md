# Codex MCP Setup

Generate a Codex MCP template, validate it, then run `mcp-client-smoke`.

```powershell
python -m ithz_mcp mcp-config-template --project C:\path\to\project --client codex --out codex_mcp_config.json
python -m ithz_mcp mcp-config-validate --config codex_mcp_config.json
python -m ithz_mcp mcp-client-smoke --config codex_mcp_config.json
```

MCP13 validates scripted stdio `initialize`, `tools/list` and `tools/call`; do not claim broad host certification unless that host was actually tested.

Memory-first behavior is exposed through MCP initialize instructions and `agent_policy.memory_first=true` in generated configs. For hard enforcement, launch the host in a profile that exposes ITHZ-MCP first and broad filesystem/codebase tools only after a context pack is retrieved.
