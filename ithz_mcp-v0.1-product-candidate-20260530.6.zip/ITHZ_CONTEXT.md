# ITHZ Context

This repository is the standalone ITHZ-MCP / ITHZ ContextDB project.

It exists to provide deterministic, auditable agent work memory: decisions, reasons, gates, context packs and next steps.

Current stage order:

1. Stage 0 import and skeleton.
2. MCP0 local context archive CLI.
3. MCP1 read-only MCP server.
4. MCP2 write-back checkpoints.
5. MCP3 memory benchmark and beta adoption.
6. MCP4 context VCS timeline.
7. MCP5 Git metadata integration.
8. MCP6 team memory sync.
9. MCP7 productization and dogfooding.
10. MCP8 local shim, beta fixture, corruption, sync and package hardening.
11. MCP9 native ITHZ read-only dogfooding.
12. MCP10 Markdown-minimal mode, `.ithz-context` layout, compiler benchmark and RC3 packaging.
13. MCP11 MCP config validation, gate/risk scoring v2, native dogfood query suite v2, context quality regression and RC4 packaging.
14. MCP12 explicit prompt/response memory capture with summary default, redaction, context commit linking and team-sync local-only skip.
15. MCP13 real MCP host protocol compatibility and native archive memory using `project.md` plus `project.ithz`.
16. MCP16 Git merge driver for `project.ithz`.
17. MCP17 append-only events, derived indexes and snapshots.
18. MCP18 project workflow intake and end-of-task checkpoint.
19. MCP19 workflow branch profiles for user/team-specific workflow rules inside `project.ithz`.
20. MCP20 project-scoped agent-history import appends summary-only prompt/response records to the shared `project.ithz` with author and time provenance.

