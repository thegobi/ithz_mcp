# ITHZ-MCP v0.1 product candidate

Build: `product-candidate-fast-install-search.20260530.4`

This package is a production-test candidate for local deterministic project memory. It includes native `project.ithz` storage, memory-first MCP configs, host installer scripts, prompt/response summary memory, durable instruction memory, workflow profiles, Git merge driver support and shared-project smoke coverage.

It does not replace Git, a production database, cloud sync, external host history, vector databases or every retrieval system.
