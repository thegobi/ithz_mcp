# ITHZ-MCP Ubuntu package

This package installs the local Python stdio MCP server and CLI for Ubuntu/Linux.

## User-local install

```sh
tar -xzf ithz-mcp-ubuntu.tar.gz
cd ithz-mcp-ubuntu
./install.sh
ithz-mcp version
```

## Debian package install

```sh
sudo apt install ./ithz-mcp-ubuntu.deb
ithz-mcp version
```

- Python 3 is required.
- Host installers are in `host_installers_linux/`.
- `install_ithz.md` is included as the one-file agent install playbook.
- Use `./build_linux_native_package.sh` on Ubuntu to build the bundled native build kit into `native/ithz-native`.
- Use `./install_linux_native.sh` to build and install `ithz-native` into `~/.local/share/ithz-mcp/native/ithz-native`.
- Fallback archive commands are available as `ithz-verify.sh`, `ithz-list.sh`, `ithz-extract-here.sh`, and `ithz-open-temp.sh`; they require a resolved `ithz-native` binary.
- Generated Linux host configs default to `legacy` storage unless you provide a compatible Linux `ithz-native` binary.
- Full Linux Drive/FUSE mount support is not bundled yet; `ithz-open-temp.sh` opens an extraction-backed temporary folder.
- This package does not replace Git, a production database, cloud sync, or every retrieval system.
