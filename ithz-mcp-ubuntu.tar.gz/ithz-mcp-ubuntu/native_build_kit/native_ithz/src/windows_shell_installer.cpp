#include <windows.h>

#include <filesystem>
#include <fstream>
#include <iostream>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace fs = std::filesystem;

namespace {

constexpr int kAvx2ExeResource = 101;
constexpr int kScalarExeResource = 102;
constexpr int kShellPs1Resource = 103;
constexpr int kUninstallPs1Resource = 104;
constexpr int kReadmeResource = 105;
constexpr int kFuseProviderResource = 106;
constexpr int kDokanFuseDllResource = 107;
constexpr int kShellLauncherResource = 108;
constexpr int kIconIcoResource = 109;

struct Options {
    bool install = true;
    bool uninstall = false;
    bool dry_run = false;
    bool remove_files = false;
    std::wstring install_dir;
    std::wstring profile = L"auto";
};

struct NativeSelection {
    int resource_id = kScalarExeResource;
    std::wstring profile = L"scalar";
    bool avx2_supported = false;
};

std::wstring widen_env(const wchar_t* name) {
    const DWORD needed = GetEnvironmentVariableW(name, nullptr, 0);
    if (needed == 0) return L"";
    std::wstring value(needed, L'\0');
    const DWORD written = GetEnvironmentVariableW(name, value.data(), needed);
    if (written == 0) return L"";
    value.resize(written);
    return value;
}

std::wstring default_install_dir() {
    const std::wstring local = widen_env(L"LOCALAPPDATA");
    if (local.empty()) {
        throw std::runtime_error("LOCALAPPDATA is not set");
    }
    return (fs::path(local) / L"ITHZ" / L"shell").wstring();
}

std::wstring json_escape(const std::wstring& value) {
    std::wostringstream out;
    for (wchar_t ch : value) {
        switch (ch) {
            case L'\\': out << L"\\\\"; break;
            case L'"': out << L"\\\""; break;
            case L'\n': out << L"\\n"; break;
            case L'\r': out << L"\\r"; break;
            case L'\t': out << L"\\t"; break;
            default: out << ch; break;
        }
    }
    return out.str();
}

bool avx2_supported() {
    constexpr DWORD kAvx2ProcessorFeature = 40;
    return IsProcessorFeaturePresent(kAvx2ProcessorFeature) != FALSE;
}

bool dokan_runtime_available() {
    const std::wstring windir = widen_env(L"WINDIR");
    if (windir.empty()) return false;
    return fs::exists(fs::path(windir) / L"System32" / L"dokan2.dll");
}

bool use_slovak_labels() {
    WCHAR locale_name[LOCALE_NAME_MAX_LENGTH] = {};
    if (GetUserDefaultLocaleName(locale_name, LOCALE_NAME_MAX_LENGTH) > 0) {
        const std::wstring locale(locale_name);
        if (locale.rfind(L"sk", 0) == 0 || locale.rfind(L"cs", 0) == 0) return true;
    }
    const LANGID lang = GetUserDefaultUILanguage();
    const WORD primary = PRIMARYLANGID(lang);
    return primary == LANG_SLOVAK || primary == LANG_CZECH;
}

struct ShellLabels {
    std::wstring archive_type;
    std::wstring browse_temp;
    std::wstring mount_best;
    std::wstring mount_editable;
    std::wstring mount_drive;
    std::wstring mount_fuse;
    std::wstring unmount_fuse;
    std::wstring open_console;
    std::wstring inspect;
    std::wstring list;
    std::wstring verify;
    std::wstring extract_here;
    std::wstring create_zone;
    std::wstring create_zone_here;
};

ShellLabels shell_labels() {
    if (use_slovak_labels()) {
        return ShellLabels{
            L"ITHZ pamäťová zóna",
            L"Otvoriť v Prieskumníkovi",
            L"Otvoriť ITHZ jednotku",
            L"Otvoriť upraviteľný priečinok",
            L"Otvoriť upraviteľnú jednotku",
            L"Otvoriť virtuálnu ITHZ jednotku",
            L"Odpojiť ITHZ jednotku",
            L"Otvoriť textový náhľad",
            L"Zobraziť rodiny",
            L"Zobraziť obsah",
            L"Bezpečne overiť",
            L"Rozbaliť sem",
            L"Vytvoriť ITHZ zónu",
            L"Vytvoriť ITHZ zónu tu",
        };
    }
    return ShellLabels{
        L"ITHZ Memory Zone",
        L"Browse in Explorer",
        L"Open ITHZ drive",
        L"Open editable folder",
        L"Open editable drive",
        L"Open virtual ITHZ drive",
        L"Unmount ITHZ drive",
        L"Open text view",
        L"Inspect families",
        L"List contents",
        L"Verify safe",
        L"Extract here",
        L"Create ITHZ zone",
        L"Create ITHZ zone here",
    };
}

void print_usage() {
    std::wcout
        << L"ITHZ shell installer\n\n"
        << L"Usage:\n"
        << L"  ithz-shell-installer.exe [--install] [--dry-run] [--profile auto|avx2|scalar]\n"
        << L"  ithz-shell-installer.exe --uninstall [--remove-files]\n\n"
        << L"Options:\n"
        << L"  --install-dir <dir>   Install folder, default %LOCALAPPDATA%\\ITHZ\\shell\n"
        << L"  --profile <profile>   auto, avx2, or scalar\n"
        << L"  --dry-run             Print planned actions without writing files/registry\n"
        << L"  --remove-files        With --uninstall, remove installed files too\n"
        << L"  Dokan/FUSE provider is installed with the shell files; real virtual drive\n"
        << L"  mounting requires the Dokany runtime to be installed on Windows.\n"
        << L"  --help                Show this help\n";
}

Options parse_args(int argc, wchar_t** argv) {
    Options opt;
    for (int i = 1; i < argc; ++i) {
        const std::wstring arg = argv[i];
        if (arg == L"--help" || arg == L"-h" || arg == L"/?") {
            print_usage();
            ExitProcess(0);
        } else if (arg == L"--install") {
            opt.install = true;
            opt.uninstall = false;
        } else if (arg == L"--uninstall") {
            opt.install = false;
            opt.uninstall = true;
        } else if (arg == L"--dry-run") {
            opt.dry_run = true;
        } else if (arg == L"--remove-files") {
            opt.remove_files = true;
        } else if (arg == L"--install-dir") {
            if (++i >= argc) throw std::runtime_error("--install-dir requires a value");
            opt.install_dir = argv[i];
        } else if (arg == L"--profile") {
            if (++i >= argc) throw std::runtime_error("--profile requires a value");
            opt.profile = argv[i];
            if (opt.profile != L"auto" && opt.profile != L"avx2" && opt.profile != L"scalar") {
                throw std::runtime_error("--profile must be auto, avx2, or scalar");
            }
        } else {
            std::wcerr << L"Unknown argument: " << arg << L"\n";
            throw std::runtime_error("unknown argument");
        }
    }
    if (opt.install_dir.empty()) opt.install_dir = default_install_dir();
    return opt;
}

NativeSelection select_native(const Options& opt) {
    NativeSelection selected;
    selected.avx2_supported = avx2_supported();
    if (opt.profile == L"avx2") {
        if (!selected.avx2_supported) {
            throw std::runtime_error("AVX2 profile was requested, but this CPU/OS does not report AVX2 support");
        }
        selected.resource_id = kAvx2ExeResource;
        selected.profile = L"avx2";
    } else if (opt.profile == L"scalar") {
        selected.resource_id = kScalarExeResource;
        selected.profile = L"scalar";
    } else if (selected.avx2_supported) {
        selected.resource_id = kAvx2ExeResource;
        selected.profile = L"avx2";
    }
    return selected;
}

std::string resource_bytes(int id) {
    HMODULE module = GetModuleHandleW(nullptr);
    HRSRC res = FindResourceW(module, MAKEINTRESOURCEW(id), MAKEINTRESOURCEW(10));
    if (!res) throw std::runtime_error("embedded resource not found");
    HGLOBAL loaded = LoadResource(module, res);
    if (!loaded) throw std::runtime_error("embedded resource could not be loaded");
    DWORD size = SizeofResource(module, res);
    void* data = LockResource(loaded);
    if (!data || size == 0) throw std::runtime_error("embedded resource is empty");
    return std::string(static_cast<const char*>(data), static_cast<size_t>(size));
}

void write_binary_file(const fs::path& path, const std::string& data, bool dry_run) {
    if (dry_run) {
        std::wcout << L"[dry-run] write " << path.wstring() << L" (" << data.size() << L" bytes)\n";
        return;
    }
    fs::create_directories(path.parent_path());
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) throw std::runtime_error("failed to open output file");
    out.write(data.data(), static_cast<std::streamsize>(data.size()));
}

void write_text_file(const fs::path& path, const std::wstring& text, bool dry_run) {
    if (dry_run) {
        std::wcout << L"[dry-run] write " << path.wstring() << L"\n";
        return;
    }
    fs::create_directories(path.parent_path());
    std::wofstream out(path, std::ios::trunc);
    if (!out) throw std::runtime_error("failed to open output file");
    out << text;
}

std::optional<std::wstring> read_reg_default(HKEY root, const std::wstring& subkey) {
    HKEY key = nullptr;
    if (RegOpenKeyExW(root, subkey.c_str(), 0, KEY_QUERY_VALUE, &key) != ERROR_SUCCESS) {
        return std::nullopt;
    }
    DWORD type = 0;
    DWORD bytes = 0;
    const LONG probe = RegQueryValueExW(key, nullptr, nullptr, &type, nullptr, &bytes);
    if (probe != ERROR_SUCCESS || (type != REG_SZ && type != REG_EXPAND_SZ)) {
        RegCloseKey(key);
        return std::nullopt;
    }
    std::wstring value(bytes / sizeof(wchar_t), L'\0');
    const LONG read = RegQueryValueExW(key, nullptr, nullptr, &type, reinterpret_cast<LPBYTE>(value.data()), &bytes);
    RegCloseKey(key);
    if (read != ERROR_SUCCESS) return std::nullopt;
    while (!value.empty() && value.back() == L'\0') value.pop_back();
    return value;
}

void set_reg_default(const std::wstring& subkey, const std::wstring& value, bool dry_run) {
    if (dry_run) {
        std::wcout << L"[dry-run] HKCU\\" << subkey << L" = " << value << L"\n";
        return;
    }
    HKEY key = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, subkey.c_str(), 0, nullptr, 0, KEY_SET_VALUE, nullptr, &key, nullptr) != ERROR_SUCCESS) {
        throw std::runtime_error("failed to create registry key");
    }
    const DWORD bytes = static_cast<DWORD>((value.size() + 1) * sizeof(wchar_t));
    const LONG status = RegSetValueExW(key, nullptr, 0, REG_SZ, reinterpret_cast<const BYTE*>(value.c_str()), bytes);
    RegCloseKey(key);
    if (status != ERROR_SUCCESS) throw std::runtime_error("failed to set registry value");
}

void set_reg_string_value(const std::wstring& subkey, const std::wstring& name, const std::wstring& value, bool dry_run) {
    if (dry_run) {
        std::wcout << L"[dry-run] HKCU\\" << subkey << L" /v " << name << L" = " << value << L"\n";
        return;
    }
    HKEY key = nullptr;
    if (RegCreateKeyExW(HKEY_CURRENT_USER, subkey.c_str(), 0, nullptr, 0, KEY_SET_VALUE, nullptr, &key, nullptr) != ERROR_SUCCESS) {
        throw std::runtime_error("failed to create registry key");
    }
    const DWORD bytes = static_cast<DWORD>((value.size() + 1) * sizeof(wchar_t));
    const LONG status = RegSetValueExW(key, name.c_str(), 0, REG_SZ, reinterpret_cast<const BYTE*>(value.c_str()), bytes);
    RegCloseKey(key);
    if (status != ERROR_SUCCESS) throw std::runtime_error("failed to set registry named value");
}

std::optional<std::wstring> read_previous_association(const fs::path& install_dir) {
    const fs::path state = install_dir / L"install_state.json";
    if (!fs::exists(state)) return std::nullopt;
    std::wifstream in(state);
    if (!in) return std::nullopt;
    std::wstringstream buffer;
    buffer << in.rdbuf();
    const std::wstring text = buffer.str();
    const std::wstring key = L"\"previousIthzDefault\"";
    const size_t key_pos = text.find(key);
    if (key_pos == std::wstring::npos) return std::nullopt;
    const size_t colon = text.find(L':', key_pos + key.size());
    if (colon == std::wstring::npos) return std::nullopt;
    const size_t first_quote = text.find(L'"', colon + 1);
    if (first_quote == std::wstring::npos) return std::nullopt;

    std::wstring value;
    bool escaped = false;
    for (size_t i = first_quote + 1; i < text.size(); ++i) {
        const wchar_t ch = text[i];
        if (escaped) {
            value.push_back(ch);
            escaped = false;
        } else if (ch == L'\\') {
            escaped = true;
        } else if (ch == L'"') {
            return value;
        } else {
            value.push_back(ch);
        }
    }
    return std::nullopt;
}

void delete_reg_tree(const std::wstring& subkey, bool dry_run) {
    if (dry_run) {
        std::wcout << L"[dry-run] delete HKCU\\" << subkey << L"\n";
        return;
    }
    RegDeleteTreeW(HKEY_CURRENT_USER, subkey.c_str());
}

std::wstring ps_command(const fs::path& script, const std::wstring& action, const std::wstring& target_token, bool explorer) {
    std::wstring command = L"powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"";
    command += script.wstring();
    command += L"\" ";
    command += action;
    command += L" \"";
    command += target_token;
    command += L"\"";
    if (explorer) command += L" -Explorer";
    return command;
}

std::wstring launcher_command(const fs::path& launcher, const std::wstring& action, const std::wstring& target_token) {
    std::wstring command = L"\"";
    command += launcher.wstring();
    command += L"\" ";
    command += action;
    command += L" \"";
    command += target_token;
    command += L"\"";
    return command;
}

void install_registry(const fs::path& install_dir, bool dry_run) {
    const fs::path launcher = install_dir / L"ithz-shell-launcher.exe";
    const fs::path icon = install_dir / L"ithz-zone.ico";
    auto labels = shell_labels();
    if (use_slovak_labels()) {
        labels.unmount_fuse = L"Odpojiť ITHZ jednotku";
    }

    set_reg_default(L"Software\\Classes\\.ithz", L"ITHZ.Archive", dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive", labels.archive_type, dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\DefaultIcon", L"\"" + icon.wstring() + L"\",0", dry_run);
    delete_reg_tree(L"Software\\Classes\\ITHZ.Archive\\shell", dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\open\\command", launcher_command(launcher, L"MountBest", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\01_browse_temp", labels.browse_temp, dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\01_browse_temp\\command", launcher_command(launcher, L"BrowseTemp", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\02_extract_here", labels.extract_here, dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\02_extract_here\\command", launcher_command(launcher, L"ExtractHere", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\03_mount_best", labels.mount_best, dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\03_mount_best\\command", launcher_command(launcher, L"MountBest", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\04_unmount_fuse", labels.unmount_fuse, dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\04_unmount_fuse\\command", launcher_command(launcher, L"UnmountAnyDrive", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\05_verify", labels.verify, dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\05_verify\\command", launcher_command(launcher, L"Verify", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\90_open_console", labels.open_console, dry_run);
    set_reg_string_value(L"Software\\Classes\\ITHZ.Archive\\shell\\90_open_console", L"Extended", L"", dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\90_open_console\\command", launcher_command(launcher, L"Open", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\91_inspect", labels.inspect, dry_run);
    set_reg_string_value(L"Software\\Classes\\ITHZ.Archive\\shell\\91_inspect", L"Extended", L"", dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\91_inspect\\command", launcher_command(launcher, L"Inspect", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\92_list", labels.list, dry_run);
    set_reg_string_value(L"Software\\Classes\\ITHZ.Archive\\shell\\92_list", L"Extended", L"", dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\92_list\\command", launcher_command(launcher, L"List", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\93_mount_editable", labels.mount_editable, dry_run);
    set_reg_string_value(L"Software\\Classes\\ITHZ.Archive\\shell\\93_mount_editable", L"Extended", L"", dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\93_mount_editable\\command", launcher_command(launcher, L"MountEditable", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\94_mount_drive", labels.mount_drive, dry_run);
    set_reg_string_value(L"Software\\Classes\\ITHZ.Archive\\shell\\94_mount_drive", L"Extended", L"", dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\94_mount_drive\\command", launcher_command(launcher, L"MountDrive", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\95_mount_fuse", labels.mount_fuse, dry_run);
    set_reg_string_value(L"Software\\Classes\\ITHZ.Archive\\shell\\95_mount_fuse", L"Extended", L"", dry_run);
    set_reg_default(L"Software\\Classes\\ITHZ.Archive\\shell\\95_mount_fuse\\command", launcher_command(launcher, L"MountFuse", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\Directory\\shell\\ITHZ.CreateZone", labels.create_zone, dry_run);
    set_reg_default(L"Software\\Classes\\Directory\\shell\\ITHZ.CreateZone\\command", launcher_command(launcher, L"CreateZone", L"%1"), dry_run);
    set_reg_default(L"Software\\Classes\\Directory\\Background\\shell\\ITHZ.CreateZoneHere", labels.create_zone_here, dry_run);
    set_reg_default(L"Software\\Classes\\Directory\\Background\\shell\\ITHZ.CreateZoneHere\\command", launcher_command(launcher, L"CreateZone", L"%V"), dry_run);
    set_reg_default(L"Software\\Classes\\*\\shell\\ITHZ.CreateZone", labels.create_zone, dry_run);
    set_reg_string_value(L"Software\\Classes\\*\\shell\\ITHZ.CreateZone", L"Extended", L"", dry_run);
    set_reg_default(L"Software\\Classes\\*\\shell\\ITHZ.CreateZone\\command", launcher_command(launcher, L"CreateZone", L"%1"), dry_run);
}

void uninstall_registry(const fs::path& install_dir, bool dry_run) {
    delete_reg_tree(L"Software\\Classes\\ITHZ.Archive", dry_run);
    delete_reg_tree(L"Software\\Classes\\Directory\\shell\\ITHZ.CreateZone", dry_run);
    delete_reg_tree(L"Software\\Classes\\Directory\\Background\\shell\\ITHZ.CreateZoneHere", dry_run);
    delete_reg_tree(L"Software\\Classes\\*\\shell\\ITHZ.CreateZone", dry_run);
    const auto default_ithz = read_reg_default(HKEY_CURRENT_USER, L"Software\\Classes\\.ithz");
    if (default_ithz && *default_ithz == L"ITHZ.Archive") {
        const auto previous = read_previous_association(install_dir);
        if (previous && !previous->empty()) {
            set_reg_default(L"Software\\Classes\\.ithz", *previous, dry_run);
        } else {
            delete_reg_tree(L"Software\\Classes\\.ithz", dry_run);
        }
    } else {
        std::wcout << L"Leaving .ithz association untouched; it is not owned by ITHZ.Archive.\n";
    }
}

void install(const Options& opt) {
    const NativeSelection native = select_native(opt);
    const fs::path install_dir(opt.install_dir);
    const fs::path shell = install_dir / L"ithz-shell.ps1";
    const fs::path uninstall_ps1 = install_dir / L"uninstall_ithz_shell.ps1";
    const fs::path readme = install_dir / L"README_WINDOWS_SHELL.md";
    const fs::path native_exe = install_dir / L"ithz-native.exe";
    const fs::path fuse_provider = install_dir / L"ithz-fuse-provider.exe";
    const fs::path dokanfuse_dll = install_dir / L"dokanfuse2.dll";
    const fs::path launcher_exe = install_dir / L"ithz-shell-launcher.exe";
    const fs::path icon_ico = install_dir / L"ithz-zone.ico";
    const fs::path cmd = install_dir / L"ithz-shell.cmd";
    const fs::path config = install_dir / L"ithz-shell.config.json";
    const fs::path state = install_dir / L"install_state.json";
    const bool dokan_available = dokan_runtime_available();

    std::wcout << L"ITHZ shell installer\n"
               << L"Install dir: " << install_dir.wstring() << L"\n"
               << L"Native profile: " << native.profile << L"\n"
               << L"AVX2 supported: " << (native.avx2_supported ? L"true" : L"false") << L"\n"
               << L"Dokany runtime: " << (dokan_available ? L"available" : L"missing") << L"\n"
               << L"Mode: " << (opt.dry_run ? L"dry-run" : L"install") << L"\n";

    if (!opt.dry_run) fs::create_directories(install_dir);
    write_binary_file(native_exe, resource_bytes(native.resource_id), opt.dry_run);
    write_binary_file(shell, resource_bytes(kShellPs1Resource), opt.dry_run);
    write_binary_file(uninstall_ps1, resource_bytes(kUninstallPs1Resource), opt.dry_run);
    write_binary_file(readme, resource_bytes(kReadmeResource), opt.dry_run);
    write_binary_file(fuse_provider, resource_bytes(kFuseProviderResource), opt.dry_run);
    write_binary_file(dokanfuse_dll, resource_bytes(kDokanFuseDllResource), opt.dry_run);
    write_binary_file(launcher_exe, resource_bytes(kShellLauncherResource), opt.dry_run);
    write_binary_file(icon_ico, resource_bytes(kIconIcoResource), opt.dry_run);

    write_text_file(cmd, L"@echo off\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File \"%~dp0ithz-shell.ps1\" %*\r\n", opt.dry_run);

    const auto previous = read_reg_default(HKEY_CURRENT_USER, L"Software\\Classes\\.ithz").value_or(L"");
    std::wostringstream config_json;
    config_json << L"{\n"
                << L"  \"nativeExe\": \"" << json_escape(native_exe.wstring()) << L"\",\n"
                << L"  \"fuseProviderExe\": \"" << json_escape(fuse_provider.wstring()) << L"\",\n"
                << L"  \"dokanFuseDll\": \"" << json_escape(dokanfuse_dll.wstring()) << L"\",\n"
                << L"  \"shellLauncherExe\": \"" << json_escape(launcher_exe.wstring()) << L"\",\n"
                << L"  \"iconIco\": \"" << json_escape(icon_ico.wstring()) << L"\",\n"
                << L"  \"nativeProfile\": \"" << json_escape(native.profile) << L"\",\n"
                << L"  \"avx2Supported\": " << (native.avx2_supported ? L"true" : L"false") << L",\n"
                << L"  \"dokanRuntimeAvailable\": " << (dokan_available ? L"true" : L"false") << L",\n"
                << L"  \"installerKind\": \"single-exe\"\n"
                << L"}\n";
    write_text_file(config, config_json.str(), opt.dry_run);

    std::wostringstream state_json;
    state_json << L"{\n"
               << L"  \"installedBy\": \"ITHZ single-exe shell installer\",\n"
               << L"  \"previousIthzDefault\": \"" << json_escape(previous) << L"\",\n"
               << L"  \"nativeProfile\": \"" << json_escape(native.profile) << L"\",\n"
               << L"  \"avx2Supported\": " << (native.avx2_supported ? L"true" : L"false") << L",\n"
               << L"  \"dokanRuntimeAvailable\": " << (dokan_available ? L"true" : L"false") << L"\n"
               << L"}\n";
    write_text_file(state, state_json.str(), opt.dry_run);

    install_registry(install_dir, opt.dry_run);
    std::wcout << (opt.dry_run ? L"Dry-run complete.\n" : L"Installed. Restart Explorer if menu entries do not appear immediately.\n");
}

void uninstall(const Options& opt) {
    const fs::path install_dir(opt.install_dir);
    std::wcout << L"ITHZ shell uninstaller\n"
               << L"Install dir: " << install_dir.wstring() << L"\n"
               << L"Mode: " << (opt.dry_run ? L"dry-run" : L"uninstall") << L"\n";
    uninstall_registry(install_dir, opt.dry_run);
    if (opt.remove_files) {
        if (opt.dry_run) {
            std::wcout << L"[dry-run] remove " << install_dir.wstring() << L"\n";
        } else if (fs::exists(install_dir)) {
            fs::remove_all(install_dir);
        }
    }
    std::wcout << (opt.dry_run ? L"Dry-run complete.\n" : L"Uninstalled.\n");
}

}  // namespace

int wmain(int argc, wchar_t** argv) {
    try {
        const Options opt = parse_args(argc, argv);
        if (opt.uninstall) {
            uninstall(opt);
        } else {
            install(opt);
        }
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << "error: " << ex.what() << "\n";
        return 1;
    }
}
