#include <windows.h>
#include <shellapi.h>

#include <filesystem>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

std::wstring quote_arg(const std::wstring& value) {
    std::wstring out = L"\"";
    for (wchar_t ch : value) {
        if (ch == L'"') out += L'\\';
        out += ch;
    }
    out += L"\"";
    return out;
}

std::wstring module_dir() {
    std::wstring buffer(MAX_PATH, L'\0');
    DWORD size = GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
    while (size == buffer.size()) {
        buffer.resize(buffer.size() * 2, L'\0');
        size = GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
    }
    buffer.resize(size);
    return fs::path(buffer).parent_path().wstring();
}

std::wstring local_appdata() {
    DWORD needed = GetEnvironmentVariableW(L"LOCALAPPDATA", nullptr, 0);
    if (needed == 0) return module_dir();
    std::wstring value(needed, L'\0');
    DWORD written = GetEnvironmentVariableW(L"LOCALAPPDATA", value.data(), needed);
    if (written == 0) return module_dir();
    value.resize(written);
    return value;
}

std::wstring nowish_log_path() {
    const fs::path dir = fs::path(local_appdata()) / L"ITHZ" / L"shell" / L"logs";
    std::error_code ec;
    fs::create_directories(dir, ec);
    return (dir / L"ithz-shell-last.log").wstring();
}

bool should_skip_launch(int argc, wchar_t** argv) {
    if (argc < 2 || argv[1] == nullptr) return true;
    const std::wstring action = argv[1];
    return action == L"CreateZone" ||
           action == L"ExtractHere" ||
           action == L"CommitMount" ||
           action == L"DiscardMount" ||
           action == L"MountStatus" ||
           action == L"WatchMount" ||
           action == L"UnmountDrive" ||
           action == L"UnmountFuse" ||
           action == L"UnmountAnyDrive";
}

std::wstring join_args(int argc, wchar_t** argv) {
    std::wstring script = fs::path(module_dir()) / L"ithz-shell.ps1";
    std::wstring cmd = L"powershell.exe -NoProfile -ExecutionPolicy Bypass -File ";
    cmd += quote_arg(script);
    for (int i = 1; i < argc; ++i) {
        cmd += L" ";
        cmd += quote_arg(argv[i]);
    }
    if (should_skip_launch(argc, argv)) {
        cmd += L" -NoLaunch";
    }
    return cmd;
}

void show_error(const std::wstring& message) {
    MessageBoxW(nullptr, message.c_str(), L"ITHZ Shell", MB_OK | MB_ICONERROR);
}

}  // namespace

int WINAPI wWinMain(HINSTANCE, HINSTANCE, PWSTR, int) {
    int argc = 0;
    wchar_t** argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (!argv) {
        show_error(L"Failed to parse command line.");
        return 1;
    }

    const std::wstring log_path = nowish_log_path();
    HANDLE log = CreateFileW(
        log_path.c_str(),
        GENERIC_WRITE,
        FILE_SHARE_READ,
        nullptr,
        CREATE_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        nullptr
    );
    if (log == INVALID_HANDLE_VALUE) {
        LocalFree(argv);
        show_error(L"Failed to create ITHZ shell log.");
        return 1;
    }

    std::wstring command = join_args(argc, argv);
    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
    si.wShowWindow = SW_HIDE;
    si.hStdOutput = log;
    si.hStdError = log;
    PROCESS_INFORMATION pi{};
    std::vector<wchar_t> mutable_command(command.begin(), command.end());
    mutable_command.push_back(L'\0');
    BOOL ok = CreateProcessW(
        nullptr,
        mutable_command.data(),
        nullptr,
        nullptr,
        TRUE,
        CREATE_NO_WINDOW,
        nullptr,
        nullptr,
        &si,
        &pi
    );
    if (!ok) {
        CloseHandle(log);
        LocalFree(argv);
        show_error(L"Failed to start ITHZ shell action.");
        return 1;
    }

    WaitForSingleObject(pi.hProcess, INFINITE);
    DWORD exit_code = 1;
    GetExitCodeProcess(pi.hProcess, &exit_code);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    CloseHandle(log);
    LocalFree(argv);

    if (exit_code != 0) {
        show_error(L"ITHZ action failed. See log:\n" + log_path);
    }
    return static_cast<int>(exit_code);
}
