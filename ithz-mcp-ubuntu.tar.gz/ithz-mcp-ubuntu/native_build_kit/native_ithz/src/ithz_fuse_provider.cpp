#define FUSE_USE_VERSION 27

#include <fuse.h>

#include <windows.h>
#include <bcrypt.h>

#include <algorithm>
#include <cctype>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <filesystem>
#include <map>
#include <mutex>
#include <optional>
#include <set>
#include <sstream>
#include <string>
#include <string_view>
#include <vector>

#ifndef S_IFDIR
#define S_IFDIR 0040000
#endif
#ifndef S_IFREG
#define S_IFREG 0100000
#endif

namespace {

struct Entry {
    bool directory = false;
    std::uint64_t size = 0;
};

struct FileHandle {
    std::string path;
    std::vector<std::uint8_t> data;
    bool dirty = false;
};

struct ProviderState {
    std::wstring native_exe;
    std::wstring archive;
    std::string archive_hash;
    bool read_write = false;
    std::mutex mutex;
    std::map<std::string, Entry> entries;
    std::map<std::string, std::set<std::string>> children;
};

ProviderState *g_provider_state = nullptr;

void debug_log(const std::string &line) {
    wchar_t path_buffer[MAX_PATH]{};
    const DWORD len = GetEnvironmentVariableW(L"ITHZ_FUSE_DEBUG_LOG", path_buffer, MAX_PATH);
    if (len == 0 || len >= MAX_PATH) {
        return;
    }
    HANDLE file = CreateFileW(path_buffer, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE, nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) {
        return;
    }
    std::string out = line + "\r\n";
    DWORD written = 0;
    WriteFile(file, out.data(), static_cast<DWORD>(out.size()), &written, nullptr);
    CloseHandle(file);
}

ProviderState *state() {
    auto *ctx = fuse_get_context();
    if (!ctx || !ctx->private_data) {
        return g_provider_state;
    }
    return static_cast<ProviderState *>(ctx->private_data);
}

std::wstring widen_utf8(const std::string &input) {
    if (input.empty()) {
        return L"";
    }
    const int needed = MultiByteToWideChar(CP_UTF8, 0, input.data(), static_cast<int>(input.size()), nullptr, 0);
    if (needed <= 0) {
        return L"";
    }
    std::wstring out(static_cast<std::size_t>(needed), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, input.data(), static_cast<int>(input.size()), out.data(), needed);
    return out;
}

std::string narrow_utf8(const std::wstring &input) {
    if (input.empty()) {
        return "";
    }
    const int needed = WideCharToMultiByte(CP_UTF8, 0, input.data(), static_cast<int>(input.size()), nullptr, 0, nullptr, nullptr);
    if (needed <= 0) {
        return "";
    }
    std::string out(static_cast<std::size_t>(needed), '\0');
    WideCharToMultiByte(CP_UTF8, 0, input.data(), static_cast<int>(input.size()), out.data(), needed, nullptr, nullptr);
    return out;
}

std::wstring quote_arg(const std::wstring &arg) {
    std::wstring out = L"\"";
    std::size_t slash_count = 0;
    for (const wchar_t ch : arg) {
        if (ch == L'\\') {
            ++slash_count;
        } else if (ch == L'"') {
            out.append(slash_count * 2 + 1, L'\\');
            out.push_back(ch);
            slash_count = 0;
        } else {
            out.append(slash_count, L'\\');
            slash_count = 0;
            out.push_back(ch);
        }
    }
    out.append(slash_count * 2, L'\\');
    out.push_back(L'"');
    return out;
}

struct ProcessResult {
    DWORD exit_code = 1;
    std::vector<std::uint8_t> output;
};

ProcessResult run_process(const std::wstring &command_line, const std::vector<std::uint8_t> *stdin_bytes = nullptr) {
    SECURITY_ATTRIBUTES sa{};
    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;

    HANDLE child_stdout_read = nullptr;
    HANDLE child_stdout_write = nullptr;
    if (!CreatePipe(&child_stdout_read, &child_stdout_write, &sa, 0)) {
        return {};
    }
    SetHandleInformation(child_stdout_read, HANDLE_FLAG_INHERIT, 0);

    HANDLE child_stdin_read = nullptr;
    HANDLE child_stdin_write = nullptr;
    if (stdin_bytes) {
        if (!CreatePipe(&child_stdin_read, &child_stdin_write, &sa, 0)) {
            CloseHandle(child_stdout_read);
            CloseHandle(child_stdout_write);
            return {};
        }
        SetHandleInformation(child_stdin_write, HANDLE_FLAG_INHERIT, 0);
    }

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES;
    si.hStdOutput = child_stdout_write;
    si.hStdError = child_stdout_write;
    si.hStdInput = stdin_bytes ? child_stdin_read : GetStdHandle(STD_INPUT_HANDLE);

    PROCESS_INFORMATION pi{};
    std::wstring mutable_cmd = command_line;
    const BOOL ok = CreateProcessW(
        nullptr,
        mutable_cmd.data(),
        nullptr,
        nullptr,
        TRUE,
        CREATE_NO_WINDOW,
        nullptr,
        nullptr,
        &si,
        &pi);

    CloseHandle(child_stdout_write);
    if (child_stdin_read) {
        CloseHandle(child_stdin_read);
    }

    ProcessResult result{};
    if (!ok) {
        if (child_stdin_write) {
            CloseHandle(child_stdin_write);
        }
        CloseHandle(child_stdout_read);
        return result;
    }

    if (stdin_bytes && child_stdin_write) {
        DWORD written = 0;
        std::size_t pos = 0;
        while (pos < stdin_bytes->size()) {
            const DWORD chunk = static_cast<DWORD>(std::min<std::size_t>(stdin_bytes->size() - pos, 64 * 1024));
            if (!WriteFile(child_stdin_write, stdin_bytes->data() + pos, chunk, &written, nullptr)) {
                break;
            }
            pos += written;
        }
        CloseHandle(child_stdin_write);
    }

    std::uint8_t buffer[8192];
    DWORD read = 0;
    while (ReadFile(child_stdout_read, buffer, sizeof(buffer), &read, nullptr) && read > 0) {
        result.output.insert(result.output.end(), buffer, buffer + read);
    }

    WaitForSingleObject(pi.hProcess, INFINITE);
    GetExitCodeProcess(pi.hProcess, &result.exit_code);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    CloseHandle(child_stdout_read);
    return result;
}

std::wstring native_command(const ProviderState &s, const std::vector<std::wstring> &args) {
    std::wstring cmd = quote_arg(s.native_exe);
    for (const auto &arg : args) {
        cmd.push_back(L' ');
        cmd += quote_arg(arg);
    }
    return cmd;
}

std::string bytes_to_string(const std::vector<std::uint8_t> &bytes) {
    return std::string(reinterpret_cast<const char *>(bytes.data()), bytes.size());
}

std::vector<std::string> split_csv_simple(const std::string &line) {
    std::vector<std::string> out;
    std::string current;
    for (const char ch : line) {
        if (ch == ',') {
            out.push_back(current);
            current.clear();
        } else {
            current.push_back(ch);
        }
    }
    out.push_back(current);
    return out;
}

std::string lowercase(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return value;
}

bool is_reserved_windows_name(std::string component) {
    const auto dot = component.find('.');
    if (dot != std::string::npos) {
        component = component.substr(0, dot);
    }
    component = lowercase(component);
    static const std::set<std::string> reserved = {
        "con", "prn", "aux", "nul", "com1", "com2", "com3", "com4", "com5", "com6", "com7", "com8", "com9",
        "lpt1", "lpt2", "lpt3", "lpt4", "lpt5", "lpt6", "lpt7", "lpt8", "lpt9"};
    return reserved.count(component) != 0;
}

bool safe_archive_path(const std::string &path) {
    if (path.empty() || path.size() > 240 || path[0] == '/' || path.find('\\') != std::string::npos || path.find(':') != std::string::npos) {
        return false;
    }
    std::stringstream ss(path);
    std::string part;
    while (std::getline(ss, part, '/')) {
        if (part.empty() || part == "." || part == "..") {
            return false;
        }
        const char last = part.back();
        if (last == '.' || last == ' ') {
            return false;
        }
        for (const unsigned char ch : part) {
            if (ch < 0x20) {
                return false;
            }
        }
        if (is_reserved_windows_name(part)) {
            return false;
        }
    }
    return true;
}

std::optional<std::string> fuse_to_archive_path(const char *raw_path) {
    if (!raw_path) {
        return std::nullopt;
    }
    std::string path(raw_path);
    if (path == "/") {
        return std::string();
    }
    std::replace(path.begin(), path.end(), '\\', '/');
    while (!path.empty() && path[0] == '/') {
        path.erase(path.begin());
    }
    if (path.empty()) {
        return std::string();
    }
    if (!safe_archive_path(path)) {
        return std::nullopt;
    }
    return path;
}

void clear_index(ProviderState &s) {
    s.entries.clear();
    s.children.clear();
    s.entries[""] = Entry{true, 0};
}

void add_file_to_index(ProviderState &s, const std::string &path, std::uint64_t size) {
    s.entries[path] = Entry{false, size};
    std::string parent;
    std::stringstream ss(path);
    std::string part;
    std::vector<std::string> parts;
    while (std::getline(ss, part, '/')) {
        parts.push_back(part);
    }
    for (std::size_t i = 0; i + 1 < parts.size(); ++i) {
        const std::string next = parent.empty() ? parts[i] : parent + "/" + parts[i];
        s.entries[next] = Entry{true, 0};
        s.children[parent].insert(parts[i]);
        parent = next;
    }
    s.children[parent].insert(parts.back());
}

bool refresh_index(ProviderState &s) {
    const auto cmd = native_command(s, {L"--list", s.archive});
    const ProcessResult result = run_process(cmd);
    if (result.exit_code != 0) {
        debug_log("refresh_index failed exit=" + std::to_string(result.exit_code));
        return false;
    }
    debug_log("refresh_index output=" + bytes_to_string(result.output));
    clear_index(s);
    std::stringstream text(bytes_to_string(result.output));
    std::string line;
    bool first = true;
    while (std::getline(text, line)) {
        if (!line.empty() && line.back() == '\r') {
            line.pop_back();
        }
        if (line.empty()) {
            continue;
        }
        if (first) {
            first = false;
            continue;
        }
        const auto cols = split_csv_simple(line);
        if (cols.size() < 5 || cols[0].find(',') != std::string::npos || !safe_archive_path(cols[0])) {
            return false;
        }
        try {
            add_file_to_index(s, cols[0], static_cast<std::uint64_t>(std::stoull(cols[1])));
            debug_log("indexed " + cols[0]);
        } catch (...) {
            return false;
        }
    }
    debug_log("entry_count=" + std::to_string(s.entries.size()));
    return true;
}

std::string sha256_file_hex(const std::wstring &path) {
    HANDLE file = CreateFileW(path.c_str(), GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) {
        return {};
    }
    BCRYPT_ALG_HANDLE alg = nullptr;
    BCRYPT_HASH_HANDLE hash = nullptr;
    std::string hex;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, 0) == 0 &&
        BCryptCreateHash(alg, &hash, nullptr, 0, nullptr, 0, 0) == 0) {
        std::uint8_t buf[64 * 1024];
        DWORD read = 0;
        while (ReadFile(file, buf, sizeof(buf), &read, nullptr) && read > 0) {
            BCryptHashData(hash, buf, read, 0);
        }
        std::uint8_t digest[32];
        if (BCryptFinishHash(hash, digest, sizeof(digest), 0) == 0) {
            static constexpr char table[] = "0123456789abcdef";
            for (const auto b : digest) {
                hex.push_back(table[b >> 4]);
                hex.push_back(table[b & 0x0f]);
            }
        }
    }
    if (hash) {
        BCryptDestroyHash(hash);
    }
    if (alg) {
        BCryptCloseAlgorithmProvider(alg, 0);
    }
    CloseHandle(file);
    return hex;
}

std::vector<std::uint8_t> extract_file(ProviderState &s, const std::string &path) {
    const auto cmd = native_command(s, {L"--extract-file", s.archive, L"--path", widen_utf8(path), L"--output", L"-"});
    const ProcessResult result = run_process(cmd);
    if (result.exit_code != 0) {
        return {};
    }
    return result.output;
}

bool update_file(ProviderState &s, const std::string &path, const std::vector<std::uint8_t> &data) {
    const std::string current_hash = sha256_file_hex(s.archive);
    if (current_hash.empty() || (!s.archive_hash.empty() && current_hash != s.archive_hash)) {
        return false;
    }
    const auto cmd = native_command(s, {L"--update-file", s.archive, L"--path", widen_utf8(path), L"--input", L"-", L"--verify=safe"});
    const ProcessResult result = run_process(cmd, &data);
    if (result.exit_code != 0) {
        return false;
    }
    s.archive_hash = sha256_file_hex(s.archive);
    return refresh_index(s);
}

bool delete_file(ProviderState &s, const std::string &path) {
    const std::string current_hash = sha256_file_hex(s.archive);
    if (current_hash.empty() || (!s.archive_hash.empty() && current_hash != s.archive_hash)) {
        return false;
    }
    const auto cmd = native_command(s, {L"--delete-file", s.archive, L"--path", widen_utf8(path), L"--verify=safe"});
    const ProcessResult result = run_process(cmd);
    if (result.exit_code != 0) {
        return false;
    }
    s.archive_hash = sha256_file_hex(s.archive);
    return refresh_index(s);
}

bool rename_file(ProviderState &s, const std::string &from_path, const std::string &to_path) {
    const std::string current_hash = sha256_file_hex(s.archive);
    if (current_hash.empty() || (!s.archive_hash.empty() && current_hash != s.archive_hash)) {
        return false;
    }
    const auto cmd = native_command(s, {L"--rename-file", s.archive, L"--path", widen_utf8(from_path), L"--to", widen_utf8(to_path), L"--verify=safe"});
    const ProcessResult result = run_process(cmd);
    if (result.exit_code != 0) {
        return false;
    }
    s.archive_hash = sha256_file_hex(s.archive);
    return refresh_index(s);
}

int fs_getattr(const char *path, struct FUSE_STAT *stbuf) {
    debug_log(std::string("getattr ") + (path ? path : "<null>"));
    auto *s = state();
    if (!s || !stbuf) {
        return -EIO;
    }
    const auto archive_path = fuse_to_archive_path(path);
    if (!archive_path) {
        return -EINVAL;
    }
    std::lock_guard<std::mutex> lock(s->mutex);
    const auto it = s->entries.find(*archive_path);
    if (it == s->entries.end()) {
        debug_log("getattr miss " + *archive_path);
        return -ENOENT;
    }
    *stbuf = {};
    if (it->second.directory) {
        stbuf->st_mode = S_IFDIR | 0555;
        stbuf->st_nlink = 2;
    } else {
        stbuf->st_mode = S_IFREG | (s->read_write ? 0644 : 0444);
        stbuf->st_nlink = 1;
        stbuf->st_size = static_cast<FUSE_OFF_T>(it->second.size);
    }
    debug_log("getattr hit " + *archive_path + " size=" + std::to_string(static_cast<unsigned long long>(it->second.size)));
    return 0;
}

int fs_readdir(const char *path, void *buf, fuse_fill_dir_t filler, FUSE_OFF_T, struct fuse_file_info *) {
    debug_log(std::string("readdir ") + (path ? path : "<null>"));
    auto *s = state();
    if (!s) {
        return -EIO;
    }
    const auto archive_path = fuse_to_archive_path(path);
    if (!archive_path) {
        return -EINVAL;
    }
    std::vector<std::string> names;
    {
        std::lock_guard<std::mutex> lock(s->mutex);
        const auto entry = s->entries.find(*archive_path);
        if (entry == s->entries.end() || !entry->second.directory) {
            return -ENOENT;
        }
        const auto it = s->children.find(*archive_path);
        if (it != s->children.end()) {
            names.assign(it->second.begin(), it->second.end());
        }
    }
    filler(buf, ".", nullptr, 0);
    filler(buf, "..", nullptr, 0);
    for (const auto &child : names) {
        filler(buf, child.c_str(), nullptr, 0);
    }
    return 0;
}

int fs_getdir(const char *path, fuse_dirh_t handle, fuse_dirfil_t filler) {
    debug_log(std::string("getdir ") + (path ? path : "<null>"));
    auto *s = state();
    if (!s) {
        return -EIO;
    }
    const auto archive_path = fuse_to_archive_path(path);
    if (!archive_path) {
        return -EINVAL;
    }
    std::vector<std::pair<std::string, int>> names;
    {
        std::lock_guard<std::mutex> lock(s->mutex);
        const auto parent = s->entries.find(*archive_path);
        if (parent == s->entries.end() || !parent->second.directory) {
            return -ENOENT;
        }
        const auto it = s->children.find(*archive_path);
        if (it != s->children.end()) {
            names.reserve(it->second.size());
            for (const auto &child : it->second) {
            const std::string child_path = archive_path->empty() ? child : *archive_path + "/" + child;
            const auto entry = s->entries.find(child_path);
            const int type = (entry != s->entries.end() && entry->second.directory) ? S_IFDIR : S_IFREG;
                names.emplace_back(child, type);
            }
        }
    }
    filler(handle, ".", S_IFDIR, 0);
    filler(handle, "..", S_IFDIR, 0);
    for (const auto &child : names) {
        filler(handle, child.first.c_str(), child.second, 0);
    }
    return 0;
}

uint32_t fs_win_get_attributes(const char *path) {
    debug_log(std::string("win_get_attributes ") + (path ? path : "<null>"));
    auto *s = state();
    if (!s) {
        return INVALID_FILE_ATTRIBUTES;
    }
    const auto archive_path = fuse_to_archive_path(path);
    if (!archive_path) {
        return INVALID_FILE_ATTRIBUTES;
    }
    std::lock_guard<std::mutex> lock(s->mutex);
    const auto it = s->entries.find(*archive_path);
    if (it == s->entries.end()) {
        return INVALID_FILE_ATTRIBUTES;
    }
    return it->second.directory ? FILE_ATTRIBUTE_DIRECTORY : FILE_ATTRIBUTE_NORMAL;
}

int fs_open(const char *path, struct fuse_file_info *fi) {
    debug_log(std::string("open ") + (path ? path : "<null>"));
    auto *s = state();
    if (!s || !fi) {
        return -EIO;
    }
    const auto archive_path = fuse_to_archive_path(path);
    if (!archive_path || archive_path->empty()) {
        return -EINVAL;
    }
    {
        std::lock_guard<std::mutex> lock(s->mutex);
        if (s->entries.find(*archive_path) == s->entries.end()) {
            return -ENOENT;
        }
    }
    auto *handle = new FileHandle();
    handle->path = *archive_path;
    handle->data = extract_file(*s, *archive_path);
    fi->fh = reinterpret_cast<std::uint64_t>(handle);
    return 0;
}

int fs_create(const char *path, mode_t, struct fuse_file_info *fi) {
    debug_log(std::string("create ") + (path ? path : "<null>"));
    auto *s = state();
    if (!s || !fi) {
        return -EIO;
    }
    if (!s->read_write) {
        return -EROFS;
    }
    const auto archive_path = fuse_to_archive_path(path);
    if (!archive_path || archive_path->empty()) {
        return -EINVAL;
    }
    auto *handle = new FileHandle();
    handle->path = *archive_path;
    handle->dirty = true;
    fi->fh = reinterpret_cast<std::uint64_t>(handle);
    return 0;
}

FileHandle *handle_from_fi(struct fuse_file_info *fi) {
    if (!fi || !fi->fh) {
        return nullptr;
    }
    return reinterpret_cast<FileHandle *>(fi->fh);
}

int fs_read(const char *, char *buf, size_t size, FUSE_OFF_T offset, struct fuse_file_info *fi) {
    debug_log("read");
    auto *handle = handle_from_fi(fi);
    if (!handle || offset < 0) {
        return -EIO;
    }
    const auto pos = static_cast<std::size_t>(offset);
    if (pos >= handle->data.size()) {
        return 0;
    }
    const auto count = std::min<std::size_t>(size, handle->data.size() - pos);
    std::memcpy(buf, handle->data.data() + pos, count);
    return static_cast<int>(count);
}

int fs_write(const char *, const char *buf, size_t size, FUSE_OFF_T offset, struct fuse_file_info *fi) {
    debug_log("write");
    auto *s = state();
    auto *handle = handle_from_fi(fi);
    if (!s || !handle || offset < 0) {
        return -EIO;
    }
    if (!s->read_write) {
        return -EROFS;
    }
    const auto pos = static_cast<std::size_t>(offset);
    if (pos + size > handle->data.size()) {
        handle->data.resize(pos + size);
    }
    std::memcpy(handle->data.data() + pos, buf, size);
    handle->dirty = true;
    return static_cast<int>(size);
}

int fs_truncate(const char *path, FUSE_OFF_T size) {
    debug_log(std::string("truncate ") + (path ? path : "<null>"));
    auto *s = state();
    if (!s || !s->read_write || size < 0) {
        return s && !s->read_write ? -EROFS : -EINVAL;
    }
    const auto archive_path = fuse_to_archive_path(path);
    if (!archive_path || archive_path->empty()) {
        return -EINVAL;
    }
    auto data = extract_file(*s, *archive_path);
    data.resize(static_cast<std::size_t>(size));
    std::lock_guard<std::mutex> lock(s->mutex);
    return update_file(*s, *archive_path, data) ? 0 : -EIO;
}

int fs_flush(const char *, struct fuse_file_info *fi) {
    debug_log("flush");
    auto *s = state();
    auto *handle = handle_from_fi(fi);
    if (!s || !handle) {
        return -EIO;
    }
    if (!handle->dirty) {
        return 0;
    }
    std::lock_guard<std::mutex> lock(s->mutex);
    if (!update_file(*s, handle->path, handle->data)) {
        return -EIO;
    }
    handle->dirty = false;
    return 0;
}

int fs_release(const char *, struct fuse_file_info *fi) {
    auto *handle = handle_from_fi(fi);
    if (handle) {
        delete handle;
        fi->fh = 0;
    }
    return 0;
}

int fs_unlink(const char *path) {
    auto *s = state();
    if (!s) {
        return -EIO;
    }
    if (!s->read_write) {
        return -EROFS;
    }
    const auto archive_path = fuse_to_archive_path(path);
    if (!archive_path || archive_path->empty()) {
        return -EINVAL;
    }
    std::lock_guard<std::mutex> lock(s->mutex);
    return delete_file(*s, *archive_path) ? 0 : -EIO;
}

int fs_rename(const char *from, const char *to) {
    auto *s = state();
    if (!s) {
        return -EIO;
    }
    if (!s->read_write) {
        return -EROFS;
    }
    const auto from_path = fuse_to_archive_path(from);
    const auto to_path = fuse_to_archive_path(to);
    if (!from_path || !to_path || from_path->empty() || to_path->empty()) {
        return -EINVAL;
    }
    std::lock_guard<std::mutex> lock(s->mutex);
    return rename_file(*s, *from_path, *to_path) ? 0 : -EIO;
}

int fs_mkdir(const char *, mode_t) {
    return -EROFS;
}

int fs_rmdir(const char *) {
    return -EROFS;
}

void print_usage() {
    std::fwprintf(stderr, L"usage: ithz-fuse-provider --archive <file.ithz> --mount <X:> --native <ithz-native.exe> [--read-write] [--foreground]\n");
}

} // namespace

int wmain(int argc, wchar_t **argv) {
    ProviderState provider;
    std::wstring mount;
    bool foreground = false;
    bool probe = false;

    for (int i = 1; i < argc; ++i) {
        const std::wstring arg = argv[i];
        if (arg == L"--archive" && i + 1 < argc) {
            provider.archive = argv[++i];
        } else if (arg == L"--mount" && i + 1 < argc) {
            mount = argv[++i];
        } else if (arg == L"--native" && i + 1 < argc) {
            provider.native_exe = argv[++i];
        } else if (arg == L"--read-write") {
            provider.read_write = true;
        } else if (arg == L"--foreground") {
            foreground = true;
        } else if (arg == L"--probe") {
            probe = true;
        } else if (arg == L"--help" || arg == L"-h") {
            print_usage();
            return 0;
        } else {
            print_usage();
            return 1;
        }
    }

    if (probe) {
        const HMODULE module = LoadLibraryW(L"dokanfuse2.dll");
        if (!module) {
            std::fwprintf(stderr, L"dokanfuse2.dll not loadable\n");
            return 2;
        }
        FreeLibrary(module);
        std::printf("dokan_fuse_provider_probe_ok=true\n");
        return 0;
    }

    if (provider.archive.empty() || provider.native_exe.empty() || mount.empty()) {
        print_usage();
        return 1;
    }
    if (!std::filesystem::exists(provider.archive) || !std::filesystem::exists(provider.native_exe)) {
        std::fwprintf(stderr, L"archive or native executable not found\n");
        return 1;
    }

    provider.archive_hash = sha256_file_hex(provider.archive);
    if (provider.archive_hash.empty() || !refresh_index(provider)) {
        std::fwprintf(stderr, L"failed to inspect archive\n");
        return 2;
    }
    g_provider_state = &provider;

    std::vector<std::string> args;
    args.push_back("ithz-fuse-provider");
    if (foreground) {
        args.push_back("-f");
    }
    args.push_back("-s");
    args.push_back(narrow_utf8(mount));

    std::vector<char *> fuse_args;
    fuse_args.reserve(args.size());
    for (auto &arg : args) {
        fuse_args.push_back(arg.data());
    }

    fuse_operations ops{};
    ops.getattr = fs_getattr;
    ops.getdir = fs_getdir;
    ops.readdir = fs_readdir;
    ops.open = fs_open;
    ops.create = fs_create;
    ops.read = fs_read;
    ops.write = fs_write;
    ops.truncate = fs_truncate;
    ops.flush = fs_flush;
    ops.release = fs_release;
    ops.unlink = fs_unlink;
    ops.rename = fs_rename;
    ops.mkdir = fs_mkdir;
    ops.rmdir = fs_rmdir;
    ops.win_get_attributes = fs_win_get_attributes;

    return fuse_main(static_cast<int>(fuse_args.size()), fuse_args.data(), &ops, &provider);
}
