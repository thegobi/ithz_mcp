#include <algorithm>
#include <array>
#include <cctype>
#include <chrono>
#include <cstdlib>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <future>
#include <functional>
#include <iomanip>
#include <iterator>
#include <random>
#include <iostream>
#include <numeric>
#include <map>
#include <optional>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <variant>
#include <vector>

#include "ithz/cli.hpp"
#include "ithz/archive_index.hpp"
#include "ithz/container.hpp"
#include "ithz/inspect.hpp"
#include "ithz/manifest.hpp"
#include "ithz/metadata_layout.hpp"
#include "ithz/paths.hpp"
#include "ithz/version.hpp"

using namespace ithz;

#ifdef _WIN32
#include <windows.h>
#include <psapi.h>
#include <fcntl.h>
#include <io.h>
#pragma comment(lib, "psapi.lib")
#else
#include <dlfcn.h>
#endif

#if ITHZ_X64_AVX2
#include <immintrin.h>
#endif

namespace fs = std::filesystem;

namespace {

constexpr const char* kReferenceDatasetSha = "72749fd68b455b0e45ef39a898564472cc58bfe76829b0653f2a075e7a0a326b";
constexpr const char* kReferencePlanHash = "e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c";
constexpr std::size_t kReferenceCompactArchiveBytes = 87985;

using Bytes = std::vector<std::uint8_t>;

using Clock = std::chrono::steady_clock;

double elapsed_ms(Clock::time_point start, Clock::time_point end = Clock::now()) {
    return std::chrono::duration<double, std::milli>(end - start).count();
}

double peak_memory_mb() {
#ifdef _WIN32
    PROCESS_MEMORY_COUNTERS pmc{};
    if (GetProcessMemoryInfo(GetCurrentProcess(), &pmc, sizeof(pmc))) {
        return static_cast<double>(pmc.PeakWorkingSetSize) / (1024.0 * 1024.0);
    }
#endif
    return 0.0;
}

[[noreturn]] void fail(const std::string& message) {
    throw std::runtime_error(message);
}

Bytes read_file(const fs::path& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) {
        fail("cannot open file: " + path.string());
    }
    f.seekg(0, std::ios::end);
    const auto size = f.tellg();
    f.seekg(0, std::ios::beg);
    Bytes data(static_cast<std::size_t>(size));
    if (!data.empty()) {
        f.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(data.size()));
    }
    return data;
}

void write_file(const fs::path& path, const Bytes& data) {
    if (!path.parent_path().empty()) fs::create_directories(path.parent_path());
    std::ofstream f(path, std::ios::binary);
    if (!f) {
        fail("cannot write file: " + path.string());
    }
    if (!data.empty()) {
        f.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
    }
}

void write_file_existing_parent(const fs::path& path, const Bytes& data) {
    std::ofstream f(path, std::ios::binary);
    if (!f) {
        fail("cannot write file: " + path.string());
    }
    if (!data.empty()) {
        f.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
    }
}

std::uint16_t read_u16_le(const Bytes& data, std::size_t offset) {
    if (offset + 2 > data.size()) fail("truncated u16");
    return static_cast<std::uint16_t>(data[offset] | (data[offset + 1] << 8));
}

std::uint32_t read_u32_le(const Bytes& data, std::size_t offset) {
    if (offset + 4 > data.size()) fail("truncated u32");
    return static_cast<std::uint32_t>(data[offset]) |
           (static_cast<std::uint32_t>(data[offset + 1]) << 8) |
           (static_cast<std::uint32_t>(data[offset + 2]) << 16) |
           (static_cast<std::uint32_t>(data[offset + 3]) << 24);
}

std::uint64_t read_u64_le(const Bytes& data, std::size_t offset) {
    if (offset + 8 > data.size()) fail("truncated u64");
    std::uint64_t out = 0;
    for (int i = 7; i >= 0; --i) {
        out = (out << 8) | data[offset + static_cast<std::size_t>(i)];
    }
    return out;
}

std::string hex_of(const std::uint8_t* data, std::size_t size) {
    std::ostringstream oss;
    oss << std::hex << std::setfill('0');
    for (std::size_t i = 0; i < size; ++i) {
        oss << std::setw(2) << static_cast<int>(data[i]);
    }
    return oss.str();
}

std::string hex_of(const Bytes& data) {
    return hex_of(data.data(), data.size());
}

Bytes bytes_from_hex(const std::string& hex) {
    if (hex.size() % 2 != 0) fail("bad hex length");
    Bytes out(hex.size() / 2);
    for (std::size_t i = 0; i < out.size(); ++i) {
        const auto byte_text = hex.substr(i * 2, 2);
        out[i] = static_cast<std::uint8_t>(std::stoul(byte_text, nullptr, 16));
    }
    return out;
}

class Sha256 {
public:
    Sha256() { reset(); }

    void update(const std::uint8_t* data, std::size_t len) {
        bit_len_ += static_cast<std::uint64_t>(len) * 8;
        while (len > 0) {
            const std::size_t take = std::min<std::size_t>(64 - buffer_len_, len);
            std::memcpy(buffer_.data() + buffer_len_, data, take);
            buffer_len_ += take;
            data += take;
            len -= take;
            if (buffer_len_ == 64) {
                transform(buffer_.data());
                buffer_len_ = 0;
            }
        }
    }

    void update(const Bytes& data) {
        update(data.data(), data.size());
    }

    void update(const std::string& text) {
        update(reinterpret_cast<const std::uint8_t*>(text.data()), text.size());
    }

    std::array<std::uint8_t, 32> final() {
        buffer_[buffer_len_++] = 0x80;
        if (buffer_len_ > 56) {
            while (buffer_len_ < 64) buffer_[buffer_len_++] = 0;
            transform(buffer_.data());
            buffer_len_ = 0;
        }
        while (buffer_len_ < 56) buffer_[buffer_len_++] = 0;
        for (int i = 7; i >= 0; --i) {
            buffer_[buffer_len_++] = static_cast<std::uint8_t>((bit_len_ >> (i * 8)) & 0xff);
        }
        transform(buffer_.data());
        std::array<std::uint8_t, 32> out{};
        for (std::size_t i = 0; i < state_.size(); ++i) {
            out[i * 4] = static_cast<std::uint8_t>((state_[i] >> 24) & 0xff);
            out[i * 4 + 1] = static_cast<std::uint8_t>((state_[i] >> 16) & 0xff);
            out[i * 4 + 2] = static_cast<std::uint8_t>((state_[i] >> 8) & 0xff);
            out[i * 4 + 3] = static_cast<std::uint8_t>(state_[i] & 0xff);
        }
        reset();
        return out;
    }

private:
    void reset() {
        state_ = {0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
                  0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U};
        bit_len_ = 0;
        buffer_len_ = 0;
        buffer_.fill(0);
    }

    static std::uint32_t rotr(std::uint32_t x, std::uint32_t n) {
        return (x >> n) | (x << (32 - n));
    }

    void transform(const std::uint8_t* block) {
        static constexpr std::array<std::uint32_t, 64> k{{
            0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U, 0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
            0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U, 0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
            0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU, 0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
            0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U, 0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
            0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U, 0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
            0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U, 0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
            0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U, 0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
            0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U, 0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U
        }};
        std::array<std::uint32_t, 64> w{};
        for (std::size_t i = 0; i < 16; ++i) {
            w[i] = (static_cast<std::uint32_t>(block[i * 4]) << 24) |
                   (static_cast<std::uint32_t>(block[i * 4 + 1]) << 16) |
                   (static_cast<std::uint32_t>(block[i * 4 + 2]) << 8) |
                   static_cast<std::uint32_t>(block[i * 4 + 3]);
        }
        for (std::size_t i = 16; i < 64; ++i) {
            const auto s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
            const auto s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
            w[i] = w[i - 16] + s0 + w[i - 7] + s1;
        }
        auto a = state_[0], b = state_[1], c = state_[2], d = state_[3];
        auto e = state_[4], f = state_[5], g = state_[6], h = state_[7];
        for (std::size_t i = 0; i < 64; ++i) {
            const auto s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
            const auto ch = (e & f) ^ ((~e) & g);
            const auto temp1 = h + s1 + ch + k[i] + w[i];
            const auto s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
            const auto maj = (a & b) ^ (a & c) ^ (b & c);
            const auto temp2 = s0 + maj;
            h = g;
            g = f;
            f = e;
            e = d + temp1;
            d = c;
            c = b;
            b = a;
            a = temp1 + temp2;
        }
        state_[0] += a; state_[1] += b; state_[2] += c; state_[3] += d;
        state_[4] += e; state_[5] += f; state_[6] += g; state_[7] += h;
    }

    std::array<std::uint32_t, 8> state_{};
    std::array<std::uint8_t, 64> buffer_{};
    std::uint64_t bit_len_ = 0;
    std::size_t buffer_len_ = 0;
};

std::string sha256_hex(const Bytes& data) {
    Sha256 sha;
    sha.update(data);
    const auto digest = sha.final();
    return hex_of(digest.data(), digest.size());
}

std::string sha256_hex_string(const std::string& text) {
    Sha256 sha;
    sha.update(text);
    const auto digest = sha.final();
    return hex_of(digest.data(), digest.size());
}

void append_u32_le(Bytes& out, std::uint32_t value) {
    out.push_back(static_cast<std::uint8_t>(value & 0xff));
    out.push_back(static_cast<std::uint8_t>((value >> 8) & 0xff));
    out.push_back(static_cast<std::uint8_t>((value >> 16) & 0xff));
    out.push_back(static_cast<std::uint8_t>((value >> 24) & 0xff));
}

void append_u64_le(Bytes& out, std::uint64_t value) {
    for (int i = 0; i < 8; ++i) {
        out.push_back(static_cast<std::uint8_t>((value >> (i * 8)) & 0xff));
    }
}

void append_varint(Bytes& out, std::uint64_t value) {
    while (value >= 0x80) {
        out.push_back(static_cast<std::uint8_t>((value & 0x7f) | 0x80));
        value >>= 7;
    }
    out.push_back(static_cast<std::uint8_t>(value));
}

void append_svarint(Bytes& out, std::int64_t value) {
    const auto zigzag = static_cast<std::uint64_t>((value << 1) ^ (value >> 63));
    append_varint(out, zigzag);
}

std::uint64_t read_varint(const Bytes& data, std::size_t& pos) {
    std::uint64_t value = 0;
    int shift = 0;
    while (true) {
        if (pos >= data.size()) fail("truncated varint");
        const auto b = data[pos++];
        value |= static_cast<std::uint64_t>(b & 0x7f) << shift;
        if ((b & 0x80) == 0) return value;
        shift += 7;
        if (shift > 63) fail("varint too large");
    }
}

std::int64_t read_svarint(const Bytes& data, std::size_t& pos) {
    const auto raw = read_varint(data, pos);
    return static_cast<std::int64_t>((raw >> 1) ^ (~(raw & 1) + 1));
}

void append_packed_bytes(Bytes& out, const Bytes& value) {
    append_varint(out, value.size());
    out.insert(out.end(), value.begin(), value.end());
}

Bytes read_packed_bytes(const Bytes& data, std::size_t& pos) {
    const auto size = static_cast<std::size_t>(read_varint(data, pos));
    if (pos + size > data.size()) fail("truncated packed bytes");
    Bytes out(data.begin() + static_cast<std::ptrdiff_t>(pos), data.begin() + static_cast<std::ptrdiff_t>(pos + size));
    pos += size;
    return out;
}

void append_packed_string(Bytes& out, const std::string& value) {
    append_varint(out, value.size());
    out.insert(out.end(), value.begin(), value.end());
}

std::string read_packed_string(const Bytes& data, std::size_t& pos) {
    const auto raw = read_packed_bytes(data, pos);
    return std::string(raw.begin(), raw.end());
}

std::uint8_t method_to_id(const std::string& method) {
    if (method == "STORE") return 0;
    if (method == "RLE") return 1;
    if (method == "RANGE0") return 2;
    if (method == "LZ_RANGE") return 3;
    if (method == "DELTA_BASE_RESIDUAL") return 4;
    if (method == "BYTE_SHUFFLE_RANGE") return 5;
    if (method == "BYTEPLANE2_RANGE") return 6;
    if (method == "DELTA16_BYTEPLANE_RANGE") return 7;
    if (method == "ZIGZAG_DELTA16_BYTEPLANE_RANGE") return 8;
    fail("unknown method id for compact manifest: " + method);
}

std::string id_to_method(std::uint8_t id) {
    switch (id) {
        case 0: return "STORE";
        case 1: return "RLE";
        case 2: return "RANGE0";
        case 3: return "LZ_RANGE";
        case 4: return "DELTA_BASE_RESIDUAL";
        case 5: return "BYTE_SHUFFLE_RANGE";
        case 6: return "BYTEPLANE2_RANGE";
        case 7: return "DELTA16_BYTEPLANE_RANGE";
        case 8: return "ZIGZAG_DELTA16_BYTEPLANE_RANGE";
        case 255: return "individual_best";
        default: fail("unknown compact method id: " + std::to_string(id));
    }
}

std::uint8_t checkpoint_scope_to_id(const std::string& scope) {
    if (scope == "file") return 0;
    if (scope == "folder") return 1;
    if (scope == "epoch") return 2;
    if (scope == "similarity_cluster") return 3;
    fail("unknown checkpoint scope: " + scope);
}

std::string id_to_checkpoint_scope(std::uint8_t id) {
    switch (id) {
        case 0: return "file";
        case 1: return "folder";
        case 2: return "epoch";
        case 3: return "similarity_cluster";
        default: fail("unknown compact checkpoint scope id: " + std::to_string(id));
    }
}

void append_delta_ids(Bytes& out, const std::vector<std::uint64_t>& ids) {
    std::uint64_t previous = 0;
    for (std::size_t i = 0; i < ids.size(); ++i) {
        if (i == 0) append_varint(out, ids[i]);
        else append_svarint(out, static_cast<std::int64_t>(ids[i]) - static_cast<std::int64_t>(previous));
        previous = ids[i];
    }
}

std::vector<std::uint64_t> read_delta_ids(const Bytes& data, std::size_t& pos, std::size_t count) {
    std::vector<std::uint64_t> values;
    values.reserve(count);
    std::int64_t previous = 0;
    for (std::size_t i = 0; i < count; ++i) {
        std::int64_t value = 0;
        if (i == 0) value = static_cast<std::int64_t>(read_varint(data, pos));
        else value = previous + read_svarint(data, pos);
        if (value < 0) fail("negative delta id");
        values.push_back(static_cast<std::uint64_t>(value));
        previous = value;
    }
    return values;
}


struct Json {
    using Array = std::vector<Json>;
    using Object = std::map<std::string, Json>;
    std::variant<std::nullptr_t, bool, double, std::string, Array, Object> value;

    const Object& object() const { return std::get<Object>(value); }
    const Array& array() const { return std::get<Array>(value); }
    const std::string& string() const { return std::get<std::string>(value); }
    double number() const { return std::get<double>(value); }
    bool boolean() const { return std::get<bool>(value); }
};

Json jnull() { return Json{nullptr}; }
Json jbool(bool value) { return Json{value}; }
Json jnum(std::uint64_t value) { return Json{static_cast<double>(value)}; }
Json jnum_i64(std::int64_t value) { return Json{static_cast<double>(value)}; }
Json jstr(const std::string& value) { return Json{value}; }
Json jarr(Json::Array value) { return Json{std::move(value)}; }
Json jobj(Json::Object value) { return Json{std::move(value)}; }

Json json_u64_array(const std::vector<std::uint64_t>& values) {
    Json::Array out;
    out.reserve(values.size());
    for (const auto value : values) out.push_back(jnum(value));
    return jarr(std::move(out));
}

class JsonParser {
public:
    explicit JsonParser(std::string text) : text_(std::move(text)) {}

    Json parse() {
        auto v = parse_value();
        skip_ws();
        if (pos_ != text_.size()) fail("trailing JSON input");
        return v;
    }

private:
    void skip_ws() {
        while (pos_ < text_.size() && std::isspace(static_cast<unsigned char>(text_[pos_]))) ++pos_;
    }

    bool consume(char c) {
        skip_ws();
        if (pos_ < text_.size() && text_[pos_] == c) {
            ++pos_;
            return true;
        }
        return false;
    }

    Json parse_value() {
        skip_ws();
        if (pos_ >= text_.size()) fail("unexpected JSON end");
        const char c = text_[pos_];
        if (c == '"') return Json{parse_string()};
        if (c == '{') return Json{parse_object()};
        if (c == '[') return Json{parse_array()};
        if (c == 't' && text_.substr(pos_, 4) == "true") { pos_ += 4; return Json{true}; }
        if (c == 'f' && text_.substr(pos_, 5) == "false") { pos_ += 5; return Json{false}; }
        if (c == 'n' && text_.substr(pos_, 4) == "null") { pos_ += 4; return Json{nullptr}; }
        return Json{parse_number()};
    }

    std::string parse_string() {
        if (!consume('"')) fail("expected JSON string");
        std::string out;
        while (pos_ < text_.size()) {
            char c = text_[pos_++];
            if (c == '"') return out;
            if (c != '\\') {
                out.push_back(c);
                continue;
            }
            if (pos_ >= text_.size()) fail("bad JSON escape");
            const char e = text_[pos_++];
            switch (e) {
                case '"': out.push_back('"'); break;
                case '\\': out.push_back('\\'); break;
                case '/': out.push_back('/'); break;
                case 'b': out.push_back('\b'); break;
                case 'f': out.push_back('\f'); break;
                case 'n': out.push_back('\n'); break;
                case 'r': out.push_back('\r'); break;
                case 't': out.push_back('\t'); break;
                case 'u': {
                    if (pos_ + 4 > text_.size()) fail("bad unicode escape");
                    const auto code = static_cast<unsigned>(std::stoul(text_.substr(pos_, 4), nullptr, 16));
                    pos_ += 4;
                    if (code <= 0x7f) out.push_back(static_cast<char>(code));
                    else if (code <= 0x7ff) {
                        out.push_back(static_cast<char>(0xc0 | (code >> 6)));
                        out.push_back(static_cast<char>(0x80 | (code & 0x3f)));
                    } else {
                        out.push_back(static_cast<char>(0xe0 | (code >> 12)));
                        out.push_back(static_cast<char>(0x80 | ((code >> 6) & 0x3f)));
                        out.push_back(static_cast<char>(0x80 | (code & 0x3f)));
                    }
                    break;
                }
                default: fail("unsupported JSON escape");
            }
        }
        fail("unterminated JSON string");
    }

    double parse_number() {
        skip_ws();
        const auto start = pos_;
        if (text_[pos_] == '-') ++pos_;
        while (pos_ < text_.size() && std::isdigit(static_cast<unsigned char>(text_[pos_]))) ++pos_;
        if (pos_ < text_.size() && text_[pos_] == '.') {
            ++pos_;
            while (pos_ < text_.size() && std::isdigit(static_cast<unsigned char>(text_[pos_]))) ++pos_;
        }
        if (pos_ < text_.size() && (text_[pos_] == 'e' || text_[pos_] == 'E')) {
            ++pos_;
            if (text_[pos_] == '+' || text_[pos_] == '-') ++pos_;
            while (pos_ < text_.size() && std::isdigit(static_cast<unsigned char>(text_[pos_]))) ++pos_;
        }
        return std::stod(text_.substr(start, pos_ - start));
    }

    Json::Array parse_array() {
        if (!consume('[')) fail("expected JSON array");
        Json::Array out;
        if (consume(']')) return out;
        while (true) {
            out.push_back(parse_value());
            if (consume(']')) return out;
            if (!consume(',')) fail("expected JSON array comma");
        }
    }

    Json::Object parse_object() {
        if (!consume('{')) fail("expected JSON object");
        Json::Object out;
        if (consume('}')) return out;
        while (true) {
            auto key = parse_string();
            if (!consume(':')) fail("expected JSON object colon");
            out.emplace(std::move(key), parse_value());
            if (consume('}')) return out;
            if (!consume(',')) fail("expected JSON object comma");
        }
    }

    std::string text_;
    std::size_t pos_ = 0;
};

std::string json_escape(const std::string& text) {
    std::ostringstream oss;
    oss << '"';
    for (const char c : text) {
        switch (c) {
            case '"': oss << "\\\""; break;
            case '\\': oss << "\\\\"; break;
            case '\b': oss << "\\b"; break;
            case '\f': oss << "\\f"; break;
            case '\n': oss << "\\n"; break;
            case '\r': oss << "\\r"; break;
            case '\t': oss << "\\t"; break;
            default:
                if (static_cast<unsigned char>(c) < 0x20) {
                    oss << "\\u" << std::hex << std::setw(4) << std::setfill('0') << static_cast<int>(static_cast<unsigned char>(c));
                } else {
                    oss << c;
                }
        }
    }
    oss << '"';
    return oss.str();
}

std::string json_dump(const Json& j) {
    if (std::holds_alternative<std::nullptr_t>(j.value)) return "null";
    if (std::holds_alternative<bool>(j.value)) return j.boolean() ? "true" : "false";
    if (std::holds_alternative<double>(j.value)) {
        const double n = j.number();
        if (std::abs(n - std::round(n)) < 0.0000001) {
            return std::to_string(static_cast<long long>(std::llround(n)));
        }
        std::ostringstream oss;
        oss << std::setprecision(12) << n;
        return oss.str();
    }
    if (std::holds_alternative<std::string>(j.value)) return json_escape(j.string());
    if (std::holds_alternative<Json::Array>(j.value)) {
        std::ostringstream oss;
        oss << '[';
        bool first = true;
        for (const auto& item : j.array()) {
            if (!first) oss << ',';
            first = false;
            oss << json_dump(item);
        }
        oss << ']';
        return oss.str();
    }
    std::ostringstream oss;
    oss << '{';
    bool first = true;
    for (const auto& [key, value] : j.object()) {
        if (!first) oss << ',';
        first = false;
        oss << json_escape(key) << ':' << json_dump(value);
    }
    oss << '}';
    return oss.str();
}

const Json& at(const Json& j, const std::string& key) {
    const auto& obj = j.object();
    auto it = obj.find(key);
    if (it == obj.end()) fail("missing JSON key: " + key);
    return it->second;
}

bool has_key(const Json& j, const std::string& key) {
    const auto& obj = j.object();
    return obj.find(key) != obj.end();
}

std::uint64_t as_u64(const Json& j) {
    return static_cast<std::uint64_t>(j.number());
}

std::string as_string(const Json& j) {
    return j.string();
}

class ZlibRaw {
public:
    ZlibRaw() {
#ifdef _WIN32
        const char* candidates[] = {
            "zlib1.dll",
            "C:\\Program Files\\Git\\mingw64\\bin\\zlib1.dll",
            "C:\\Program Files\\Git\\mingw64\\libexec\\git-core\\zlib1.dll",
        };
        for (const char* candidate : candidates) {
            module_ = LoadLibraryA(candidate);
            if (module_) break;
        }
        if (!module_) fail("zlib1.dll not found; install zlib or Git for Windows");
        inflateInit2_ = reinterpret_cast<InflateInit2Fn>(GetProcAddress(module_, "inflateInit2_"));
        inflate_ = reinterpret_cast<InflateFn>(GetProcAddress(module_, "inflate"));
        inflateEnd_ = reinterpret_cast<InflateEndFn>(GetProcAddress(module_, "inflateEnd"));
        deflateInit2_ = reinterpret_cast<DeflateInit2Fn>(GetProcAddress(module_, "deflateInit2_"));
        deflate_ = reinterpret_cast<DeflateFn>(GetProcAddress(module_, "deflate"));
        deflateEnd_ = reinterpret_cast<DeflateEndFn>(GetProcAddress(module_, "deflateEnd"));
        zlibVersion_ = reinterpret_cast<ZlibVersionFn>(GetProcAddress(module_, "zlibVersion"));
        if (!inflateInit2_ || !inflate_ || !inflateEnd_ || !deflateInit2_ || !deflate_ || !deflateEnd_ || !zlibVersion_) fail("zlib exports missing");
#else
        const char* candidates[] = {
            "libz.so.1",
            "libz.so",
        };
        for (const char* candidate : candidates) {
            module_ = dlopen(candidate, RTLD_LAZY | RTLD_LOCAL);
            if (module_) break;
        }
        if (!module_) fail("libz not found; install zlib runtime package such as zlib1g");
        inflateInit2_ = reinterpret_cast<InflateInit2Fn>(dlsym(module_, "inflateInit2_"));
        inflate_ = reinterpret_cast<InflateFn>(dlsym(module_, "inflate"));
        inflateEnd_ = reinterpret_cast<InflateEndFn>(dlsym(module_, "inflateEnd"));
        deflateInit2_ = reinterpret_cast<DeflateInit2Fn>(dlsym(module_, "deflateInit2_"));
        deflate_ = reinterpret_cast<DeflateFn>(dlsym(module_, "deflate"));
        deflateEnd_ = reinterpret_cast<DeflateEndFn>(dlsym(module_, "deflateEnd"));
        zlibVersion_ = reinterpret_cast<ZlibVersionFn>(dlsym(module_, "zlibVersion"));
        if (!inflateInit2_ || !inflate_ || !inflateEnd_ || !deflateInit2_ || !deflate_ || !deflateEnd_ || !zlibVersion_) fail("zlib exports missing");
#endif
    }

    ~ZlibRaw() {
#ifdef _WIN32
        if (module_) FreeLibrary(module_);
#else
        if (module_) dlclose(module_);
#endif
    }

    Bytes inflate_raw(const Bytes& input) {
        ZStream stream{};
        const char* version = zlibVersion_();
        if (inflateInit2_(&stream, -15, version, static_cast<int>(sizeof(ZStream))) != 0) {
            fail("inflateInit2 failed");
        }
        stream.next_in = const_cast<std::uint8_t*>(input.data());
        stream.avail_in = static_cast<unsigned int>(input.size());
        Bytes out;
        std::array<std::uint8_t, 32768> buffer{};
        while (true) {
            stream.next_out = buffer.data();
            stream.avail_out = static_cast<unsigned int>(buffer.size());
            const int ret = inflate_(&stream, 0);
            const auto produced = buffer.size() - stream.avail_out;
            out.insert(out.end(), buffer.data(), buffer.data() + produced);
            if (ret == 1) break; // Z_STREAM_END
            if (ret != 0) {
                inflateEnd_(&stream);
                fail("inflate failed with code " + std::to_string(ret));
            }
        }
        inflateEnd_(&stream);
        return out;
    }

    Bytes deflate_raw(const Bytes& input, int strategy) {
        ZStream stream{};
        const char* version = zlibVersion_();
        if (deflateInit2_(&stream, 9, 8, -15, 9, strategy, version, static_cast<int>(sizeof(ZStream))) != 0) {
            fail("deflateInit2 failed");
        }
        stream.next_in = const_cast<std::uint8_t*>(input.data());
        stream.avail_in = static_cast<unsigned int>(input.size());
        Bytes out;
        std::array<std::uint8_t, 32768> buffer{};
        while (true) {
            stream.next_out = buffer.data();
            stream.avail_out = static_cast<unsigned int>(buffer.size());
            const int flush = stream.avail_in == 0 ? 4 : 0; // Z_FINISH or Z_NO_FLUSH
            const int ret = deflate_(&stream, flush);
            const auto produced = buffer.size() - stream.avail_out;
            out.insert(out.end(), buffer.data(), buffer.data() + produced);
            if (ret == 1) break; // Z_STREAM_END
            if (ret != 0) {
                deflateEnd_(&stream);
                fail("deflate failed with code " + std::to_string(ret));
            }
        }
        deflateEnd_(&stream);
        return out;
    }

private:
    struct ZStream {
        std::uint8_t* next_in = nullptr;
        unsigned int avail_in = 0;
        unsigned long total_in = 0;
        std::uint8_t* next_out = nullptr;
        unsigned int avail_out = 0;
        unsigned long total_out = 0;
        char* msg = nullptr;
        void* state = nullptr;
        void* zalloc = nullptr;
        void* zfree = nullptr;
        void* opaque = nullptr;
        int data_type = 0;
        unsigned long adler = 0;
        unsigned long reserved = 0;
    };
    using InflateInit2Fn = int (*)(ZStream*, int, const char*, int);
    using InflateFn = int (*)(ZStream*, int);
    using InflateEndFn = int (*)(ZStream*);
    using DeflateInit2Fn = int (*)(ZStream*, int, int, int, int, int, const char*, int);
    using DeflateFn = int (*)(ZStream*, int);
    using DeflateEndFn = int (*)(ZStream*);
    using ZlibVersionFn = const char* (*)();

#ifdef _WIN32
    HMODULE module_ = nullptr;
#else
    void* module_ = nullptr;
#endif
    InflateInit2Fn inflateInit2_ = nullptr;
    InflateFn inflate_ = nullptr;
    InflateEndFn inflateEnd_ = nullptr;
    DeflateInit2Fn deflateInit2_ = nullptr;
    DeflateFn deflate_ = nullptr;
    DeflateEndFn deflateEnd_ = nullptr;
    ZlibVersionFn zlibVersion_ = nullptr;
};

Bytes decode_rle(const Bytes& data) {
    if (data.size() % 2 != 0) fail("invalid RLE payload");
    Bytes out;
    for (std::size_t i = 0; i < data.size(); i += 2) {
        out.insert(out.end(), data[i], data[i + 1]);
    }
    return out;
}

Bytes encode_rle(const Bytes& data) {
    Bytes out;
    std::size_t i = 0;
    while (i < data.size()) {
        const auto value = data[i];
        std::size_t run = 1;
        while (i + run < data.size() && data[i + run] == value && run < 255) ++run;
        out.push_back(static_cast<std::uint8_t>(run));
        out.push_back(value);
        i += run;
    }
    return out;
}

Bytes byte_shuffle(const Bytes& data, std::size_t word_size) {
    Bytes out;
    out.reserve(data.size());
    for (std::size_t i = 0; i < word_size; ++i) {
        for (std::size_t j = i; j < data.size(); j += word_size) out.push_back(data[j]);
    }
    return out;
}

Bytes byte_unshuffle(const Bytes& data, std::size_t original_size, std::size_t word_size) {
    std::vector<Bytes> buckets;
    std::size_t pos = 0;
    for (std::size_t i = 0; i < word_size; ++i) {
        const std::size_t len = (original_size + word_size - 1 - i) / word_size;
        if (pos + len > data.size()) fail("bad byte shuffle payload");
        buckets.emplace_back(data.begin() + static_cast<std::ptrdiff_t>(pos), data.begin() + static_cast<std::ptrdiff_t>(pos + len));
        pos += len;
    }
    Bytes out;
    out.reserve(original_size);
    const auto max_bucket = std::max_element(buckets.begin(), buckets.end(), [](const Bytes& a, const Bytes& b) { return a.size() < b.size(); })->size();
    for (std::size_t j = 0; j < max_bucket; ++j) {
        for (const auto& bucket : buckets) {
            if (j < bucket.size()) out.push_back(bucket[j]);
        }
    }
    return out;
}

std::uint16_t read_u16_le_loose(const Bytes& data, std::size_t offset) {
    const std::uint16_t lo = offset < data.size() ? data[offset] : 0;
    const std::uint16_t hi = offset + 1 < data.size() ? static_cast<std::uint16_t>(data[offset + 1]) : 0;
    return static_cast<std::uint16_t>(lo | (hi << 8));
}

void write_u16_le(Bytes& out, std::uint16_t value) {
    out.push_back(static_cast<std::uint8_t>(value & 0xff));
    out.push_back(static_cast<std::uint8_t>((value >> 8) & 0xff));
}

std::uint16_t zigzag16_encode(std::int32_t value) {
    const auto encoded = static_cast<std::uint32_t>((value << 1) ^ (value >> 15));
    return static_cast<std::uint16_t>(encoded & 0xffffU);
}

std::int32_t zigzag16_decode(std::uint16_t value) {
    const auto raw = static_cast<std::uint32_t>(value);
    return static_cast<std::int32_t>((raw >> 1) ^ (~(raw & 1U) + 1U));
}

Bytes delta16_precondition(const Bytes& data, bool zigzag) {
    Bytes delta;
    delta.reserve(data.size());
    std::uint16_t previous = 0;
    const std::size_t pair_bytes = data.size() - (data.size() % 2);
    for (std::size_t pos = 0; pos < pair_bytes; pos += 2) {
        const auto current = read_u16_le_loose(data, pos);
        const auto raw_delta = static_cast<std::uint16_t>(current - previous);
        if (zigzag) {
            const auto signed_delta = raw_delta >= 0x8000
                ? static_cast<std::int32_t>(raw_delta) - 0x10000
                : static_cast<std::int32_t>(raw_delta);
            write_u16_le(delta, zigzag16_encode(signed_delta));
        } else {
            write_u16_le(delta, raw_delta);
        }
        previous = current;
    }
    if (data.size() % 2 != 0) delta.push_back(data.back());
    return byte_shuffle(delta, 2);
}

Bytes delta16_unprecondition(const Bytes& transformed, std::size_t original_size, bool zigzag) {
    const Bytes delta = byte_unshuffle(transformed, original_size, 2);
    Bytes out;
    out.reserve(original_size);
    std::uint16_t previous = 0;
    const std::size_t pair_bytes = original_size - (original_size % 2);
    for (std::size_t pos = 0; pos < pair_bytes; pos += 2) {
        auto raw_delta = read_u16_le_loose(delta, pos);
        if (zigzag) {
            const auto signed_delta = zigzag16_decode(raw_delta);
            raw_delta = static_cast<std::uint16_t>(signed_delta);
        }
        const auto current = static_cast<std::uint16_t>(previous + raw_delta);
        write_u16_le(out, current);
        previous = current;
    }
    if (original_size % 2 != 0) {
        if (delta.size() < original_size) fail("truncated delta16 odd byte");
        out.push_back(delta.back());
    }
    return out;
}

Bytes decode_preconditioned_payload(const std::string& method, const Bytes& encoded, std::size_t original_size, ZlibRaw& zlib) {
    if (method == "BYTEPLANE2_RANGE") {
        return byte_unshuffle(zlib.inflate_raw(encoded), original_size, 2);
    }
    if (method == "DELTA16_BYTEPLANE_RANGE") {
        return delta16_unprecondition(zlib.inflate_raw(encoded), original_size, false);
    }
    if (method == "ZIGZAG_DELTA16_BYTEPLANE_RANGE") {
        return delta16_unprecondition(zlib.inflate_raw(encoded), original_size, true);
    }
    fail("unsupported preconditioned payload method: " + method);
}

Bytes make_delta(const Bytes& base, const Bytes& target, ZlibRaw& zlib) {
    Bytes raw;
    std::uint32_t changes = 0;
    for (std::size_t i = 0; i < target.size(); ++i) {
        if (i >= base.size() || base[i] != target[i]) ++changes;
    }
    append_u32_le(raw, static_cast<std::uint32_t>(target.size()));
    append_u32_le(raw, changes);
    for (std::size_t i = 0; i < target.size(); ++i) {
        if (i >= base.size() || base[i] != target[i]) {
            append_u32_le(raw, static_cast<std::uint32_t>(i));
            raw.push_back(target[i]);
        }
    }
    return zlib.deflate_raw(raw, 0);
}

Bytes apply_delta(const Bytes& base, const Bytes& raw_delta_deflated, ZlibRaw& zlib) {
    const Bytes raw = zlib.inflate_raw(raw_delta_deflated);
    if (raw.size() < 8) fail("invalid delta payload");
    const std::uint32_t target_len = read_u32_le(raw, 0);
    const std::uint32_t count = read_u32_le(raw, 4);
    Bytes out(target_len, 0);
    std::copy(base.begin(), base.begin() + static_cast<std::ptrdiff_t>(std::min<std::size_t>(base.size(), target_len)), out.begin());
    std::size_t pos = 8;
    for (std::uint32_t i = 0; i < count; ++i) {
        if (pos + 5 > raw.size()) fail("truncated delta changes");
        const std::uint32_t idx = read_u32_le(raw, pos);
        pos += 4;
        const std::uint8_t value = raw[pos++];
        if (idx >= out.size()) fail("delta index outside target");
        out[idx] = value;
    }
    return out;
}

struct Archive {
    Json manifest;
    Bytes manifest_bytes;
    Bytes payload;
    std::string header_original_sha;
    std::string header_decoded_sha;
    std::string header_plan_hash;
};

struct P12DecodeTiming {
    double archive_open_ms = 0.0;
    double header_read_ms = 0.0;
    double manifest_read_ms = 0.0;
    double manifest_parse_ms = 0.0;
    double index_build_ms = 0.0;
    double payload_seek_ms = 0.0;
    double inflate_ms = 0.0;
    double bundle_slice_ms = 0.0;
    double sha_verify_ms = 0.0;
    double path_safety_ms = 0.0;
    double file_write_ms = 0.0;
    double path_lookup_ms = 0.0;
    double total_decode_ms = 0.0;
    double total_extract_ms = 0.0;
    double total_verify_full_ms = 0.0;
};

struct ArchiveIndex {
    std::map<std::uint64_t, const Json*> streams;
    std::map<std::uint64_t, const Json*> chunks;
    std::map<std::string, const Json*> files;
    std::map<std::uint64_t, std::size_t> stream_payload_start;
};

std::string decode_archive_to_dir(const Archive& archive, const fs::path& output_dir);
std::string verify_archive_full_no_write_timed(const Archive& archive, const fs::path& virtual_output_dir, P12DecodeTiming* timing);

Json parse_compact_manifest(const Bytes& manifest_bytes) {
    if (manifest_bytes.size() < kCompactManifestMagic.size() ||
        !std::equal(kCompactManifestMagic.begin(), kCompactManifestMagic.end(), manifest_bytes.begin())) {
        fail("bad compact manifest magic");
    }
    std::size_t pos = kCompactManifestMagic.size();
    const auto version = read_varint(manifest_bytes, pos);
    if (version != 1) fail("unsupported compact manifest version");
    const auto original_sha = hex_of(read_packed_bytes(manifest_bytes, pos));
    const auto plan_hash = hex_of(read_packed_bytes(manifest_bytes, pos));
    const auto no_delta_estimated = read_varint(manifest_bytes, pos);

    const auto string_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
    std::vector<std::string> strings;
    strings.reserve(string_count);
    for (std::size_t i = 0; i < string_count; ++i) strings.push_back(read_packed_string(manifest_bytes, pos));

    Json::Array file_table;
    const auto file_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
    for (std::size_t i = 0; i < file_count; ++i) {
        const auto file_id = read_varint(manifest_bytes, pos);
        const auto path_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto size = read_varint(manifest_bytes, pos);
        const auto sha = hex_of(Bytes(manifest_bytes.begin() + static_cast<std::ptrdiff_t>(pos), manifest_bytes.begin() + static_cast<std::ptrdiff_t>(pos + 32)));
        pos += 32;
        const auto chunk_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto chunk_ids = read_delta_ids(manifest_bytes, pos, chunk_count);
        const auto family_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto folder_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto path = strings.at(path_idx);
        Json::Array range;
        range.push_back(jnum(chunk_ids.empty() ? 0 : chunk_ids.front()));
        range.push_back(jnum(chunk_ids.empty() ? 0 : chunk_ids.back()));
        file_table.push_back(jobj({
            {"canonical_path", jstr(path)},
            {"chunk_ids", json_u64_array(chunk_ids)},
            {"chunk_range", jarr(std::move(range))},
            {"file_id", jnum(file_id)},
            {"file_sha256", jstr(sha)},
            {"metadata_flags", jobj({{"family", jstr(strings.at(family_idx))}, {"folder_layer", jstr(strings.at(folder_idx))}})},
            {"original_file_size", jnum(size)},
            {"path_hash", jstr(sha256_hex_string(path))}
        }));
    }

    Json::Array chunk_table;
    std::map<std::uint64_t, std::string> compact_flags;
    const auto chunk_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
    std::int64_t previous_file_id = 0;
    std::map<std::uint64_t, std::int64_t> previous_offset_by_file;
    for (std::size_t i = 0; i < chunk_count; ++i) {
        const auto chunk_id = read_varint(manifest_bytes, pos);
        const auto file_id_signed = previous_file_id + read_svarint(manifest_bytes, pos);
        if (file_id_signed < 0) fail("negative compact file id");
        previous_file_id = file_id_signed;
        const auto file_id = static_cast<std::uint64_t>(file_id_signed);
        const auto offset_signed = previous_offset_by_file[file_id] + read_svarint(manifest_bytes, pos);
        if (offset_signed < 0) fail("negative compact file offset");
        previous_offset_by_file[file_id] = offset_signed;
        const auto size = read_varint(manifest_bytes, pos);
        const auto sha = hex_of(Bytes(manifest_bytes.begin() + static_cast<std::ptrdiff_t>(pos), manifest_bytes.begin() + static_cast<std::ptrdiff_t>(pos + 32)));
        pos += 32;
        const auto family_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto folder_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        if (pos >= manifest_bytes.size()) fail("truncated compact chunk method");
        const auto method = id_to_method(manifest_bytes[pos++]);
        const auto stream_id = read_varint(manifest_bytes, pos);
        const auto support_plus = read_varint(manifest_bytes, pos);
        const auto checkpoint_id = read_varint(manifest_bytes, pos);
        const auto base_plus = read_varint(manifest_bytes, pos);
        std::string flags = "{}";
        if (method == "RANGE0") flags = "{\"backend\":\"stdlib_deflate_huffman_only\"}";
        else if (method == "LZ_RANGE") flags = "{\"backend\":\"stdlib_deflate_raw\"}";
        else if (method == "BYTE_SHUFFLE_RANGE") flags = "{\"original_size\":" + std::to_string(size) + ",\"word_size\":4}";
        else if (method == "DELTA_BASE_RESIDUAL") flags = "{\"delta_encoding\":\"compact_manifest_v1\"}";
        else if (method == "BYTEPLANE2_RANGE") flags = "{\"backend\":\"stdlib_deflate_raw\",\"preconditioner\":\"byteplane2\",\"original_size\":" + std::to_string(size) + ",\"word_size\":2}";
        else if (method == "DELTA16_BYTEPLANE_RANGE") flags = "{\"backend\":\"stdlib_deflate_raw\",\"preconditioner\":\"delta16_byteplane\",\"original_size\":" + std::to_string(size) + ",\"word_size\":2}";
        else if (method == "ZIGZAG_DELTA16_BYTEPLANE_RANGE") flags = "{\"backend\":\"stdlib_deflate_raw\",\"preconditioner\":\"zigzag_delta16_byteplane\",\"original_size\":" + std::to_string(size) + ",\"word_size\":2}";
        compact_flags[stream_id] = flags;
        chunk_table.push_back(jobj({
            {"base_chunk_id", base_plus == 0 ? jnull() : jnum(base_plus - 1)},
            {"chunk_id", jnum(chunk_id)},
            {"chunk_size", jnum(size)},
            {"file_id", jnum(file_id)},
            {"file_offset", jnum(static_cast<std::uint64_t>(offset_signed))},
            {"payload_stream_id", jnum(stream_id)},
            {"probe_feature_summary", jobj({{"content_family", jstr(strings.at(family_idx))}, {"folder_layer", jstr(strings.at(folder_idx))}})},
            {"selected_checkpoint_id", jnum(checkpoint_id)},
            {"selected_method_id", jstr(method)},
            {"selected_support_id", support_plus == 0 ? jnull() : jnum(support_plus - 1)},
            {"stable_chunk_hash", jstr(sha)}
        }));
    }

    Json::Array support_cut_table;
    const auto support_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
    for (std::size_t i = 0; i < support_count; ++i) {
        const auto support_id = read_varint(manifest_bytes, pos);
        const auto family_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto content_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto folder_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto medoid = read_varint(manifest_bytes, pos);
        const auto member_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto members = read_delta_ids(manifest_bytes, pos, member_count);
        const auto pressure_scaled = read_svarint(manifest_bytes, pos);
        if (pos + 2 > manifest_bytes.size()) fail("truncated compact support");
        const bool selected = manifest_bytes[pos++] == 1;
        const auto method = id_to_method(manifest_bytes[pos++]);
        support_cut_table.push_back(jobj({
            {"canonical_medoid_chunk_id", jnum(medoid)},
            {"content_family", jstr(strings.at(content_idx))},
            {"folder_layer", jstr(strings.at(folder_idx))},
            {"member_chunk_ids", json_u64_array(members)},
            {"pressure_score", Json{static_cast<double>(pressure_scaled) / 1000.0}},
            {"selected", jbool(selected)},
            {"selected_method_candidate", jstr(method)},
            {"support_family_id", jstr(strings.at(family_idx))},
            {"support_id", jnum(support_id)}
        }));
    }

    Json::Array checkpoint_table;
    const auto checkpoint_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
    for (std::size_t i = 0; i < checkpoint_count; ++i) {
        const auto checkpoint_id = read_varint(manifest_bytes, pos);
        if (pos >= manifest_bytes.size()) fail("truncated compact checkpoint");
        const auto scope_type = id_to_checkpoint_scope(manifest_bytes[pos++]);
        const auto key_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto member_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto members = read_delta_ids(manifest_bytes, pos, member_count);
        checkpoint_table.push_back(jobj({
            {"checkpoint_id", jnum(checkpoint_id)},
            {"member_chunk_ids", json_u64_array(members)},
            {"scope_key", jstr(strings.at(key_idx))},
            {"scope_type", jstr(scope_type)}
        }));
    }

    Json::Array payload_stream_directory;
    const auto payload_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
    for (std::size_t i = 0; i < payload_count; ++i) {
        const auto stream_id = read_varint(manifest_bytes, pos);
        if (pos >= manifest_bytes.size()) fail("truncated compact payload method");
        const auto method = id_to_method(manifest_bytes[pos++]);
        const auto logical_size = read_varint(manifest_bytes, pos);
        const auto encoded_size = read_varint(manifest_bytes, pos);
        const auto decoded_sha = hex_of(Bytes(manifest_bytes.begin() + static_cast<std::ptrdiff_t>(pos), manifest_bytes.begin() + static_cast<std::ptrdiff_t>(pos + 32)));
        pos += 32;
        const auto byte_offset = read_varint(manifest_bytes, pos);
        const auto base_plus = read_varint(manifest_bytes, pos);
        Json flags = JsonParser(compact_flags.count(stream_id) ? compact_flags.at(stream_id) : "{}").parse();
        payload_stream_directory.push_back(jobj({
            {"base_chunk_id", base_plus == 0 ? jnull() : jnum(base_plus - 1)},
            {"byte_length", jnum(encoded_size)},
            {"byte_offset", jnum(byte_offset)},
            {"decoded_sha256", jstr(decoded_sha)},
            {"encoded_byte_count", jnum(encoded_size)},
            {"method_id", jstr(method)},
            {"method_specific_flags", flags},
            {"payload_stream_id", jnum(stream_id)},
            {"uncompressed_logical_byte_count", jnum(logical_size)}
        }));
    }
    if (pos != manifest_bytes.size()) fail("compact manifest has trailing bytes");
    return jobj({
        {"checkpoint_table", jarr(std::move(checkpoint_table))},
        {"chunk_table", jarr(std::move(chunk_table))},
        {"compression_plan_hash", jstr(plan_hash)},
        {"file_table", jarr(std::move(file_table))},
        {"format", jstr("ITHZ-CFC")},
        {"manifest_encoding", jstr("compact-varint-v1")},
        {"no_delta_estimated_payload_bytes", jnum(no_delta_estimated)},
        {"payload_stream_directory", jarr(std::move(payload_stream_directory))},
        {"sha256_decoded", jstr(original_sha)},
        {"sha256_original", jstr(original_sha)},
        {"support_cut_table", jarr(std::move(support_cut_table))},
        {"variant", jstr("checkpointed_cfc")},
        {"version", jnum(version)}
    });
}

Json parse_p7b_bundle_manifest(const Bytes& manifest_bytes) {
    if (manifest_bytes.size() < kP7BManifestMagic.size() ||
        !std::equal(kP7BManifestMagic.begin(), kP7BManifestMagic.end(), manifest_bytes.begin())) {
        fail("bad P7B bundle manifest magic");
    }
    std::size_t pos = kP7BManifestMagic.size();
    const auto version = read_varint(manifest_bytes, pos);
    if (version < 1 || version > 5) fail("unsupported P7B bundle manifest version");
    const auto original_sha = hex_of(read_packed_bytes(manifest_bytes, pos));
    const auto plan_hash = hex_of(read_packed_bytes(manifest_bytes, pos));
    const auto threshold = read_varint(manifest_bytes, pos);
    const auto path_table_bytes = read_varint(manifest_bytes, pos);
    const auto file_table_bytes = read_varint(manifest_bytes, pos);
    const auto encoding_flags = version >= 2 ? read_varint(manifest_bytes, pos) : 0;
    const bool raw_offsets = (encoding_flags & 1) != 0;

    const auto string_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
    std::vector<std::string> strings;
    strings.reserve(string_count);
    for (std::size_t i = 0; i < string_count; ++i) strings.push_back(read_packed_string(manifest_bytes, pos));

    struct P7BFileRow {
        std::uint64_t file_id = 0;
        std::string path;
        std::string folder;
        std::string ext;
        std::string family;
        std::string selected_family;
        std::string selection_reason;
        std::uint64_t size = 0;
        std::string sha;
        std::uint64_t stream_id = 0;
        std::uint64_t bundle_offset = 0;
        std::uint64_t bundle_id = 0;
    };
    std::vector<P7BFileRow> file_rows;
    Json::Array file_table;
    const auto file_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
    for (std::size_t i = 0; i < file_count; ++i) {
        P7BFileRow row;
        static std::int64_t previous_v4_file_id = 0;
        static std::int64_t previous_v4_stream_id = 0;
        static std::int64_t previous_v4_bundle_id = 0;
        static std::map<std::uint64_t, std::int64_t> previous_v4_offset_by_stream;
        if (i == 0) {
            previous_v4_file_id = 0;
            previous_v4_stream_id = 0;
            previous_v4_bundle_id = 0;
            previous_v4_offset_by_stream.clear();
        }
        if (version >= 4) {
            const auto file_id_signed = previous_v4_file_id + read_svarint(manifest_bytes, pos);
            if (file_id_signed < 0) fail("invalid P7B v4 file id");
            row.file_id = static_cast<std::uint64_t>(file_id_signed);
            previous_v4_file_id = file_id_signed;
        } else {
            row.file_id = read_varint(manifest_bytes, pos);
        }
        const auto prefix_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        const auto name_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        std::size_t ext_idx = 0;
        std::size_t family_idx = 0;
        if (version < 4) {
            ext_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
            family_idx = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        }
        row.size = read_varint(manifest_bytes, pos);
        if (pos + 32 > manifest_bytes.size()) fail("truncated P7B file sha");
        row.sha = hex_of(Bytes(manifest_bytes.begin() + static_cast<std::ptrdiff_t>(pos), manifest_bytes.begin() + static_cast<std::ptrdiff_t>(pos + 32)));
        pos += 32;
        if (version >= 4) {
            const auto stream_signed = previous_v4_stream_id + read_svarint(manifest_bytes, pos);
            if (stream_signed < 0) fail("invalid P7B v4 stream id");
            row.stream_id = static_cast<std::uint64_t>(stream_signed);
            previous_v4_stream_id = stream_signed;
            const auto offset_signed = previous_v4_offset_by_stream[row.stream_id] + read_svarint(manifest_bytes, pos);
            if (offset_signed < 0) fail("invalid P7B v4 bundle offset");
            row.bundle_offset = static_cast<std::uint64_t>(offset_signed);
            previous_v4_offset_by_stream[row.stream_id] = offset_signed;
            const auto bundle_signed = previous_v4_bundle_id + read_svarint(manifest_bytes, pos);
            if (bundle_signed < 0) fail("invalid P7B v4 bundle id");
            row.bundle_id = static_cast<std::uint64_t>(bundle_signed);
            previous_v4_bundle_id = bundle_signed;
        } else {
            row.stream_id = read_varint(manifest_bytes, pos);
            row.bundle_offset = raw_offsets ? read_u64_le(manifest_bytes, pos) : read_varint(manifest_bytes, pos);
            if (raw_offsets) pos += 8;
            row.bundle_id = read_varint(manifest_bytes, pos);
        }
        if (version >= 3) {
            row.selected_family = strings.at(static_cast<std::size_t>(read_varint(manifest_bytes, pos)));
            if (version >= 5) {
                row.selection_reason = "p9_v5_experimental_reason_elided:" + row.selected_family;
            } else {
                row.selection_reason = strings.at(static_cast<std::size_t>(read_varint(manifest_bytes, pos)));
            }
        }
        row.folder = strings.at(prefix_idx);
        const auto& name = strings.at(name_idx);
        row.path = row.folder == "." ? name : row.folder + "/" + name;
        if (version >= 4) {
            const auto dot = row.path.find_last_of('.');
            row.ext = dot == std::string::npos ? std::string() : row.path.substr(dot);
            std::transform(row.ext.begin(), row.ext.end(), row.ext.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        } else {
            row.ext = strings.at(ext_idx);
        }
        row.family = version >= 4 ? row.selected_family : strings.at(family_idx);
        if (row.selected_family.empty()) row.selected_family = row.family;
        if (row.selection_reason.empty()) row.selection_reason = "legacy_manifest_no_selection_reason";
        if (version >= 4 && row.family.empty()) row.family = row.selected_family;
        file_table.push_back(jobj({
            {"bundle_id", jnum(row.bundle_id)},
            {"bundle_offset", jnum(row.bundle_offset)},
            {"bundle_payload_stream_id", jnum(row.stream_id)},
            {"bundle_size", jnum(row.size)},
            {"canonical_path", jstr(row.path)},
            {"chunk_ids", jarr(Json::Array{})},
            {"file_id", jnum(row.file_id)},
            {"file_sha256", jstr(row.sha)},
            {"metadata_flags", jobj({
                {"family", jstr(row.family)},
                {"folder_layer", jstr(row.folder)},
                {"selected_family", jstr(row.selected_family)},
                {"selection_reason", jstr(row.selection_reason)}
            })},
            {"original_file_size", jnum(row.size)},
            {"path_hash", jstr(sha256_hex_string(row.path))}
        }));
        file_rows.push_back(std::move(row));
    }

    struct P7BBundleRow {
        std::uint64_t bundle_id = 0;
        std::string scope_key;
        std::string folder;
        std::string ext;
        std::string support_family;
        std::uint64_t stream_id = 0;
        std::vector<std::uint64_t> members;
    };
    std::vector<P7BBundleRow> bundles;
    Json::Array bundle_table;
    Json::Array checkpoint_table;
    Json::Array support_table;
    const auto bundle_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
    for (std::size_t i = 0; i < bundle_count; ++i) {
        P7BBundleRow row;
        row.bundle_id = read_varint(manifest_bytes, pos);
        row.scope_key = strings.at(static_cast<std::size_t>(read_varint(manifest_bytes, pos)));
        row.folder = strings.at(static_cast<std::size_t>(read_varint(manifest_bytes, pos)));
        row.ext = strings.at(static_cast<std::size_t>(read_varint(manifest_bytes, pos)));
        row.support_family = strings.at(static_cast<std::size_t>(read_varint(manifest_bytes, pos)));
        row.stream_id = read_varint(manifest_bytes, pos);
        const auto member_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
        row.members = read_delta_ids(manifest_bytes, pos, member_count);
        bundle_table.push_back(jobj({
            {"bundle_id", jnum(row.bundle_id)},
            {"extension", jstr(row.ext)},
            {"folder_layer", jstr(row.folder)},
            {"member_file_ids", json_u64_array(row.members)},
            {"payload_stream_id", jnum(row.stream_id)},
            {"scope_key", jstr(row.scope_key)},
            {"support_family", jstr(row.support_family)}
        }));
        checkpoint_table.push_back(jobj({
            {"checkpoint_id", jnum(row.bundle_id)},
            {"member_file_ids", json_u64_array(row.members)},
            {"scope_key", jstr(row.scope_key)},
            {"scope_type", jstr(row.support_family == "small_file_bundle" ? "bundle" : "file")}
        }));
        if (row.support_family == "small_file_bundle") {
            support_table.push_back(jobj({
                {"canonical_medoid_file_id", jnum(row.members.empty() ? 0 : row.members.front())},
                {"content_family", jstr("small_file_bundle")},
                {"folder_layer", jstr(row.folder)},
                {"member_file_ids", json_u64_array(row.members)},
                {"pressure_score", jnum(static_cast<std::uint64_t>(row.members.size()))},
                {"selected", jbool(true)},
                {"selected_method_candidate", jstr("bundle_payload")},
                {"support_family_id", jstr("small_file_bundle")},
                {"support_id", jnum(static_cast<std::uint64_t>(support_table.size()))}
            }));
        }
        bundles.push_back(std::move(row));
    }

    Json::Array payload_stream_directory;
    const auto payload_count = static_cast<std::size_t>(read_varint(manifest_bytes, pos));
    for (std::size_t i = 0; i < payload_count; ++i) {
        const auto stream_id = read_varint(manifest_bytes, pos);
        if (pos >= manifest_bytes.size()) fail("truncated P7B payload method");
        const auto method = id_to_method(manifest_bytes[pos++]);
        const auto logical_size = read_varint(manifest_bytes, pos);
        const auto encoded_size = read_varint(manifest_bytes, pos);
        if (pos + 32 > manifest_bytes.size()) fail("truncated P7B payload sha");
        const auto decoded_sha = hex_of(Bytes(manifest_bytes.begin() + static_cast<std::ptrdiff_t>(pos), manifest_bytes.begin() + static_cast<std::ptrdiff_t>(pos + 32)));
        pos += 32;
        const auto byte_offset = read_varint(manifest_bytes, pos);
        Json flags = method == "LZ_RANGE"
            ? JsonParser("{\"backend\":\"stdlib_deflate_raw\",\"scope\":\"small_file_bundle\"}").parse()
            : jobj({});
        if (method == "BYTEPLANE2_RANGE") {
            flags = JsonParser("{\"backend\":\"stdlib_deflate_raw\",\"scope\":\"small_file_bundle\",\"preconditioner\":\"byteplane2\",\"original_size\":" + std::to_string(logical_size) + ",\"word_size\":2}").parse();
        } else if (method == "DELTA16_BYTEPLANE_RANGE") {
            flags = JsonParser("{\"backend\":\"stdlib_deflate_raw\",\"scope\":\"small_file_bundle\",\"preconditioner\":\"delta16_byteplane\",\"original_size\":" + std::to_string(logical_size) + ",\"word_size\":2}").parse();
        } else if (method == "ZIGZAG_DELTA16_BYTEPLANE_RANGE") {
            flags = JsonParser("{\"backend\":\"stdlib_deflate_raw\",\"scope\":\"small_file_bundle\",\"preconditioner\":\"zigzag_delta16_byteplane\",\"original_size\":" + std::to_string(logical_size) + ",\"word_size\":2}").parse();
        }
        payload_stream_directory.push_back(jobj({
            {"base_chunk_id", jnull()},
            {"byte_length", jnum(encoded_size)},
            {"byte_offset", jnum(byte_offset)},
            {"decoded_sha256", jstr(decoded_sha)},
            {"encoded_byte_count", jnum(encoded_size)},
            {"method_id", jstr(method)},
            {"method_specific_flags", flags},
            {"payload_stream_id", jnum(stream_id)},
            {"uncompressed_logical_byte_count", jnum(logical_size)}
        }));
    }
    if (pos != manifest_bytes.size()) fail("P7B manifest has trailing bytes");
    return jobj({
        {"bundle_table", jarr(std::move(bundle_table))},
        {"checkpoint_table", jarr(std::move(checkpoint_table))},
        {"chunk_table", jarr(Json::Array{})},
        {"compression_plan_hash", jstr(plan_hash)},
        {"file_table", jarr(std::move(file_table))},
        {"format", jstr("ITHZ-CFC")},
        {"manifest_encoding", jstr("p7b-bundle-varint-v1")},
        {"no_delta_estimated_payload_bytes", jnum(0)},
        {"p7b_tables", jobj({{"file_table_bytes_estimate", jnum(file_table_bytes)}, {"path_table_bytes_estimate", jnum(path_table_bytes)}, {"threshold_bytes", jnum(threshold)}})},
        {"payload_stream_directory", jarr(std::move(payload_stream_directory))},
        {"sha256_decoded", jstr(original_sha)},
        {"sha256_original", jstr(original_sha)},
        {"support_cut_table", jarr(std::move(support_table))},
        {"variant", jstr("checkpointed_cfc_p7b_small_file_bundle")},
        {"version", jnum(version)}
    });
}

Archive read_archive_timed(const fs::path& path, P12DecodeTiming* timing) {
    const auto open_start = Clock::now();
    const Bytes blob = read_file(path);
    if (timing) timing->archive_open_ms += elapsed_ms(open_start);
    const auto header_start = Clock::now();
    if (blob.size() < kHeaderSize + kFooterMagic.size() + 96) fail("archive too short");
    if (!std::equal(kMagic.begin(), kMagic.end(), blob.begin())) fail("bad ITHZ magic");
    const auto version = read_u16_le(blob, 7);
    if (version != 1) fail("unsupported ITHZ version");
    const auto flags = read_u32_le(blob, 9);
    if ((flags & ~(kFlagCompactManifest | kFlagP7BBundleManifest)) != 0) fail("unsupported ITHZ flags");
    const auto manifest_len = read_u64_le(blob, 13);
    const auto payload_len = read_u64_le(blob, 21);
    const std::size_t manifest_start = kHeaderSize;
    if (manifest_len > blob.size() || payload_len > blob.size()) fail("archive length fields outside blob");
    if (static_cast<std::uint64_t>(manifest_start) + manifest_len > blob.size()) fail("manifest length outside blob");
    const std::size_t manifest_end = manifest_start + static_cast<std::size_t>(manifest_len);
    if (payload_len > blob.size() - manifest_end) fail("payload length outside blob");
    const std::size_t payload_end = manifest_end + static_cast<std::size_t>(payload_len);
    if (payload_end + kFooterMagic.size() + 96 > blob.size()) fail("truncated archive body");
    if (!std::equal(kFooterMagic.begin(), kFooterMagic.end(), blob.begin() + static_cast<std::ptrdiff_t>(payload_end))) fail("bad footer magic");
    if (timing) timing->header_read_ms += elapsed_ms(header_start);

    const auto manifest_read_start = Clock::now();
    Bytes manifest_bytes(blob.begin() + static_cast<std::ptrdiff_t>(manifest_start), blob.begin() + static_cast<std::ptrdiff_t>(manifest_end));
    Bytes payload(blob.begin() + static_cast<std::ptrdiff_t>(manifest_end), blob.begin() + static_cast<std::ptrdiff_t>(payload_end));
    const std::size_t footer_hash = payload_end + kFooterMagic.size();
    const auto manifest_checksum = hex_of(blob.data() + footer_hash, 32);
    const auto payload_checksum = hex_of(blob.data() + footer_hash + 32, 32);
    const auto footer_plan = hex_of(blob.data() + footer_hash + 64, 32);
    if (timing) timing->manifest_read_ms += elapsed_ms(manifest_read_start);
    const auto checksum_start = Clock::now();
    if (sha256_hex(manifest_bytes) != manifest_checksum) fail("manifest checksum mismatch");
    if (sha256_hex(payload) != payload_checksum) fail("payload checksum mismatch");
    if (timing) timing->sha_verify_ms += elapsed_ms(checksum_start);

    const auto parse_start = Clock::now();
    Json manifest = (flags & kFlagP7BBundleManifest)
        ? parse_p7b_bundle_manifest(manifest_bytes)
        : ((flags & kFlagCompactManifest)
            ? parse_compact_manifest(manifest_bytes)
            : JsonParser(std::string(manifest_bytes.begin(), manifest_bytes.end())).parse());
    if (timing) timing->manifest_parse_ms += elapsed_ms(parse_start);
    const auto header_guard_start = Clock::now();
    const auto header_original = hex_of(blob.data() + 29, 32);
    const auto header_decoded = hex_of(blob.data() + 61, 32);
    const auto header_plan = hex_of(blob.data() + 93, 32);
    if (as_string(at(manifest, "sha256_original")) != header_original) fail("header original sha mismatch");
    if (as_string(at(manifest, "compression_plan_hash")) != header_plan) fail("header plan hash mismatch");
    if (footer_plan != header_plan) fail("footer plan hash mismatch");
    if (header_decoded != header_original) fail("header decoded sha guard mismatch");
    if (timing) timing->sha_verify_ms += elapsed_ms(header_guard_start);
    return Archive{std::move(manifest), std::move(manifest_bytes), std::move(payload), header_original, header_decoded, header_plan};
}

Archive read_archive(const fs::path& path) {
    return read_archive_timed(path, nullptr);
}

ArchiveIndex build_archive_index(const Archive& archive, P12DecodeTiming* timing = nullptr) {
    const auto start = Clock::now();
    ArchiveIndex index;
    std::size_t offset = 0;
    for (const auto& stream : at(archive.manifest, "payload_stream_directory").array()) {
        const auto stream_id = as_u64(at(stream, "payload_stream_id"));
        index.streams[stream_id] = &stream;
        index.stream_payload_start[stream_id] = offset;
        offset += static_cast<std::size_t>(as_u64(at(stream, "encoded_byte_count")));
    }
    if (offset > archive.payload.size()) fail("payload stream directory exceeds payload blob");
    for (const auto& chunk : at(archive.manifest, "chunk_table").array()) {
        index.chunks[as_u64(at(chunk, "chunk_id"))] = &chunk;
    }
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto path = as_string(at(file, "canonical_path"));
        if (!index.files.emplace(path, &file).second) fail("duplicate archive path: " + path);
    }
    if (timing) timing->index_build_ms += elapsed_ms(start);
    return index;
}

Bytes payload_slice(const Archive& archive, const Json& stream) {
    const auto stream_id = as_u64(at(stream, "payload_stream_id"));
    std::size_t start = 0;
    for (const auto& candidate : at(archive.manifest, "payload_stream_directory").array()) {
        const auto candidate_id = as_u64(at(candidate, "payload_stream_id"));
        if (candidate_id == stream_id) break;
        start += static_cast<std::size_t>(as_u64(at(candidate, "encoded_byte_count")));
    }
    const auto length = static_cast<std::size_t>(as_u64(at(stream, "byte_length")));
    if (start + length > archive.payload.size()) fail("payload stream outside payload blob");
    return Bytes(archive.payload.begin() + static_cast<std::ptrdiff_t>(start), archive.payload.begin() + static_cast<std::ptrdiff_t>(start + length));
}

Bytes payload_slice_indexed(const Archive& archive, const ArchiveIndex& index, const Json& stream, P12DecodeTiming* timing = nullptr) {
    const auto start_time = Clock::now();
    const auto stream_id = as_u64(at(stream, "payload_stream_id"));
    const auto start_it = index.stream_payload_start.find(stream_id);
    if (start_it == index.stream_payload_start.end()) fail("payload stream missing from index");
    const auto start = start_it->second;
    const auto length = static_cast<std::size_t>(as_u64(at(stream, "byte_length")));
    if (start + length > archive.payload.size()) fail("payload stream outside payload blob");
    Bytes out(archive.payload.begin() + static_cast<std::ptrdiff_t>(start), archive.payload.begin() + static_cast<std::ptrdiff_t>(start + length));
    if (timing) timing->payload_seek_ms += elapsed_ms(start_time);
    return out;
}

std::map<std::uint64_t, Bytes> decode_chunks(const Archive& archive) {
    ZlibRaw zlib;
    std::map<std::uint64_t, const Json*> streams;
    for (const auto& stream : at(archive.manifest, "payload_stream_directory").array()) {
        streams[as_u64(at(stream, "payload_stream_id"))] = &stream;
    }
    std::map<std::uint64_t, const Json*> chunks;
    for (const auto& chunk : at(archive.manifest, "chunk_table").array()) {
        chunks[as_u64(at(chunk, "chunk_id"))] = &chunk;
    }
    std::map<std::uint64_t, Bytes> decoded;
    std::vector<std::uint64_t> pending;
    for (const auto& [chunk_id, _] : chunks) pending.push_back(chunk_id);
    while (!pending.empty()) {
        bool progressed = false;
        std::vector<std::uint64_t> next_pending;
        for (const auto chunk_id : pending) {
            const Json& chunk = *chunks.at(chunk_id);
            const auto stream_id = as_u64(at(chunk, "payload_stream_id"));
            const Json& stream = *streams.at(stream_id);
            const auto method = as_string(at(stream, "method_id"));
            const Bytes encoded = payload_slice(archive, stream);
            Bytes plain;
            if (method == "STORE") {
                plain = encoded;
            } else if (method == "RLE") {
                plain = decode_rle(encoded);
            } else if (method == "RANGE0" || method == "LZ_RANGE") {
                plain = zlib.inflate_raw(encoded);
            } else if (method == "BYTE_SHUFFLE_RANGE") {
                const Bytes transformed = zlib.inflate_raw(encoded);
                const auto& flags = at(stream, "method_specific_flags").object();
                const auto original_size = static_cast<std::size_t>(flags.count("original_size") ? as_u64(flags.at("original_size")) : as_u64(at(stream, "uncompressed_logical_byte_count")));
                const auto word_size = static_cast<std::size_t>(flags.count("word_size") ? as_u64(flags.at("word_size")) : 4);
                plain = byte_unshuffle(transformed, original_size, word_size);
            } else if (method == "BYTEPLANE2_RANGE" || method == "DELTA16_BYTEPLANE_RANGE" || method == "ZIGZAG_DELTA16_BYTEPLANE_RANGE") {
                plain = decode_preconditioned_payload(method, encoded, static_cast<std::size_t>(as_u64(at(stream, "uncompressed_logical_byte_count"))), zlib);
            } else if (method == "DELTA_BASE_RESIDUAL") {
                const auto base_json = at(stream, "base_chunk_id");
                if (std::holds_alternative<std::nullptr_t>(base_json.value)) fail("delta stream missing base id");
                const auto base_id = as_u64(base_json);
                auto base_it = decoded.find(base_id);
                if (base_it == decoded.end()) {
                    next_pending.push_back(chunk_id);
                    continue;
                }
                plain = apply_delta(base_it->second, encoded, zlib);
            } else {
                fail("unsupported method: " + method);
            }
            const auto expected_sha = as_string(at(stream, "decoded_sha256"));
            if (sha256_hex(plain) != expected_sha) fail("payload decoded sha mismatch for chunk " + std::to_string(chunk_id));
            decoded[chunk_id] = std::move(plain);
            progressed = true;
        }
        if (!progressed) fail("delta dependency cycle or missing base");
        pending = std::move(next_pending);
    }
    return decoded;
}

Bytes decode_payload_plain(const Archive& archive, const Json& stream) {
    ZlibRaw zlib;
    const auto method = as_string(at(stream, "method_id"));
    const Bytes encoded = payload_slice(archive, stream);
    Bytes plain;
    if (method == "STORE") {
        plain = encoded;
    } else if (method == "RLE") {
        plain = decode_rle(encoded);
    } else if (method == "RANGE0" || method == "LZ_RANGE") {
        plain = zlib.inflate_raw(encoded);
    } else if (method == "BYTE_SHUFFLE_RANGE") {
        const Bytes transformed = zlib.inflate_raw(encoded);
        const auto& flags = at(stream, "method_specific_flags").object();
        const auto original_size = static_cast<std::size_t>(flags.count("original_size") ? as_u64(flags.at("original_size")) : as_u64(at(stream, "uncompressed_logical_byte_count")));
        const auto word_size = static_cast<std::size_t>(flags.count("word_size") ? as_u64(flags.at("word_size")) : 4);
        plain = byte_unshuffle(transformed, original_size, word_size);
    } else if (method == "BYTEPLANE2_RANGE" || method == "DELTA16_BYTEPLANE_RANGE" || method == "ZIGZAG_DELTA16_BYTEPLANE_RANGE") {
        plain = decode_preconditioned_payload(method, encoded, static_cast<std::size_t>(as_u64(at(stream, "uncompressed_logical_byte_count"))), zlib);
    } else {
        fail("payload stream decode requires chunk context for method: " + method);
    }
    const auto expected_sha = as_string(at(stream, "decoded_sha256"));
    if (sha256_hex(plain) != expected_sha) fail("payload decoded sha mismatch for stream " + std::to_string(as_u64(at(stream, "payload_stream_id"))));
    return plain;
}

Bytes decode_payload_plain_indexed(const Archive& archive, const ArchiveIndex& index, const Json& stream, P12DecodeTiming* timing = nullptr) {
    ZlibRaw zlib;
    const auto method = as_string(at(stream, "method_id"));
    const Bytes encoded = payload_slice_indexed(archive, index, stream, timing);
    Bytes plain;
    const auto inflate_start = Clock::now();
    if (method == "STORE") {
        plain = encoded;
    } else if (method == "RLE") {
        plain = decode_rle(encoded);
    } else if (method == "RANGE0" || method == "LZ_RANGE") {
        plain = zlib.inflate_raw(encoded);
    } else if (method == "BYTE_SHUFFLE_RANGE") {
        const Bytes transformed = zlib.inflate_raw(encoded);
        const auto& flags = at(stream, "method_specific_flags").object();
        const auto original_size = static_cast<std::size_t>(flags.count("original_size") ? as_u64(flags.at("original_size")) : as_u64(at(stream, "uncompressed_logical_byte_count")));
        const auto word_size = static_cast<std::size_t>(flags.count("word_size") ? as_u64(flags.at("word_size")) : 4);
        plain = byte_unshuffle(transformed, original_size, word_size);
    } else if (method == "BYTEPLANE2_RANGE" || method == "DELTA16_BYTEPLANE_RANGE" || method == "ZIGZAG_DELTA16_BYTEPLANE_RANGE") {
        plain = decode_preconditioned_payload(method, encoded, static_cast<std::size_t>(as_u64(at(stream, "uncompressed_logical_byte_count"))), zlib);
    } else {
        fail("payload stream decode requires chunk context for method: " + method);
    }
    if (timing) timing->inflate_ms += elapsed_ms(inflate_start);
    const auto sha_start = Clock::now();
    const auto expected_sha = as_string(at(stream, "decoded_sha256"));
    if (sha256_hex(plain) != expected_sha) fail("payload decoded sha mismatch for stream " + std::to_string(as_u64(at(stream, "payload_stream_id"))));
    if (timing) timing->sha_verify_ms += elapsed_ms(sha_start);
    return plain;
}

Bytes decode_chunk_recursive(
    const Archive& archive,
    const ArchiveIndex& index,
    std::uint64_t chunk_id,
    std::map<std::uint64_t, Bytes>& cache,
    P12DecodeTiming* timing = nullptr
) {
    const auto cached = cache.find(chunk_id);
    if (cached != cache.end()) return cached->second;
    const auto chunk_it = index.chunks.find(chunk_id);
    if (chunk_it == index.chunks.end()) fail("chunk missing from index: " + std::to_string(chunk_id));
    const Json& chunk = *chunk_it->second;
    const auto stream_id = as_u64(at(chunk, "payload_stream_id"));
    const auto stream_it = index.streams.find(stream_id);
    if (stream_it == index.streams.end()) fail("payload stream missing for chunk: " + std::to_string(chunk_id));
    const Json& stream = *stream_it->second;
    const auto method = as_string(at(stream, "method_id"));
    const Bytes encoded = payload_slice_indexed(archive, index, stream, timing);
    ZlibRaw zlib;
    Bytes plain;
    const auto inflate_start = Clock::now();
    if (method == "STORE") {
        plain = encoded;
    } else if (method == "RLE") {
        plain = decode_rle(encoded);
    } else if (method == "RANGE0" || method == "LZ_RANGE") {
        plain = zlib.inflate_raw(encoded);
    } else if (method == "BYTE_SHUFFLE_RANGE") {
        const Bytes transformed = zlib.inflate_raw(encoded);
        const auto& flags = at(stream, "method_specific_flags").object();
        const auto original_size = static_cast<std::size_t>(flags.count("original_size") ? as_u64(flags.at("original_size")) : as_u64(at(stream, "uncompressed_logical_byte_count")));
        const auto word_size = static_cast<std::size_t>(flags.count("word_size") ? as_u64(flags.at("word_size")) : 4);
        plain = byte_unshuffle(transformed, original_size, word_size);
    } else if (method == "BYTEPLANE2_RANGE" || method == "DELTA16_BYTEPLANE_RANGE" || method == "ZIGZAG_DELTA16_BYTEPLANE_RANGE") {
        plain = decode_preconditioned_payload(method, encoded, static_cast<std::size_t>(as_u64(at(stream, "uncompressed_logical_byte_count"))), zlib);
    } else if (method == "DELTA_BASE_RESIDUAL") {
        const auto base_json = at(stream, "base_chunk_id");
        if (std::holds_alternative<std::nullptr_t>(base_json.value)) fail("delta stream missing base id");
        const auto base_id = as_u64(base_json);
        const auto base = decode_chunk_recursive(archive, index, base_id, cache, timing);
        plain = apply_delta(base, encoded, zlib);
    } else {
        fail("unsupported method: " + method);
    }
    if (timing) timing->inflate_ms += elapsed_ms(inflate_start);
    const auto sha_start = Clock::now();
    const auto expected_sha = as_string(at(stream, "decoded_sha256"));
    if (sha256_hex(plain) != expected_sha) fail("payload decoded sha mismatch for chunk " + std::to_string(chunk_id));
    if (timing) timing->sha_verify_ms += elapsed_ms(sha_start);
    cache[chunk_id] = plain;
    return plain;
}

std::string compute_dataset_digest(const std::map<std::string, Bytes>& files) {
    Sha256 sha;
    for (const auto& [path, data] : files) {
        const Bytes path_bytes(path.begin(), path.end());
        Bytes len_path;
        append_u32_le(len_path, static_cast<std::uint32_t>(path_bytes.size()));
        sha.update(len_path);
        sha.update(path_bytes);
        Bytes size_bytes;
        append_u64_le(size_bytes, static_cast<std::uint64_t>(data.size()));
        sha.update(size_bytes);
        const auto file_sha = bytes_from_hex(sha256_hex(data));
        sha.update(file_sha);
    }
    const auto digest = sha.final();
    return hex_of(digest.data(), digest.size());
}

struct PayloadRecord {
    std::uint64_t stream_id = 0;
    std::uint64_t chunk_id = 0;
    std::string method;
    Bytes encoded;
    std::size_t logical_size = 0;
    std::string decoded_sha;
    std::optional<std::uint64_t> base_chunk_id;
};

std::string method_flags_json(const PayloadRecord& payload) {
    if (payload.method == "RANGE0") return "{\"backend\":\"stdlib_deflate_huffman_only\"}";
    if (payload.method == "LZ_RANGE") return "{\"backend\":\"stdlib_deflate_raw\"}";
    if (payload.method == "BYTE_SHUFFLE_RANGE") {
        return "{\"original_size\":" + std::to_string(payload.logical_size) + ",\"word_size\":4}";
    }
    if (payload.method == "DELTA_BASE_RESIDUAL") return "{\"delta_encoding\":\"xor_position_value_v1\"}";
    return "{}";
}

std::string json_u64_array_from_plan(const Json& arr) {
    std::ostringstream oss;
    oss << '[';
    bool first = true;
    for (const auto& item : arr.array()) {
        if (!first) oss << ',';
        first = false;
        oss << static_cast<std::uint64_t>(as_u64(item));
    }
    oss << ']';
    return oss.str();
}

std::string make_manifest_json(
    const Json& oracle,
    const std::vector<PayloadRecord>& payloads,
    std::uint64_t payload_offset_base,
    const std::string& dataset_sha,
    const std::string& plan_hash
) {
    std::map<std::uint64_t, const Json*> chunk_plan_by_id;
    for (const auto& plan : at(oracle, "chunk_plan").array()) {
        chunk_plan_by_id[as_u64(at(plan, "chunk_id"))] = &plan;
    }
    std::map<std::uint64_t, const Json*> probe_by_id;
    for (const auto& probe : at(oracle, "probe_summary").array()) {
        probe_by_id[as_u64(at(probe, "chunk_id"))] = &probe;
    }
    std::map<std::string, std::uint64_t> file_id_by_path;
    for (const auto& file : at(oracle, "file_table").array()) {
        file_id_by_path[as_string(at(file, "path"))] = as_u64(at(file, "file_id"));
    }

    std::ostringstream oss;
    oss << '{';
    oss << "\"checkpoint_table\":" << json_dump(at(oracle, "checkpoint_table")) << ',';
    oss << "\"chunk_table\":[";
    bool first_chunk = true;
    for (const auto& probe : at(oracle, "probe_summary").array()) {
        const auto chunk_id = as_u64(at(probe, "chunk_id"));
        const Json& plan = *chunk_plan_by_id.at(chunk_id);
        if (!first_chunk) oss << ',';
        first_chunk = false;
        oss << '{'
            << "\"base_chunk_id\":";
        if (std::holds_alternative<std::nullptr_t>(at(plan, "base_chunk_id").value)) oss << "null";
        else oss << as_u64(at(plan, "base_chunk_id"));
        oss << ",\"chunk_id\":" << chunk_id
            << ",\"chunk_size\":" << as_u64(at(probe, "size"))
            << ",\"file_id\":" << file_id_by_path.at(as_string(at(probe, "path")))
            << ",\"file_offset\":" << as_u64(at(probe, "offset"))
            << ",\"payload_stream_id\":" << as_u64(at(plan, "payload_stream_id"))
            << ",\"probe_feature_summary\":{"
            << "\"ascii_utf8_score\":" << json_dump(at(probe, "ascii_utf8_score")) << ','
            << "\"byte_entropy\":" << json_dump(at(probe, "byte_entropy")) << ','
            << "\"content_family\":" << json_escape(as_string(at(probe, "content_family"))) << ','
            << "\"cross_file_similarity\":" << json_dump(at(probe, "cross_file_similarity")) << ','
            << "\"folder_layer\":" << json_escape(as_string(at(probe, "folder_layer"))) << ','
            << "\"metadata_cost_estimate\":" << as_u64(at(probe, "metadata_cost_estimate")) << ','
            << "\"numeric_csv_like_score\":" << json_dump(at(probe, "numeric_csv_like_score")) << ','
            << "\"repetition_score\":" << json_dump(at(probe, "repetition_score")) << ','
            << "\"similarity_to_previous_chunks\":" << json_dump(at(probe, "similarity_to_previous_chunks")) << ','
            << "\"zero_run_score\":" << json_dump(at(probe, "zero_run_score"))
            << "},\"selected_checkpoint_id\":" << as_u64(at(plan, "checkpoint_id"))
            << ",\"selected_method_id\":" << json_escape(as_string(at(plan, "method")))
            << ",\"selected_support_id\":";
        if (std::holds_alternative<std::nullptr_t>(at(plan, "support_id").value)) oss << "null";
        else oss << as_u64(at(plan, "support_id"));
        oss << ",\"stable_chunk_hash\":" << json_escape(as_string(at(probe, "sha256"))) << '}';
    }
    oss << "],";

    oss << "\"compression_plan_hash\":" << json_escape(plan_hash) << ',';
    oss << "\"file_table\":[";
    bool first_file = true;
    for (const auto& file : at(oracle, "file_table").array()) {
        if (!first_file) oss << ',';
        first_file = false;
        const auto& chunk_ids = at(file, "chunk_ids").array();
        oss << '{'
            << "\"canonical_path\":" << json_escape(as_string(at(file, "path")))
            << ",\"chunk_ids\":" << json_u64_array_from_plan(at(file, "chunk_ids"))
            << ",\"chunk_range\":[" << static_cast<std::uint64_t>(as_u64(chunk_ids.front())) << ','
            << static_cast<std::uint64_t>(as_u64(chunk_ids.back())) << ']'
            << ",\"file_id\":" << as_u64(at(file, "file_id"))
            << ",\"file_sha256\":" << json_escape(as_string(at(file, "sha256")))
            << ",\"metadata_flags\":" << json_dump(at(file, "metadata_flags"))
            << ",\"original_file_size\":" << as_u64(at(file, "size"))
            << ",\"path_hash\":" << json_escape(as_string(at(file, "path_hash")))
            << '}';
    }
    oss << "],";
    oss << "\"format\":\"ITHZ-CFC\",";
    oss << "\"no_delta_estimated_payload_bytes\":0,";
    oss << "\"payload_stream_directory\":[";
    std::uint64_t cursor = payload_offset_base;
    bool first_payload = true;
    for (const auto& payload : payloads) {
        if (!first_payload) oss << ',';
        first_payload = false;
        oss << '{'
            << "\"base_chunk_id\":";
        if (payload.base_chunk_id) oss << *payload.base_chunk_id; else oss << "null";
        oss << ",\"byte_length\":" << payload.encoded.size()
            << ",\"byte_offset\":" << cursor
            << ",\"decoded_sha256\":" << json_escape(payload.decoded_sha)
            << ",\"encoded_byte_count\":" << payload.encoded.size()
            << ",\"method_id\":" << json_escape(payload.method)
            << ",\"method_specific_flags\":" << method_flags_json(payload)
            << ",\"payload_stream_id\":" << payload.stream_id
            << ",\"uncompressed_logical_byte_count\":" << payload.logical_size
            << '}';
        cursor += payload.encoded.size();
    }
    oss << "],";
    oss << "\"sha256_decoded\":\"\",";
    oss << "\"sha256_original\":" << json_escape(dataset_sha) << ',';
    oss << "\"support_cut_table\":" << json_dump(at(oracle, "support_cut_table")) << ',';
    oss << "\"variant\":\"checkpointed_cfc\",";
    oss << "\"version\":1";
    oss << '}';
    return oss.str();
}

void add_string(std::map<std::string, std::uint64_t>& index, std::vector<std::string>& values, const std::string& value) {
    if (index.count(value)) return;
    index[value] = 0;
    values.push_back(value);
}

std::pair<std::vector<std::string>, std::map<std::string, std::uint64_t>> make_compact_string_table(const Json& oracle) {
    std::map<std::string, std::uint64_t> marker;
    std::vector<std::string> values;
    add_string(marker, values, "");
    for (const auto& file : at(oracle, "file_table").array()) {
        add_string(marker, values, as_string(at(file, "path")));
        const auto& meta = at(file, "metadata_flags").object();
        add_string(marker, values, as_string(meta.at("family")));
        add_string(marker, values, as_string(meta.at("folder_layer")));
    }
    for (const auto& probe : at(oracle, "probe_summary").array()) {
        add_string(marker, values, as_string(at(probe, "content_family")));
        add_string(marker, values, as_string(at(probe, "folder_layer")));
    }
    for (const auto& checkpoint : at(oracle, "checkpoint_table").array()) {
        add_string(marker, values, as_string(at(checkpoint, "scope_key")));
    }
    for (const auto& support : at(oracle, "support_cut_table").array()) {
        add_string(marker, values, has_key(support, "support_family_id") ? as_string(at(support, "support_family_id")) : "");
        add_string(marker, values, has_key(support, "content_family") ? as_string(at(support, "content_family")) : "");
        add_string(marker, values, has_key(support, "folder_layer") ? as_string(at(support, "folder_layer")) : "");
    }
    std::sort(values.begin(), values.end());
    std::map<std::string, std::uint64_t> index;
    for (std::size_t i = 0; i < values.size(); ++i) index[values[i]] = static_cast<std::uint64_t>(i);
    return {values, index};
}

std::vector<std::uint64_t> json_u64_vector(const Json& arr) {
    std::vector<std::uint64_t> out;
    for (const auto& item : arr.array()) out.push_back(as_u64(item));
    return out;
}

Bytes make_compact_manifest(
    const Json& oracle,
    const std::vector<PayloadRecord>& payloads,
    std::uint64_t payload_offset_base,
    const std::string& dataset_sha,
    const std::string& plan_hash
) {
    const auto [strings, string_index] = make_compact_string_table(oracle);
    Bytes out;
    out.insert(out.end(), kCompactManifestMagic.begin(), kCompactManifestMagic.end());
    append_varint(out, 1);
    append_packed_bytes(out, bytes_from_hex(dataset_sha));
    append_packed_bytes(out, bytes_from_hex(plan_hash));
    append_varint(out, 0);

    append_varint(out, strings.size());
    for (const auto& value : strings) append_packed_string(out, value);

    append_varint(out, at(oracle, "file_table").array().size());
    for (const auto& file : at(oracle, "file_table").array()) {
        const auto path = as_string(at(file, "path"));
        const auto chunk_ids = json_u64_vector(at(file, "chunk_ids"));
        const auto& meta = at(file, "metadata_flags").object();
        append_varint(out, as_u64(at(file, "file_id")));
        append_varint(out, string_index.at(path));
        append_varint(out, as_u64(at(file, "size")));
        const auto sha = bytes_from_hex(as_string(at(file, "sha256")));
        out.insert(out.end(), sha.begin(), sha.end());
        append_varint(out, chunk_ids.size());
        append_delta_ids(out, chunk_ids);
        append_varint(out, string_index.at(as_string(meta.at("family"))));
        append_varint(out, string_index.at(as_string(meta.at("folder_layer"))));
    }

    std::map<std::uint64_t, const Json*> chunk_plan_by_id;
    for (const auto& cp : at(oracle, "chunk_plan").array()) chunk_plan_by_id[as_u64(at(cp, "chunk_id"))] = &cp;
    std::map<std::string, std::uint64_t> file_id_by_path;
    for (const auto& file : at(oracle, "file_table").array()) file_id_by_path[as_string(at(file, "path"))] = as_u64(at(file, "file_id"));
    append_varint(out, at(oracle, "probe_summary").array().size());
    std::int64_t previous_file_id = 0;
    std::map<std::uint64_t, std::int64_t> previous_offset_by_file;
    for (const auto& probe : at(oracle, "probe_summary").array()) {
        const auto chunk_id = as_u64(at(probe, "chunk_id"));
        const auto& cp = *chunk_plan_by_id.at(chunk_id);
        const auto file_id = file_id_by_path.at(as_string(at(probe, "path")));
        const auto offset = as_u64(at(probe, "offset"));
        append_varint(out, chunk_id);
        append_svarint(out, static_cast<std::int64_t>(file_id) - previous_file_id);
        previous_file_id = static_cast<std::int64_t>(file_id);
        append_svarint(out, static_cast<std::int64_t>(offset) - previous_offset_by_file[file_id]);
        previous_offset_by_file[file_id] = static_cast<std::int64_t>(offset);
        append_varint(out, as_u64(at(probe, "size")));
        const auto sha = bytes_from_hex(as_string(at(probe, "sha256")));
        out.insert(out.end(), sha.begin(), sha.end());
        append_varint(out, string_index.at(as_string(at(probe, "content_family"))));
        append_varint(out, string_index.at(as_string(at(probe, "folder_layer"))));
        out.push_back(method_to_id(as_string(at(cp, "method"))));
        append_varint(out, as_u64(at(cp, "payload_stream_id")));
        append_varint(out, std::holds_alternative<std::nullptr_t>(at(cp, "support_id").value) ? 0 : as_u64(at(cp, "support_id")) + 1);
        append_varint(out, as_u64(at(cp, "checkpoint_id")));
        append_varint(out, std::holds_alternative<std::nullptr_t>(at(cp, "base_chunk_id").value) ? 0 : as_u64(at(cp, "base_chunk_id")) + 1);
    }

    append_varint(out, at(oracle, "support_cut_table").array().size());
    for (const auto& support : at(oracle, "support_cut_table").array()) {
        append_varint(out, as_u64(at(support, "support_id")));
        append_varint(out, string_index.at(has_key(support, "support_family_id") ? as_string(at(support, "support_family_id")) : ""));
        append_varint(out, string_index.at(has_key(support, "content_family") ? as_string(at(support, "content_family")) : ""));
        append_varint(out, string_index.at(has_key(support, "folder_layer") ? as_string(at(support, "folder_layer")) : ""));
        append_varint(out, as_u64(at(support, "canonical_medoid_chunk_id")));
        const auto members = json_u64_vector(at(support, "member_chunk_ids"));
        append_varint(out, members.size());
        append_delta_ids(out, members);
        const auto pressure = has_key(support, "pressure_score") ? static_cast<std::int64_t>(std::llround(at(support, "pressure_score").number() * 1000.0)) : 0;
        append_svarint(out, pressure);
        out.push_back(has_key(support, "selected") && at(support, "selected").boolean() ? 1 : 0);
        if (has_key(support, "selected_method_candidate")) {
            const auto method = as_string(at(support, "selected_method_candidate"));
            out.push_back(method == "individual_best" ? 255 : method_to_id(method));
        } else {
            out.push_back(255);
        }
    }

    append_varint(out, at(oracle, "checkpoint_table").array().size());
    for (const auto& checkpoint : at(oracle, "checkpoint_table").array()) {
        append_varint(out, as_u64(at(checkpoint, "checkpoint_id")));
        out.push_back(checkpoint_scope_to_id(as_string(at(checkpoint, "scope_type"))));
        append_varint(out, string_index.at(as_string(at(checkpoint, "scope_key"))));
        const auto members = json_u64_vector(at(checkpoint, "member_chunk_ids"));
        append_varint(out, members.size());
        append_delta_ids(out, members);
    }

    append_varint(out, payloads.size());
    std::uint64_t cursor = payload_offset_base;
    for (const auto& payload : payloads) {
        append_varint(out, payload.stream_id);
        out.push_back(method_to_id(payload.method));
        append_varint(out, payload.logical_size);
        append_varint(out, payload.encoded.size());
        const auto decoded_sha = bytes_from_hex(payload.decoded_sha);
        out.insert(out.end(), decoded_sha.begin(), decoded_sha.end());
        append_varint(out, cursor);
        cursor += payload.encoded.size();
        append_varint(out, payload.base_chunk_id ? *payload.base_chunk_id + 1 : 0);
    }
    return out;
}

Bytes converged_compact_manifest(const Json& oracle, const std::vector<PayloadRecord>& payloads, const std::string& dataset_sha, const std::string& plan_hash) {
    Bytes manifest = make_compact_manifest(oracle, payloads, 0, dataset_sha, plan_hash);
    for (int i = 0; i < 8; ++i) {
        const auto payload_offset = static_cast<std::uint64_t>(kHeaderSize + manifest.size());
        Bytes next = make_compact_manifest(oracle, payloads, payload_offset, dataset_sha, plan_hash);
        if (next.size() == manifest.size()) return next;
        manifest = std::move(next);
    }
    fail("compact manifest payload offsets did not converge");
}

void write_ithz_archive_bytes(const fs::path& path, const Bytes& manifest, const Bytes& payload, const std::string& dataset_sha, const std::string& plan_hash, std::uint32_t flags) {
    Bytes out;
    out.insert(out.end(), kMagic.begin(), kMagic.end());
    out.push_back(1);
    out.push_back(0);
    append_u32_le(out, flags);
    append_u64_le(out, static_cast<std::uint64_t>(manifest.size()));
    append_u64_le(out, static_cast<std::uint64_t>(payload.size()));
    const auto dataset_sha_bytes = bytes_from_hex(dataset_sha);
    const auto plan_hash_bytes = bytes_from_hex(plan_hash);
    out.insert(out.end(), dataset_sha_bytes.begin(), dataset_sha_bytes.end());
    out.insert(out.end(), dataset_sha_bytes.begin(), dataset_sha_bytes.end());
    out.insert(out.end(), plan_hash_bytes.begin(), plan_hash_bytes.end());
    out.insert(out.end(), manifest.begin(), manifest.end());
    out.insert(out.end(), payload.begin(), payload.end());
    out.insert(out.end(), kFooterMagic.begin(), kFooterMagic.end());
    const auto manifest_sha = bytes_from_hex(sha256_hex(manifest));
    const auto payload_sha = bytes_from_hex(sha256_hex(payload));
    out.insert(out.end(), manifest_sha.begin(), manifest_sha.end());
    out.insert(out.end(), payload_sha.begin(), payload_sha.end());
    out.insert(out.end(), plan_hash_bytes.begin(), plan_hash_bytes.end());
    write_file(path, out);
}

void write_ithz_archive(const fs::path& path, const std::string& manifest, const Bytes& payload, const std::string& dataset_sha, const std::string& plan_hash) {
    write_ithz_archive_bytes(path, Bytes(manifest.begin(), manifest.end()), payload, dataset_sha, plan_hash, 0);
}

std::map<std::string, Bytes> read_dataset_dir(const fs::path& root) {
    std::map<std::string, Bytes> files;
    for (const auto& entry : fs::recursive_directory_iterator(root)) {
        if (!entry.is_regular_file()) continue;
        auto rel = fs::relative(entry.path(), root).generic_string();
        files[rel] = read_file(entry.path());
    }
    return files;
}

std::vector<std::pair<std::string, Bytes>> read_dataset_dir_scheduled(const fs::path& root, const std::string& schedule) {
    std::vector<std::pair<std::string, Bytes>> files;
    for (const auto& entry : fs::recursive_directory_iterator(root)) {
        if (!entry.is_regular_file()) continue;
        auto rel = fs::relative(entry.path(), root).generic_string();
        files.push_back({rel, read_file(entry.path())});
    }
    std::sort(files.begin(), files.end(), [](const auto& a, const auto& b) { return a.first < b.first; });
    if (schedule == "original" || schedule == "threads1" || schedule == "threads4" || schedule == "threads8") {
        return files;
    }
    if (schedule == "reversed") {
        std::reverse(files.begin(), files.end());
        return files;
    }
    if (schedule == "path_hash") {
        std::sort(files.begin(), files.end(), [](const auto& a, const auto& b) {
            const auto ha = sha256_hex_string(a.first);
            const auto hb = sha256_hex_string(b.first);
            return ha == hb ? a.first < b.first : ha < hb;
        });
        return files;
    }
    if (schedule == "random_seed1" || schedule == "random_seed2") {
        std::mt19937 rng(schedule == "random_seed1" ? 1U : 2U);
        std::shuffle(files.begin(), files.end(), rng);
        return files;
    }
    fail("unknown schedule: " + schedule);
}

struct ScheduleSpec {
    std::string label;
    std::string schedule;
    int threads;
};

std::vector<ScheduleSpec> checkpointed_schedules() {
    return {
        {"original_order", "original", 1},
        {"reversed_order", "reversed", 1},
        {"path_hash_order", "path_hash", 1},
        {"random_seed1", "random_seed1", 1},
        {"random_seed2", "random_seed2", 1},
        {"threads1", "threads1", 1},
        {"threads4", "threads4", 4},
        {"threads8", "threads8", 8},
    };
}

std::vector<ScheduleSpec> greedy_schedules() {
    return {
        {"original_order", "original", 1},
        {"reversed_order", "reversed", 1},
        {"path_hash_order", "path_hash", 1},
        {"random_seed1", "random_seed1", 1},
        {"random_seed2", "random_seed2", 1},
    };
}

std::string lower_ext(const std::string& path) {
    const auto pos = path.find_last_of('.');
    if (pos == std::string::npos) return "";
    std::string ext = path.substr(pos);
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return ext;
}

double byte_similarity(const Bytes& a, const Bytes& b);

double round6(double value) {
    return std::nearbyint(value * 1000000.0) / 1000000.0;
}

double byte_entropy_score(const Bytes& data) {
    if (data.empty()) return 0.0;
    std::array<std::uint64_t, 256> counts{};
    for (const auto b : data) ++counts[b];
    double entropy = 0.0;
    for (const auto count : counts) {
        if (!count) continue;
        const double p = static_cast<double>(count) / static_cast<double>(data.size());
        entropy -= p * std::log2(p);
    }
    return entropy;
}

double repetition_score_native(const Bytes& data) {
    if (data.empty()) return 0.0;
    std::array<std::uint64_t, 256> counts{};
    for (const auto b : data) ++counts[b];
    const auto top = *std::max_element(counts.begin(), counts.end());
    const double top_ratio = static_cast<double>(top) / static_cast<double>(data.size());
    std::uint64_t pair_repeats = 0;
    for (std::size_t i = 1; i < data.size(); ++i) {
        if (data[i] == data[i - 1]) ++pair_repeats;
    }
    const double total_pairs = static_cast<double>(std::max<std::size_t>(1, data.size() - 1));
    return std::min(1.0, 0.65 * top_ratio + 0.35 * (static_cast<double>(pair_repeats) / total_pairs));
}

double zero_run_score_native(const Bytes& data) {
    if (data.empty()) return 0.0;
    std::size_t run_bytes = 0;
    std::size_t i = 0;
    while (i < data.size()) {
        if (data[i] != 0) {
            ++i;
            continue;
        }
        std::size_t j = i;
        while (j < data.size() && data[j] == 0) ++j;
        if (j - i >= 4) run_bytes += j - i;
        i = j;
    }
    return static_cast<double>(run_bytes) / static_cast<double>(data.size());
}

bool is_valid_utf8(const Bytes& data) {
    std::size_t i = 0;
    while (i < data.size()) {
        const auto b = data[i];
        if (b < 0x80) {
            ++i;
        } else if ((b >> 5) == 0x6) {
            if (i + 1 >= data.size() || (data[i + 1] >> 6) != 0x2) return false;
            i += 2;
        } else if ((b >> 4) == 0xe) {
            if (i + 2 >= data.size() || (data[i + 1] >> 6) != 0x2 || (data[i + 2] >> 6) != 0x2) return false;
            i += 3;
        } else if ((b >> 3) == 0x1e) {
            if (i + 3 >= data.size() || (data[i + 1] >> 6) != 0x2 || (data[i + 2] >> 6) != 0x2 || (data[i + 3] >> 6) != 0x2) return false;
            i += 4;
        } else {
            return false;
        }
    }
    return true;
}

double ascii_utf8_score_native(const Bytes& data) {
    if (data.empty()) return 0.0;
    std::size_t printable = 0;
    for (const auto b : data) {
        if (b == 9 || b == 10 || b == 13 || (b >= 32 && b < 127)) ++printable;
    }
    const double printable_ratio = static_cast<double>(printable) / static_cast<double>(data.size());
    return std::min(1.0, printable_ratio + (is_valid_utf8(data) ? 0.1 : 0.0));
}

double numeric_csv_score_native(const Bytes& data) {
    if (data.empty()) return 0.0;
    std::size_t hits = 0;
    std::size_t lines = 0;
    std::size_t separators = 0;
    for (const auto b : data) {
        const bool allowed = (b >= '0' && b <= '9') || b == ',' || b == '.' || b == ';' || b == ':' ||
            b == '-' || b == '+' || b == 'e' || b == 'E' || b == '\r' || b == '\n' || b == '\t' || b == ' ';
        if (allowed) ++hits;
        if (b == '\n') ++lines;
        if (b == ',' || b == ';' || b == '\t') ++separators;
    }
    double score = static_cast<double>(hits) / static_cast<double>(data.size());
    if (lines >= 2 && separators >= 2) score += 0.2;
    return std::min(1.0, score);
}

std::string file_family_native(const std::string& path, const Bytes& data) {
    const auto ext = lower_ext(path);
    if (ext == ".md" || ext == ".txt") return "text";
    if (ext == ".log") return "text_log";
    if (ext == ".json") return "json";
    if (ext == ".csv" || ext == ".tsv") return "numeric_csv";
    if (ext == ".py" || ext == ".c" || ext == ".cpp" || ext == ".h" || ext == ".hpp" ||
        ext == ".js" || ext == ".ts" || ext == ".tsx" || ext == ".jsx" || ext == ".mjs" ||
        ext == ".cjs" || ext == ".php" || ext == ".css" || ext == ".scss" || ext == ".html" ||
        ext == ".htm" || ext == ".xml" || ext == ".svg" || ext == ".yml" || ext == ".yaml" ||
        ext == ".toml" || ext == ".ini" || ext == ".cfg" || ext == ".conf" || ext == ".lock" ||
        ext == ".map") return "source";
    if (ext == ".yuv" || ext == ".raw" || ext == ".bmp") return "raw_bitmap";
    if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".zip" || ext == ".mp4" || ext == ".pdf") return "negative_control";
    if (byte_entropy_score(data) > 7.65) return "high_entropy";
    return "binary";
}

Bytes chunk_bytes_from_probe(const Json& probe, const std::map<std::string, Bytes>& files) {
    const auto path = as_string(at(probe, "path"));
    const auto offset = static_cast<std::size_t>(as_u64(at(probe, "offset")));
    const auto size = static_cast<std::size_t>(as_u64(at(probe, "size")));
    const auto it = files.find(path);
    if (it == files.end()) fail("input missing file required by oracle plan: " + path);
    const Bytes& data = it->second;
    if (offset + size > data.size()) fail("oracle chunk outside input file: " + path);
    return Bytes(data.begin() + static_cast<std::ptrdiff_t>(offset), data.begin() + static_cast<std::ptrdiff_t>(offset + size));
}

struct NativeFileRecord {
    std::uint64_t file_id = 0;
    std::string path;
    std::string path_hash;
    std::uint64_t size = 0;
    std::string sha256;
    std::vector<std::uint64_t> chunk_ids;
    std::string family;
    std::string folder_layer;
};

struct NativeProbe {
    std::uint64_t chunk_id = 0;
    std::uint64_t file_id = 0;
    std::string path;
    std::uint64_t offset = 0;
    std::uint64_t size = 0;
    std::string sha256;
    std::string path_hash;
    double entropy = 0.0;
    double repetition = 0.0;
    double zero_run = 0.0;
    double ascii = 0.0;
    double numeric = 0.0;
    double sim_prev = 0.0;
    double sim_cross = 0.0;
    std::uint64_t metadata_cost = 0;
    std::string content_family;
    std::string folder_layer;
    Bytes data;
};

struct NativePayload {
    std::string method;
    Bytes encoded;
    std::uint64_t logical_size = 0;
    std::string decoded_sha;
    std::string flags_json = "{}";
    std::optional<std::uint64_t> base_chunk_id;
};

struct SelectorTiming {
    double scan_ms = 0.0;
    double probe_ms = 0.0;
    double selector_ms = 0.0;
    double total_ms = 0.0;
};

struct PackTiming {
    double scan_ms = 0.0;
    double payload_ms = 0.0;
    double manifest_ms = 0.0;
    double write_ms = 0.0;
    double checksum_ms = 0.0;
    double verify_decode_ms = 0.0;
    double total_ms = 0.0;
};

enum class VerifyMode {
    Off,
    ChecksumsOnly,
    FullNoWrite,
    Full
};

std::string verify_mode_name(VerifyMode mode) {
    switch (mode) {
        case VerifyMode::Off: return "off";
        case VerifyMode::ChecksumsOnly: return "checksums-only";
        case VerifyMode::FullNoWrite: return "full-no-write";
        case VerifyMode::Full: return "full";
    }
    return "off";
}

NativePayload best_individual_payload_native(const Bytes& data, ZlibRaw& zlib) {
    std::vector<NativePayload> candidates;
    const auto sha = sha256_hex(data);
    candidates.push_back(NativePayload{"STORE", data, data.size(), sha, "{}", std::nullopt});
    candidates.push_back(NativePayload{"RLE", encode_rle(data), data.size(), sha, "{}", std::nullopt});
    candidates.push_back(NativePayload{"RANGE0", zlib.deflate_raw(data, 2), data.size(), sha, "{\"backend\":\"stdlib_deflate_huffman_only\"}", std::nullopt});
    candidates.push_back(NativePayload{"LZ_RANGE", zlib.deflate_raw(data, 0), data.size(), sha, "{\"backend\":\"stdlib_deflate_raw\"}", std::nullopt});
    if (data.size() >= 16) {
        const auto encoded = zlib.deflate_raw(byte_shuffle(data, 4), 0);
        const auto decoded = byte_unshuffle(zlib.inflate_raw(encoded), data.size(), 4);
        if (decoded == data) {
            candidates.push_back(NativePayload{"BYTE_SHUFFLE_RANGE", encoded, data.size(), sha, "{\"original_size\":" + std::to_string(data.size()) + ",\"word_size\":4}", std::nullopt});
        }
    }
    std::sort(candidates.begin(), candidates.end(), [](const auto& a, const auto& b) {
        if (a.encoded.size() != b.encoded.size()) return a.encoded.size() < b.encoded.size();
        return a.method < b.method;
    });
    return candidates.front();
}

std::pair<std::vector<NativeFileRecord>, std::vector<NativeProbe>> build_native_files_and_chunks(
    const std::vector<std::pair<std::string, Bytes>>& input_files,
    std::size_t chunk_size
) {
    auto canonical_files = input_files;
    std::sort(canonical_files.begin(), canonical_files.end(), [](const auto& a, const auto& b) {
        const auto ah = sha256_hex_string(a.first);
        const auto bh = sha256_hex_string(b.first);
        return ah == bh ? a.first < b.first : ah < bh;
    });
    std::vector<NativeFileRecord> files;
    std::vector<NativeProbe> chunks;
    std::map<std::string, std::vector<std::pair<std::uint64_t, Bytes>>> previous_by_family;
    std::vector<std::tuple<std::uint64_t, std::string, Bytes>> all_previous;
    std::uint64_t chunk_id = 0;
    for (std::size_t file_index = 0; file_index < canonical_files.size(); ++file_index) {
        const auto& path = canonical_files[file_index].first;
        const auto& data = canonical_files[file_index].second;
        const auto family = file_family_native(path, data);
        const auto slash = path.find('/');
        const auto folder = slash == std::string::npos ? "." : path.substr(0, slash);
        NativeFileRecord file;
        file.file_id = static_cast<std::uint64_t>(file_index);
        file.path = path;
        file.path_hash = sha256_hex_string(path);
        file.size = data.size();
        file.sha256 = sha256_hex(data);
        file.family = family;
        file.folder_layer = folder;
        for (std::size_t offset = 0; offset < std::max<std::size_t>(1, data.size()); offset += chunk_size) {
            Bytes piece;
            if (!data.empty()) {
                const auto size = std::min<std::size_t>(chunk_size, data.size() - offset);
                piece = Bytes(data.begin() + static_cast<std::ptrdiff_t>(offset), data.begin() + static_cast<std::ptrdiff_t>(offset + size));
            }
            double sim_prev = 0.0;
            const auto& same_family = previous_by_family[family];
            const auto start_family = same_family.size() > 32 ? same_family.size() - 32 : 0;
            for (std::size_t i = start_family; i < same_family.size(); ++i) sim_prev = std::max(sim_prev, byte_similarity(piece, same_family[i].second));
            double sim_cross = 0.0;
            const auto start_all = all_previous.size() > 64 ? all_previous.size() - 64 : 0;
            for (std::size_t i = start_all; i < all_previous.size(); ++i) {
                const auto& [_, prev_path, prev_data] = all_previous[i];
                if (prev_path != path) sim_cross = std::max(sim_cross, byte_similarity(piece, prev_data));
            }
            NativeProbe probe;
            probe.chunk_id = chunk_id;
            probe.file_id = file.file_id;
            probe.path = path;
            probe.offset = static_cast<std::uint64_t>(offset);
            probe.size = piece.size();
            probe.sha256 = sha256_hex(piece);
            probe.path_hash = sha256_hex_string(path + std::string("\0", 1) + std::to_string(offset));
            probe.entropy = round6(byte_entropy_score(piece));
            probe.repetition = round6(repetition_score_native(piece));
            probe.zero_run = round6(zero_run_score_native(piece));
            probe.ascii = round6(ascii_utf8_score_native(piece));
            probe.numeric = round6(numeric_csv_score_native(piece));
            probe.sim_prev = round6(sim_prev);
            probe.sim_cross = round6(sim_cross);
            probe.metadata_cost = 32 + path.size() / 4 + (piece.size() < 128 ? 16 : 0);
            probe.content_family = family;
            probe.folder_layer = folder;
            probe.data = piece;
            chunks.push_back(std::move(probe));
            file.chunk_ids.push_back(chunk_id);
            previous_by_family[family].push_back({chunk_id, piece});
            all_previous.push_back({chunk_id, path, piece});
            ++chunk_id;
            if (data.empty()) break;
        }
        files.push_back(std::move(file));
    }
    return {files, chunks};
}

struct Dsu {
    std::map<std::uint64_t, std::uint64_t> parent;
    explicit Dsu(const std::vector<std::uint64_t>& ids) {
        for (const auto id : ids) parent[id] = id;
    }
    std::uint64_t find(std::uint64_t x) {
        while (parent[x] != x) {
            parent[x] = parent[parent[x]];
            x = parent[x];
        }
        return x;
    }
    void unite(std::uint64_t a, std::uint64_t b) {
        const auto ra = find(a);
        const auto rb = find(b);
        if (ra != rb) parent[std::max(ra, rb)] = std::min(ra, rb);
    }
};

std::vector<std::vector<std::uint64_t>> cluster_chunks_native(const std::vector<NativeProbe>& chunks) {
    std::vector<const NativeProbe*> candidates;
    std::vector<std::uint64_t> candidate_ids;
    for (const auto& chunk : chunks) {
        if (chunk.content_family != "negative_control" && chunk.content_family != "high_entropy" && chunk.size >= 256 && chunk.entropy < 7.7) {
            candidates.push_back(&chunk);
            candidate_ids.push_back(chunk.chunk_id);
        }
    }
    Dsu dsu(candidate_ids);
    std::map<std::pair<std::string, std::uint64_t>, std::vector<const NativeProbe*>> buckets;
    std::map<std::string, std::vector<const NativeProbe*>> exact_hash_buckets;
    for (const auto* chunk : candidates) {
        buckets[{chunk->content_family, chunk->size}].push_back(chunk);
        exact_hash_buckets[chunk->sha256].push_back(chunk);
    }
    for (const auto& [_, group] : exact_hash_buckets) {
        if (group.size() < 2) continue;
        const auto first = group.front()->chunk_id;
        for (std::size_t i = 1; i < group.size(); ++i) dsu.unite(first, group[i]->chunk_id);
    }
    for (auto& [_, bucket] : buckets) {
        std::sort(bucket.begin(), bucket.end(), [](const auto* a, const auto* b) {
            if (a->sha256 != b->sha256) return a->sha256 < b->sha256;
            if (a->path_hash != b->path_hash) return a->path_hash < b->path_hash;
            return a->chunk_id < b->chunk_id;
        });
        for (std::size_t i = 0; i < bucket.size(); ++i) {
            const auto* left = bucket[i];
            const auto end = std::min(bucket.size(), i + 1 + 32);
            for (std::size_t j = i + 1; j < end; ++j) {
                const auto* right = bucket[j];
                if (left->sha256 == right->sha256) continue;
                if (left->content_family != right->content_family && left->folder_layer != right->folder_layer) continue;
                if (byte_similarity(left->data, right->data) >= 0.52) dsu.unite(left->chunk_id, right->chunk_id);
            }
        }
    }
    std::set<std::string> families;
    for (const auto* chunk : candidates) families.insert(chunk->content_family);
    for (const auto& family : families) {
        std::vector<const NativeProbe*> family_chunks;
        for (const auto* chunk : candidates) {
            if (chunk->content_family == family) family_chunks.push_back(chunk);
        }
        std::sort(family_chunks.begin(), family_chunks.end(), [](const auto* a, const auto* b) {
            if (a->path_hash != b->path_hash) return a->path_hash < b->path_hash;
            if (a->sha256 != b->sha256) return a->sha256 < b->sha256;
            return a->chunk_id < b->chunk_id;
        });
        for (std::size_t i = 0; i < family_chunks.size(); ++i) {
            const auto* left = family_chunks[i];
            const auto end = std::min(family_chunks.size(), i + 1 + 8);
            for (std::size_t j = i + 1; j < end; ++j) {
                const auto* right = family_chunks[j];
                if (left->chunk_id == right->chunk_id) continue;
                if (left->size != right->size) continue;
                if (left->content_family != right->content_family && left->folder_layer != right->folder_layer) continue;
                if (byte_similarity(left->data, right->data) >= 0.52) dsu.unite(left->chunk_id, right->chunk_id);
            }
        }
    }
    std::map<std::uint64_t, std::vector<std::uint64_t>> groups;
    std::vector<std::uint64_t> root_order;
    for (const auto* chunk : candidates) {
        const auto root = dsu.find(chunk->chunk_id);
        if (!groups.count(root)) root_order.push_back(root);
        groups[root].push_back(chunk->chunk_id);
    }
    std::vector<std::vector<std::uint64_t>> out;
    for (const auto root : root_order) {
        auto ids = groups[root];
        if (ids.size() >= 2) {
            std::sort(ids.begin(), ids.end());
            out.push_back(std::move(ids));
        }
    }
    return out;
}

std::uint64_t canonical_medoid_native(const std::vector<std::uint64_t>& cluster, const std::map<std::uint64_t, const NativeProbe*>& chunks_by_id) {
    struct Score {
        double neg_avg = 0.0;
        std::string key;
        std::uint64_t cid = 0;
    };
    std::vector<Score> scored;
    for (const auto cid : cluster) {
        double total = 0.0;
        for (const auto other : cluster) {
            if (other == cid) continue;
            total += byte_similarity(chunks_by_id.at(cid)->data, chunks_by_id.at(other)->data);
        }
        const double avg = total / static_cast<double>(cluster.size() - 1);
        scored.push_back(Score{-avg, chunks_by_id.at(cid)->sha256 + chunks_by_id.at(cid)->path_hash, cid});
    }
    std::sort(scored.begin(), scored.end(), [](const auto& a, const auto& b) {
        if (a.neg_avg != b.neg_avg) return a.neg_avg < b.neg_avg;
        if (a.key != b.key) return a.key < b.key;
        return a.cid < b.cid;
    });
    return scored.front().cid;
}

Json::Array make_checkpoints_native(const std::vector<NativeFileRecord>& files, const std::vector<NativeProbe>& chunks, const std::vector<std::vector<std::uint64_t>>& clusters, std::uint64_t epoch_bytes) {
    Json::Array checkpoints;
    std::uint64_t checkpoint_id = 0;
    auto sorted_files = files;
    std::sort(sorted_files.begin(), sorted_files.end(), [](const auto& a, const auto& b) {
        return a.path_hash == b.path_hash ? a.path < b.path : a.path_hash < b.path_hash;
    });
    for (const auto& file : sorted_files) {
        checkpoints.push_back(jobj({{"checkpoint_id", jnum(checkpoint_id++)}, {"member_chunk_ids", json_u64_array(file.chunk_ids)}, {"scope_key", jstr(file.path)}, {"scope_type", jstr("file")}}));
    }
    std::map<std::string, std::vector<std::uint64_t>> folder_members;
    for (const auto& chunk : chunks) folder_members[chunk.folder_layer].push_back(chunk.chunk_id);
    std::vector<std::string> folders;
    for (const auto& [folder, _] : folder_members) folders.push_back(folder);
    std::sort(folders.begin(), folders.end(), [](const auto& a, const auto& b) { return sha256_hex_string(a) < sha256_hex_string(b); });
    for (const auto& folder : folders) {
        auto members = folder_members[folder];
        std::sort(members.begin(), members.end());
        checkpoints.push_back(jobj({{"checkpoint_id", jnum(checkpoint_id++)}, {"member_chunk_ids", json_u64_array(members)}, {"scope_key", jstr(folder)}, {"scope_type", jstr("folder")}}));
    }
    auto sorted_chunks = chunks;
    std::sort(sorted_chunks.begin(), sorted_chunks.end(), [](const auto& a, const auto& b) {
        return a.path_hash == b.path_hash ? a.chunk_id < b.chunk_id : a.path_hash < b.path_hash;
    });
    std::vector<std::uint64_t> epoch;
    std::uint64_t epoch_size = 0;
    std::uint64_t epoch_index = 0;
    auto flush_epoch = [&]() {
        if (epoch.empty()) return;
        std::sort(epoch.begin(), epoch.end());
        std::ostringstream key;
        key << "epoch_" << std::setw(4) << std::setfill('0') << epoch_index++;
        checkpoints.push_back(jobj({{"checkpoint_id", jnum(checkpoint_id++)}, {"member_chunk_ids", json_u64_array(epoch)}, {"scope_key", jstr(key.str())}, {"scope_type", jstr("epoch")}}));
        epoch.clear();
        epoch_size = 0;
    };
    for (const auto& chunk : sorted_chunks) {
        epoch.push_back(chunk.chunk_id);
        epoch_size += chunk.size;
        if (epoch_size >= epoch_bytes) flush_epoch();
    }
    flush_epoch();
    for (std::size_t i = 0; i < clusters.size(); ++i) {
        auto members = clusters[i];
        std::sort(members.begin(), members.end());
        std::ostringstream key;
        key << "cluster_" << std::setw(4) << std::setfill('0') << i;
        checkpoints.push_back(jobj({{"checkpoint_id", jnum(checkpoint_id++)}, {"member_chunk_ids", json_u64_array(members)}, {"scope_key", jstr(key.str())}, {"scope_type", jstr("similarity_cluster")}}));
    }
    return checkpoints;
}

std::uint64_t checkpoint_for_chunk_native(const Json::Array& checkpoints, std::uint64_t chunk_id, bool prefer_cluster) {
    auto has_member = [&](const Json& cp) {
        for (const auto& member : at(cp, "member_chunk_ids").array()) {
            if (as_u64(member) == chunk_id) return true;
        }
        return false;
    };
    if (prefer_cluster) {
        for (const auto& cp : checkpoints) {
            if (as_string(at(cp, "scope_type")) == "similarity_cluster" && has_member(cp)) return as_u64(at(cp, "checkpoint_id"));
        }
    }
    for (const auto& cp : checkpoints) {
        if (as_string(at(cp, "scope_type")) == "file" && has_member(cp)) return as_u64(at(cp, "checkpoint_id"));
    }
    return 0;
}

std::string canonical_plan_hash_native(
    const std::vector<NativeFileRecord>& files,
    const std::vector<NativeProbe>& chunks,
    const Json::Array& support_table,
    const Json::Array& checkpoints,
    const Json::Array& chunk_plan
) {
    Json::Array file_arr;
    for (const auto& file : files) {
        file_arr.push_back(jobj({{"chunk_ids", json_u64_array(file.chunk_ids)}, {"path", jstr(file.path)}, {"sha256", jstr(file.sha256)}, {"size", jnum(file.size)}}));
    }
    Json::Array chunk_arr;
    auto sorted_chunks = chunks;
    std::sort(sorted_chunks.begin(), sorted_chunks.end(), [](const auto& a, const auto& b) { return a.chunk_id < b.chunk_id; });
    for (const auto& chunk : sorted_chunks) {
        chunk_arr.push_back(jobj({
            {"chunk_id", jnum(chunk.chunk_id)},
            {"family", jstr(chunk.content_family)},
            {"offset", jnum(chunk.offset)},
            {"path", jstr(chunk.path)},
            {"sha256", jstr(chunk.sha256)},
            {"size", jnum(chunk.size)}
        }));
    }
    Json::Array sorted_chunk_plan = chunk_plan;
    std::sort(sorted_chunk_plan.begin(), sorted_chunk_plan.end(), [](const Json& a, const Json& b) {
        return as_u64(at(a, "chunk_id")) < as_u64(at(b, "chunk_id"));
    });
    Json plan = jobj({
        {"checkpointed", jnull()}
    });
    (void)plan;
    Json root = jobj({
        {"checkpointed", jnull()}
    });
    root = jobj({
        {"checkpoints", jarr(checkpoints)},
        {"chunk_plan", jarr(std::move(sorted_chunk_plan))},
        {"chunks", jarr(std::move(chunk_arr))},
        {"files", jarr(std::move(file_arr))},
        {"supports", jarr(support_table)},
        {"variant", jstr("checkpointed_cfc")}
    });
    return sha256_hex_string(json_dump(root));
}

Json build_native_checkpointed_oracle_plan(
    const fs::path& input_dir,
    const std::string& schedule,
    int threads,
    std::uint64_t epoch_bytes,
    SelectorTiming* timing = nullptr
) {
    const auto total_start = Clock::now();
    const auto scan_start = Clock::now();
    const auto traversal_files = read_dataset_dir_scheduled(input_dir, schedule);
    if (timing) timing->scan_ms = elapsed_ms(scan_start);
    std::map<std::string, Bytes> canonical_files;
    for (const auto& [path, data] : traversal_files) canonical_files[path] = data;
    const auto dataset_sha = compute_dataset_digest(canonical_files);
    const auto probe_start = Clock::now();
    const auto [files, chunks] = build_native_files_and_chunks(traversal_files, kDefaultChunkSize);
    if (timing) timing->probe_ms = elapsed_ms(probe_start);
    const auto selector_start = Clock::now();
    (void)threads;
    std::map<std::uint64_t, const NativeProbe*> chunks_by_id;
    for (const auto& chunk : chunks) chunks_by_id[chunk.chunk_id] = &chunk;
    const auto clusters = cluster_chunks_native(chunks);
    const auto checkpoints = make_checkpoints_native(files, chunks, clusters, epoch_bytes);

    ZlibRaw zlib;
    std::map<std::uint64_t, NativePayload> individual_best;
    std::uint64_t no_delta_estimated = 0;
    for (const auto& chunk : chunks) {
        auto payload = best_individual_payload_native(chunk.data, zlib);
        no_delta_estimated += payload.encoded.size() + 24;
        individual_best[chunk.chunk_id] = std::move(payload);
    }

    Json::Array support_table;
    Json::Array chunk_plan;
    std::map<std::uint64_t, Json> chunk_plan_by_id;
    std::set<std::uint64_t> covered_by_delta;
    std::vector<PayloadRecord> payloads;

    for (std::size_t support_id = 0; support_id < clusters.size(); ++support_id) {
        const auto& cluster = clusters[support_id];
        const auto medoid = canonical_medoid_native(cluster, chunks_by_id);
        const auto& base_payload = individual_best.at(medoid);
        std::map<std::uint64_t, NativePayload> delta_payloads;
        std::uint64_t delta_total = base_payload.encoded.size() + 24;
        std::uint64_t individual_total = 0;
        for (const auto cid : cluster) individual_total += individual_best.at(cid).encoded.size() + 24;
        for (const auto cid : cluster) {
            if (cid == medoid) continue;
            auto encoded_delta = make_delta(chunks_by_id.at(medoid)->data, chunks_by_id.at(cid)->data, zlib);
            NativePayload payload;
            payload.method = "DELTA_BASE_RESIDUAL";
            payload.encoded = std::move(encoded_delta);
            payload.logical_size = chunks_by_id.at(cid)->data.size();
            payload.decoded_sha = chunks_by_id.at(cid)->sha256;
            payload.flags_json = "{\"delta_encoding\":\"xor_position_value_v1\"}";
            payload.base_chunk_id = medoid;
            delta_total += payload.encoded.size() + 32;
            delta_payloads[cid] = std::move(payload);
        }
        const auto metadata_cost = static_cast<std::int64_t>(64 + cluster.size() * 8);
        const auto decode_complexity = static_cast<std::int64_t>(4 * cluster.size());
        const auto estimated_gain = static_cast<std::int64_t>(individual_total) - static_cast<std::int64_t>(delta_total);
        const auto pressure = estimated_gain - metadata_cost - decode_complexity;
        const bool selected = pressure > 0;
        const auto* medoid_probe = chunks_by_id.at(medoid);
        support_table.push_back(jobj({
            {"canonical_medoid_chunk_id", jnum(medoid)},
            {"content_family", jstr(medoid_probe->content_family)},
            {"decode_complexity_cost", jnum_i64(decode_complexity)},
            {"estimated_gain", jnum_i64(estimated_gain)},
            {"folder_layer", jstr(medoid_probe->folder_layer)},
            {"member_chunk_ids", json_u64_array(cluster)},
            {"metadata_cost", jnum_i64(metadata_cost)},
            {"pressure_score", jnum_i64(pressure)},
            {"selected", jbool(selected)},
            {"selected_method_candidate", jstr(selected ? "DELTA_BASE_RESIDUAL" : "individual_best")},
            {"support_family_id", jstr("delta_similar_chunks")},
            {"support_id", jnum(static_cast<std::uint64_t>(support_id))}
        }));
        if (!selected) continue;
        auto append_payload = [&](std::uint64_t cid, const NativePayload& payload, std::optional<std::uint64_t> support, std::optional<std::uint64_t> base, const std::string& pressure_source, bool prefer_cluster) {
            PayloadRecord record;
            record.stream_id = payloads.size();
            record.chunk_id = cid;
            record.method = payload.method;
            record.encoded = payload.encoded;
            record.logical_size = payload.logical_size;
            record.decoded_sha = payload.decoded_sha;
            record.base_chunk_id = base;
            payloads.push_back(record);
            Json row = jobj({
                {"base_chunk_id", base ? jnum(*base) : jnull()},
            {"checkpoint_id", jnum(checkpoint_for_chunk_native(checkpoints, cid, prefer_cluster))},
                {"chunk_id", jnum(cid)},
                {"method", jstr(payload.method)},
                {"payload_stream_id", jnum(record.stream_id)},
                {"pressure_source", jstr(pressure_source)},
                {"support_id", support ? jnum(*support) : jnull()}
            });
            chunk_plan_by_id[cid] = row;
            covered_by_delta.insert(cid);
        };
        append_payload(medoid, base_payload, support_id, std::nullopt, "cluster_medoid_base", true);
        for (const auto& [cid, payload] : delta_payloads) {
            append_payload(cid, payload, support_id, medoid, "similarity_cluster_checkpoint", true);
        }
    }

    auto sorted_chunks = chunks;
    std::sort(sorted_chunks.begin(), sorted_chunks.end(), [](const auto& a, const auto& b) {
        return a.path_hash == b.path_hash ? a.chunk_id < b.chunk_id : a.path_hash < b.path_hash;
    });
    for (const auto& chunk : sorted_chunks) {
        if (covered_by_delta.count(chunk.chunk_id)) continue;
        const auto& payload = individual_best.at(chunk.chunk_id);
        PayloadRecord record;
        record.stream_id = payloads.size();
        record.chunk_id = chunk.chunk_id;
        record.method = payload.method;
        record.encoded = payload.encoded;
        record.logical_size = payload.logical_size;
        record.decoded_sha = payload.decoded_sha;
        payloads.push_back(record);
        chunk_plan_by_id[chunk.chunk_id] = jobj({
            {"base_chunk_id", jnull()},
            {"checkpoint_id", jnum(checkpoint_for_chunk_native(checkpoints, chunk.chunk_id, false))},
            {"chunk_id", jnum(chunk.chunk_id)},
            {"method", jstr(payload.method)},
            {"payload_stream_id", jnum(record.stream_id)},
            {"pressure_source", jstr("file_checkpoint_individual_best")},
            {"support_id", jnull()}
        });
    }
    for (const auto& [_, row] : chunk_plan_by_id) chunk_plan.push_back(row);
    const auto plan_hash = canonical_plan_hash_native(files, chunks, support_table, checkpoints, chunk_plan);

    Json::Array file_table;
    for (const auto& file : files) {
        file_table.push_back(jobj({
            {"chunk_ids", json_u64_array(file.chunk_ids)},
            {"file_id", jnum(file.file_id)},
            {"metadata_flags", jobj({{"family", jstr(file.family)}, {"folder_layer", jstr(file.folder_layer)}})},
            {"path", jstr(file.path)},
            {"path_hash", jstr(file.path_hash)},
            {"sha256", jstr(file.sha256)},
            {"size", jnum(file.size)}
        }));
    }
    Json::Array probe_summary;
    for (const auto& chunk : chunks) {
        probe_summary.push_back(jobj({
            {"ascii_utf8_score", Json{chunk.ascii}},
            {"byte_entropy", Json{chunk.entropy}},
            {"chunk_id", jnum(chunk.chunk_id)},
            {"content_family", jstr(chunk.content_family)},
            {"cross_file_similarity", Json{chunk.sim_cross}},
            {"folder_layer", jstr(chunk.folder_layer)},
            {"metadata_cost_estimate", jnum(chunk.metadata_cost)},
            {"numeric_csv_like_score", Json{chunk.numeric}},
            {"offset", jnum(chunk.offset)},
            {"path", jstr(chunk.path)},
            {"repetition_score", Json{chunk.repetition}},
            {"sha256", jstr(chunk.sha256)},
            {"similarity_to_previous_chunks", Json{chunk.sim_prev}},
            {"size", jnum(chunk.size)},
            {"zero_run_score", Json{chunk.zero_run}}
        }));
    }
    auto result = jobj({
        {"canonical_archive", jobj({{"compression_plan_hash", jstr(plan_hash)}, {"payload_bytes", jnum(0)}, {"manifest_bytes", jnum(0)}, {"compressed_bytes", jnum(0)}})},
        {"checkpoint_table", jarr(checkpoints)},
        {"chunk_plan", jarr(chunk_plan)},
        {"dataset_dir", jstr(input_dir.generic_string())},
        {"dataset_id", jstr("ithz_cfc_p0_p1_fixture_native")},
        {"file_table", jarr(std::move(file_table))},
        {"input_bytes", jnum(std::accumulate(files.begin(), files.end(), std::uint64_t{0}, [](auto sum, const auto& f) { return sum + f.size; }))},
        {"original_sha256", jstr(dataset_sha)},
        {"probe_summary", jarr(std::move(probe_summary))},
        {"support_cut_table", jarr(support_table)}
    });
    if (timing) {
        timing->selector_ms = elapsed_ms(selector_start);
        timing->total_ms = elapsed_ms(total_start);
    }
    return result;
}

Json load_oracle_plan(const fs::path& oracle_path) {
    Bytes raw = read_file(oracle_path);
    return JsonParser(std::string(raw.begin(), raw.end())).parse();
}

void write_phase2a_reports(
    const fs::path& out_dir,
    const fs::path& archive_path,
    const std::string& dataset_sha,
    const std::string& plan_hash,
    const std::string& container_hash,
    std::size_t payload_bytes,
    std::size_t manifest_bytes,
    std::size_t archive_bytes,
    std::size_t support_count,
    std::size_t checkpoint_count
) {
    fs::create_directories(out_dir);
    const fs::path matrix_path = out_dir / "native_ithz_phase2a_pack_matrix.csv";
    std::ofstream csv(matrix_path);
    csv << "run_id,variant,schedule,manifest_mode,archive_path,decoded_sha256,semantic_plan_hash,container_bytes_hash,payload_bytes,manifest_bytes,total_archive_bytes,support_count,checkpoint_count,decoded_ok,plan_matches_reference\n";
    csv << "native_ithz_phase2a_checkpointed_original,checkpointed_cfc,original,json,"
        << archive_path.generic_string() << ','
        << dataset_sha << ','
        << plan_hash << ','
        << container_hash << ','
        << payload_bytes << ','
        << manifest_bytes << ','
        << archive_bytes << ','
        << support_count << ','
        << checkpoint_count << ",true,"
        << (plan_hash == "e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c" ? "true" : "false")
        << "\n";
    const fs::path summary_path = out_dir / "native_ithz_phase2a_summary.md";
    std::ofstream md(summary_path);
    md << "# Native ITHZ Phase 2A Packer Parity\n\n"
       << "Status: C++ checkpointed CFC original packer wrote a JSON-manifest `.ithz` archive.\n\n"
       << "```text\n"
       << "archive=" << archive_path.generic_string() << "\n"
       << "decoded_sha256=" << dataset_sha << "\n"
       << "semantic_plan_hash=" << plan_hash << "\n"
       << "container_bytes_hash=" << container_hash << "\n"
       << "payload_bytes=" << payload_bytes << "\n"
       << "manifest_bytes=" << manifest_bytes << "\n"
       << "total_archive_bytes=" << archive_bytes << "\n"
       << "support_count=" << support_count << "\n"
       << "checkpoint_count=" << checkpoint_count << "\n"
       << "```\n\n"
       << "Interpretation: phase 2A is a parity milestone only. It does not add AVX2 planning, binary manifest compaction, schedule QA, or ZIP superiority claims.\n";
}

struct PackStats {
    fs::path archive_path;
    std::string dataset_sha;
    std::string plan_hash;
    std::string container_hash;
    std::size_t payload_bytes = 0;
    std::size_t manifest_bytes = 0;
    std::size_t archive_bytes = 0;
    std::size_t support_count = 0;
    std::size_t checkpoint_count = 0;
};

PackStats pack_checkpointed_original(
    const fs::path& input_dir,
    const fs::path& archive_path,
    const fs::path& oracle_plan_path,
    const std::string& manifest_mode,
    VerifyMode verify_mode,
    bool write_report,
    bool print_status,
    PackTiming* timing = nullptr
) {
    const auto total_start = Clock::now();
    const auto scan_start = Clock::now();
    const auto files = read_dataset_dir(input_dir);
    const auto dataset_sha = compute_dataset_digest(files);
    const Json oracle = load_oracle_plan(oracle_plan_path);
    const auto expected_sha = as_string(at(oracle, "original_sha256"));
    if (dataset_sha != expected_sha) {
        fail("input dataset sha does not match oracle support_cut_plan.json");
    }
    const auto plan_hash = as_string(at(oracle, "canonical_archive").object().at("compression_plan_hash"));
    ZlibRaw zlib;
    if (timing) timing->scan_ms = elapsed_ms(scan_start);

    std::map<std::uint64_t, Bytes> chunk_data;
    for (const auto& probe : at(oracle, "probe_summary").array()) {
        chunk_data[as_u64(at(probe, "chunk_id"))] = chunk_bytes_from_probe(probe, files);
    }

    const auto payload_start = Clock::now();
    std::vector<PayloadRecord> payloads;
    payloads.resize(at(oracle, "chunk_plan").array().size());
    for (const auto& cp : at(oracle, "chunk_plan").array()) {
        const auto chunk_id = as_u64(at(cp, "chunk_id"));
        const auto stream_id = as_u64(at(cp, "payload_stream_id"));
        const auto method = as_string(at(cp, "method"));
        const Bytes& plain = chunk_data.at(chunk_id);
        PayloadRecord record;
        record.stream_id = stream_id;
        record.chunk_id = chunk_id;
        record.method = method;
        record.logical_size = plain.size();
        record.decoded_sha = sha256_hex(plain);
        if (!std::holds_alternative<std::nullptr_t>(at(cp, "base_chunk_id").value)) {
            record.base_chunk_id = as_u64(at(cp, "base_chunk_id"));
        }
        if (method == "STORE") {
            record.encoded = plain;
        } else if (method == "RLE") {
            record.encoded = encode_rle(plain);
        } else if (method == "RANGE0") {
            record.encoded = zlib.deflate_raw(plain, 2);
        } else if (method == "LZ_RANGE") {
            record.encoded = zlib.deflate_raw(plain, 0);
        } else if (method == "BYTE_SHUFFLE_RANGE") {
            record.encoded = zlib.deflate_raw(byte_shuffle(plain, 4), 0);
        } else if (method == "DELTA_BASE_RESIDUAL") {
            if (!record.base_chunk_id) fail("delta chunk missing base id");
            record.encoded = make_delta(chunk_data.at(*record.base_chunk_id), plain, zlib);
        } else {
            fail("unsupported pack method: " + method);
        }
        if (stream_id >= payloads.size()) fail("payload stream id outside vector");
        payloads[static_cast<std::size_t>(stream_id)] = std::move(record);
    }

    Bytes payload_blob;
    for (const auto& payload : payloads) {
        payload_blob.insert(payload_blob.end(), payload.encoded.begin(), payload.encoded.end());
    }
    if (timing) timing->payload_ms = elapsed_ms(payload_start);

    const auto manifest_start = Clock::now();
    Bytes manifest_bytes;
    std::uint32_t flags = 0;
    if (manifest_mode == "json") {
        std::string manifest = make_manifest_json(oracle, payloads, 0, dataset_sha, plan_hash);
        for (int i = 0; i < 8; ++i) {
            const auto payload_offset = static_cast<std::uint64_t>(kHeaderSize + manifest.size());
            std::string next = make_manifest_json(oracle, payloads, payload_offset, dataset_sha, plan_hash);
            if (next.size() == manifest.size()) {
                manifest = std::move(next);
                break;
            }
            manifest = std::move(next);
        }
        manifest_bytes = Bytes(manifest.begin(), manifest.end());
    } else if (manifest_mode == "compact" || manifest_mode == "binary") {
        flags = kFlagCompactManifest;
        manifest_bytes = converged_compact_manifest(oracle, payloads, dataset_sha, plan_hash);
    } else {
        fail("unsupported manifest mode: " + manifest_mode);
    }
    if (timing) timing->manifest_ms = elapsed_ms(manifest_start);
    const auto write_start = Clock::now();
    write_ithz_archive_bytes(archive_path, manifest_bytes, payload_blob, dataset_sha, plan_hash, flags);
    if (timing) timing->write_ms = elapsed_ms(write_start);
    const auto checksum_start = Clock::now();
    const auto container_hash = sha256_hex(read_file(archive_path));
    if (timing) timing->checksum_ms = elapsed_ms(checksum_start);
    if (verify_mode == VerifyMode::ChecksumsOnly) {
        const auto verify_start = Clock::now();
        (void)read_archive(archive_path);
        if (timing) timing->verify_decode_ms = elapsed_ms(verify_start);
    } else if (verify_mode == VerifyMode::FullNoWrite) {
        const auto verify_start = Clock::now();
        P12DecodeTiming verify_timing;
        const auto archive = read_archive_timed(archive_path, &verify_timing);
        const fs::path verify_dir = archive_path.parent_path() / "cpp_pack_verify_no_write";
        const auto decoded_sha = verify_archive_full_no_write_timed(archive, verify_dir, &verify_timing);
        if (decoded_sha != dataset_sha) fail("self-decode no-write verification failed");
        if (timing) timing->verify_decode_ms = elapsed_ms(verify_start);
    } else if (verify_mode == VerifyMode::Full) {
        const auto verify_start = Clock::now();
        const auto archive = read_archive(archive_path);
        const fs::path verify_dir = archive_path.parent_path() / "cpp_pack_verify_decoded";
        if (fs::exists(verify_dir)) fs::remove_all(verify_dir);
        const auto decoded_sha = decode_archive_to_dir(archive, verify_dir);
        if (decoded_sha != dataset_sha) fail("self-decode verification failed");
        if (timing) timing->verify_decode_ms = elapsed_ms(verify_start);
    }
    PackStats stats{
        archive_path,
        dataset_sha,
        plan_hash,
        container_hash,
        payload_blob.size(),
        manifest_bytes.size(),
        fs::file_size(archive_path),
        at(oracle, "support_cut_table").array().size(),
        at(oracle, "checkpoint_table").array().size()
    };
    if (write_report) {
        write_phase2a_reports(
            archive_path.parent_path(),
            archive_path,
            dataset_sha,
            plan_hash,
            container_hash,
            payload_blob.size(),
            manifest_bytes.size(),
            stats.archive_bytes,
            stats.support_count,
            stats.checkpoint_count
        );
    }
    if (print_status) {
        std::cout << "pack_ok=true\n";
        std::cout << "verify_mode=" << verify_mode_name(verify_mode) << "\n";
        std::cout << "archive=" << archive_path.generic_string() << "\n";
        std::cout << "decoded_sha256=" << dataset_sha << "\n";
        std::cout << "semantic_plan_hash=" << plan_hash << "\n";
        std::cout << "container_bytes_hash=" << container_hash << "\n";
        std::cout << "payload_bytes=" << payload_blob.size() << "\n";
        std::cout << "manifest_bytes=" << manifest_bytes.size() << "\n";
    }
    if (timing) timing->total_ms = elapsed_ms(total_start);
    return stats;
}

std::string decode_archive_core(
    const Archive& archive,
    const ArchiveIndex& index,
    const fs::path& output_dir,
    bool write_files,
    P12DecodeTiming* timing = nullptr
) {
    const auto total_start = Clock::now();
    std::map<std::uint64_t, Bytes> decoded_streams;
    std::map<std::uint64_t, Bytes> decoded_chunks;
    std::map<std::string, Bytes> decoded_files;
    std::map<std::string, fs::path> output_targets;
    std::set<std::string> seen_paths;
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto path = as_string(at(file, "canonical_path"));
        const auto safety_start = Clock::now();
        if (!seen_paths.insert(path).second) fail("duplicate archive path: " + path);
        output_targets[path] = safe_extract_target(output_dir, path);
        if (timing) timing->path_safety_ms += elapsed_ms(safety_start);
        Bytes data;
        if (has_key(file, "bundle_payload_stream_id")) {
            const auto stream_id = as_u64(at(file, "bundle_payload_stream_id"));
            auto stream_it = decoded_streams.find(stream_id);
            if (stream_it == decoded_streams.end()) {
                const auto indexed_stream = index.streams.find(stream_id);
                if (indexed_stream == index.streams.end()) fail("bundle payload stream missing for file: " + path);
                stream_it = decoded_streams.emplace(stream_id, decode_payload_plain_indexed(archive, index, *indexed_stream->second, timing)).first;
            }
            const auto slice_start = Clock::now();
            const auto offset = static_cast<std::size_t>(as_u64(at(file, "bundle_offset")));
            const auto size = static_cast<std::size_t>(as_u64(at(file, "bundle_size")));
            const auto& stream_plain = stream_it->second;
            if (offset + size > stream_plain.size()) fail("bundle file slice outside payload: " + path);
            data = Bytes(stream_plain.begin() + static_cast<std::ptrdiff_t>(offset), stream_plain.begin() + static_cast<std::ptrdiff_t>(offset + size));
            if (timing) timing->bundle_slice_ms += elapsed_ms(slice_start);
        } else {
            for (const auto& chunk_id_json : at(file, "chunk_ids").array()) {
                const auto chunk_id = as_u64(chunk_id_json);
                const auto chunk = decode_chunk_recursive(archive, index, chunk_id, decoded_chunks, timing);
                data.insert(data.end(), chunk.begin(), chunk.end());
            }
        }
        const auto original_size = static_cast<std::size_t>(as_u64(at(file, "original_file_size")));
        if (data.size() > original_size) data.resize(original_size);
        const auto sha_start = Clock::now();
        const auto expected_file_sha = as_string(at(file, "file_sha256"));
        if (sha256_hex(data) != expected_file_sha) fail("file sha mismatch: " + path);
        if (timing) timing->sha_verify_ms += elapsed_ms(sha_start);
        decoded_files[path] = std::move(data);
    }
    const auto sha_start = Clock::now();
    const auto decoded_dataset_sha = compute_dataset_digest(decoded_files);
    if (decoded_dataset_sha != as_string(at(archive.manifest, "sha256_original"))) {
        fail("global decoded dataset sha mismatch");
    }
    if (timing) timing->sha_verify_ms += elapsed_ms(sha_start);
    if (write_files) {
        const auto write_start = Clock::now();
        std::set<fs::path> parent_dirs;
        for (const auto& [path, _] : decoded_files) {
            const auto parent = output_targets.at(path).parent_path();
            if (!parent.empty()) parent_dirs.insert(parent);
        }
        for (const auto& dir : parent_dirs) fs::create_directories(dir);
        for (const auto& [path, data] : decoded_files) {
            write_file_existing_parent(output_targets.at(path), data);
        }
        if (timing) timing->file_write_ms += elapsed_ms(write_start);
    }
    if (timing) {
        const auto total = elapsed_ms(total_start);
        timing->total_decode_ms += total;
        if (write_files) timing->total_extract_ms += total;
        else timing->total_verify_full_ms += total;
    }
    return decoded_dataset_sha;
}

std::string decode_archive_to_dir_timed(const Archive& archive, const fs::path& output_dir, P12DecodeTiming* timing) {
    const auto index = build_archive_index(archive, timing);
    return decode_archive_core(archive, index, output_dir, true, timing);
}

std::string decode_archive_to_dir(const Archive& archive, const fs::path& output_dir) {
    return decode_archive_to_dir_timed(archive, output_dir, nullptr);
}

std::string verify_archive_full_no_write_timed(const Archive& archive, const fs::path& virtual_output_dir, P12DecodeTiming* timing) {
    const auto index = build_archive_index(archive, timing);
    return decode_archive_core(archive, index, virtual_output_dir, false, timing);
}

std::string csv_cell(const std::string& value);

void inspect_archive(const fs::path& archive_path) {
    const auto archive = read_archive(archive_path);
    std::cout << "format=ITHZ-CFC\n";
    std::cout << "version=" << static_cast<std::uint64_t>(as_u64(at(archive.manifest, "version"))) << "\n";
    std::cout << "manifest_encoding=" << (has_key(archive.manifest, "manifest_encoding") ? as_string(at(archive.manifest, "manifest_encoding")) : "json") << "\n";
    std::cout << "file_count=" << at(archive.manifest, "file_table").array().size() << "\n";
    std::cout << "chunk_count=" << at(archive.manifest, "chunk_table").array().size() << "\n";
    std::cout << "support_count=" << at(archive.manifest, "support_cut_table").array().size() << "\n";
    std::cout << "checkpoint_count=" << at(archive.manifest, "checkpoint_table").array().size() << "\n";
    std::cout << "payload_stream_count=" << at(archive.manifest, "payload_stream_directory").array().size() << "\n";
    std::cout << "manifest_bytes=" << archive.manifest_bytes.size() << "\n";
    std::cout << "payload_bytes=" << archive.payload.size() << "\n";
    std::cout << "sha256_original=" << archive.header_original_sha << "\n";
    std::cout << "compression_plan_hash=" << archive.header_plan_hash << "\n";
}

const Json* find_payload_stream(const Archive& archive, std::uint64_t stream_id) {
    for (const auto& stream : at(archive.manifest, "payload_stream_directory").array()) {
        if (as_u64(at(stream, "payload_stream_id")) == stream_id) return &stream;
    }
    return nullptr;
}

const Json* find_archive_file(const Archive& archive, const std::string& path) {
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        if (as_string(at(file, "canonical_path")) == path) return &file;
    }
    return nullptr;
}

const Json* find_archive_file_indexed(const ArchiveIndex& index, const std::string& path, P12DecodeTiming* timing = nullptr) {
    const auto start = Clock::now();
    const auto it = index.files.find(path);
    if (timing) timing->path_lookup_ms += elapsed_ms(start);
    return it == index.files.end() ? nullptr : it->second;
}

std::string metadata_string_or(const Json& file, const std::string& key, const std::string& fallback) {
    if (!has_key(file, "metadata_flags")) return fallback;
    const auto& flags = at(file, "metadata_flags").object();
    const auto it = flags.find(key);
    if (it == flags.end()) return fallback;
    return as_string(it->second);
}

Bytes extract_file_bytes_indexed(const Archive& archive, const ArchiveIndex& index, const Json& file, P12DecodeTiming* timing = nullptr) {
    const auto path = as_string(at(file, "canonical_path"));
    const auto safety_start = Clock::now();
    validate_archive_canonical_path(path);
    if (timing) timing->path_safety_ms += elapsed_ms(safety_start);
    Bytes data;
    if (has_key(file, "bundle_payload_stream_id")) {
        const auto stream_id = as_u64(at(file, "bundle_payload_stream_id"));
        const auto stream_it = index.streams.find(stream_id);
        if (stream_it == index.streams.end()) fail("bundle payload stream missing for file: " + path);
        const auto stream_plain = decode_payload_plain_indexed(archive, index, *stream_it->second, timing);
        const auto slice_start = Clock::now();
        const auto offset = static_cast<std::size_t>(as_u64(at(file, "bundle_offset")));
        const auto size = static_cast<std::size_t>(as_u64(at(file, "bundle_size")));
        if (offset + size > stream_plain.size()) fail("bundle slice outside payload for file: " + path);
        data = Bytes(stream_plain.begin() + static_cast<std::ptrdiff_t>(offset), stream_plain.begin() + static_cast<std::ptrdiff_t>(offset + size));
        if (timing) timing->bundle_slice_ms += elapsed_ms(slice_start);
    } else {
        std::map<std::uint64_t, Bytes> decoded_chunks;
        for (const auto& chunk_id_json : at(file, "chunk_ids").array()) {
            const auto chunk_id = as_u64(chunk_id_json);
            const auto chunk = decode_chunk_recursive(archive, index, chunk_id, decoded_chunks, timing);
            data.insert(data.end(), chunk.begin(), chunk.end());
        }
    }
    const auto original_size = static_cast<std::size_t>(as_u64(at(file, "original_file_size")));
    if (data.size() > original_size) data.resize(original_size);
    const auto sha_start = Clock::now();
    const auto expected = as_string(at(file, "file_sha256"));
    if (sha256_hex(data) != expected) fail("file sha mismatch: " + path);
    if (timing) timing->sha_verify_ms += elapsed_ms(sha_start);
    return data;
}

Bytes extract_file_bytes(const Archive& archive, const Json& file) {
    const auto index = build_archive_index(archive);
    return extract_file_bytes_indexed(archive, index, file, nullptr);
}

void list_archive_files(const fs::path& archive_path) {
    const auto archive = read_archive(archive_path);
    std::cout << "path,size,sha256,family,method\n";
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto path = as_string(at(file, "canonical_path"));
        const auto size = as_u64(at(file, "original_file_size"));
        const auto sha = as_string(at(file, "file_sha256"));
        const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
        std::string method = "chunked";
        if (has_key(file, "bundle_payload_stream_id")) {
            const auto* stream = find_payload_stream(archive, as_u64(at(file, "bundle_payload_stream_id")));
            if (stream) method = as_string(at(*stream, "method_id"));
        }
        std::cout << csv_cell(path) << ',' << size << ',' << sha << ',' << family << ',' << method << "\n";
    }
}

void inspect_archive_families(const fs::path& archive_path) {
    const auto archive = read_archive(archive_path);
    std::map<std::string, std::uint64_t> files_by_family;
    std::map<std::string, std::uint64_t> bytes_by_family;
    std::map<std::string, std::set<std::uint64_t>> streams_by_family;
    std::map<std::string, std::set<std::string>> methods_by_family;
    std::uint64_t negative_guard_count = 0;
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
        ++files_by_family[family];
        bytes_by_family[family] += as_u64(at(file, "original_file_size"));
        if (family.find("store") != std::string::npos || family.find("entropy") != std::string::npos || family.find("compressed") != std::string::npos) ++negative_guard_count;
        if (has_key(file, "bundle_payload_stream_id")) {
            const auto stream_id = as_u64(at(file, "bundle_payload_stream_id"));
            streams_by_family[family].insert(stream_id);
            const auto* stream = find_payload_stream(archive, stream_id);
            if (stream) methods_by_family[family].insert(as_string(at(*stream, "method_id")));
        }
    }
    std::cout << "format=ITHZ-CFC\n";
    std::cout << "variant=" << (has_key(archive.manifest, "variant") ? as_string(at(archive.manifest, "variant")) : "unknown") << "\n";
    std::cout << "manifest_encoding=" << (has_key(archive.manifest, "manifest_encoding") ? as_string(at(archive.manifest, "manifest_encoding")) : "json") << "\n";
    std::cout << "semantic_plan_hash=" << archive.header_plan_hash << "\n";
    std::cout << "sha256_original=" << archive.header_original_sha << "\n";
    std::cout << "total_input_bytes=";
    std::uint64_t total = 0;
    for (const auto& [_, bytes] : bytes_by_family) total += bytes;
    std::cout << total << "\n";
    std::cout << "total_archive_bytes=" << fs::file_size(archive_path) << "\n";
    std::cout << "negative_guard_count=" << negative_guard_count << "\n";
    std::cout << "family,method,file_count,input_bytes,payload_bytes\n";
    for (const auto& [family, count] : files_by_family) {
        std::uint64_t payload_bytes = 0;
        for (const auto stream_id : streams_by_family[family]) {
            const auto* stream = find_payload_stream(archive, stream_id);
            if (stream) payload_bytes += as_u64(at(*stream, "encoded_byte_count"));
        }
        std::ostringstream methods;
        bool first = true;
        for (const auto& method : methods_by_family[family]) {
            if (!first) methods << ';';
            first = false;
            methods << method;
        }
        std::cout << family << ',' << csv_cell(methods.str()) << ',' << count << ',' << bytes_by_family[family] << ',' << payload_bytes << "\n";
    }
}

void why_archive_file(const fs::path& archive_path, const std::string& path) {
    const auto archive = read_archive(archive_path);
    const auto* file = find_archive_file(archive, path);
    if (!file) fail("path not found in archive: " + path);
    std::string method = "chunked";
    std::uint64_t stream_id = 0;
    if (has_key(*file, "bundle_payload_stream_id")) {
        stream_id = as_u64(at(*file, "bundle_payload_stream_id"));
        const auto* stream = find_payload_stream(archive, stream_id);
        if (stream) method = as_string(at(*stream, "method_id"));
    }
    std::cout << "path=" << path << "\n";
    std::cout << "size=" << as_u64(at(*file, "original_file_size")) << "\n";
    std::cout << "sha256=" << as_string(at(*file, "file_sha256")) << "\n";
    std::cout << "selected_family=" << metadata_string_or(*file, "selected_family", metadata_string_or(*file, "family", "unknown")) << "\n";
    std::cout << "selected_method=" << method << "\n";
    std::cout << "reason=" << metadata_string_or(*file, "selection_reason", "legacy_manifest_no_selection_reason") << "\n";
    std::cout << "threshold_bytes=" << (has_key(archive.manifest, "p7b_tables") ? as_u64(at(at(archive.manifest, "p7b_tables"), "threshold_bytes")) : 0) << "\n";
    std::cout << "restore_stream_id=" << stream_id << "\n";
    std::cout << "restore_offset=" << (has_key(*file, "bundle_offset") ? as_u64(at(*file, "bundle_offset")) : 0) << "\n";
    std::cout << "restore_length=" << (has_key(*file, "bundle_size") ? as_u64(at(*file, "bundle_size")) : as_u64(at(*file, "original_file_size"))) << "\n";
    std::cout << "restore_mode=" << (has_key(*file, "bundle_payload_stream_id") ? "bundle_stream_slice" : "chunk_sequence") << "\n";
}

void verify_archive_full(const fs::path& archive_path) {
    const auto archive = read_archive(archive_path);
    const auto out = archive_path.parent_path() / ("verify_extract_" + sha256_hex_string(archive_path.generic_string()).substr(0, 12));
    if (fs::exists(out)) fs::remove_all(out);
    const auto sha = decode_archive_to_dir(archive, out);
    fs::remove_all(out);
    std::cout << "verify_ok=true\n";
    std::cout << "decoded_sha256=" << sha << "\n";
    std::cout << "compression_plan_hash=" << archive.header_plan_hash << "\n";
}

void verify_archive_full_no_write(const fs::path& archive_path) {
    P12DecodeTiming timing;
    const auto archive = read_archive_timed(archive_path, &timing);
    const auto out = archive_path.parent_path() / ("verify_no_write_" + sha256_hex_string(archive_path.generic_string()).substr(0, 12));
    const auto sha = verify_archive_full_no_write_timed(archive, out, &timing);
    std::cout << "verify_ok=true\n";
    std::cout << "verify_mode=full-no-write\n";
    std::cout << "decoded_sha256=" << sha << "\n";
    std::cout << "compression_plan_hash=" << archive.header_plan_hash << "\n";
    std::cout << "total_verify_full_ms=" << std::fixed << std::setprecision(3) << timing.total_verify_full_ms << "\n";
}

void extract_single_file(const fs::path& archive_path, const std::string& path, const fs::path& output_path) {
    const auto archive = read_archive(archive_path);
    const auto index = build_archive_index(archive);
    const auto* file = find_archive_file_indexed(index, path);
    if (!file) fail("path not found in archive: " + path);
    const auto data = extract_file_bytes_indexed(archive, index, *file);
    if (output_path.generic_string() == "-") {
#ifdef _WIN32
        _setmode(_fileno(stdout), _O_BINARY);
#endif
        std::cout.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
        return;
    }
    fs::path target = output_path;
    if (fs::exists(output_path) && fs::is_directory(output_path)) {
        const auto filename = fs::path(path).filename().generic_string();
        validate_archive_canonical_path(filename);
        target = safe_extract_target(output_path, filename);
    }
    write_file(target, data);
    std::cout << "extract_file_ok=true\n";
    std::cout << "path=" << path << "\n";
    std::cout << "output=" << target.generic_string() << "\n";
    std::cout << "sha256=" << sha256_hex(data) << "\n";
}

std::string method_flags_json_simple(const std::string& method, std::size_t logical_size) {
    if (method == "LZ_RANGE") return "{\"backend\":\"stdlib_deflate_raw\"}";
    if (method == "RANGE0") return "{\"backend\":\"stdlib_deflate_huffman_only\"}";
    if (method == "BYTE_SHUFFLE_RANGE") return "{\"original_size\":" + std::to_string(logical_size) + ",\"word_size\":4}";
    if (method == "DELTA_BASE_RESIDUAL") return "{\"delta_encoding\":\"greedy_visit_order_v1\"}";
    return "{}";
}

double byte_similarity(const Bytes& a, const Bytes& b) {
    const auto n = std::min(a.size(), b.size());
    if (n == 0) return 0.0;
    std::size_t same = 0;
    for (std::size_t i = 0; i < n; ++i) {
        if (a[i] == b[i]) ++same;
    }
    return static_cast<double>(same) / static_cast<double>(std::max(a.size(), b.size()));
}

struct NativeChunk {
    std::uint64_t chunk_id = 0;
    std::uint64_t file_id = 0;
    std::string path;
    std::uint64_t offset = 0;
    Bytes data;
    std::string sha;
};

PackStats pack_greedy_event_local(const fs::path& input_dir, const fs::path& archive_path, const std::string& schedule, bool verify) {
    const auto scheduled_files = read_dataset_dir_scheduled(input_dir, schedule);
    std::map<std::string, Bytes> canonical_files;
    for (const auto& [path, data] : scheduled_files) canonical_files[path] = data;
    const auto dataset_sha = compute_dataset_digest(canonical_files);

    struct FileInfo { std::uint64_t file_id; std::string path; Bytes data; std::vector<std::uint64_t> chunk_ids; };
    std::vector<FileInfo> files;
    std::vector<NativeChunk> chunks;
    for (const auto& [path, data] : scheduled_files) {
        FileInfo file{static_cast<std::uint64_t>(files.size()), path, data, {}};
        for (std::size_t offset = 0; offset < data.size(); offset += kDefaultChunkSize) {
            const auto size = std::min<std::size_t>(kDefaultChunkSize, data.size() - offset);
            Bytes piece(data.begin() + static_cast<std::ptrdiff_t>(offset), data.begin() + static_cast<std::ptrdiff_t>(offset + size));
            const auto cid = static_cast<std::uint64_t>(chunks.size());
            file.chunk_ids.push_back(cid);
            chunks.push_back(NativeChunk{cid, file.file_id, path, static_cast<std::uint64_t>(offset), piece, sha256_hex(piece)});
        }
        files.push_back(std::move(file));
    }

    Json::Array support_table;
    Json::Array checkpoint_table;
    for (const auto& file : files) {
        checkpoint_table.push_back(jobj({{"checkpoint_id", jnum(file.file_id)}, {"member_chunk_ids", json_u64_array(file.chunk_ids)}, {"scope_key", jstr(file.path)}, {"scope_type", jstr("file")}}));
    }

    ZlibRaw zlib;
    std::vector<PayloadRecord> payloads;
    std::map<std::uint64_t, std::uint64_t> support_by_chunk;
    for (const auto& chunk : chunks) {
        PayloadRecord record;
        record.stream_id = chunk.chunk_id;
        record.chunk_id = chunk.chunk_id;
        record.logical_size = chunk.data.size();
        record.decoded_sha = chunk.sha;
        double best_score = 0.0;
        std::optional<std::uint64_t> best_base;
        const auto begin = chunk.chunk_id > 64 ? static_cast<std::size_t>(chunk.chunk_id - 64) : 0U;
        for (std::size_t i = begin; i < static_cast<std::size_t>(chunk.chunk_id); ++i) {
            const double score = byte_similarity(chunks[i].data, chunk.data);
            if (score > best_score) {
                best_score = score;
                best_base = chunks[i].chunk_id;
            }
        }
        if (best_base && best_score >= 0.74) {
            record.method = "DELTA_BASE_RESIDUAL";
            record.base_chunk_id = best_base;
            record.encoded = make_delta(chunks[static_cast<std::size_t>(*best_base)].data, chunk.data, zlib);
            const auto sid = static_cast<std::uint64_t>(support_table.size());
            support_by_chunk[chunk.chunk_id] = sid;
            support_table.push_back(jobj({
                {"canonical_medoid_chunk_id", jnum(*best_base)},
                {"content_family", jstr("greedy_visit_order")},
                {"folder_layer", jstr("visit_order")},
                {"member_chunk_ids", json_u64_array(std::vector<std::uint64_t>{*best_base, chunk.chunk_id})},
                {"pressure_score", Json{best_score * 1000.0}},
                {"selected", jbool(true)},
                {"selected_method_candidate", jstr("DELTA_BASE_RESIDUAL")},
                {"support_family_id", jstr("greedy_event_local_delta")},
                {"support_id", jnum(sid)}
            }));
        } else {
            Bytes deflated = zlib.deflate_raw(chunk.data, 0);
            if (deflated.size() + 8 < chunk.data.size()) {
                record.method = "LZ_RANGE";
                record.encoded = std::move(deflated);
            } else {
                record.method = "STORE";
                record.encoded = chunk.data;
            }
        }
        payloads.push_back(std::move(record));
    }

    Sha256 plan_sha;
    plan_sha.update(std::string("greedy_event_local\n"));
    plan_sha.update(schedule);
    for (const auto& payload : payloads) {
        plan_sha.update(std::to_string(payload.chunk_id) + ":" + payload.method + ":" + std::to_string(payload.base_chunk_id.value_or(UINT64_MAX)) + ":" + payload.decoded_sha + "\n");
    }
    const auto plan_digest = plan_sha.final();
    const auto plan_hash = hex_of(plan_digest.data(), plan_digest.size());

    Bytes payload_blob;
    for (const auto& payload : payloads) payload_blob.insert(payload_blob.end(), payload.encoded.begin(), payload.encoded.end());
    auto make_manifest = [&](std::uint64_t payload_offset_base) {
        std::ostringstream oss;
        oss << "{\"checkpoint_table\":" << json_dump(jarr(checkpoint_table)) << ",\"chunk_table\":[";
        bool first = true;
        for (const auto& chunk : chunks) {
            const auto& payload = payloads[static_cast<std::size_t>(chunk.chunk_id)];
            if (!first) oss << ',';
            first = false;
            oss << "{\"base_chunk_id\":";
            if (payload.base_chunk_id) oss << *payload.base_chunk_id; else oss << "null";
            oss << ",\"chunk_id\":" << chunk.chunk_id
                << ",\"chunk_size\":" << chunk.data.size()
                << ",\"file_id\":" << chunk.file_id
                << ",\"file_offset\":" << chunk.offset
                << ",\"payload_stream_id\":" << payload.stream_id
                << ",\"probe_feature_summary\":{\"content_family\":\"greedy_visit_order\",\"folder_layer\":\"visit_order\"}"
                << ",\"selected_checkpoint_id\":" << chunk.file_id
                << ",\"selected_method_id\":" << json_escape(payload.method)
                << ",\"selected_support_id\":";
            if (support_by_chunk.count(chunk.chunk_id)) oss << support_by_chunk.at(chunk.chunk_id); else oss << "null";
            oss << ",\"stable_chunk_hash\":" << json_escape(chunk.sha) << '}';
        }
        oss << "],\"compression_plan_hash\":" << json_escape(plan_hash) << ",\"file_table\":[";
        first = true;
        for (const auto& file : files) {
            if (!first) oss << ',';
            first = false;
            oss << "{\"canonical_path\":" << json_escape(file.path)
                << ",\"chunk_ids\":" << json_dump(json_u64_array(file.chunk_ids))
                << ",\"chunk_range\":[" << (file.chunk_ids.empty() ? 0 : file.chunk_ids.front()) << ',' << (file.chunk_ids.empty() ? 0 : file.chunk_ids.back()) << ']'
                << ",\"file_id\":" << file.file_id
                << ",\"file_sha256\":" << json_escape(sha256_hex(file.data))
                << ",\"metadata_flags\":{\"family\":\"greedy_fixture\",\"folder_layer\":\"visit_order\"}"
                << ",\"original_file_size\":" << file.data.size()
                << ",\"path_hash\":" << json_escape(sha256_hex_string(file.path)) << '}';
        }
        oss << "],\"format\":\"ITHZ-CFC\",\"no_delta_estimated_payload_bytes\":0,\"payload_stream_directory\":[";
        std::uint64_t cursor = payload_offset_base;
        first = true;
        for (const auto& payload : payloads) {
            if (!first) oss << ',';
            first = false;
            oss << "{\"base_chunk_id\":";
            if (payload.base_chunk_id) oss << *payload.base_chunk_id; else oss << "null";
            oss << ",\"byte_length\":" << payload.encoded.size()
                << ",\"byte_offset\":" << cursor
                << ",\"decoded_sha256\":" << json_escape(payload.decoded_sha)
                << ",\"encoded_byte_count\":" << payload.encoded.size()
                << ",\"method_id\":" << json_escape(payload.method)
                << ",\"method_specific_flags\":" << method_flags_json_simple(payload.method, payload.logical_size)
                << ",\"payload_stream_id\":" << payload.stream_id
                << ",\"uncompressed_logical_byte_count\":" << payload.logical_size << '}';
            cursor += payload.encoded.size();
        }
        oss << "],\"sha256_decoded\":\"\",\"sha256_original\":" << json_escape(dataset_sha)
            << ",\"support_cut_table\":" << json_dump(jarr(support_table))
            << ",\"variant\":\"greedy_event_local\",\"version\":1}";
        return oss.str();
    };
    std::string manifest = make_manifest(0);
    for (int i = 0; i < 8; ++i) {
        std::string next = make_manifest(static_cast<std::uint64_t>(kHeaderSize + manifest.size()));
        if (next.size() == manifest.size()) {
            manifest = std::move(next);
            break;
        }
        manifest = std::move(next);
    }
    write_ithz_archive(archive_path, manifest, payload_blob, dataset_sha, plan_hash);
    if (verify) {
        const auto archive = read_archive(archive_path);
        const fs::path verify_dir = archive_path.parent_path() / ("greedy_verify_" + schedule);
        if (fs::exists(verify_dir)) fs::remove_all(verify_dir);
        const auto decoded_sha = decode_archive_to_dir(archive, verify_dir);
        if (decoded_sha != dataset_sha) fail("greedy self-decode verification failed");
    }
    return PackStats{archive_path, dataset_sha, plan_hash, sha256_hex(read_file(archive_path)), payload_blob.size(), manifest.size(), fs::file_size(archive_path), support_table.size(), checkpoint_table.size()};
}

void run_phase2b_schedule_qa(const fs::path& input_dir, const fs::path& out_dir, const fs::path& oracle_plan_path) {
    fs::create_directories(out_dir);
    const fs::path archives = out_dir / "phase2b_archives";
    fs::create_directories(archives);
    const fs::path matrix = out_dir / "native_ithz_phase2b_schedule_stability_matrix.csv";
    std::ofstream csv(matrix);
    csv << "phase,variant,schedule,threads,manifest_mode,archive_path,decoded_sha256,semantic_plan_hash,container_bytes_hash,payload_bytes,manifest_bytes,total_archive_bytes,support_count,checkpoint_count,decoded_ok,plan_matches_reference,notes\n";
    std::size_t stable = 0;
    for (const auto& spec : checkpointed_schedules()) {
        const auto archive_path = archives / ("checkpointed_cfc_" + spec.label + ".ithz");
        const auto stats = pack_checkpointed_original(input_dir, archive_path, oracle_plan_path, "json", VerifyMode::Full, false, false);
        const bool decoded_ok = stats.dataset_sha == kReferenceDatasetSha;
        const bool plan_ok = stats.plan_hash == kReferencePlanHash;
        if (plan_ok) ++stable;
        csv << "2B,checkpointed_cfc," << spec.label << ',' << spec.threads << ",json,"
            << archive_path.generic_string() << ',' << stats.dataset_sha << ',' << stats.plan_hash << ','
            << stats.container_hash << ',' << stats.payload_bytes << ',' << stats.manifest_bytes << ','
            << stats.archive_bytes << ',' << stats.support_count << ',' << stats.checkpoint_count << ','
            << (decoded_ok ? "true" : "false") << ',' << (plan_ok ? "true" : "false")
            << ",oracle_plan_scalar_schedule_writer\n";
    }
    const fs::path summary = out_dir / "native_ithz_phase2b_schedule_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ Phase 2B Schedule QA Scalar\n\n"
       << "Status: checkpointed CFC writer was run across traversal/thread schedule labels in scalar/oracle-plan parity mode.\n\n"
       << "- schedules: " << checkpointed_schedules().size() << "\n"
       << "- stable semantic plan hashes: " << stable << "/" << checkpointed_schedules().size() << "\n"
       << "- reference semantic_plan_hash: `" << kReferencePlanHash << "`\n\n"
       << "Scope note: this phase validates native container/payload determinism across schedules while the selector is still the Python oracle plan. It is not yet a full native selector schedule proof.\n";
    std::cout << "phase2b_ok=true\nmatrix=" << matrix.generic_string() << "\nsummary=" << summary.generic_string() << "\n";
}

void run_phase2c_greedy_negative(const fs::path& input_dir, const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const fs::path archives = out_dir / "phase2c_greedy_archives";
    fs::create_directories(archives);
    const fs::path matrix = out_dir / "native_ithz_phase2c_greedy_matrix.csv";
    std::ofstream csv(matrix);
    csv << "phase,variant,schedule,threads,archive_path,decoded_sha256,semantic_plan_hash,container_bytes_hash,payload_bytes,manifest_bytes,total_archive_bytes,support_count,checkpoint_count,decoded_ok,notes\n";
    std::map<std::string, int> hashes;
    for (const auto& spec : greedy_schedules()) {
        const auto archive_path = archives / ("greedy_event_local_" + spec.label + ".ithz");
        const auto stats = pack_greedy_event_local(input_dir, archive_path, spec.schedule, true);
        hashes[stats.plan_hash]++;
        csv << "2C,greedy_event_local," << spec.label << ',' << spec.threads << ','
            << archive_path.generic_string() << ',' << stats.dataset_sha << ',' << stats.plan_hash << ','
            << stats.container_hash << ',' << stats.payload_bytes << ',' << stats.manifest_bytes << ','
            << stats.archive_bytes << ',' << stats.support_count << ',' << stats.checkpoint_count << ','
            << (stats.dataset_sha == kReferenceDatasetSha ? "true" : "false")
            << ",native_greedy_visit_order_negative_control\n";
    }
    const fs::path summary = out_dir / "native_ithz_phase2c_greedy_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ Phase 2C Greedy Event-Local Negative Control\n\n"
       << "Status: native greedy visit-order control decoded losslessly and produced schedule-sensitive semantic plan hashes.\n\n"
       << "- schedules: " << greedy_schedules().size() << "\n"
       << "- unique greedy semantic plan hashes: " << hashes.size() << "\n\n"
       << "Interpretation: this is a negative control. It may decode correctly, but it commits local choices in visit order and therefore is not the checkpointed CFC discipline.\n";
    std::cout << "phase2c_ok=true\nunique_plan_hashes=" << hashes.size() << "\nmatrix=" << matrix.generic_string() << "\nsummary=" << summary.generic_string() << "\n";
}

void run_phase2d_parity_matrix(const fs::path& input_dir, const fs::path& out_dir, const fs::path& oracle_plan_path) {
    fs::create_directories(out_dir);
    const fs::path archive_path = out_dir / "phase2d_checkpointed_cpp_json.ithz";
    const auto native = pack_checkpointed_original(input_dir, archive_path, oracle_plan_path, "json", VerifyMode::Full, false, false);
    const Json oracle = load_oracle_plan(oracle_plan_path);
    const auto& canonical = at(oracle, "canonical_archive").object();
    const fs::path matrix = out_dir / "native_ithz_phase2d_python_parity_matrix.csv";
    std::ofstream csv(matrix);
    csv << "phase,run_id,producer,manifest_mode,decoded_sha256,semantic_plan_hash,payload_bytes,manifest_bytes,total_archive_bytes,support_count,checkpoint_count,plan_matches_python,decoded_ok,notes\n";
    csv << "2D,python_p0_p1_reference,python,json," << as_string(at(oracle, "original_sha256")) << ','
        << as_string(canonical.at("compression_plan_hash")) << ','
        << as_u64(canonical.at("payload_bytes")) << ','
        << as_u64(canonical.at("manifest_bytes")) << ','
        << as_u64(canonical.at("compressed_bytes")) << ','
        << at(oracle, "support_cut_table").array().size() << ','
        << at(oracle, "checkpoint_table").array().size() << ",true,true,python_oracle_reference\n";
    csv << "2D,native_cpp_checkpointed_json,cxx,json," << native.dataset_sha << ',' << native.plan_hash << ','
        << native.payload_bytes << ',' << native.manifest_bytes << ',' << native.archive_bytes << ','
        << native.support_count << ',' << native.checkpoint_count << ','
        << (native.plan_hash == as_string(canonical.at("compression_plan_hash")) ? "true" : "false") << ','
        << (native.dataset_sha == as_string(at(oracle, "original_sha256")) ? "true" : "false")
        << ",native_oracle_plan_writer\n";
    const fs::path summary = out_dir / "native_ithz_phase2d_python_parity_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ Phase 2D C++ vs Python Parity Matrix\n\n"
       << "Status: C++ JSON writer remains semantically aligned with the Python P0/P1 oracle plan.\n\n"
       << "- Python plan hash: `" << as_string(canonical.at("compression_plan_hash")) << "`\n"
       << "- C++ semantic plan hash: `" << native.plan_hash << "`\n"
       << "- C++ decoded SHA: `" << native.dataset_sha << "`\n\n"
       << "Physical container bytes can differ because the native writer serializes JSON independently; semantic plan hash is the parity gate.\n";
    std::cout << "phase2d_ok=true\nmatrix=" << matrix.generic_string() << "\nsummary=" << summary.generic_string() << "\n";
}

struct ProbeStats {
    std::uint64_t bytes = 0;
    std::uint64_t zeros = 0;
    std::uint64_t ascii = 0;
    std::uint64_t separators = 0;
};

ProbeStats probe_scalar(const Bytes& data) {
    ProbeStats s;
    s.bytes = data.size();
    for (const auto b : data) {
        if (b == 0) ++s.zeros;
        if ((b >= 32 && b <= 126) || b == 9 || b == 10 || b == 13) ++s.ascii;
        if (b == ',' || b == ';' || b == '\t' || b == '\n' || b == ':' || b == '|' || b == ' ') ++s.separators;
    }
    return s;
}

ProbeStats probe_avx2(const Bytes& data) {
#if ITHZ_X64_AVX2
    ProbeStats s;
    s.bytes = data.size();
    std::size_t i = 0;
    const __m256i zero = _mm256_setzero_si256();
    const __m256i low = _mm256_set1_epi8(31);
    const __m256i high = _mm256_set1_epi8(127);
    const __m256i tab = _mm256_set1_epi8('\t');
    const __m256i nl = _mm256_set1_epi8('\n');
    const __m256i cr = _mm256_set1_epi8('\r');
    const __m256i comma = _mm256_set1_epi8(',');
    const __m256i semi = _mm256_set1_epi8(';');
    const __m256i colon = _mm256_set1_epi8(':');
    const __m256i pipe = _mm256_set1_epi8('|');
    const __m256i space = _mm256_set1_epi8(' ');
    for (; i + 32 <= data.size(); i += 32) {
        const auto v = _mm256_loadu_si256(reinterpret_cast<const __m256i*>(data.data() + i));
        s.zeros += static_cast<std::uint32_t>(__popcnt(_mm256_movemask_epi8(_mm256_cmpeq_epi8(v, zero))));
        const auto printable = _mm256_and_si256(_mm256_cmpgt_epi8(v, low), _mm256_cmpgt_epi8(high, v));
        const auto ws = _mm256_or_si256(_mm256_or_si256(_mm256_cmpeq_epi8(v, tab), _mm256_cmpeq_epi8(v, nl)), _mm256_cmpeq_epi8(v, cr));
        s.ascii += static_cast<std::uint32_t>(__popcnt(_mm256_movemask_epi8(_mm256_or_si256(printable, ws))));
        auto sep = _mm256_or_si256(_mm256_cmpeq_epi8(v, comma), _mm256_cmpeq_epi8(v, semi));
        sep = _mm256_or_si256(sep, _mm256_cmpeq_epi8(v, tab));
        sep = _mm256_or_si256(sep, _mm256_cmpeq_epi8(v, nl));
        sep = _mm256_or_si256(sep, _mm256_cmpeq_epi8(v, colon));
        sep = _mm256_or_si256(sep, _mm256_cmpeq_epi8(v, pipe));
        sep = _mm256_or_si256(sep, _mm256_cmpeq_epi8(v, space));
        s.separators += static_cast<std::uint32_t>(__popcnt(_mm256_movemask_epi8(sep)));
    }
    if (i < data.size()) {
        Bytes tail(data.begin() + static_cast<std::ptrdiff_t>(i), data.end());
        const auto t = probe_scalar(tail);
        s.zeros += t.zeros;
        s.ascii += t.ascii;
        s.separators += t.separators;
    }
    return s;
#else
    return probe_scalar(data);
#endif
}

void run_phase3a_avx2_probe(const fs::path& input_dir, const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const auto files = read_dataset_dir(input_dir);
    ProbeStats scalar_total, avx_total;
    for (const auto& [_, data] : files) {
        const auto s = probe_scalar(data);
        const auto a = probe_avx2(data);
        scalar_total.bytes += s.bytes; scalar_total.zeros += s.zeros; scalar_total.ascii += s.ascii; scalar_total.separators += s.separators;
        avx_total.bytes += a.bytes; avx_total.zeros += a.zeros; avx_total.ascii += a.ascii; avx_total.separators += a.separators;
    }
    const bool match = scalar_total.bytes == avx_total.bytes && scalar_total.zeros == avx_total.zeros && scalar_total.ascii == avx_total.ascii && scalar_total.separators == avx_total.separators;
    const fs::path matrix = out_dir / "native_ithz_phase3a_avx2_probe_matrix.csv";
    std::ofstream csv(matrix);
    csv << "phase,avx2_build,input_bytes,scalar_zero_count,avx2_zero_count,scalar_ascii_count,avx2_ascii_count,scalar_separator_count,avx2_separator_count,metrics_match,semantic_plan_hash_unchanged,notes\n";
    csv << "3A," << (ITHZ_X64_AVX2 ? "true" : "false") << ',' << scalar_total.bytes << ','
        << scalar_total.zeros << ',' << avx_total.zeros << ',' << scalar_total.ascii << ',' << avx_total.ascii << ','
        << scalar_total.separators << ',' << avx_total.separators << ',' << (match ? "true" : "false")
        << ",true,avx2_probe_smoke_no_selector_commit\n";
    const fs::path summary = out_dir / "native_ithz_phase3a_avx2_probe_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ Phase 3A AVX2 Probe Acceleration\n\n"
       << "Status: AVX2 probe smoke test compares byte-level counters against the scalar path.\n\n"
       << "- avx2_build: `" << (ITHZ_X64_AVX2 ? "true" : "false") << "`\n"
       << "- metrics_match: `" << (match ? "true" : "false") << "`\n"
       << "- semantic_plan_hash_unchanged: `true`\n\n"
       << "Scope note: AVX2 is only used for byte-level probe counters here. It does not commit transform choices or alter the checkpointed plan.\n";
    if (!match) fail("AVX2 probe metrics mismatch");
    std::cout << "phase3a_ok=true\nmatrix=" << matrix.generic_string() << "\nsummary=" << summary.generic_string() << "\n";
}

void run_phase3b_binary_manifest(const fs::path& input_dir, const fs::path& out_dir, const fs::path& oracle_plan_path) {
    fs::create_directories(out_dir);
    const auto json_stats = pack_checkpointed_original(input_dir, out_dir / "phase3b_checkpointed_json.ithz", oracle_plan_path, "json", VerifyMode::Full, false, false);
    const auto compact_stats = pack_checkpointed_original(input_dir, out_dir / "phase3b_checkpointed_compact.ithz", oracle_plan_path, "compact", VerifyMode::Full, false, false);
    const double reduction = json_stats.manifest_bytes ? (1.0 - static_cast<double>(compact_stats.manifest_bytes) / static_cast<double>(json_stats.manifest_bytes)) * 100.0 : 0.0;
    const fs::path matrix = out_dir / "native_ithz_phase3b_binary_manifest_matrix.csv";
    std::ofstream csv(matrix);
    csv << "phase,manifest_mode,archive_path,decoded_sha256,semantic_plan_hash,container_bytes_hash,manifest_json_bytes,manifest_binary_bytes,manifest_bytes,payload_bytes,total_archive_bytes,header_footer_bytes,overhead_ratio,plan_hash_matches_json,decoded_ok,notes\n";
    auto emit = [&](const std::string& mode, const PackStats& stats) {
        const double overhead_ratio = stats.payload_bytes ? static_cast<double>(stats.archive_bytes - stats.payload_bytes) / static_cast<double>(stats.payload_bytes) : 0.0;
        csv << "3B," << mode << ',' << stats.archive_path.generic_string() << ',' << stats.dataset_sha << ',' << stats.plan_hash << ','
            << stats.container_hash << ',' << json_stats.manifest_bytes << ',' << compact_stats.manifest_bytes << ',' << stats.manifest_bytes << ','
            << stats.payload_bytes << ',' << stats.archive_bytes << ",228," << std::fixed << std::setprecision(6) << overhead_ratio << ','
            << (stats.plan_hash == json_stats.plan_hash ? "true" : "false") << ','
            << (stats.dataset_sha == kReferenceDatasetSha ? "true" : "false") << ",native_binary_manifest_compaction\n";
    };
    emit("json", json_stats);
    emit("compact", compact_stats);
    const fs::path summary = out_dir / "native_ithz_phase3b_binary_manifest_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ Phase 3B Binary Manifest Compaction\n\n"
       << "Status: native compact-varint manifest writer/reader roundtripped the same checkpointed CFC semantic plan.\n\n"
       << "- json manifest bytes: `" << json_stats.manifest_bytes << "`\n"
       << "- compact manifest bytes: `" << compact_stats.manifest_bytes << "`\n"
       << "- manifest reduction: `" << std::fixed << std::setprecision(3) << reduction << "%`\n"
       << "- semantic plan hash preserved: `" << (compact_stats.plan_hash == json_stats.plan_hash ? "true" : "false") << "`\n"
       << "- decoded SHA preserved: `" << (compact_stats.dataset_sha == json_stats.dataset_sha ? "true" : "false") << "`\n\n"
       << "Interpretation: this is a container compaction result only. It changes physical archive bytes, not the CFC plan.\n";
    if (compact_stats.plan_hash != json_stats.plan_hash) fail("compact manifest changed semantic plan hash");
    if (compact_stats.dataset_sha != json_stats.dataset_sha) fail("compact manifest decode SHA mismatch");
    std::cout << "phase3b_ok=true\nmanifest_reduction_pct=" << std::fixed << std::setprecision(3) << reduction << "\nmatrix=" << matrix.generic_string() << "\nsummary=" << summary.generic_string() << "\n";
}

void run_native_phase2b_to_3b(const fs::path& input_dir, const fs::path& out_dir, const fs::path& oracle_plan_path) {
    run_phase2b_schedule_qa(input_dir, out_dir, oracle_plan_path);
    run_phase2c_greedy_negative(input_dir, out_dir);
    run_phase2d_parity_matrix(input_dir, out_dir, oracle_plan_path);
    run_phase3a_avx2_probe(input_dir, out_dir);
    run_phase3b_binary_manifest(input_dir, out_dir, oracle_plan_path);
    const fs::path summary = out_dir / "native_ithz_phase2b_3b_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ Phase 2B-3B Summary\n\n"
       << "Completed native follow-up phases:\n\n"
       << "- Phase 2B: scalar schedule QA in oracle-plan writer mode.\n"
       << "- Phase 2C: native greedy event-local negative control.\n"
       << "- Phase 2D: C++ vs Python semantic parity matrix.\n"
       << "- Phase 3A: AVX2 byte-level probe smoke test.\n"
       << "- Phase 3B: compact-varint binary manifest compaction.\n\n"
       << "The checkpointed CFC claim remains semantic and schedule-discipline focused. No ZIP superiority claim is made.\n";
    std::cout << "native_phase2b_3b_ok=true\nsummary=" << summary.generic_string() << "\n";
}

std::map<std::string, int> method_counts_from_plan(const Json& plan) {
    std::map<std::string, int> counts;
    for (const auto& row : at(plan, "chunk_plan").array()) ++counts[as_string(at(row, "method"))];
    return counts;
}

std::string method_counts_text(const std::map<std::string, int>& counts) {
    std::ostringstream oss;
    bool first = true;
    for (const auto& [method, count] : counts) {
        if (!first) oss << ';';
        first = false;
        oss << method << '=' << count;
    }
    return oss.str();
}

void write_text_file(const fs::path& path, const std::string& text) {
    if (!path.parent_path().empty()) fs::create_directories(path.parent_path());
    std::ofstream f(path, std::ios::binary);
    if (!f) fail("cannot write file: " + path.string());
    f << text;
}

void write_p4_probe_parity(const Json& native_plan, const Json& reference_plan, const fs::path& out_dir) {
    const fs::path probe_csv = out_dir / "native_ithz_p4_probe_parity.csv";
    std::ofstream csv(probe_csv);
    csv << "chunk_id,path,offset,size,native_sha256,python_sha256,sha_match,native_entropy,python_entropy,entropy_match,native_zero_run,python_zero_run,zero_run_match,native_ascii,python_ascii,ascii_match,native_numeric,python_numeric,numeric_match,native_repetition,python_repetition,repetition_match,native_sim_prev,python_sim_prev,sim_prev_match,native_cross_file,python_cross_file,cross_file_match,native_family,python_family,family_match\n";
    std::map<std::uint64_t, const Json*> ref_by_id;
    for (const auto& probe : at(reference_plan, "probe_summary").array()) ref_by_id[as_u64(at(probe, "chunk_id"))] = &probe;
    for (const auto& probe : at(native_plan, "probe_summary").array()) {
        const auto cid = as_u64(at(probe, "chunk_id"));
        const Json& ref = *ref_by_id.at(cid);
        auto match_num = [](const Json& a, const Json& b) { return std::abs(a.number() - b.number()) < 0.0000001; };
        csv << cid << ',' << as_string(at(probe, "path")) << ',' << as_u64(at(probe, "offset")) << ',' << as_u64(at(probe, "size")) << ','
            << as_string(at(probe, "sha256")) << ',' << as_string(at(ref, "sha256")) << ',' << (as_string(at(probe, "sha256")) == as_string(at(ref, "sha256")) ? "true" : "false") << ','
            << json_dump(at(probe, "byte_entropy")) << ',' << json_dump(at(ref, "byte_entropy")) << ',' << (match_num(at(probe, "byte_entropy"), at(ref, "byte_entropy")) ? "true" : "false") << ','
            << json_dump(at(probe, "zero_run_score")) << ',' << json_dump(at(ref, "zero_run_score")) << ',' << (match_num(at(probe, "zero_run_score"), at(ref, "zero_run_score")) ? "true" : "false") << ','
            << json_dump(at(probe, "ascii_utf8_score")) << ',' << json_dump(at(ref, "ascii_utf8_score")) << ',' << (match_num(at(probe, "ascii_utf8_score"), at(ref, "ascii_utf8_score")) ? "true" : "false") << ','
            << json_dump(at(probe, "numeric_csv_like_score")) << ',' << json_dump(at(ref, "numeric_csv_like_score")) << ',' << (match_num(at(probe, "numeric_csv_like_score"), at(ref, "numeric_csv_like_score")) ? "true" : "false") << ','
            << json_dump(at(probe, "repetition_score")) << ',' << json_dump(at(ref, "repetition_score")) << ',' << (match_num(at(probe, "repetition_score"), at(ref, "repetition_score")) ? "true" : "false") << ','
            << json_dump(at(probe, "similarity_to_previous_chunks")) << ',' << json_dump(at(ref, "similarity_to_previous_chunks")) << ',' << (match_num(at(probe, "similarity_to_previous_chunks"), at(ref, "similarity_to_previous_chunks")) ? "true" : "false") << ','
            << json_dump(at(probe, "cross_file_similarity")) << ',' << json_dump(at(ref, "cross_file_similarity")) << ',' << (match_num(at(probe, "cross_file_similarity"), at(ref, "cross_file_similarity")) ? "true" : "false") << ','
            << as_string(at(probe, "content_family")) << ',' << as_string(at(ref, "content_family")) << ',' << (as_string(at(probe, "content_family")) == as_string(at(ref, "content_family")) ? "true" : "false") << "\n";
    }
}

void write_p4_selector_diff(const Json& native_plan, const Json& reference_plan, const fs::path& out_dir) {
    const auto native_hash = as_string(at(at(native_plan, "canonical_archive"), "compression_plan_hash"));
    const auto reference_hash = as_string(at(at(reference_plan, "canonical_archive"), "compression_plan_hash"));
    const auto native_methods = method_counts_from_plan(native_plan);
    const auto reference_methods = method_counts_from_plan(reference_plan);
    const fs::path diff_path = out_dir / "native_ithz_p4_selector_diff.md";
    std::ofstream md(diff_path);
    md << "# Native ITHZ P4 Selector Diff\n\n"
       << "| Field | Python Reference | Native C++ | Match |\n"
       << "|---|---:|---:|---|\n"
       << "| support_count | " << at(reference_plan, "support_cut_table").array().size() << " | " << at(native_plan, "support_cut_table").array().size() << " | " << (at(reference_plan, "support_cut_table").array().size() == at(native_plan, "support_cut_table").array().size() ? "true" : "false") << " |\n"
       << "| checkpoint_count | " << at(reference_plan, "checkpoint_table").array().size() << " | " << at(native_plan, "checkpoint_table").array().size() << " | " << (at(reference_plan, "checkpoint_table").array().size() == at(native_plan, "checkpoint_table").array().size() ? "true" : "false") << " |\n"
       << "| method_counts | `" << method_counts_text(reference_methods) << "` | `" << method_counts_text(native_methods) << "` | " << (reference_methods == native_methods ? "true" : "false") << " |\n"
       << "| semantic_plan_hash | `" << reference_hash << "` | `" << native_hash << "` | " << (reference_hash == native_hash ? "true" : "false") << " |\n\n";
    if (reference_hash != native_hash) {
        md << "Status: mismatch. Per-chunk method/base/support rows should be inspected before promoting P4.\n\n";
        md << "| chunk_id | python_method | native_method | python_base | native_base | python_support | native_support |\n";
        md << "|---:|---|---|---:|---:|---:|---:|\n";
        std::map<std::uint64_t, const Json*> ref_by_id;
        for (const auto& row : at(reference_plan, "chunk_plan").array()) ref_by_id[as_u64(at(row, "chunk_id"))] = &row;
        for (const auto& row : at(native_plan, "chunk_plan").array()) {
            const auto cid = as_u64(at(row, "chunk_id"));
            const auto& ref = *ref_by_id.at(cid);
            const auto ref_method = as_string(at(ref, "method"));
            const auto native_method = as_string(at(row, "method"));
            const auto ref_base = std::holds_alternative<std::nullptr_t>(at(ref, "base_chunk_id").value) ? std::string("null") : std::to_string(as_u64(at(ref, "base_chunk_id")));
            const auto native_base = std::holds_alternative<std::nullptr_t>(at(row, "base_chunk_id").value) ? std::string("null") : std::to_string(as_u64(at(row, "base_chunk_id")));
            const auto ref_support = std::holds_alternative<std::nullptr_t>(at(ref, "support_id").value) ? std::string("null") : std::to_string(as_u64(at(ref, "support_id")));
            const auto native_support = std::holds_alternative<std::nullptr_t>(at(row, "support_id").value) ? std::string("null") : std::to_string(as_u64(at(row, "support_id")));
            if (ref_method != native_method || ref_base != native_base || ref_support != native_support) {
                md << "| " << cid << " | " << ref_method << " | " << native_method << " | " << ref_base << " | " << native_base << " | " << ref_support << " | " << native_support << " |\n";
            }
        }
    } else {
        md << "Status: match. Native C++ selector reproduces the Python oracle semantic plan for the P0/P1 fixture.\n";
    }
}

void run_phase4_native_selector(const fs::path& input_dir, const fs::path& out_dir, const fs::path& reference_plan_path);

std::string csv_cell(const std::string& value) {
    if (value.find_first_of(",\"\n\r") == std::string::npos) return value;
    std::string out = "\"";
    for (const char c : value) {
        if (c == '"') out += "\"\"";
        else out.push_back(c);
    }
    out += '"';
    return out;
}

bool text_file_contains(const fs::path& path, const std::string& needle) {
    if (!fs::exists(path)) return false;
    const auto raw = read_file(path);
    const std::string text(raw.begin(), raw.end());
    return text.find(needle) != std::string::npos;
}

bool run_python_decode_check(const fs::path& archive_path, const fs::path& output_dir, const fs::path& log_path, const std::string& expected_sha) {
    if (fs::exists(output_dir)) fs::remove_all(output_dir);
    fs::create_directories(output_dir.parent_path());
    fs::create_directories(log_path.parent_path());
    std::ostringstream cmd;
    cmd << "python experiments\\06_ithz_archive\\ithz_cfc_p0_p1.py --decode --archive \""
        << archive_path.string() << "\" --decode-output-dir \"" << output_dir.string()
        << "\" > \"" << log_path.string() << "\"";
    const int rc = std::system(cmd.str().c_str());
    return rc == 0 && text_file_contains(log_path, expected_sha);
}

std::uint64_t input_bytes_from_plan(const Json& plan) {
    return as_u64(at(plan, "input_bytes"));
}

std::uint64_t chunk_count_from_plan(const Json& plan) {
    return static_cast<std::uint64_t>(at(plan, "probe_summary").array().size());
}

std::uint64_t file_count_from_plan(const Json& plan) {
    return static_cast<std::uint64_t>(at(plan, "file_table").array().size());
}

void emit_golden_row(std::ofstream& csv, const std::string& gate, const std::string& expected, const std::string& actual, bool passed, const std::string& notes) {
    csv << csv_cell(gate) << ',' << csv_cell(expected) << ',' << csv_cell(actual) << ',' << (passed ? "true" : "false") << ',' << csv_cell(notes) << "\n";
}

void copy_if_exists(const fs::path& from, const fs::path& to) {
    if (!fs::exists(from)) return;
    fs::create_directories(to.parent_path());
    fs::copy_file(from, to, fs::copy_options::overwrite_existing);
}

void write_greedy_extract(const fs::path& schedule_matrix, const fs::path& greedy_matrix) {
    const auto raw = read_file(schedule_matrix);
    std::istringstream in(std::string(raw.begin(), raw.end()));
    std::ofstream out(greedy_matrix);
    std::string line;
    bool first = true;
    while (std::getline(in, line)) {
        if (first || line.find("greedy_event_local") != std::string::npos) out << line << "\n";
        first = false;
    }
}

bool phase_summary_passed(const fs::path& summary, const std::vector<fs::path>& required_outputs) {
    if (!text_file_contains(summary, "Status: `passed`")) return false;
    for (const auto& path : required_outputs) {
        if (!fs::exists(path)) return false;
    }
    return true;
}

std::string file_sha256_or_missing(const fs::path& path) {
    if (!fs::exists(path) || !fs::is_regular_file(path)) return "missing";
    return sha256_hex(read_file(path));
}

std::string current_exe_path_string() {
#ifdef _WIN32
    std::array<char, 4096> buffer{};
    const DWORD n = GetModuleFileNameA(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
    if (n > 0 && n < buffer.size()) return std::string(buffer.data(), buffer.data() + n);
#endif
    return "unknown";
}

std::string native_binary_hash() {
    const auto path = current_exe_path_string();
    if (path == "unknown") return "unknown";
    return file_sha256_or_missing(path);
}

std::string source_hash() {
    std::ostringstream oss;
    const std::array<fs::path, 2> files{fs::path("native_ithz/src/main.cpp"), fs::path("native_ithz/CMakeLists.txt")};
    for (const auto& path : files) {
        oss << path.generic_string() << '=' << file_sha256_or_missing(path) << '\n';
    }
    return sha256_hex_string(oss.str());
}

std::string dataset_tree_hash(const fs::path& root) {
    if (!fs::exists(root)) return "missing";
    std::vector<std::string> rows;
    for (const auto& entry : fs::recursive_directory_iterator(root, fs::directory_options::skip_permission_denied)) {
        if (!entry.is_regular_file()) continue;
        const auto rel = fs::relative(entry.path(), root).generic_string();
        rows.push_back(rel + "|" + std::to_string(fs::file_size(entry.path())) + "|" + file_sha256_or_missing(entry.path()));
    }
    std::sort(rows.begin(), rows.end());
    std::ostringstream oss;
    for (const auto& row : rows) oss << row << '\n';
    return sha256_hex_string(oss.str());
}

struct CacheIdentity {
    std::string command_name;
    std::string source_hash_value;
    std::string native_binary_hash_value;
    std::string dataset_hash_value;
    std::string parameter_hash_value;
    std::string manifest_version;
    std::string payload_method_version;
    std::string build_profile;
};

CacheIdentity make_cache_identity(const std::string& command_name, const fs::path& dataset_root, const std::string& parameter_text) {
    return CacheIdentity{
        command_name,
        source_hash(),
        native_binary_hash(),
        dataset_tree_hash(dataset_root),
        sha256_hex_string(parameter_text),
        "ithz-container-v1+p7b-bundle-varint-v1",
        "STORE,RLE,RANGE0,LZ_RANGE,DELTA_BASE_RESIDUAL,BYTE_SHUFFLE_RANGE",
        ITHZ_X64_AVX2 ? "Release_AVX2" : "Release_scalar"
    };
}

std::string cache_key_for(const CacheIdentity& id) {
    std::ostringstream oss;
    oss << "command=" << id.command_name << '\n'
        << "source_hash=" << id.source_hash_value << '\n'
        << "native_binary_hash=" << id.native_binary_hash_value << '\n'
        << "dataset_hash=" << id.dataset_hash_value << '\n'
        << "parameter_hash=" << id.parameter_hash_value << '\n'
        << "manifest_version=" << id.manifest_version << '\n'
        << "payload_method_version=" << id.payload_method_version << '\n'
        << "build_profile=" << id.build_profile << '\n';
    return sha256_hex_string(oss.str());
}

bool phase_summary_passed(const fs::path& summary, const std::vector<fs::path>& required_outputs, const CacheIdentity& id) {
    const auto key = cache_key_for(id);
    return phase_summary_passed(summary, required_outputs) &&
        text_file_contains(summary, "cache_key=" + key) &&
        text_file_contains(summary, "source_hash=" + id.source_hash_value) &&
        text_file_contains(summary, "dataset_hash=" + id.dataset_hash_value);
}

void write_cache_block(std::ofstream& md, const CacheIdentity& id, bool cached, const std::string& reason) {
    md << "\n## Cache Identity\n\n"
       << "```text\n"
       << "cached=" << (cached ? "true" : "false") << "\n"
       << "cache_key=" << cache_key_for(id) << "\n"
       << "cache_reason=" << reason << "\n"
       << "command_name=" << id.command_name << "\n"
       << "source_hash=" << id.source_hash_value << "\n"
       << "native_binary_hash=" << id.native_binary_hash_value << "\n"
       << "dataset_hash=" << id.dataset_hash_value << "\n"
       << "parameter_hash=" << id.parameter_hash_value << "\n"
       << "manifest_version=" << id.manifest_version << "\n"
       << "payload_method_version=" << id.payload_method_version << "\n"
       << "build_profile=" << id.build_profile << "\n"
       << "```\n";
}

void write_cache_hygiene_summary(const fs::path& out_dir, const CacheIdentity& id, bool cached, const std::string& reason) {
    const fs::path summary = out_dir / "native_ithz_cache_hygiene_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ Cache Hygiene\n\n"
       << "Status: `passed`\n\n"
       << "Cached pass guards are keyed by command name, source hash, native binary hash, dataset hash, parameter hash, manifest/payload version, and build profile. If the key is absent or mismatched, the gate is treated as stale and must rerun.\n";
    write_cache_block(md, id, cached, reason);
}

void run_golden_regression(const fs::path& input_dir, const fs::path& out_dir, const fs::path& reference_plan_path) {
    fs::create_directories(out_dir);
    const fs::path golden_dir = out_dir / "golden";
    fs::create_directories(golden_dir);

    run_phase4_native_selector(input_dir, out_dir, reference_plan_path);

    const Json native_plan = load_oracle_plan(out_dir / "support_cut_plan_native.json");
    const Json reference_plan = load_oracle_plan(reference_plan_path);
    const auto native_hash = as_string(at(at(native_plan, "canonical_archive"), "compression_plan_hash"));
    const auto reference_hash = as_string(at(at(reference_plan, "canonical_archive"), "compression_plan_hash"));
    const auto schedule_matrix = out_dir / "native_ithz_p4_schedule_matrix.csv";
    const auto archive_path = out_dir / "cpp_no_oracle_checkpointed_compact.ithz";
    const bool p4a_probe = text_file_contains(out_dir / "native_ithz_p4_probe_parity.csv", ",false") == false;
    const bool p4b_selector = native_hash == reference_hash &&
        at(native_plan, "support_cut_table").array().size() == 19 &&
        at(native_plan, "checkpoint_table").array().size() == 46 &&
        method_counts_text(method_counts_from_plan(native_plan)) == "BYTE_SHUFFLE_RANGE=4;DELTA_BASE_RESIDUAL=8;LZ_RANGE=74;RANGE0=2;STORE=12";
    const auto archive = read_archive(archive_path);
    const fs::path cpp_decode_dir = out_dir / "golden_cpp_decoded";
    if (fs::exists(cpp_decode_dir)) fs::remove_all(cpp_decode_dir);
    const auto cpp_decoded_sha = decode_archive_to_dir(archive, cpp_decode_dir);
    const bool cpp_decode_ok = cpp_decoded_sha == kReferenceDatasetSha;
    const bool python_decode_ok = run_python_decode_check(
        archive_path,
        out_dir / "golden_python_decoded",
        out_dir / "golden_python_decode.log",
        kReferenceDatasetSha
    );
    const auto matrix_raw = read_file(schedule_matrix);
    const std::string matrix_text(matrix_raw.begin(), matrix_raw.end());
    const bool p4d_stable = matrix_text.find("checkpointed_cfc_no_oracle") != std::string::npos &&
        matrix_text.find("greedy_event_local") != std::string::npos &&
        text_file_contains(out_dir / "native_ithz_p4_summary.md", "checkpointed_unique_plan_hashes=1") &&
        text_file_contains(out_dir / "native_ithz_p4_summary.md", "greedy_unique_plan_hashes=5");
    const bool bytes_ok = fs::file_size(archive_path) == kReferenceCompactArchiveBytes;

    copy_if_exists(archive_path, golden_dir / "golden_compact_archive.ithz");
    copy_if_exists(out_dir / "native_ithz_p4_probe_parity.csv", golden_dir / "golden_probe_parity_csv.csv");
    copy_if_exists(out_dir / "native_ithz_p4_selector_diff.md", golden_dir / "golden_selector_diff.md");
    copy_if_exists(schedule_matrix, golden_dir / "golden_schedule_matrix.csv");
    write_greedy_extract(schedule_matrix, golden_dir / "golden_greedy_matrix.csv");
    write_text_file(golden_dir / "golden_p0p1_dataset_sha256.txt", std::string(kReferenceDatasetSha) + "\n");
    write_text_file(golden_dir / "golden_semantic_plan_hash.txt", std::string(kReferencePlanHash) + "\n");

    const fs::path matrix = out_dir / "golden_regression_matrix.csv";
    std::ofstream csv(matrix);
    csv << "gate,expected,actual,passed,notes\n";
    emit_golden_row(csv, "P4A_probe_parity", "100/100 no false cells", p4a_probe ? "100/100" : "mismatch", p4a_probe, "native probe table compared against Python reference");
    emit_golden_row(csv, "P4B_selector_parity", kReferencePlanHash, native_hash, p4b_selector, "support/checkpoint/method counts preserved");
    emit_golden_row(csv, "P4C_cpp_decode", kReferenceDatasetSha, cpp_decoded_sha, cpp_decode_ok, "C++ decoded no-oracle compact archive");
    emit_golden_row(csv, "P4C_python_decode", kReferenceDatasetSha, python_decode_ok ? kReferenceDatasetSha : "python_decode_failed", python_decode_ok, "Python decoded C++ compact archive");
    emit_golden_row(csv, "P4D_checkpointed_schedule_stability", "8/8 stable; 1 unique hash", p4d_stable ? "8/8 stable; 1 unique hash" : "unstable", p4d_stable, "no-oracle schedule matrix");
    emit_golden_row(csv, "greedy_negative_control", "5 unique plan hashes", text_file_contains(out_dir / "native_ithz_p4_summary.md", "greedy_unique_plan_hashes=5") ? "5 unique plan hashes" : "unexpected", text_file_contains(out_dir / "native_ithz_p4_summary.md", "greedy_unique_plan_hashes=5"), "greedy remains schedule-sensitive");
    emit_golden_row(csv, "semantic_plan_hash", kReferencePlanHash, native_hash, native_hash == kReferencePlanHash, "golden semantic plan hash");
    emit_golden_row(csv, "decoded_sha256", kReferenceDatasetSha, cpp_decoded_sha, cpp_decoded_sha == kReferenceDatasetSha, "golden dataset SHA");
    emit_golden_row(csv, "compact_archive_bytes", std::to_string(kReferenceCompactArchiveBytes), std::to_string(fs::file_size(archive_path)), bytes_ok, "bump only with explicit format-version note");

    const bool all_ok = p4a_probe && p4b_selector && cpp_decode_ok && python_decode_ok && p4d_stable && bytes_ok;
    const fs::path summary = out_dir / "golden_regression_summary.md";
    std::ofstream md(summary);
    md << "# ITHZ Native Golden Regression\n\n"
       << "Status: `" << (all_ok ? "passed" : "failed") << "`\n\n"
       << "Golden P4 reference values:\n\n"
       << "```text\n"
       << "dataset_sha256=" << kReferenceDatasetSha << "\n"
       << "semantic_plan_hash=" << kReferencePlanHash << "\n"
       << "compact_archive_bytes=" << kReferenceCompactArchiveBytes << "\n"
       << "support_count=19\ncheckpoint_count=46\n"
       << "method_counts=BYTE_SHUFFLE_RANGE=4;DELTA_BASE_RESIDUAL=8;LZ_RANGE=74;RANGE0=2;STORE=12\n"
       << "```\n\n"
       << "Artifacts are frozen under `" << golden_dir.generic_string() << "`. This is a regression gate only; it does not claim compression superiority.\n";
    if (!all_ok) fail("golden regression failed");
    std::cout << "golden_regression_ok=true\nmatrix=" << matrix.generic_string() << "\nsummary=" << summary.generic_string() << "\n";
}

Bytes repeated_pattern_bytes(const std::string& pattern, std::size_t target_size) {
    Bytes out;
    out.reserve(target_size);
    while (out.size() < target_size) {
        const auto take = std::min<std::size_t>(pattern.size(), target_size - out.size());
        out.insert(out.end(), pattern.begin(), pattern.begin() + static_cast<std::ptrdiff_t>(take));
    }
    return out;
}

Bytes deterministic_noise(std::size_t size, std::uint32_t seed) {
    Bytes out(size);
    std::mt19937 rng(seed);
    for (auto& b : out) b = static_cast<std::uint8_t>(rng() & 0xffU);
    return out;
}

std::string repeated_lines(const std::string& line, std::size_t target_size) {
    std::string out;
    out.reserve(target_size + line.size());
    while (out.size() < target_size) out += line;
    out.resize(target_size);
    return out;
}

void write_text_bytes(const fs::path& path, const std::string& text) {
    write_file(path, Bytes(text.begin(), text.end()));
}

void generate_structured_profile(const fs::path& dir, std::size_t target_bytes, int scale) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    const std::string log_line = "2026-05-28T12:34:56Z INFO cfc selector gain=192 metadata_cost=41 decode_complexity=3 file=alpha chunk=17\n";
    for (int i = 0; i < 8 * scale; ++i) {
        write_text_bytes(dir / "logs" / ("app_" + std::to_string(i) + ".log"), repeated_lines(log_line, std::max<std::size_t>(4096, target_bytes / (20 * scale))));
    }
    for (int i = 0; i < 5 * scale; ++i) {
        std::ostringstream json;
        json << "{\"version\":" << i << ",\"selector\":\"checkpointed_cfc\",\"rows\":[";
        for (int j = 0; j < 600 * scale; ++j) {
            if (j) json << ',';
            json << "{\"chunk\":" << j << ",\"gain\":" << ((j * 31 + i) % 4096) << ",\"family\":\"json\",\"path\":\"src/module_" << (j % 11) << ".py\"}";
        }
        json << "]}\n";
        write_text_bytes(dir / "json" / ("config_" + std::to_string(i) + ".json"), json.str());
    }
    for (int i = 0; i < 4 * scale; ++i) {
        std::ostringstream csv;
        csv << "ts,series,value_a,value_b,value_c\n";
        for (int j = 0; j < 2000 * scale; ++j) {
            csv << j << ",sensor_" << (j % 9) << ',' << (j * 17 + i) % 10000 << ',' << (j * 19 + i) % 10000 << ',' << (j % 37) << "\n";
        }
        write_text_bytes(dir / "csv" / ("telemetry_" + std::to_string(i) + ".csv"), csv.str());
    }
    const std::string source_base = "def pressure_budget(rows):\n    total = 0\n    for row in rows:\n        total += row.get('gain', 0) - row.get('metadata_cost', 0) - row.get('decode_complexity', 0)\n    return total\n\n";
    for (int i = 0; i < 12 * scale; ++i) {
        std::string body;
        for (int j = 0; j < 70 * scale; ++j) body += source_base + "def selector_" + std::to_string(i) + "_" + std::to_string(j) + "():\n    return 'canonical-" + std::to_string((i + j) % 5) + "'\n\n";
        write_text_bytes(dir / "src" / ("module_" + std::to_string(i) + ".py"), body);
    }
    Bytes raw = repeated_pattern_bytes("ITHZRAW\0\0\0\1\2\3\4\5", target_bytes / 5);
    write_file(dir / "raw" / "frame_000.raw", raw);
    write_file(dir / "raw" / "frame_001.bmp", repeated_pattern_bytes("BMITHZCFC\x00\x00\xff\x7f", target_bytes / 6));
    std::size_t current = 0;
    for (const auto& entry : fs::recursive_directory_iterator(dir)) {
        if (entry.is_regular_file()) current += fs::file_size(entry.path());
    }
    if (current < target_bytes) {
        write_file(dir / "pad" / "structured_pad.txt", repeated_pattern_bytes("canonical checkpoint support cut pressure budget\n", target_bytes - current));
    }
}

void generate_many_small_profile(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int i = 0; i < 1000; ++i) {
        std::ostringstream text;
        text << "file=" << i << "\nfamily=small\nselector=checkpointed_cfc\n";
        for (int j = 0; j < 12; ++j) text << "row," << j << ",gain," << ((i + j) % 97) << ",metadata," << (24 + (j % 7)) << "\n";
        write_text_bytes(dir / "small" / ("item_" + std::to_string(i / 100) + "_" + std::to_string(i) + ".txt"), text.str());
    }
}

void generate_versioned_sources_profile(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    const std::string base = "class CanonicalSelector:\n    def __init__(self):\n        self.pressure = 0\n    def add(self, gain, meta, complexity):\n        self.pressure += gain - meta - complexity\n    def commit(self):\n        return self.pressure > 0\n\n";
    for (int v = 0; v < 80; ++v) {
        std::string body;
        for (int j = 0; j < 120; ++j) {
            body += base;
            body += "def checkpoint_" + std::to_string(j) + "():\n    return " + std::to_string((v + j) % 13) + "\n\n";
        }
        write_text_bytes(dir / "versions" / ("selector_v" + std::to_string(v) + ".py"), body);
    }
}

void generate_logs_json_csv_profile(const fs::path& dir) {
    generate_structured_profile(dir, 3ULL * 1024ULL * 1024ULL, 1);
}

void generate_negative_profile(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    write_file(dir / "media" / "sample.jpg", deterministic_noise(512 * 1024, 101));
    write_file(dir / "media" / "sample.png", deterministic_noise(512 * 1024, 102));
    write_file(dir / "media" / "sample.mp4", deterministic_noise(512 * 1024, 103));
    write_file(dir / "archives" / "sample.zip", deterministic_noise(512 * 1024, 104));
    write_file(dir / "docs" / "sample.pdf", deterministic_noise(512 * 1024, 105));
    write_file(dir / "random" / "high_entropy.bin", deterministic_noise(1024 * 1024, 106));
}

struct CorpusProfile {
    std::string id;
    std::string class_label;
    fs::path dir;
};

std::vector<CorpusProfile> generate_p5_corpora(const fs::path& out_dir) {
    const fs::path root = out_dir / "p5_corpora";
    fs::create_directories(root);
    std::vector<CorpusProfile> profiles = {
        {"p5_small_structured_1mb", "P5A_small_structured", root / "p5_small_structured_1mb"},
        {"p5_medium_structured_25mb", "P5B_medium_structured", root / "p5_medium_structured_25mb"},
        {"p5_many_small_files", "P5C_many_small_files", root / "p5_many_small_files"},
        {"p5_versioned_sources", "P5D_versioned_sources", root / "p5_versioned_sources"},
        {"p5_logs_json_csv", "P5D_logs_json_csv", root / "p5_logs_json_csv"},
        {"p5_negative_precompressed_random", "P5E_negative_controls", root / "p5_negative_precompressed_random"}
    };
    generate_structured_profile(profiles[0].dir, 1ULL * 1024ULL * 1024ULL, 1);
    generate_structured_profile(profiles[1].dir, 25ULL * 1024ULL * 1024ULL, 4);
    generate_many_small_profile(profiles[2].dir);
    generate_versioned_sources_profile(profiles[3].dir);
    generate_logs_json_csv_profile(profiles[4].dir);
    generate_negative_profile(profiles[5].dir);
    return profiles;
}

ProbeStats add_probe_stats(const ProbeStats& a, const ProbeStats& b) {
    return ProbeStats{a.bytes + b.bytes, a.zeros + b.zeros, a.ascii + b.ascii, a.separators + b.separators};
}

ProbeStats probe_files_parallel(const std::map<std::string, Bytes>& files, int workers) {
    if (workers <= 1 || files.size() < 2) {
        ProbeStats total;
        for (const auto& [_, data] : files) total = add_probe_stats(total, probe_scalar(data));
        return total;
    }
    std::vector<const Bytes*> data_refs;
    for (const auto& [_, data] : files) data_refs.push_back(&data);
    const auto worker_count = std::min<std::size_t>(static_cast<std::size_t>(workers), data_refs.size());
    std::vector<std::future<ProbeStats>> futures;
    for (std::size_t worker = 0; worker < worker_count; ++worker) {
        futures.push_back(std::async(std::launch::async, [worker, worker_count, &data_refs]() {
            ProbeStats local;
            for (std::size_t i = worker; i < data_refs.size(); i += worker_count) {
                local = add_probe_stats(local, probe_scalar(*data_refs[i]));
            }
            return local;
        }));
    }
    ProbeStats total;
    for (auto& f : futures) total = add_probe_stats(total, f.get());
    return total;
}

void write_plan_for_schedule(const fs::path& profile_dir, const fs::path& plan_path, const std::string& schedule, int threads, SelectorTiming* timing) {
    const Json plan = build_native_checkpointed_oracle_plan(profile_dir, schedule, threads, 1024ULL * 1024ULL, timing);
    write_text_file(plan_path, json_dump(plan));
}

void run_p5_p6_stress(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const fs::path archives_root = out_dir / "p5_archives";
    const fs::path plans_root = out_dir / "p5_plans";
    const fs::path corpus_matrix = out_dir / "native_ithz_p5_corpus_matrix.csv";
    const fs::path schedule_matrix = out_dir / "native_ithz_p5_schedule_matrix.csv";
    const fs::path timing_matrix = out_dir / "native_ithz_p5_timing_matrix.csv";
    const fs::path avx_matrix = out_dir / "native_ithz_p6b_avx2_probe_matrix.csv";
    const fs::path thread_matrix = out_dir / "native_ithz_p6c_threading_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p5_p6_summary.md";
    const auto cache_id = make_cache_identity("--run-p5-p6-stress", out_dir / "p5_corpora", "profiles=6;schedules=8;greedy=5;p6b;p6c;verify=original-full-others-checksum");
    if (phase_summary_passed(summary, {corpus_matrix, schedule_matrix, timing_matrix, avx_matrix, thread_matrix}, cache_id)) {
        write_cache_hygiene_summary(out_dir, cache_id, true, "matched_existing_p5_p6_summary_and_required_matrices");
        std::cout << "p5_p6_stress_ok=true\ncached=true\nsummary=" << summary.generic_string()
                  << "\ncorpus_matrix=" << corpus_matrix.generic_string()
                  << "\nschedule_matrix=" << schedule_matrix.generic_string()
                  << "\ntiming_matrix=" << timing_matrix.generic_string() << "\n";
        return;
    }
    const auto profiles = generate_p5_corpora(out_dir);
    fs::create_directories(archives_root);
    fs::create_directories(plans_root);

    std::ofstream corpus_csv(corpus_matrix);
    std::ofstream sched_csv(schedule_matrix);
    std::ofstream timing_csv(timing_matrix);
    std::ofstream avx_csv(avx_matrix);
    std::ofstream thread_csv(thread_matrix);

    corpus_csv << "dataset_id,class,input_bytes,file_count,chunk_count,checkpointed_unique_hashes,greedy_unique_hashes,checkpointed_all_decoded_ok,python_decode_ok,representative_archive_bytes,representative_payload_bytes,representative_manifest_bytes,support_count,checkpoint_count,method_counts,notes\n";
    sched_csv << "phase,dataset_id,variant,schedule,threads,input_bytes,file_count,chunk_count,archive_path,decoded_sha256,semantic_plan_hash,container_bytes_hash,payload_bytes,compact_manifest_bytes,total_archive_bytes,support_count,checkpoint_count,method_counts,decoded_ok,python_decode_ok,plan_unique_count_note,notes\n";
    timing_csv << "phase,dataset_id,variant,schedule,threads,input_bytes,file_count,chunk_count,scan_ms,probe_ms,selector_ms,payload_ms,manifest_ms,write_ms,verify_decode_ms,total_pack_ms,total_decode_ms,notes\n";
    avx_csv << "phase,dataset_id,avx2_build,input_bytes,scalar_zero_count,avx2_zero_count,scalar_ascii_count,avx2_ascii_count,scalar_separator_count,avx2_separator_count,metrics_match,semantic_plan_hash_unchanged,notes\n";
    thread_csv << "phase,dataset_id,threads,input_bytes,serial_probe_zero,threaded_probe_zero,serial_probe_ascii,threaded_probe_ascii,serial_probe_separator,threaded_probe_separator,probe_match,semantic_plan_hash,commit_canonical,notes\n";

    std::size_t stable_profiles = 0;
    std::size_t greedy_sensitive_profiles = 0;
    std::size_t all_decoded_profiles = 0;

    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto input_sha = compute_dataset_digest(files);
        std::uint64_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();

        ProbeStats scalar_total, avx_total;
        for (const auto& [_, data] : files) {
            scalar_total = add_probe_stats(scalar_total, probe_scalar(data));
            avx_total = add_probe_stats(avx_total, probe_avx2(data));
        }
        const bool avx_match = scalar_total.bytes == avx_total.bytes && scalar_total.zeros == avx_total.zeros &&
            scalar_total.ascii == avx_total.ascii && scalar_total.separators == avx_total.separators;
        avx_csv << "P6B," << profile.id << ',' << (ITHZ_X64_AVX2 ? "true" : "false") << ',' << input_bytes << ','
            << scalar_total.zeros << ',' << avx_total.zeros << ',' << scalar_total.ascii << ',' << avx_total.ascii << ','
            << scalar_total.separators << ',' << avx_total.separators << ',' << (avx_match ? "true" : "false")
            << ",true,avx2_byte_counter_path_does_not_commit_plan\n";

        std::set<std::string> checkpoint_hashes;
        std::set<std::string> greedy_hashes;
        bool checkpoint_decoded_all = true;
        bool python_decode_ok = false;
        PackStats representative_stats;
        Json representative_plan;
        std::string representative_method_counts;
        std::uint64_t file_count = 0;
        std::uint64_t chunk_count = 0;
        double representative_decode_ms = 0.0;

        for (const auto& spec : checkpointed_schedules()) {
            SelectorTiming selector_timing;
            PackTiming pack_timing;
            const fs::path plan_path = plans_root / profile.id / ("checkpointed_" + spec.label + ".json");
            write_plan_for_schedule(profile.dir, plan_path, spec.schedule, spec.threads, &selector_timing);
            Json plan = load_oracle_plan(plan_path);
            const fs::path archive_path = archives_root / profile.id / ("checkpointed_" + spec.label + ".ithz");
            const auto verify_mode = spec.label == "original_order" ? VerifyMode::Full : VerifyMode::ChecksumsOnly;
            const auto stats = pack_checkpointed_original(profile.dir, archive_path, plan_path, "compact", verify_mode, false, false, &pack_timing);
            const auto decoded_sha = stats.dataset_sha;
            const double decode_ms = pack_timing.verify_decode_ms;
            const bool decoded_ok = decoded_sha == input_sha;
            checkpoint_decoded_all = checkpoint_decoded_all && decoded_ok;
            checkpoint_hashes.insert(stats.plan_hash);
            const auto methods = method_counts_text(method_counts_from_plan(plan));
            const auto current_file_count = file_count_from_plan(plan);
            const auto current_chunk_count = chunk_count_from_plan(plan);
            sched_csv << "P5," << profile.id << ",checkpointed_cfc_no_oracle," << spec.label << ',' << spec.threads << ','
                << input_bytes_from_plan(plan) << ',' << current_file_count << ',' << current_chunk_count << ','
                << archive_path.generic_string() << ',' << decoded_sha << ',' << stats.plan_hash << ',' << stats.container_hash << ','
                << stats.payload_bytes << ',' << stats.manifest_bytes << ',' << stats.archive_bytes << ','
                << stats.support_count << ',' << stats.checkpoint_count << ',' << csv_cell(methods) << ','
                << (decoded_ok ? "true" : "false") << ',';
            bool row_python_ok = false;
            if (spec.label == "original_order") {
                row_python_ok = run_python_decode_check(
                    archive_path,
                    out_dir / "p5_python_decoded" / profile.id,
                    out_dir / "p5_python_decode_logs" / (profile.id + ".log"),
                    input_sha
                );
                python_decode_ok = row_python_ok;
            }
            sched_csv << (row_python_ok ? "true" : "false") << ",checkpointed_unique_calculated_after_profile,native_selector_stress\n";
            timing_csv << "P6A," << profile.id << ",checkpointed_cfc_no_oracle," << spec.label << ',' << spec.threads << ','
                << input_bytes_from_plan(plan) << ',' << current_file_count << ',' << current_chunk_count << ','
                << std::fixed << std::setprecision(3)
                << selector_timing.scan_ms << ',' << selector_timing.probe_ms << ',' << selector_timing.selector_ms << ','
                << pack_timing.payload_ms << ',' << pack_timing.manifest_ms << ',' << pack_timing.write_ms << ','
                << pack_timing.verify_decode_ms << ',' << pack_timing.total_ms << ',' << decode_ms
                << ",timing_breakdown_wall_clock_ms\n";
            if (spec.label == "original_order") {
                representative_stats = stats;
                representative_plan = std::move(plan);
                representative_method_counts = methods;
                file_count = current_file_count;
                chunk_count = current_chunk_count;
                representative_decode_ms = decode_ms;
            }
        }

        for (const auto& spec : greedy_schedules()) {
            const fs::path archive_path = archives_root / profile.id / ("greedy_" + spec.label + ".ithz");
            const auto start = Clock::now();
            const auto stats = pack_greedy_event_local(profile.dir, archive_path, spec.schedule, spec.label == "original_order");
            const double greedy_pack_ms = elapsed_ms(start);
            greedy_hashes.insert(stats.plan_hash);
            const auto decoded_sha = stats.dataset_sha;
            const double decode_ms = 0.0;
            const bool decoded_ok = decoded_sha == input_sha;
            sched_csv << "P5," << profile.id << ",greedy_event_local," << spec.label << ',' << spec.threads << ','
                << input_bytes << ',' << files.size() << ",0," << archive_path.generic_string() << ',' << decoded_sha << ','
                << stats.plan_hash << ',' << stats.container_hash << ',' << stats.payload_bytes << ',' << stats.manifest_bytes << ','
                << stats.archive_bytes << ',' << stats.support_count << ',' << stats.checkpoint_count << ",greedy_visit_order,"
                << (decoded_ok ? "true" : "false") << ",false,greedy_unique_calculated_after_profile,native_greedy_negative_control\n";
            timing_csv << "P6A," << profile.id << ",greedy_event_local," << spec.label << ',' << spec.threads << ','
                << input_bytes << ',' << files.size() << ",0,0,0,0,0,0,0,0," << std::fixed << std::setprecision(3)
                << greedy_pack_ms << ',' << decode_ms << ",greedy_negative_control_timing_ms\n";
        }

        const bool stable = checkpoint_hashes.size() == 1;
        const bool greedy_sensitive = greedy_hashes.size() > 1;
        if (stable) ++stable_profiles;
        if (greedy_sensitive) ++greedy_sensitive_profiles;
        if (checkpoint_decoded_all) ++all_decoded_profiles;

        for (const int threads : {1, 4, 8}) {
            const auto threaded = probe_files_parallel(files, threads);
            const bool match = scalar_total.zeros == threaded.zeros && scalar_total.ascii == threaded.ascii && scalar_total.separators == threaded.separators;
            thread_csv << "P6C," << profile.id << ',' << threads << ',' << input_bytes << ','
                << scalar_total.zeros << ',' << threaded.zeros << ',' << scalar_total.ascii << ',' << threaded.ascii << ','
                << scalar_total.separators << ',' << threaded.separators << ',' << (match ? "true" : "false") << ','
                << (checkpoint_hashes.empty() ? "" : *checkpoint_hashes.begin()) << ",true,parallel_probe_reduce_then_canonical_commit\n";
        }

        corpus_csv << profile.id << ',' << profile.class_label << ',' << input_bytes << ',' << file_count << ',' << chunk_count << ','
            << checkpoint_hashes.size() << ',' << greedy_hashes.size() << ',' << (checkpoint_decoded_all ? "true" : "false") << ','
            << (python_decode_ok ? "true" : "false") << ',' << representative_stats.archive_bytes << ',' << representative_stats.payload_bytes << ','
            << representative_stats.manifest_bytes << ',' << representative_stats.support_count << ',' << representative_stats.checkpoint_count << ','
            << csv_cell(representative_method_counts) << ",native_no_oracle_corpus_stress\n";
        corpus_csv.flush();
        sched_csv.flush();
        timing_csv.flush();
        avx_csv.flush();
        thread_csv.flush();
        (void)representative_decode_ms;
    }

    const bool all_profiles_stable = stable_profiles == profiles.size();
    const bool all_profiles_decoded = all_decoded_profiles == profiles.size();
    const bool any_greedy_sensitive = greedy_sensitive_profiles > 0;
    std::ofstream md(summary);
    md << "# Native ITHZ P5/P6 Corpus Stress And Timing\n\n"
       << "Status: `" << (all_profiles_stable && all_profiles_decoded && any_greedy_sensitive ? "passed" : "attention") << "`\n\n"
       << "## Scope\n\n"
       << "- P5 stress-tests native no-oracle checkpointed CFC stability beyond the P0/P1 fixture.\n"
       << "- P6A records wall-clock timing breakdowns.\n"
       << "- P6B compares AVX2 byte-counter probe results with scalar counters.\n"
       << "- P6C checks threaded probe reduction against scalar counters while keeping final plan commit canonical.\n\n"
       << "## Acceptance\n\n"
       << "- checkpointed profiles with one semantic plan hash: `" << stable_profiles << "/" << profiles.size() << "`\n"
       << "- checkpointed profiles with all decoded rows OK: `" << all_decoded_profiles << "/" << profiles.size() << "`\n"
       << "- greedy profiles with schedule sensitivity: `" << greedy_sensitive_profiles << "/" << profiles.size() << "`\n"
       << "- ZIP superiority claim: `false`\n\n"
       << "Raw matrices:\n\n"
       << "- `" << corpus_matrix.generic_string() << "`\n"
       << "- `" << schedule_matrix.generic_string() << "`\n"
       << "- `" << timing_matrix.generic_string() << "`\n"
       << "- `" << avx_matrix.generic_string() << "`\n"
       << "- `" << thread_matrix.generic_string() << "`\n";
    write_cache_block(md, cache_id, false, "fresh_p5_p6_run_completed");
    if (!all_profiles_stable || !all_profiles_decoded || !any_greedy_sensitive) {
        fail("P5/P6 stress acceptance failed");
    }
    std::cout << "p5_p6_stress_ok=true\nsummary=" << summary.generic_string() << "\ncorpus_matrix=" << corpus_matrix.generic_string() << "\nschedule_matrix=" << schedule_matrix.generic_string() << "\ntiming_matrix=" << timing_matrix.generic_string() << "\n";
}

std::string dq(const fs::path& path) {
    std::string s = path.string();
    std::string out = "\"";
    for (const char c : s) {
        if (c == '"') out += "\\\"";
        else out.push_back(c);
    }
    out += '"';
    return out;
}

std::string ps_quote(const fs::path& path) {
    std::string s = path.string();
    std::string out = "'";
    for (const char c : s) {
        if (c == '\'') out += "''";
        else out.push_back(c);
    }
    out += "'";
    return out;
}

bool command_ok(const std::string& command) {
    return std::system(command.c_str()) == 0;
}

bool tool_available(const std::string& name) {
#ifdef _WIN32
    return command_ok("where.exe " + name + " >nul 2>nul");
#else
    return command_ok("command -v " + name + " >/dev/null 2>&1");
#endif
}

double decode_archive_ms(const fs::path& archive_path, const fs::path& decoded_dir, std::string* decoded_sha) {
    if (fs::exists(decoded_dir)) fs::remove_all(decoded_dir);
    const auto start = Clock::now();
    const auto archive = read_archive(archive_path);
    const auto sha = decode_archive_to_dir(archive, decoded_dir);
    const double ms = elapsed_ms(start);
    if (decoded_sha) *decoded_sha = sha;
    return ms;
}

double decode_archive_ms_timed(const fs::path& archive_path, const fs::path& decoded_dir, std::string* decoded_sha, P12DecodeTiming* timing) {
    if (fs::exists(decoded_dir)) fs::remove_all(decoded_dir);
    const auto start = Clock::now();
    const auto archive = read_archive_timed(archive_path, timing);
    const auto sha = decode_archive_to_dir_timed(archive, decoded_dir, timing);
    const double ms = elapsed_ms(start);
    if (timing) {
        timing->total_decode_ms = ms;
        timing->total_extract_ms = ms;
    }
    if (decoded_sha) *decoded_sha = sha;
    return ms;
}

double verify_archive_no_write_ms_timed(const fs::path& archive_path, std::string* decoded_sha, P12DecodeTiming* timing) {
    const auto start = Clock::now();
    const auto archive = read_archive_timed(archive_path, timing);
    const auto sha = verify_archive_full_no_write_timed(archive, archive_path.parent_path() / "verify_no_write_virtual", timing);
    const double ms = elapsed_ms(start);
    if (timing) timing->total_verify_full_ms = ms;
    if (decoded_sha) *decoded_sha = sha;
    return ms;
}

void run_p6d_perf_clean(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const auto profiles = generate_p5_corpora(out_dir);
    const fs::path archives_root = out_dir / "p6d_archives";
    const fs::path plans_root = out_dir / "p6d_plans";
    fs::create_directories(archives_root);
    fs::create_directories(plans_root);
    const fs::path matrix = out_dir / "native_ithz_p6d_perf_clean_matrix.csv";
    std::ofstream csv(matrix);
    csv << "phase,dataset_id,input_bytes,file_count,chunk_count,archive_path,semantic_plan_hash,decoded_sha256_ok,scan_ms,probe_ms,selector_ms,payload_encode_ms,manifest_write_ms,archive_write_ms,checksum_ms,decode_ms,total_pack_ms_no_verify,total_pack_ms_checksums_only,total_pack_ms_full_verify,peak_memory_mb,notes\n";

    bool all_decode_ok = true;
    double max_peak = 0.0;
    for (const auto& profile : profiles) {
        SelectorTiming selector_timing;
        const fs::path plan_path = plans_root / profile.id / "checkpointed_original_order.json";
        write_plan_for_schedule(profile.dir, plan_path, "original", 1, &selector_timing);
        const Json plan = load_oracle_plan(plan_path);
        const auto expected_sha = as_string(at(plan, "original_sha256"));
        const auto plan_hash = as_string(at(at(plan, "canonical_archive"), "compression_plan_hash"));

        PackTiming off_timing;
        const fs::path archive_off = archives_root / profile.id / "checkpointed_compact_verify_off.ithz";
        const auto off_stats = pack_checkpointed_original(profile.dir, archive_off, plan_path, "compact", VerifyMode::Off, false, false, &off_timing);

        PackTiming checksum_timing;
        const fs::path archive_checksum = archives_root / profile.id / "checkpointed_compact_checksums_only.ithz";
        (void)pack_checkpointed_original(profile.dir, archive_checksum, plan_path, "compact", VerifyMode::ChecksumsOnly, false, false, &checksum_timing);

        PackTiming full_timing;
        const fs::path archive_full = archives_root / profile.id / "checkpointed_compact_full_verify.ithz";
        (void)pack_checkpointed_original(profile.dir, archive_full, plan_path, "compact", VerifyMode::Full, false, false, &full_timing);

        std::string decoded_sha;
        const double decode_ms = decode_archive_ms(archive_off, out_dir / "p6d_decoded" / profile.id, &decoded_sha);
        const bool decoded_ok = decoded_sha == expected_sha;
        all_decode_ok = all_decode_ok && decoded_ok;
        max_peak = std::max(max_peak, peak_memory_mb());
        const auto files_count = file_count_from_plan(plan);
        const auto chunks_count = chunk_count_from_plan(plan);
        const auto scan_ms = selector_timing.scan_ms + off_timing.scan_ms;
        const auto total_no_verify = selector_timing.total_ms + off_timing.total_ms;
        const auto total_checksum = selector_timing.total_ms + checksum_timing.total_ms;
        const auto total_full = selector_timing.total_ms + full_timing.total_ms;
        csv << "P6D," << profile.id << ',' << input_bytes_from_plan(plan) << ',' << files_count << ',' << chunks_count << ','
            << archive_off.generic_string() << ',' << plan_hash << ',' << (decoded_ok ? "true" : "false") << ','
            << std::fixed << std::setprecision(3)
            << scan_ms << ',' << selector_timing.probe_ms << ',' << selector_timing.selector_ms << ','
            << off_timing.payload_ms << ',' << off_timing.manifest_ms << ',' << off_timing.write_ms << ','
            << off_timing.checksum_ms << ',' << decode_ms << ',' << total_no_verify << ',' << total_checksum << ','
            << total_full << ',' << peak_memory_mb()
            << ",pack_time_excludes_full_decode_verify\n";
    }
    const fs::path summary = out_dir / "native_ithz_p6d_perf_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ P6D Performance Measurement Cleanup\n\n"
       << "Status: `" << (all_decode_ok ? "passed" : "failed") << "`\n\n"
       << "P6D separates practical pack timing from full decode verification.\n\n"
       << "- `--verify=off`: writes the archive and computes container hash, without decode verify.\n"
       << "- `--verify=checksums-only`: reads the archive and checks header/footer/manifest/payload checksums, without payload decode.\n"
       << "- `--verify=full`: performs full archive decode verification.\n"
       << "- decode benchmark is reported separately as `decode_ms`.\n"
       << "- peak memory MB is best-effort process peak working set on Windows.\n\n"
       << "Output matrix: `" << matrix.generic_string() << "`\n";
    if (!all_decode_ok) fail("P6D decode benchmark failed");
    std::cout << "p6d_perf_ok=true\nmatrix=" << matrix.generic_string() << "\nsummary=" << summary.generic_string() << "\npeak_memory_mb=" << std::fixed << std::setprecision(3) << max_peak << "\n";
}

struct ExternalBaselineResult {
    std::string name;
    bool available = false;
    fs::path archive_path;
    std::size_t archive_bytes = 0;
    double pack_ms = 0.0;
    double decode_ms = 0.0;
    bool decoded_ok = false;
    std::string notes;
};

ExternalBaselineResult run_zip_baseline(const CorpusProfile& profile, const fs::path& out_dir, const std::string& expected_sha) {
    ExternalBaselineResult r;
    r.name = "ZIP_deflate";
    r.available = true;
    const fs::path archive = out_dir / "p7a_baselines" / profile.id / "baseline_zip_deflate.zip";
    const fs::path decoded = out_dir / "p7a_baselines" / profile.id / "zip_decoded";
    const fs::path log = out_dir / "p7a_baselines" / profile.id / "zip.log";
    fs::create_directories(archive.parent_path());
    if (fs::exists(archive)) fs::remove(archive);
    if (fs::exists(decoded)) fs::remove_all(decoded);
    std::ostringstream pack_cmd;
    pack_cmd << "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Compress-Archive -Path (Join-Path "
             << ps_quote(profile.dir) << " '*') -DestinationPath " << ps_quote(archive) << " -CompressionLevel Optimal -Force\" > "
             << dq(log) << " 2>&1";
    const auto pack_start = Clock::now();
    const bool pack_ok = command_ok(pack_cmd.str());
    r.pack_ms = elapsed_ms(pack_start);
    if (!pack_ok || !fs::exists(archive)) {
        r.notes = "zip_pack_failed";
        return r;
    }
    r.archive_path = archive;
    r.archive_bytes = fs::file_size(archive);
    std::ostringstream decode_cmd;
    decode_cmd << "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Expand-Archive -Path "
               << ps_quote(archive) << " -DestinationPath " << ps_quote(decoded) << " -Force\" >> "
               << dq(log) << " 2>&1";
    const auto decode_start = Clock::now();
    const bool decode_ok = command_ok(decode_cmd.str());
    r.decode_ms = elapsed_ms(decode_start);
    r.decoded_ok = decode_ok && fs::exists(decoded) && compute_dataset_digest(read_dataset_dir(decoded)) == expected_sha;
    r.notes = "powershell_compress_archive_deflate";
    return r;
}

ExternalBaselineResult run_7z_baseline(const CorpusProfile& profile, const fs::path& out_dir, const std::string& expected_sha) {
    ExternalBaselineResult r;
    r.name = "7z";
    r.available = tool_available("7z.exe") || tool_available("7z");
    if (!r.available) {
        r.notes = "7z_not_available";
        return r;
    }
    const fs::path archive = out_dir / "p7a_baselines" / profile.id / "baseline.7z";
    const fs::path decoded = out_dir / "p7a_baselines" / profile.id / "7z_decoded";
    const fs::path log = out_dir / "p7a_baselines" / profile.id / "7z.log";
    fs::create_directories(archive.parent_path());
    if (fs::exists(archive)) fs::remove(archive);
    if (fs::exists(decoded)) fs::remove_all(decoded);
    std::ostringstream pack_cmd;
    pack_cmd << "powershell -NoProfile -ExecutionPolicy Bypass -Command \"Push-Location " << ps_quote(profile.dir)
             << "; & 7z a -t7z " << ps_quote(archive) << " * -y; Pop-Location\" > " << dq(log) << " 2>&1";
    const auto pack_start = Clock::now();
    const bool pack_ok = command_ok(pack_cmd.str());
    r.pack_ms = elapsed_ms(pack_start);
    if (!pack_ok || !fs::exists(archive)) {
        r.notes = "7z_pack_failed";
        return r;
    }
    r.archive_path = archive;
    r.archive_bytes = fs::file_size(archive);
    fs::create_directories(decoded);
    std::ostringstream decode_cmd;
    decode_cmd << "7z x " << dq(archive) << " -o" << dq(decoded) << " -y >> " << dq(log) << " 2>&1";
    const auto decode_start = Clock::now();
    const bool decode_ok = command_ok(decode_cmd.str());
    r.decode_ms = elapsed_ms(decode_start);
    r.decoded_ok = decode_ok && compute_dataset_digest(read_dataset_dir(decoded)) == expected_sha;
    r.notes = "external_7z";
    return r;
}

ExternalBaselineResult run_tar_gzip_baseline(const CorpusProfile& profile, const fs::path& out_dir, const std::string& expected_sha, const std::string& phase_dir = "p7b_real_baselines") {
    ExternalBaselineResult r;
    r.name = "tar_gzip";
    r.available = tool_available("tar");
    if (!r.available) {
        r.notes = "tar_not_available";
        return r;
    }
    const fs::path base = out_dir / phase_dir / profile.id;
    const fs::path archive = base / "baseline.tar.gz";
    const fs::path decoded = base / "tar_gzip_decoded";
    const fs::path log = base / "tar_gzip.log";
    fs::create_directories(base);
    if (fs::exists(archive)) fs::remove(archive);
    if (fs::exists(decoded)) fs::remove_all(decoded);
    std::ostringstream pack_cmd;
    pack_cmd << "tar -czf " << dq(archive) << " -C " << dq(profile.dir) << " . > " << dq(log) << " 2>&1";
    const auto pack_start = Clock::now();
    const bool pack_ok = command_ok(pack_cmd.str());
    r.pack_ms = elapsed_ms(pack_start);
    if (!pack_ok || !fs::exists(archive)) {
        r.notes = "tar_gzip_pack_failed";
        return r;
    }
    r.archive_path = archive;
    r.archive_bytes = fs::file_size(archive);
    fs::create_directories(decoded);
    std::ostringstream decode_cmd;
    decode_cmd << "tar -xzf " << dq(archive) << " -C " << dq(decoded) << " >> " << dq(log) << " 2>&1";
    const auto decode_start = Clock::now();
    const bool decode_ok = command_ok(decode_cmd.str());
    r.decode_ms = elapsed_ms(decode_start);
    r.decoded_ok = decode_ok && compute_dataset_digest(read_dataset_dir(decoded)) == expected_sha;
    r.notes = "tar_gzip_solid_stream_reference";
    return r;
}

ExternalBaselineResult run_tar_compressor_baseline(const CorpusProfile& profile, const fs::path& out_dir, const std::string& expected_sha, const std::string& tool) {
    ExternalBaselineResult r;
    r.name = tool == "zstd" ? "tar_zstd" : "tar_brotli";
    r.available = tool_available(tool) && tool_available("tar");
    if (!r.available) {
        r.notes = tool + "_or_tar_not_available";
        return r;
    }
    const fs::path base = out_dir / "p7a_baselines" / profile.id;
    const fs::path tar_path = base / (tool + "_input.tar");
    const fs::path archive = base / (tool == "zstd" ? "baseline.tar.zst" : "baseline.tar.br");
    const fs::path decoded = base / (tool + "_decoded");
    const fs::path decoded_tar = base / (tool + "_decoded.tar");
    const fs::path log = base / (tool + ".log");
    fs::create_directories(base);
    if (fs::exists(tar_path)) fs::remove(tar_path);
    if (fs::exists(archive)) fs::remove(archive);
    if (fs::exists(decoded)) fs::remove_all(decoded);
    std::ostringstream pack_cmd;
    pack_cmd << "tar -cf " << dq(tar_path) << " -C " << dq(profile.dir) << " .";
    const auto pack_start = Clock::now();
    if (!command_ok(pack_cmd.str())) {
        r.notes = "tar_pack_failed";
        return r;
    }
    std::ostringstream compress_cmd;
    if (tool == "zstd") compress_cmd << "zstd -q -f " << dq(tar_path) << " -o " << dq(archive);
    else compress_cmd << "brotli -f " << dq(tar_path) << " -o " << dq(archive);
    const bool pack_ok = command_ok(compress_cmd.str() + " > " + dq(log) + " 2>&1");
    r.pack_ms = elapsed_ms(pack_start);
    if (!pack_ok || !fs::exists(archive)) {
        r.notes = tool + "_pack_failed";
        return r;
    }
    r.archive_path = archive;
    r.archive_bytes = fs::file_size(archive);
    if (fs::exists(decoded_tar)) fs::remove(decoded_tar);
    fs::create_directories(decoded);
    std::ostringstream decompress_cmd;
    if (tool == "zstd") decompress_cmd << "zstd -q -d -f " << dq(archive) << " -o " << dq(decoded_tar);
    else decompress_cmd << "brotli -d -f " << dq(archive) << " -o " << dq(decoded_tar);
    const auto decode_start = Clock::now();
    const bool dec1 = command_ok(decompress_cmd.str() + " >> " + dq(log) + " 2>&1");
    const bool dec2 = dec1 && command_ok("tar -xf " + dq(decoded_tar) + " -C " + dq(decoded));
    r.decode_ms = elapsed_ms(decode_start);
    r.decoded_ok = dec2 && compute_dataset_digest(read_dataset_dir(decoded)) == expected_sha;
    r.notes = "external_tar_" + tool;
    return r;
}

void emit_baseline_row(std::ofstream& csv, const std::string& dataset_id, const std::string& baseline, std::uint64_t input_bytes, const ExternalBaselineResult& r, bool deterministic_schedule_ok) {
    const double ratio = r.archive_bytes ? static_cast<double>(input_bytes) / static_cast<double>(r.archive_bytes) : 0.0;
    csv << "P7A," << dataset_id << ',' << baseline << ',' << (r.available ? "true" : "false") << ','
        << input_bytes << ',' << (r.archive_bytes ? std::to_string(r.archive_bytes) : "") << ','
        << std::fixed << std::setprecision(6) << ratio << ',' << r.pack_ms << ',' << r.decode_ms << ','
        << (deterministic_schedule_ok ? "true" : "false") << ',' << (r.decoded_ok ? "true" : "false") << ','
        << (r.archive_path.empty() ? "" : r.archive_path.generic_string()) << ',' << csv_cell(r.notes) << "\n";
}

void run_p7a_baseline_harness(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const auto profiles = generate_p5_corpora(out_dir);
    const fs::path plans_root = out_dir / "p7a_plans";
    const fs::path archives_root = out_dir / "p7a_archives";
    fs::create_directories(plans_root);
    fs::create_directories(archives_root);
    const fs::path matrix = out_dir / "native_ithz_p7a_baseline_matrix.csv";
    std::ofstream csv(matrix);
    csv << "phase,dataset_id,baseline,available,input_bytes,archive_bytes,compression_ratio,pack_ms_no_verify,decode_ms,deterministic_schedule_ok,decoded_sha256_ok,archive_path,notes\n";

    bool all_ithz_decoded = true;
    std::size_t promising_profiles = 0;
    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::uint64_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();

        std::set<std::string> schedule_hashes;
        for (const auto& spec : checkpointed_schedules()) {
            SelectorTiming t;
            const auto plan_path = plans_root / profile.id / ("schedule_" + spec.label + ".json");
            write_plan_for_schedule(profile.dir, plan_path, spec.schedule, spec.threads, &t);
            const auto plan = load_oracle_plan(plan_path);
            schedule_hashes.insert(as_string(at(at(plan, "canonical_archive"), "compression_plan_hash")));
        }
        const bool deterministic_schedule_ok = schedule_hashes.size() == 1;

        SelectorTiming selector_timing;
        const fs::path plan_path = plans_root / profile.id / "checkpointed_original_order.json";
        write_plan_for_schedule(profile.dir, plan_path, "original", 1, &selector_timing);
        PackTiming pack_timing;
        const fs::path ithz_archive = archives_root / profile.id / "checkpointed_compact.ithz";
        const auto ithz_stats = pack_checkpointed_original(profile.dir, ithz_archive, plan_path, "compact", VerifyMode::Off, false, false, &pack_timing);
        std::string ithz_decoded_sha;
        const double ithz_decode_ms = decode_archive_ms(ithz_archive, out_dir / "p7a_decoded" / profile.id / "checkpointed", &ithz_decoded_sha);
        const bool ithz_decoded_ok = ithz_decoded_sha == expected_sha;
        all_ithz_decoded = all_ithz_decoded && ithz_decoded_ok;
        ExternalBaselineResult ithz_result;
        ithz_result.name = "ITHZ_checkpointed_compact";
        ithz_result.available = true;
        ithz_result.archive_path = ithz_archive;
        ithz_result.archive_bytes = ithz_stats.archive_bytes;
        ithz_result.pack_ms = selector_timing.total_ms + pack_timing.total_ms;
        ithz_result.decode_ms = ithz_decode_ms;
        ithz_result.decoded_ok = ithz_decoded_ok;
        ithz_result.notes = "native_no_oracle_checkpointed_compact_no_verify_pack";
        emit_baseline_row(csv, profile.id, ithz_result.name, input_bytes, ithz_result, deterministic_schedule_ok);

        std::set<std::string> greedy_hashes;
        ExternalBaselineResult greedy_result;
        greedy_result.name = "ITHZ_greedy_event_local";
        greedy_result.available = true;
        for (const auto& spec : greedy_schedules()) {
            const fs::path greedy_archive = archives_root / profile.id / ("greedy_" + spec.label + ".ithz");
            const auto start = Clock::now();
            const auto stats = pack_greedy_event_local(profile.dir, greedy_archive, spec.schedule, false);
            const double pack_ms = elapsed_ms(start);
            greedy_hashes.insert(stats.plan_hash);
            if (spec.label == "original_order") {
                std::string decoded_sha;
                const double decode_ms = decode_archive_ms(greedy_archive, out_dir / "p7a_decoded" / profile.id / "greedy", &decoded_sha);
                greedy_result.archive_path = greedy_archive;
                greedy_result.archive_bytes = stats.archive_bytes;
                greedy_result.pack_ms = pack_ms;
                greedy_result.decode_ms = decode_ms;
                greedy_result.decoded_ok = decoded_sha == expected_sha;
                greedy_result.notes = "negative_control_visit_order";
            }
        }
        emit_baseline_row(csv, profile.id, greedy_result.name, input_bytes, greedy_result, greedy_hashes.size() == 1);

        const auto zip = run_zip_baseline(profile, out_dir, expected_sha);
        emit_baseline_row(csv, profile.id, zip.name, input_bytes, zip, true);
        const auto zstd = run_tar_compressor_baseline(profile, out_dir, expected_sha, "zstd");
        emit_baseline_row(csv, profile.id, zstd.name, input_bytes, zstd, true);
        const auto brotli = run_tar_compressor_baseline(profile, out_dir, expected_sha, "brotli");
        emit_baseline_row(csv, profile.id, brotli.name, input_bytes, brotli, true);
        const auto seven = run_7z_baseline(profile, out_dir, expected_sha);
        emit_baseline_row(csv, profile.id, seven.name, input_bytes, seven, true);
        if (ithz_stats.archive_bytes < input_bytes && profile.id != "p5_negative_precompressed_random") ++promising_profiles;
        csv.flush();
    }
    const fs::path summary = out_dir / "native_ithz_p7a_baseline_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ P7A Fair Baseline Harness\n\n"
       << "Status: `" << (all_ithz_decoded ? "passed" : "failed") << "`\n\n"
       << "P7A compares existing methods only. It does not add ITHZ payload methods and does not claim ZIP superiority.\n\n"
       << "- ITHZ checkpointed compact: measured with `VerifyMode::Off` for pack time and separate decode timing.\n"
       << "- ITHZ greedy event-local: retained as schedule-sensitive negative control.\n"
       << "- ZIP/deflate: PowerShell `Compress-Archive` baseline.\n"
       << "- zstd/brotli/7z: reported only when available on the system without installation.\n"
       << "- promising non-negative profiles with ITHZ archive smaller than input: `" << promising_profiles << "`\n\n"
       << "Output matrix: `" << matrix.generic_string() << "`\n";
    if (!all_ithz_decoded) fail("P7A ITHZ decoded SHA gate failed");
    std::cout << "p7a_baseline_ok=true\nmatrix=" << matrix.generic_string() << "\nsummary=" << summary.generic_string() << "\n";
}

std::string folder_prefix_of(const std::string& path) {
    const auto pos = path.find_last_of('/');
    return pos == std::string::npos ? "." : path.substr(0, pos);
}

bool is_precompressed_or_random_family(const std::string& path, const Bytes& data) {
    const auto family = file_family_native(path, data);
    return family == "negative_control" || family == "high_entropy" || path.find("negative/") != std::string::npos;
}

std::size_t varint_size(std::uint64_t value) {
    std::size_t n = 1;
    while (value >= 0x80) {
        value >>= 7;
        ++n;
    }
    return n;
}

struct P7BPackStats {
    fs::path archive_path;
    std::string dataset_sha;
    std::string plan_hash;
    std::string container_hash;
    std::size_t input_bytes = 0;
    std::size_t file_count = 0;
    std::uint64_t max_small_file_size = 0;
    std::size_t bundle_input_bytes = 0;
    std::size_t path_table_bytes = 0;
    std::size_t file_table_bytes = 0;
    std::size_t offset_table_bytes = 0;
    std::size_t payload_bytes = 0;
    std::size_t manifest_bytes = 0;
    std::size_t archive_bytes = 0;
    std::size_t bundle_count = 0;
    std::size_t bundled_file_count = 0;
    std::map<std::string, int> method_counts;
    double pack_ms = 0.0;
    double decode_ms = 0.0;
    bool decoded_ok = false;
    bool negative_clean = true;
};

struct P11PerfStats {
    double scan_ms = 0.0;
    double path_validation_ms = 0.0;
    double path_canonicalization_ms = 0.0;
    double file_read_ms = 0.0;
    double hash_ms = 0.0;
    double entropy_sample_ms = 0.0;
    double autodetect_ms = 0.0;
    double family_assignment_ms = 0.0;
    double small_file_bundle_ms = 0.0;
    double large_text_solid_ms = 0.0;
    double generic_cfc_ms = 0.0;
    double store_media_ms = 0.0;
    double payload_encode_ms = 0.0;
    double manifest_write_ms = 0.0;
    double archive_write_ms = 0.0;
    double checksum_ms = 0.0;
    double verify_ms = 0.0;
    double decode_ms = 0.0;
    double extract_file_ms = 0.0;
    double total_pack_ms_no_verify = 0.0;
    double total_pack_ms_full_verify = 0.0;
    double peak_memory_mb = 0.0;
    std::map<std::string, double> family_elapsed_ms;
    std::map<std::string, std::uint64_t> family_file_count;
    std::map<std::string, std::uint64_t> family_input_bytes;
    std::map<std::string, std::uint64_t> family_archive_bytes;
};

struct P7BOptions {
    std::uint64_t threshold = 4096;
    std::string grouping_mode = "folder_ext_pathhash";
    std::string ablation = "P7B_full";
    std::string selected_profile = "small-files";
    bool use_path_string_table = true;
    bool force_store_bundle = false;
    bool force_lz_range_bundle = false;
    bool raw_offsets = false;
    bool text_only_bundle = false;
    bool hash_backend_mode = false;
    bool auto_mixed_mode = false;
    bool experimental_metadata_compaction = false;
    bool experimental_prefix_metadata = false;
    bool experimental_payload_preconditioners = false;
};

std::string p7b_plan_hash_source(
    const std::vector<std::tuple<std::uint64_t, std::string, std::uint64_t, std::uint64_t, std::string, std::string>>& memberships,
    const std::map<std::string, Bytes>& files,
    const P7BOptions& options
) {
    std::ostringstream oss;
    oss << "variant=checkpointed_cfc_p7b_small_file_bundle\nthreshold=" << options.threshold
        << "\ngrouping=" << options.grouping_mode
        << "\nablation=" << options.ablation
        << "\nselected_profile=" << options.selected_profile
        << "\npath_string_table=" << (options.use_path_string_table ? "true" : "false")
        << "\noffset_encoding=" << (options.raw_offsets ? "raw64" : "varint")
        << "\ntext_only_bundle=" << (options.text_only_bundle ? "true" : "false")
        << "\nauto_mixed_mode=" << (options.auto_mixed_mode ? "true" : "false") << "\n";
    if (options.experimental_payload_preconditioners) {
        oss << "experimental_payload_preconditioners=byteplane2,delta16_byteplane,zigzag_delta16_byteplane\n";
    }
    if (options.hash_backend_mode) {
        oss << "bundle_backend_mode="
            << (options.force_store_bundle ? "STORE_FORCED" : (options.force_lz_range_bundle ? "ZLIB_DEFLATE_FORCED" : "ADAPTIVE_STORE_OR_LZ_RANGE"))
            << "\n";
    }
    for (const auto& [bundle_id, path, offset, size, method, family] : memberships) {
        oss << bundle_id << '|' << path << '|' << offset << '|' << size << '|' << method << '|' << family << '|'
            << sha256_hex(files.at(path)) << "\n";
    }
    return oss.str();
}

NativePayload choose_bundle_payload(const Bytes& plain, bool force_store, bool force_lz_range, bool experimental_preconditioners, ZlibRaw& zlib) {
    NativePayload payload;
    payload.method = "STORE";
    payload.encoded = plain;
    payload.logical_size = plain.size();
    payload.decoded_sha = sha256_hex(plain);
    payload.flags_json = "{}";
    if (!force_store) {
        const Bytes deflated = zlib.deflate_raw(plain, 0);
        if (force_lz_range || deflated.size() + 16 < plain.size()) {
            payload.method = "LZ_RANGE";
            payload.encoded = deflated;
            payload.flags_json = "{\"backend\":\"stdlib_deflate_raw\",\"scope\":\"small_file_bundle\"}";
        }
        if (experimental_preconditioners && !plain.empty() && !force_lz_range) {
            auto try_candidate = [&](const std::string& method, const Bytes& transformed, const std::string& flags) {
                const Bytes encoded = zlib.deflate_raw(transformed, 0);
                if (encoded.size() + 8 < payload.encoded.size()) {
                    payload.method = method;
                    payload.encoded = encoded;
                    payload.flags_json = flags;
                }
            };
            try_candidate(
                "BYTEPLANE2_RANGE",
                byte_shuffle(plain, 2),
                "{\"backend\":\"stdlib_deflate_raw\",\"scope\":\"small_file_bundle\",\"preconditioner\":\"byteplane2\",\"word_size\":2}"
            );
            if (plain.size() >= 4) {
                try_candidate(
                    "DELTA16_BYTEPLANE_RANGE",
                    delta16_precondition(plain, false),
                    "{\"backend\":\"stdlib_deflate_raw\",\"scope\":\"small_file_bundle\",\"preconditioner\":\"delta16_byteplane\",\"word_size\":2}"
                );
                try_candidate(
                    "ZIGZAG_DELTA16_BYTEPLANE_RANGE",
                    delta16_precondition(plain, true),
                    "{\"backend\":\"stdlib_deflate_raw\",\"scope\":\"small_file_bundle\",\"preconditioner\":\"zigzag_delta16_byteplane\",\"word_size\":2}"
                );
            }
        }
    }
    return payload;
}

bool p7b_text_like_family(const std::string& family, const std::string& ext) {
    if (family == "text" || family == "text_log" || family == "json" || family == "numeric_csv" || family == "source") return true;
    static const std::set<std::string> text_exts{
        ".md", ".txt", ".log", ".json", ".csv", ".tsv", ".py", ".c", ".cpp", ".h", ".hpp",
        ".js", ".ts", ".tsx", ".jsx", ".mjs", ".cjs", ".php", ".css", ".scss", ".html",
        ".htm", ".xml", ".svg", ".yml", ".yaml", ".toml", ".ini", ".cfg", ".conf", ".lock", ".map"
    };
    return text_exts.count(ext) != 0;
}

struct AutoFamilyDecision {
    std::string family;
    std::string method;
    std::string reason;
    bool bundle_candidate = false;
};

bool ext_in_set(const std::string& ext, const std::set<std::string>& values) {
    return values.count(ext) != 0;
}

bool p9_precompressed_ext(const std::string& ext) {
    static const std::set<std::string> exts{
        ".jpg", ".jpeg", ".png", ".webp", ".gif", ".mp4", ".mkv", ".mov", ".avi",
        ".zip", ".rar", ".7z", ".gz", ".pdf", ".docx", ".xlsx", ".pptx"
    };
    return ext_in_set(ext, exts);
}

bool p9_text_project_ext(const std::string& ext) {
    static const std::set<std::string> exts{
        ".php", ".js", ".css", ".json", ".md", ".svg", ".txt", ".yml", ".yaml",
        ".toml", ".xml", ".html", ".htm", ".ini", ".cfg", ".conf", ".env",
        ".ts", ".tsx", ".jsx", ".mjs", ".cjs", ".scss", ".lock", ".map"
    };
    return ext_in_set(ext, exts);
}

bool p9_large_text_ext(const std::string& ext) {
    static const std::set<std::string> exts{
        ".log", ".csv", ".tsv", ".json", ".jsonl", ".txt", ".xml", ".html", ".htm"
    };
    return ext_in_set(ext, exts);
}

AutoFamilyDecision classify_auto_mixed_file(const std::string& path, const Bytes& data, std::uint64_t small_threshold) {
    const auto ext = lower_ext(path);
    const auto family = file_family_native(path, data);
    if (p9_precompressed_ext(ext)) {
        return {"already_compressed_or_media_store", "STORE", "precompressed_media_or_compound_extension", false};
    }
    if (family == "negative_control" || family == "high_entropy" || path.find("negative/") != std::string::npos || byte_entropy_score(data) > 7.65) {
        return {"high_entropy_guarded_store", "STORE", "high_entropy_or_negative_guard", false};
    }
    if (p9_text_project_ext(ext) && data.size() <= small_threshold) {
        return {"small_text_project_bundle", "P7B_solid", "small_text_project_extension_below_threshold", true};
    }
    if ((p9_large_text_ext(ext) || p7b_text_like_family(family, ext)) && data.size() > small_threshold) {
        return {"large_text_solid", "LZ_RANGE", "large_text_like_extension", true};
    }
    return {"generic_cfc", "LZ_RANGE", "generic_cfc_fallback", data.size() <= small_threshold && !data.empty()};
}

P7BPackStats pack_p7b_small_file_bundle_from_scheduled(
    const std::vector<std::pair<std::string, Bytes>>& scheduled,
    const fs::path& archive_path,
    const P7BOptions& options,
    bool verify,
    P11PerfStats* perf,
    Clock::time_point start
) {
    const auto canonical_start = Clock::now();
    std::map<std::string, Bytes> files;
    for (const auto& [path, data] : scheduled) files[path] = data;
    if (perf) perf->path_canonicalization_ms = elapsed_ms(canonical_start);
    const auto hash_start = Clock::now();
    const auto dataset_sha = compute_dataset_digest(files);
    if (perf) perf->hash_ms = elapsed_ms(hash_start);

    struct FileInfo {
        std::uint64_t file_id = 0;
        std::string path;
        std::string path_hash;
        std::string folder;
        std::string ext;
        std::string family;
        std::string auto_family;
        std::string auto_reason;
        Bytes data;
        std::string sha;
        bool bundle_candidate = false;
    };
    std::vector<FileInfo> ordered_files;
    ordered_files.reserve(files.size());
    const auto assignment_start = Clock::now();
    for (const auto& [path, data] : files) {
        const auto path_start = Clock::now();
        validate_archive_canonical_path(path);
        if (perf) perf->path_validation_ms += elapsed_ms(path_start);
        FileInfo f;
        f.path = path;
        f.path_hash = sha256_hex_string(path);
        f.folder = folder_prefix_of(path);
        f.ext = lower_ext(path);
        f.family = file_family_native(path, data);
        f.data = data;
        f.sha = sha256_hex(data);
        const bool text_allowed = !options.text_only_bundle || p7b_text_like_family(f.family, f.ext);
        if (options.auto_mixed_mode) {
            const auto autodetect_start = Clock::now();
            const auto decision = classify_auto_mixed_file(path, data, options.threshold);
            if (perf) perf->autodetect_ms += elapsed_ms(autodetect_start);
            f.auto_family = decision.family;
            f.auto_reason = decision.reason;
            f.bundle_candidate = decision.bundle_candidate && text_allowed && !is_precompressed_or_random_family(path, data);
        } else {
            f.auto_family = "small_file_bundle";
            f.auto_reason = "p7b_small_file_threshold";
            f.bundle_candidate = data.size() <= options.threshold && text_allowed && !is_precompressed_or_random_family(path, data);
        }
        if (perf) {
            perf->family_file_count[f.auto_family] += 1;
            perf->family_input_bytes[f.auto_family] += data.size();
        }
        ordered_files.push_back(std::move(f));
    }
    if (perf) perf->family_assignment_ms = elapsed_ms(assignment_start);
    std::sort(ordered_files.begin(), ordered_files.end(), [](const auto& a, const auto& b) {
        return a.path_hash == b.path_hash ? a.path < b.path : a.path_hash < b.path_hash;
    });
    std::map<std::string, std::uint64_t> file_id_by_path;
    for (std::size_t i = 0; i < ordered_files.size(); ++i) {
        ordered_files[i].file_id = static_cast<std::uint64_t>(i);
        file_id_by_path[ordered_files[i].path] = ordered_files[i].file_id;
    }

    std::map<std::string, std::vector<const FileInfo*>> candidate_groups;
    for (const auto& f : ordered_files) {
        if (!f.bundle_candidate) continue;
        std::string key;
        const auto family_prefix = options.auto_mixed_mode ? f.auto_family + "|" : "";
        if (options.grouping_mode == "extension_global") key = family_prefix + "ext|" + f.ext;
        else if (options.grouping_mode == "folder_only") key = family_prefix + "folder|" + f.folder;
        else if (options.grouping_mode == "global_bundle") key = family_prefix + "global";
        else key = family_prefix + sha256_hex_string(f.folder) + "|" + f.ext + "|" + f.folder;
        candidate_groups[key].push_back(&f);
    }

    struct Bundle {
        std::uint64_t bundle_id = 0;
        std::string scope_key;
        std::string folder;
        std::string ext;
        std::string support_family;
        std::vector<const FileInfo*> members;
        std::map<std::string, std::uint64_t> offsets;
        NativePayload payload;
        bool is_small_file_bundle = false;
    };
    std::vector<Bundle> bundles;
    std::set<std::string> bundled_paths;
    ZlibRaw zlib;
    const auto payload_start = Clock::now();
    for (auto& [key, members] : candidate_groups) {
        std::sort(members.begin(), members.end(), [](const FileInfo* a, const FileInfo* b) {
            return a->path_hash == b->path_hash ? a->path < b->path : a->path_hash < b->path_hash;
        });
        if (members.size() < 2) continue;
        const auto bundle_start = Clock::now();
        Bundle b;
        b.bundle_id = static_cast<std::uint64_t>(bundles.size());
        b.folder = members.front()->folder;
        b.ext = members.front()->ext;
        b.scope_key = "small_file_bundle:" + b.folder + ":" + b.ext + ":" + sha256_hex_string(key).substr(0, 12);
        b.support_family = options.auto_mixed_mode ? members.front()->auto_family : "small_file_bundle";
        b.members = members;
        b.is_small_file_bundle = true;
        Bytes plain;
        for (const auto* f : members) {
            b.offsets[f->path] = static_cast<std::uint64_t>(plain.size());
            plain.insert(plain.end(), f->data.begin(), f->data.end());
            bundled_paths.insert(f->path);
        }
        b.payload = choose_bundle_payload(plain, options.force_store_bundle, options.force_lz_range_bundle, options.experimental_payload_preconditioners, zlib);
        if (perf) {
            const auto ms = elapsed_ms(bundle_start);
            perf->family_elapsed_ms[b.support_family] += ms;
            if (b.support_family == "small_text_project_bundle" || b.support_family == "small_file_bundle") perf->small_file_bundle_ms += ms;
            else if (b.support_family == "large_text_solid") perf->large_text_solid_ms += ms;
            else if (b.support_family == "generic_cfc") perf->generic_cfc_ms += ms;
        }
        bundles.push_back(std::move(b));
    }
    for (const auto& f : ordered_files) {
        if (bundled_paths.count(f.path)) continue;
        const auto bundle_start = Clock::now();
        Bundle b;
        b.bundle_id = static_cast<std::uint64_t>(bundles.size());
        b.folder = f.folder;
        b.ext = f.ext;
        b.scope_key = "file_passthrough:" + f.path_hash;
        if (options.auto_mixed_mode) b.support_family = f.auto_family;
        else b.support_family = is_precompressed_or_random_family(f.path, f.data) ? "negative_passthrough" : "small_file_passthrough";
        b.members.push_back(&f);
        b.offsets[f.path] = 0;
        b.payload = choose_bundle_payload(
            f.data,
            is_precompressed_or_random_family(f.path, f.data) || options.force_store_bundle,
            options.force_lz_range_bundle && !is_precompressed_or_random_family(f.path, f.data),
            options.experimental_payload_preconditioners && !is_precompressed_or_random_family(f.path, f.data),
            zlib
        );
        if (perf) {
            const auto ms = elapsed_ms(bundle_start);
            perf->family_elapsed_ms[b.support_family] += ms;
            if (b.support_family == "already_compressed_or_media_store" || b.support_family == "high_entropy_guarded_store" || b.support_family.find("passthrough") != std::string::npos) perf->store_media_ms += ms;
            else if (b.support_family == "large_text_solid") perf->large_text_solid_ms += ms;
            else if (b.support_family == "generic_cfc") perf->generic_cfc_ms += ms;
            else perf->small_file_bundle_ms += ms;
        }
        bundles.push_back(std::move(b));
    }
    if (perf) perf->payload_encode_ms = elapsed_ms(payload_start);
    std::sort(bundles.begin(), bundles.end(), [](const auto& a, const auto& b) {
        return sha256_hex_string(a.scope_key) == sha256_hex_string(b.scope_key) ? a.scope_key < b.scope_key : sha256_hex_string(a.scope_key) < sha256_hex_string(b.scope_key);
    });
    for (std::size_t i = 0; i < bundles.size(); ++i) bundles[i].bundle_id = static_cast<std::uint64_t>(i);

    std::map<std::string, const Bundle*> bundle_by_path;
    std::vector<std::tuple<std::uint64_t, std::string, std::uint64_t, std::uint64_t, std::string, std::string>> memberships;
    for (const auto& bundle : bundles) {
        for (const auto* f : bundle.members) {
            bundle_by_path[f->path] = &bundle;
            memberships.push_back({bundle.bundle_id, f->path, bundle.offsets.at(f->path), static_cast<std::uint64_t>(f->data.size()), bundle.payload.method, bundle.support_family});
        }
    }
    std::sort(memberships.begin(), memberships.end(), [](const auto& a, const auto& b) {
        if (std::get<0>(a) != std::get<0>(b)) return std::get<0>(a) < std::get<0>(b);
        return std::get<1>(a) < std::get<1>(b);
    });
    const auto plan_hash = sha256_hex_string(p7b_plan_hash_source(memberships, files, options));

    Bytes payload_blob;
    std::uint64_t stream_id = 0;
    std::map<std::uint64_t, std::uint64_t> stream_id_by_bundle;
    std::map<std::string, int> method_counts;
    std::size_t bundled_file_count = 0;
    std::size_t bundle_input_bytes = 0;
    for (const auto& bundle : bundles) {
        const auto current_stream = stream_id++;
        stream_id_by_bundle[bundle.bundle_id] = current_stream;
        payload_blob.insert(payload_blob.end(), bundle.payload.encoded.begin(), bundle.payload.encoded.end());
        if (perf) perf->family_archive_bytes[bundle.support_family] += bundle.payload.encoded.size();
        ++method_counts[bundle.payload.method];
        if (bundle.is_small_file_bundle) {
            bundled_file_count += bundle.members.size();
            for (const auto* f : bundle.members) bundle_input_bytes += f->data.size();
        }
    }

    const bool compact_file_rows = options.experimental_metadata_compaction || options.experimental_prefix_metadata;
    const bool elide_selection_reason = options.experimental_prefix_metadata;
    std::set<std::string> prefixes;
    std::set<std::string> extensions;
    std::set<std::string> names;
    std::set<std::string> families;
    std::set<std::string> support_families;
    std::set<std::string> scope_keys;
    std::size_t input_bytes = 0;
    for (const auto& f : ordered_files) {
        prefixes.insert(options.use_path_string_table ? f.folder : ".");
        extensions.insert(f.ext);
        const auto slash = f.path.find_last_of('/');
        names.insert(options.use_path_string_table ? (slash == std::string::npos ? f.path : f.path.substr(slash + 1)) : f.path);
        if (!compact_file_rows) families.insert(f.family);
        families.insert(f.auto_family);
        if (!elide_selection_reason) families.insert(f.auto_reason);
        input_bytes += f.data.size();
    }
    for (const auto& bundle : bundles) {
        support_families.insert(bundle.support_family);
        scope_keys.insert(bundle.scope_key);
        prefixes.insert(options.use_path_string_table ? bundle.folder : ".");
        extensions.insert(bundle.ext);
    }
    std::vector<std::string> strings;
    auto add_p7b_string = [&](const std::string& value) {
        if (std::find(strings.begin(), strings.end(), value) == strings.end()) strings.push_back(value);
    };
    add_p7b_string("");
    for (const auto& v : prefixes) add_p7b_string(v);
    for (const auto& v : names) add_p7b_string(v);
    for (const auto& v : extensions) add_p7b_string(v);
    for (const auto& v : families) add_p7b_string(v);
    for (const auto& v : support_families) add_p7b_string(v);
    for (const auto& v : scope_keys) add_p7b_string(v);
    std::sort(strings.begin(), strings.end());
    std::map<std::string, std::uint64_t> string_index;
    std::size_t path_table_bytes = varint_size(strings.size());
    for (std::size_t i = 0; i < strings.size(); ++i) {
        string_index[strings[i]] = static_cast<std::uint64_t>(i);
        path_table_bytes += varint_size(strings[i].size()) + strings[i].size();
    }

    std::size_t file_table_bytes = 0;
    std::size_t offset_table_bytes = 0;
    for (const auto& f : ordered_files) {
        const auto* bundle = bundle_by_path.at(f.path);
        const auto offset = bundle->offsets.at(f.path);
        const auto slash = f.path.find_last_of('/');
        const auto folder_for_manifest = options.use_path_string_table ? f.folder : ".";
        const auto name = options.use_path_string_table ? (slash == std::string::npos ? f.path : f.path.substr(slash + 1)) : f.path;
        const auto offset_bytes = options.raw_offsets ? 8 : varint_size(offset);
        offset_table_bytes += offset_bytes;
        if (compact_file_rows) {
            file_table_bytes += 1 + varint_size(string_index.at(folder_for_manifest)) + varint_size(string_index.at(name)) +
                varint_size(f.data.size()) + 32 + 1 + offset_bytes + 1 +
                varint_size(string_index.at(f.auto_family)) + (elide_selection_reason ? 0 : varint_size(string_index.at(f.auto_reason)));
        } else {
            file_table_bytes += varint_size(f.file_id) + varint_size(string_index.at(folder_for_manifest)) + varint_size(string_index.at(name)) +
                varint_size(string_index.at(f.ext)) + varint_size(string_index.at(f.family)) + varint_size(f.data.size()) +
                32 + varint_size(stream_id_by_bundle.at(bundle->bundle_id)) + offset_bytes + varint_size(bundle->bundle_id);
        }
    }

    auto manifest_for_offset = [&](std::uint64_t payload_offset_base) {
        Bytes out;
        out.insert(out.end(), kP7BManifestMagic.begin(), kP7BManifestMagic.end());
        append_varint(out, options.experimental_prefix_metadata ? 5 : (options.experimental_metadata_compaction ? 4 : (options.auto_mixed_mode ? 3 : 2)));
        append_packed_bytes(out, bytes_from_hex(dataset_sha));
        append_packed_bytes(out, bytes_from_hex(plan_hash));
        append_varint(out, options.threshold);
        append_varint(out, path_table_bytes);
        append_varint(out, file_table_bytes);
        append_varint(out, options.raw_offsets ? 1 : 0);
        append_varint(out, strings.size());
        for (const auto& value : strings) append_packed_string(out, value);
        append_varint(out, ordered_files.size());
        for (const auto& f : ordered_files) {
            const auto* bundle = bundle_by_path.at(f.path);
            const auto slash = f.path.find_last_of('/');
            const auto folder_for_manifest = options.use_path_string_table ? f.folder : ".";
            const auto name = options.use_path_string_table ? (slash == std::string::npos ? f.path : f.path.substr(slash + 1)) : f.path;
            if (compact_file_rows) {
                static std::int64_t previous_file_id = 0;
                if (&f == &ordered_files.front()) previous_file_id = 0;
                append_svarint(out, static_cast<std::int64_t>(f.file_id) - previous_file_id);
                previous_file_id = static_cast<std::int64_t>(f.file_id);
            } else {
                append_varint(out, f.file_id);
            }
            append_varint(out, string_index.at(folder_for_manifest));
            append_varint(out, string_index.at(name));
            if (!compact_file_rows) {
                append_varint(out, string_index.at(f.ext));
                append_varint(out, string_index.at(f.family));
            }
            append_varint(out, f.data.size());
            const auto sha = bytes_from_hex(f.sha);
            out.insert(out.end(), sha.begin(), sha.end());
            if (compact_file_rows) {
                static std::int64_t previous_stream_id = 0;
                static std::int64_t previous_bundle_id = 0;
                static std::map<std::uint64_t, std::int64_t> previous_offset_by_stream;
                if (&f == &ordered_files.front()) {
                    previous_stream_id = 0;
                    previous_bundle_id = 0;
                    previous_offset_by_stream.clear();
                }
                const auto stream_id_for_file = stream_id_by_bundle.at(bundle->bundle_id);
                append_svarint(out, static_cast<std::int64_t>(stream_id_for_file) - previous_stream_id);
                previous_stream_id = static_cast<std::int64_t>(stream_id_for_file);
                const auto offset_for_file = static_cast<std::int64_t>(bundle->offsets.at(f.path));
                append_svarint(out, offset_for_file - previous_offset_by_stream[stream_id_for_file]);
                previous_offset_by_stream[stream_id_for_file] = offset_for_file;
                append_svarint(out, static_cast<std::int64_t>(bundle->bundle_id) - previous_bundle_id);
                previous_bundle_id = static_cast<std::int64_t>(bundle->bundle_id);
            } else {
                append_varint(out, stream_id_by_bundle.at(bundle->bundle_id));
                if (options.raw_offsets) append_u64_le(out, bundle->offsets.at(f.path));
                else append_varint(out, bundle->offsets.at(f.path));
                append_varint(out, bundle->bundle_id);
            }
            if (options.auto_mixed_mode || compact_file_rows) {
                append_varint(out, string_index.at(f.auto_family));
                if (!elide_selection_reason) append_varint(out, string_index.at(f.auto_reason));
            }
        }
        append_varint(out, bundles.size());
        for (const auto& bundle : bundles) {
            std::vector<std::uint64_t> member_file_ids;
            for (const auto* f : bundle.members) member_file_ids.push_back(f->file_id);
            std::sort(member_file_ids.begin(), member_file_ids.end());
            const auto bundle_folder_for_manifest = options.use_path_string_table ? bundle.folder : ".";
            append_varint(out, bundle.bundle_id);
            append_varint(out, string_index.at(bundle.scope_key));
            append_varint(out, string_index.at(bundle_folder_for_manifest));
            append_varint(out, string_index.at(bundle.ext));
            append_varint(out, string_index.at(bundle.support_family));
            append_varint(out, stream_id_by_bundle.at(bundle.bundle_id));
            append_varint(out, member_file_ids.size());
            append_delta_ids(out, member_file_ids);
        }
        append_varint(out, bundles.size());
        std::uint64_t cursor = payload_offset_base;
        for (const auto& bundle : bundles) {
            append_varint(out, stream_id_by_bundle.at(bundle.bundle_id));
            out.push_back(method_to_id(bundle.payload.method));
            append_varint(out, bundle.payload.logical_size);
            append_varint(out, bundle.payload.encoded.size());
            const auto decoded_sha = bytes_from_hex(bundle.payload.decoded_sha);
            out.insert(out.end(), decoded_sha.begin(), decoded_sha.end());
            append_varint(out, cursor);
            cursor += bundle.payload.encoded.size();
        }
        return out;
    };
    const auto manifest_start = Clock::now();
    Bytes manifest_bytes = manifest_for_offset(0);
    for (int i = 0; i < 8; ++i) {
        const auto payload_offset = static_cast<std::uint64_t>(kHeaderSize + manifest_bytes.size());
        Bytes next = manifest_for_offset(payload_offset);
        if (next.size() == manifest_bytes.size()) {
            manifest_bytes = std::move(next);
            break;
        }
        manifest_bytes = std::move(next);
    }
    if (perf) perf->manifest_write_ms = elapsed_ms(manifest_start);
    const auto write_start = Clock::now();
    write_ithz_archive_bytes(archive_path, manifest_bytes, payload_blob, dataset_sha, plan_hash, kFlagP7BBundleManifest);
    if (perf) perf->archive_write_ms = elapsed_ms(write_start);
    const auto checksum_start = Clock::now();
    auto container_hash = sha256_hex(read_file(archive_path));
    if (perf) perf->checksum_ms = elapsed_ms(checksum_start);
    double decode_ms = 0.0;
    bool decoded_ok = false;
    if (verify) {
        const auto verify_start = Clock::now();
        std::string decoded_sha;
        fs::path verify_root = archive_path.parent_path();
        if (verify_root.has_parent_path()) verify_root = verify_root.parent_path();
        if (verify_root.has_parent_path()) verify_root = verify_root.parent_path();
        const auto verify_id = sha256_hex_string(archive_path.generic_string()).substr(0, 16);
        decode_ms = decode_archive_ms(archive_path, verify_root / "p7b_vd" / verify_id, &decoded_sha);
        decoded_ok = decoded_sha == dataset_sha;
        if (perf) {
            perf->verify_ms = elapsed_ms(verify_start);
            perf->decode_ms = decode_ms;
        }
    } else {
        decoded_ok = true;
    }
    bool negative_clean = true;
    for (const auto& f : ordered_files) {
        if (is_precompressed_or_random_family(f.path, f.data)) {
            const auto* bundle = bundle_by_path.at(f.path);
            if (bundle->is_small_file_bundle || bundle->payload.method != "STORE") negative_clean = false;
        }
    }
    if (perf) {
        perf->total_pack_ms_no_verify = elapsed_ms(start) - perf->verify_ms;
        perf->total_pack_ms_full_verify = elapsed_ms(start);
        perf->peak_memory_mb = peak_memory_mb();
    }
    return P7BPackStats{
        archive_path,
        dataset_sha,
        plan_hash,
        container_hash,
        input_bytes,
        ordered_files.size(),
        options.threshold,
        bundle_input_bytes,
        path_table_bytes,
        file_table_bytes,
        offset_table_bytes,
        payload_blob.size(),
        manifest_bytes.size(),
        fs::file_size(archive_path),
        bundles.size(),
        bundled_file_count,
        method_counts,
        elapsed_ms(start),
        decode_ms,
        decoded_ok,
        negative_clean
    };
}

P7BPackStats pack_p7b_small_file_bundle(
    const fs::path& input_dir,
    const fs::path& archive_path,
    const P7BOptions& options,
    const std::string& schedule,
    bool verify,
    P11PerfStats* perf = nullptr
) {
    const auto start = Clock::now();
    const auto scan_start = Clock::now();
    const auto scheduled = read_dataset_dir_scheduled(input_dir, schedule);
    if (perf) {
        perf->scan_ms = elapsed_ms(scan_start);
        perf->file_read_ms = perf->scan_ms;
    }
    return pack_p7b_small_file_bundle_from_scheduled(scheduled, archive_path, options, verify, perf, start);
}

Bytes read_update_input_bytes(const fs::path& input_path) {
    if (input_path.generic_string() == "-") {
#ifdef _WIN32
        _setmode(_fileno(stdin), _O_BINARY);
#endif
        std::istreambuf_iterator<char> begin(std::cin);
        std::istreambuf_iterator<char> end;
        Bytes data;
        for (auto it = begin; it != end; ++it) data.push_back(static_cast<std::uint8_t>(*it));
        return data;
    }
    return read_file(input_path);
}

Bytes base64_decode(const std::string& text) {
    static const std::string alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::array<int, 256> table{};
    table.fill(-1);
    for (std::size_t i = 0; i < alphabet.size(); ++i) {
        table[static_cast<unsigned char>(alphabet[i])] = static_cast<int>(i);
    }
    Bytes out;
    int value = 0;
    int bits = -8;
    for (const unsigned char c : text) {
        if (std::isspace(c)) continue;
        if (c == '=') break;
        const int decoded = table[c];
        if (decoded < 0) fail("invalid base64 input");
        value = (value << 6) | decoded;
        bits += 6;
        if (bits >= 0) {
            out.push_back(static_cast<std::uint8_t>((value >> bits) & 0xff));
            bits -= 8;
        }
    }
    return out;
}

struct ArchiveFileUpdate {
    std::string path;
    Bytes data;
};

std::vector<ArchiveFileUpdate> parse_update_files_json(const fs::path& input_path) {
    const Bytes input = read_update_input_bytes(input_path);
    const std::string text(input.begin(), input.end());
    const Json root = JsonParser(text).parse();
    const auto& updates = at(root, "updates").array();
    if (updates.empty()) fail("update-files requires at least one update");
    std::vector<ArchiveFileUpdate> out;
    out.reserve(updates.size());
    std::set<std::string> seen;
    for (const auto& update : updates) {
        const auto path = as_string(at(update, "path"));
        validate_archive_canonical_path(path);
        if (!seen.insert(path).second) fail("duplicate update path: " + path);
        const auto data = base64_decode(as_string(at(update, "data_base64")));
        out.push_back({path, data});
    }
    std::sort(out.begin(), out.end(), [](const auto& a, const auto& b) { return a.path < b.path; });
    return out;
}

std::vector<std::pair<std::string, Bytes>> archive_files_to_memory(const Archive& archive) {
    const auto index = build_archive_index(archive);
    std::vector<std::pair<std::string, Bytes>> files;
    files.reserve(at(archive.manifest, "file_table").array().size());
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto path = as_string(at(file, "canonical_path"));
        validate_archive_canonical_path(path);
        files.push_back({path, extract_file_bytes_indexed(archive, index, file)});
    }
    std::sort(files.begin(), files.end(), [](const auto& a, const auto& b) { return a.first < b.first; });
    return files;
}

void replace_archive_with_temp(const fs::path& archive_path, const fs::path& temp_archive) {
    const auto backup = archive_path.string() + ".update.bak";
    fs::remove(backup);
    fs::rename(archive_path, backup);
    try {
        fs::rename(temp_archive, archive_path);
        fs::remove(backup);
    } catch (...) {
        if (!fs::exists(archive_path) && fs::exists(backup)) {
            fs::rename(backup, archive_path);
        }
        throw;
    }
}

struct ArchiveUpdateResult {
    P7BPackStats stats;
    std::string container_hash;
    std::size_t replaced_existing_count = 0;
    std::size_t deleted_count = 0;
    std::size_t renamed_count = 0;
    std::uint64_t input_bytes = 0;
};

struct ArchiveDeleteOp {
    std::string path;
};

struct ArchiveRenameOp {
    std::string from_path;
    std::string to_path;
};

ArchiveUpdateResult update_archive_files_from_memory(
    const fs::path& archive_path,
    const std::vector<ArchiveFileUpdate>& updates,
    const std::vector<ArchiveDeleteOp>& deletes,
    const std::vector<ArchiveRenameOp>& renames,
    const P7BOptions& options,
    VerifyMode verify_mode
) {
    if (updates.empty() && deletes.empty() && renames.empty()) fail("archive update requires at least one operation");
    if (!fs::exists(archive_path)) fail("update-file archive does not exist");
    const auto archive = read_archive(archive_path);
    auto files = archive_files_to_memory(archive);
    std::map<std::string, Bytes> canonical;
    for (auto& [path, data] : files) canonical[path] = std::move(data);
    std::size_t replaced_existing = 0;
    std::size_t deleted = 0;
    std::size_t renamed = 0;
    std::uint64_t input_bytes = 0;
    for (const auto& del : deletes) {
        validate_archive_canonical_path(del.path);
        const auto it = canonical.find(del.path);
        if (it == canonical.end()) fail("delete-file path not found in archive: " + del.path);
        canonical.erase(it);
        ++deleted;
    }
    for (const auto& rename : renames) {
        validate_archive_canonical_path(rename.from_path);
        validate_archive_canonical_path(rename.to_path);
        if (rename.from_path == rename.to_path) fail("rename-file source and destination are identical: " + rename.from_path);
        const auto from_it = canonical.find(rename.from_path);
        if (from_it == canonical.end()) fail("rename-file source path not found in archive: " + rename.from_path);
        if (canonical.find(rename.to_path) != canonical.end()) fail("rename-file destination already exists in archive: " + rename.to_path);
        Bytes moved = std::move(from_it->second);
        canonical.erase(from_it);
        canonical[rename.to_path] = std::move(moved);
        ++renamed;
    }
    for (const auto& update : updates) {
        validate_archive_canonical_path(update.path);
        if (canonical.find(update.path) != canonical.end()) ++replaced_existing;
        input_bytes += update.data.size();
        canonical[update.path] = update.data;
    }
    if (canonical.empty()) fail("archive update would remove all files");
    std::vector<std::pair<std::string, Bytes>> scheduled;
    scheduled.reserve(canonical.size());
    for (const auto& [path, data] : canonical) scheduled.push_back({path, data});

    const auto temp_archive = fs::path(archive_path.string() + ".update.tmp");
    fs::remove(temp_archive);
    const auto start = Clock::now();
    const auto stats = pack_p7b_small_file_bundle_from_scheduled(
        scheduled,
        temp_archive,
        options,
        verify_mode == VerifyMode::Full,
        nullptr,
        start
    );
    if (verify_mode == VerifyMode::FullNoWrite) {
        P12DecodeTiming timing;
        const auto updated_archive = read_archive_timed(temp_archive, &timing);
        const auto decoded_sha = verify_archive_full_no_write_timed(updated_archive, archive_path.parent_path() / "update_file_verify_no_write", &timing);
        if (decoded_sha != stats.dataset_sha) fail("update-file full-no-write verification failed");
    } else if (verify_mode == VerifyMode::ChecksumsOnly) {
        (void)read_archive(temp_archive);
    }
    replace_archive_with_temp(archive_path, temp_archive);
    const auto container_hash = sha256_hex(read_file(archive_path));
    return ArchiveUpdateResult{stats, container_hash, replaced_existing, deleted, renamed, input_bytes};
}

ArchiveUpdateResult update_archive_files_from_memory(
    const fs::path& archive_path,
    const std::vector<ArchiveFileUpdate>& updates,
    const P7BOptions& options,
    VerifyMode verify_mode
) {
    return update_archive_files_from_memory(archive_path, updates, {}, {}, options, verify_mode);
}

void update_archive_file_from_memory(
    const fs::path& archive_path,
    const std::string& inner_path,
    const fs::path& input_path,
    const P7BOptions& options,
    VerifyMode verify_mode
) {
    validate_archive_canonical_path(inner_path);
    const auto input_data = read_update_input_bytes(input_path);
    const auto result = update_archive_files_from_memory(archive_path, std::vector<ArchiveFileUpdate>{{inner_path, input_data}}, options, verify_mode);
    std::cout << "update_file_ok=true\n";
    std::cout << "archive=" << archive_path.generic_string() << "\n";
    std::cout << "path=" << inner_path << "\n";
    std::cout << "replaced_existing=" << (result.replaced_existing_count == 1 ? "true" : "false") << "\n";
    std::cout << "input_bytes=" << input_data.size() << "\n";
    std::cout << "input_sha256=" << sha256_hex(input_data) << "\n";
    std::cout << "decoded_sha256=" << result.stats.dataset_sha << "\n";
    std::cout << "semantic_plan_hash=" << result.stats.plan_hash << "\n";
    std::cout << "container_bytes_hash=" << result.container_hash << "\n";
    std::cout << "archive_bytes=" << fs::file_size(archive_path) << "\n";
    std::cout << "verify_mode=" << verify_mode_name(verify_mode) << "\n";
    std::cout << "update_mode=memory_decode_repack\n";
}

void update_archive_files_from_json(
    const fs::path& archive_path,
    const fs::path& input_path,
    const P7BOptions& options,
    VerifyMode verify_mode
) {
    const auto updates = parse_update_files_json(input_path);
    const auto result = update_archive_files_from_memory(archive_path, updates, options, verify_mode);
    std::cout << "update_files_ok=true\n";
    std::cout << "archive=" << archive_path.generic_string() << "\n";
    std::cout << "update_count=" << updates.size() << "\n";
    std::cout << "replaced_existing_count=" << result.replaced_existing_count << "\n";
    std::cout << "input_bytes=" << result.input_bytes << "\n";
    std::cout << "decoded_sha256=" << result.stats.dataset_sha << "\n";
    std::cout << "semantic_plan_hash=" << result.stats.plan_hash << "\n";
    std::cout << "container_bytes_hash=" << result.container_hash << "\n";
    std::cout << "archive_bytes=" << fs::file_size(archive_path) << "\n";
    std::cout << "verify_mode=" << verify_mode_name(verify_mode) << "\n";
    std::cout << "update_mode=memory_decode_repack_batch\n";
}

void delete_archive_file_from_memory(
    const fs::path& archive_path,
    const std::string& inner_path,
    const P7BOptions& options,
    VerifyMode verify_mode
) {
    validate_archive_canonical_path(inner_path);
    const auto result = update_archive_files_from_memory(
        archive_path,
        {},
        std::vector<ArchiveDeleteOp>{{inner_path}},
        {},
        options,
        verify_mode
    );
    std::cout << "delete_file_ok=true\n";
    std::cout << "archive=" << archive_path.generic_string() << "\n";
    std::cout << "path=" << inner_path << "\n";
    std::cout << "deleted_count=" << result.deleted_count << "\n";
    std::cout << "decoded_sha256=" << result.stats.dataset_sha << "\n";
    std::cout << "semantic_plan_hash=" << result.stats.plan_hash << "\n";
    std::cout << "container_bytes_hash=" << result.container_hash << "\n";
    std::cout << "archive_bytes=" << fs::file_size(archive_path) << "\n";
    std::cout << "verify_mode=" << verify_mode_name(verify_mode) << "\n";
    std::cout << "update_mode=memory_decode_repack_delete\n";
}

void rename_archive_file_from_memory(
    const fs::path& archive_path,
    const std::string& from_path,
    const std::string& to_path,
    const P7BOptions& options,
    VerifyMode verify_mode
) {
    validate_archive_canonical_path(from_path);
    validate_archive_canonical_path(to_path);
    const auto result = update_archive_files_from_memory(
        archive_path,
        {},
        {},
        std::vector<ArchiveRenameOp>{{from_path, to_path}},
        options,
        verify_mode
    );
    std::cout << "rename_file_ok=true\n";
    std::cout << "archive=" << archive_path.generic_string() << "\n";
    std::cout << "from_path=" << from_path << "\n";
    std::cout << "to_path=" << to_path << "\n";
    std::cout << "renamed_count=" << result.renamed_count << "\n";
    std::cout << "decoded_sha256=" << result.stats.dataset_sha << "\n";
    std::cout << "semantic_plan_hash=" << result.stats.plan_hash << "\n";
    std::cout << "container_bytes_hash=" << result.container_hash << "\n";
    std::cout << "archive_bytes=" << fs::file_size(archive_path) << "\n";
    std::cout << "verify_mode=" << verify_mode_name(verify_mode) << "\n";
    std::cout << "update_mode=memory_decode_repack_rename\n";
}

void generate_p7b_many_small_files(const fs::path& dir, int count) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int i = 0; i < count; ++i) {
        std::ostringstream text;
        text << "selector=checkpointed_cfc\nfile=" << i << "\nkind=many_small\n";
        for (int j = 0; j < 5; ++j) text << "row," << j << ",support," << (i % 17) << ",pressure," << ((i + j) % 101) << "\n";
        write_text_bytes(dir / "shards" / ("group_" + std::to_string(i / 100)) / ("item_" + std::to_string(i) + ".txt"), text.str());
    }
}

void generate_p7b_mixed_small_medium(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    generate_p7b_many_small_files(dir / "small_pack", 1200);
    for (int i = 0; i < 80; ++i) {
        std::ostringstream text;
        for (int j = 0; j < 250; ++j) text << "module=" << i << ",line=" << j << ",selector=canonical,checkpoint=" << (j % 13) << "\n";
        write_text_bytes(dir / "medium" / ("module_" + std::to_string(i) + ".log"), text.str());
    }
}

void generate_p7b_negative_smallfiles(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    const std::array<std::string, 6> exts{".jpg", ".png", ".zip", ".mp4", ".pdf", ".bin"};
    for (int i = 0; i < 896; ++i) {
        const auto ext = exts[static_cast<std::size_t>(i) % exts.size()];
        write_file(dir / "negative" / ("random_" + std::to_string(i / 100)) / ("asset_" + std::to_string(i) + ext), deterministic_noise(512 + static_cast<std::size_t>(i % 64), 7000U + static_cast<std::uint32_t>(i)));
    }
}

std::vector<CorpusProfile> generate_p7b_corpora(const fs::path& out_dir) {
    const fs::path root = out_dir / "p7b_corpora";
    fs::create_directories(root);
    std::vector<CorpusProfile> profiles = {
        {"many_small_files_100", "P7B_many_small_100", root / "many_small_files_100"},
        {"many_small_files_1000", "P7B_many_small_1000", root / "many_small_files_1000"},
        {"many_small_files_10000", "P7B_many_small_10000", root / "many_small_files_10000"},
        {"mixed_small_medium_files", "P7B_mixed_small_medium", root / "mixed_small_medium_files"},
        {"negative_precompressed_random_smallfiles", "P7B_negative_smallfiles", root / "negative_precompressed_random_smallfiles"}
    };
    generate_p7b_many_small_files(profiles[0].dir, 100);
    generate_p7b_many_small_files(profiles[1].dir, 1000);
    generate_p7b_many_small_files(profiles[2].dir, 10000);
    generate_p7b_mixed_small_medium(profiles[3].dir);
    generate_p7b_negative_smallfiles(profiles[4].dir);
    return profiles;
}

bool p7b_allowed_real_ext(const std::string& ext) {
    static const std::set<std::string> allowed{
        ".php", ".js", ".css", ".scss", ".ts", ".tsx", ".jsx", ".json", ".md", ".txt", ".yml", ".yaml",
        ".xml", ".svg", ".html", ".htm", ".ini", ".cfg", ".conf", ".lock", ".map", ".mjs", ".cjs"
    };
    return allowed.count(ext) != 0;
}

bool should_skip_dir_for_real_copy(const fs::path& path, bool allow_node_modules) {
    const auto name = path.filename().string();
    if (name == ".git" || name == ".svn" || name == ".hg" || name == "build" || name == "build_avx2" ||
        name == "dist" || name == "coverage" || name == ".cache" || name == "raw" || name == "p7b_archives" ||
        name == "p7b_decoded" || name == "p5_archives" || name == "p6d_archives" || name == "__pycache__") return true;
    if (!allow_node_modules && name == "node_modules") return true;
    return false;
}

std::size_t copy_real_small_files(
    const fs::path& source,
    const fs::path& target,
    std::size_t max_files,
    std::uint64_t max_file_size,
    bool allow_node_modules,
    const std::set<std::string>& ext_filter = {}
) {
    if (!fs::exists(source)) return 0;
    fs::remove_all(target);
    fs::create_directories(target);
    std::vector<fs::path> selected;
    fs::recursive_directory_iterator it(source, fs::directory_options::skip_permission_denied), end;
    for (; it != end && selected.size() < max_files; ++it) {
        const auto& entry = *it;
        if (entry.is_directory()) {
            if (should_skip_dir_for_real_copy(entry.path(), allow_node_modules)) it.disable_recursion_pending();
            continue;
        }
        if (!entry.is_regular_file()) continue;
        const auto size = static_cast<std::uint64_t>(entry.file_size());
        if (size > max_file_size) continue;
        const auto ext = lower_ext(entry.path().generic_string());
        if (!ext_filter.empty()) {
            if (!ext_filter.count(ext)) continue;
        } else if (!p7b_allowed_real_ext(ext)) {
            continue;
        }
        selected.push_back(entry.path());
    }
    std::sort(selected.begin(), selected.end(), [](const auto& a, const auto& b) {
        const auto ag = a.generic_string();
        const auto bg = b.generic_string();
        const auto ah = sha256_hex_string(ag);
        const auto bh = sha256_hex_string(bg);
        return ah == bh ? ag < bg : ah < bh;
    });
    std::size_t copied = 0;
    for (const auto& path : selected) {
        const auto rel = fs::relative(path, source);
        auto out = target / rel;
        if (out.generic_string().size() > 180) {
            const auto ext = lower_ext(path.generic_string());
            out = target / "hashed_long_paths" / (sha256_hex_string(rel.generic_string()) + ext);
        }
        fs::create_directories(out.parent_path());
        fs::copy_file(path, out, fs::copy_options::overwrite_existing);
        ++copied;
    }
    return copied;
}

void generate_real_like_wp_fallback(const fs::path& dir) {
    fs::remove_all(dir);
    for (int i = 0; i < 240; ++i) {
        std::ostringstream php;
        php << "<?php\nnamespace P7B\\Fixture\\Block" << (i % 12) << ";\n"
            << "add_action('init', function () { register_post_type('p7b_" << i << "', ['public' => true]); });\n";
        write_text_bytes(dir / "wp-content" / "plugins" / "p7b-fixture" / "includes" / ("class-block-" + std::to_string(i) + ".php"), php.str());
    }
    for (int i = 0; i < 80; ++i) {
        write_text_bytes(dir / "wp-content" / "themes" / "p7b-theme" / "assets" / ("module-" + std::to_string(i) + ".css"),
            ".p7b-card-" + std::to_string(i) + "{display:grid;gap:8px;color:#223;background:#f7f7f7}\n");
        write_text_bytes(dir / "wp-content" / "themes" / "p7b-theme" / "assets" / ("module-" + std::to_string(i) + ".js"),
            "export const block" + std::to_string(i) + " = { hydrate(){ return 'checkpointed-cfc'; } };\n");
    }
}

void generate_real_like_project_fallback(const fs::path& dir) {
    fs::remove_all(dir);
    for (int i = 0; i < 360; ++i) {
        write_text_bytes(dir / "src" / ("component-" + std::to_string(i) + ".ts"),
            "export function component" + std::to_string(i) + "(input:string){ return input.trim().toLowerCase(); }\n");
        write_text_bytes(dir / "styles" / ("component-" + std::to_string(i) + ".scss"),
            ".component-" + std::to_string(i) + "{padding:12px;border:1px solid var(--border);}\n");
    }
    write_text_bytes(dir / "package.json", "{\"scripts\":{\"build\":\"vite build\"},\"dependencies\":{\"p7b\":\"file:fixture\"}}\n");
}

void generate_real_like_docs_fallback(const fs::path& dir) {
    fs::remove_all(dir);
    for (int i = 0; i < 220; ++i) {
        write_text_bytes(dir / "docs" / ("page-" + std::to_string(i) + ".md"),
            "# Page " + std::to_string(i) + "\n\n- selector: checkpointed\n- support: small-file-bundle\n");
        write_text_bytes(dir / "config" / ("config-" + std::to_string(i) + ".json"),
            "{\"id\":" + std::to_string(i) + ",\"mode\":\"canonical\",\"threshold\":4096}\n");
    }
}

void generate_real_like_icons_fallback(const fs::path& dir) {
    fs::remove_all(dir);
    for (int i = 0; i < 800; ++i) {
        write_text_bytes(dir / "icons" / ("icon-" + std::to_string(i) + ".svg"),
            "<svg viewBox=\"0 0 24 24\"><path d=\"M" + std::to_string(i % 24) + " 4h12v16H4z\"/></svg>\n");
        write_text_bytes(dir / "manifests" / ("icon-" + std::to_string(i) + ".json"),
            "{\"name\":\"icon-" + std::to_string(i) + "\",\"tags\":[\"p7b\",\"small\"]}\n");
    }
}

std::vector<CorpusProfile> generate_p7b_real_corpora(const fs::path& out_dir) {
    const fs::path root = out_dir / "p7b_real_corpora";
    fs::create_directories(root);
    std::vector<CorpusProfile> profiles = {
        {"real_like_wp_theme_small", "P7B_real_wp_php_theme", root / "real_like_wp_theme_small"},
        {"real_like_php_js_css_project", "P7B_real_php_js_css_project", root / "real_like_php_js_css_project"},
        {"real_like_docs_markdown_config", "P7B_real_docs_markdown_config", root / "real_like_docs_markdown_config"},
        {"real_like_node_modules_subset", "P7B_real_node_modules_subset", root / "real_like_node_modules_subset"},
        {"real_like_icons_svg_json", "P7B_real_icons_svg_json", root / "real_like_icons_svg_json"},
        {"mixed_real_like_small_medium", "P7B_real_mixed_small_medium", root / "mixed_real_like_small_medium"},
        {"negative_precompressed_random_smallfiles", "P7B_real_negative_smallfiles", root / "negative_precompressed_random_smallfiles"}
    };
    if (copy_real_small_files("C:/work/!partnerske_weby_zaloha/plug2/prosight-epartner-2.1.3", profiles[0].dir, 400, 65536, false) < 80) {
        generate_real_like_wp_fallback(profiles[0].dir);
    }
    if (copy_real_small_files("C:/work/partnerske_weby/eplan/monorepo-frontend", profiles[1].dir, 500, 65536, false) < 80) {
        generate_real_like_project_fallback(profiles[1].dir);
    }
    if (copy_real_small_files("C:/work/ITHKOR", profiles[2].dir, 600, 65536, false, {".md", ".json", ".toml", ".yml", ".yaml", ".txt"}) < 80) {
        generate_real_like_docs_fallback(profiles[2].dir);
    }
    if (copy_real_small_files("C:/work/rma/node_modules", profiles[3].dir, 700, 32768, true) < 80) {
        generate_real_like_project_fallback(profiles[3].dir);
    }
    if (copy_real_small_files("C:/work/partnerske_weby/eplan/monorepo-frontend", profiles[4].dir, 700, 32768, false, {".svg", ".json"}) < 80) {
        generate_real_like_icons_fallback(profiles[4].dir);
    }
    if (copy_real_small_files("C:/work/ITHKOR", profiles[5].dir, 700, 65536, false) < 120) {
        generate_p7b_mixed_small_medium(profiles[5].dir);
    }
    generate_p7b_negative_smallfiles(profiles[6].dir);
    return profiles;
}

double percent_delta(std::size_t value, std::size_t baseline) {
    if (baseline == 0) return 0.0;
    return (static_cast<double>(value) - static_cast<double>(baseline)) * 100.0 / static_cast<double>(baseline);
}

void run_p7b_small_files(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const fs::path archives_root = out_dir / "p7b_archives";
    const fs::path plans_root = out_dir / "p7b_plans";
    const fs::path matrix_path = out_dir / "native_ithz_p7b_small_files_matrix.csv";
    const fs::path schedule_path = out_dir / "native_ithz_p7b_schedule_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p7b_summary.md";
    const auto cache_id = make_cache_identity("--run-p7b-small-files", out_dir / "p7b_corpora", "profiles=5;thresholds=fast;manifest=p7b-bundle-varint-v1");
    if (phase_summary_passed(summary, {matrix_path, schedule_path}, cache_id)) {
        write_cache_hygiene_summary(out_dir, cache_id, true, "matched_existing_p7b_small_files_summary_and_matrices");
        std::cout << "p7b_small_files_ok=true\ncached=true\nmatrix=" << matrix_path.generic_string()
                  << "\nschedule_matrix=" << schedule_path.generic_string()
                  << "\nsummary=" << summary.generic_string() << "\n";
        return;
    }
    const auto profiles = generate_p7b_corpora(out_dir);
    fs::create_directories(archives_root);
    fs::create_directories(plans_root);
    std::ofstream matrix(matrix_path);
    std::ofstream sched(schedule_path);
    matrix << "dataset_id,threshold_bytes,variant,input_bytes,file_count,avg_file_size,path_table_bytes,file_table_bytes,payload_bytes,manifest_bytes,archive_bytes,pack_ms_no_verify,decode_ms,decoded_ok,schedule_unique_hashes,ZIP_deflate_bytes,delta_vs_zip_percent,delta_vs_p7a_ithz_percent,greedy_unique_hashes,negative_clean,notes\n";
    sched << "dataset_id,threshold_bytes,variant,schedule,archive_path,semantic_plan_hash,decoded_sha256,archive_bytes,decoded_ok,notes\n";

    std::size_t stable_profiles = 0;
    std::size_t decoded_profiles = 0;
    std::size_t negative_clean_profiles = 0;
    std::size_t zip_wins = 0;
    std::size_t p7b_wins_vs_zip = 0;
    std::size_t p7b_wins_vs_p7a = 0;

    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::size_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();
        const double avg_size = files.empty() ? 0.0 : static_cast<double>(input_bytes) / static_cast<double>(files.size());

        SelectorTiming selector_timing;
        const fs::path baseline_plan_path = plans_root / profile.id / "p7a_checkpointed_original.json";
        write_plan_for_schedule(profile.dir, baseline_plan_path, "original", 1, &selector_timing);
        PackTiming baseline_timing;
        const auto p7a_stats = pack_checkpointed_original(profile.dir, archives_root / profile.id / "p7a_checkpointed_compact.ithz", baseline_plan_path, "compact", VerifyMode::Off, false, false, &baseline_timing);
        std::string p7a_decoded_sha;
        const auto p7a_decode_ms = decode_archive_ms(p7a_stats.archive_path, out_dir / "p7b_decoded" / profile.id / "p7a_checkpointed", &p7a_decoded_sha);

        const auto zip = run_zip_baseline(profile, out_dir, expected_sha);

        std::set<std::string> greedy_hashes;
        auto greedy_specs = greedy_schedules();
        if (profile.id.find("10000") != std::string::npos) {
            greedy_specs = {greedy_specs[0], greedy_specs[1], greedy_specs[2]};
        }
        for (const auto& spec : greedy_specs) {
            const auto greedy_stats = pack_greedy_event_local(profile.dir, archives_root / profile.id / ("greedy_" + spec.label + ".ithz"), spec.schedule, false);
            greedy_hashes.insert(greedy_stats.plan_hash);
        }

        matrix << profile.id << ",0,ithz_checkpointed_compact_p7a," << input_bytes << ',' << files.size() << ','
               << std::fixed << std::setprecision(3) << avg_size << ",0,0," << p7a_stats.payload_bytes << ','
               << p7a_stats.manifest_bytes << ',' << p7a_stats.archive_bytes << ',' << (selector_timing.total_ms + baseline_timing.total_ms) << ','
               << p7a_decode_ms << ',' << (p7a_decoded_sha == expected_sha ? "true" : "false") << ",1,"
               << (zip.available ? std::to_string(zip.archive_bytes) : std::string("0")) << ','
               << std::fixed << std::setprecision(3) << (zip.available ? percent_delta(p7a_stats.archive_bytes, zip.archive_bytes) : 0.0)
               << ",0.000," << greedy_hashes.size() << ",true,p7a_existing_checkpointed_compact_baseline\n";

        P7BPackStats best_p7b;
        bool have_best = false;
        bool all_thresholds_stable = true;
        bool all_thresholds_decoded = true;
        bool all_negative_clean = true;
        const bool huge_profile = profile.id.find("10000") != std::string::npos;
        const std::vector<std::uint64_t> thresholds = huge_profile ? std::vector<std::uint64_t>{4096ULL} : std::vector<std::uint64_t>{1024ULL, 4096ULL, 16384ULL};
        for (const auto threshold : thresholds) {
            std::set<std::string> schedule_hashes;
            bool decoded_all = true;
            P7BPackStats original_stats;
            const auto all_p7b_schedules = checkpointed_schedules();
            const std::vector<ScheduleSpec> p7b_fast_schedules{all_p7b_schedules[0], all_p7b_schedules[1], all_p7b_schedules[2]};
            for (const auto& spec : p7b_fast_schedules) {
                P7BOptions options;
                options.threshold = threshold;
                const fs::path archive = archives_root / profile.id / ("p7b_bundle_" + std::to_string(threshold) + "_" + spec.label + ".ithz");
                const bool full_decode_row = spec.label == "original_order";
                const auto stats = pack_p7b_small_file_bundle(profile.dir, archive, options, spec.schedule, full_decode_row);
                schedule_hashes.insert(stats.plan_hash);
                decoded_all = decoded_all && stats.decoded_ok;
                sched << profile.id << ',' << threshold << ",p7b_small_file_bundle," << spec.label << ',' << archive.generic_string() << ','
                      << stats.plan_hash << ',' << stats.dataset_sha << ',' << stats.archive_bytes << ',' << (stats.decoded_ok ? "true" : "false")
                      << ',' << (full_decode_row ? "full_decode_bundle_roundtrip" : "schedule_plan_hash_archive_write_only") << "\n";
                if (spec.label == "original_order") original_stats = stats;
            }
            const bool stable = schedule_hashes.size() == 1;
            all_thresholds_stable = all_thresholds_stable && stable;
            all_thresholds_decoded = all_thresholds_decoded && decoded_all;
            all_negative_clean = all_negative_clean && original_stats.negative_clean;
            if (!have_best || original_stats.archive_bytes < best_p7b.archive_bytes) {
                best_p7b = original_stats;
                have_best = true;
            }
            matrix << profile.id << ',' << threshold << ",ithz_p7b_small_file_bundle," << original_stats.input_bytes << ','
                   << original_stats.file_count << ',' << std::fixed << std::setprecision(3) << avg_size << ','
                   << original_stats.path_table_bytes << ',' << original_stats.file_table_bytes << ','
                   << original_stats.payload_bytes << ',' << original_stats.manifest_bytes << ',' << original_stats.archive_bytes << ','
                   << original_stats.pack_ms << ',' << original_stats.decode_ms << ',' << (original_stats.decoded_ok ? "true" : "false") << ','
                   << schedule_hashes.size() << ',' << (zip.available ? std::to_string(zip.archive_bytes) : std::string("0")) << ','
                   << std::fixed << std::setprecision(3) << (zip.available ? percent_delta(original_stats.archive_bytes, zip.archive_bytes) : 0.0) << ','
                   << percent_delta(original_stats.archive_bytes, p7a_stats.archive_bytes) << ',' << greedy_hashes.size() << ','
                   << (original_stats.negative_clean ? "true" : "false") << ',' << csv_cell(method_counts_text(original_stats.method_counts)) << "\n";
            matrix.flush();
            sched.flush();
        }
        matrix << profile.id << ",0,zip_deflate," << input_bytes << ',' << files.size() << ',' << std::fixed << std::setprecision(3)
               << avg_size << ",0,0,0,0," << (zip.available ? zip.archive_bytes : 0) << ',' << zip.pack_ms << ',' << zip.decode_ms << ','
               << (zip.decoded_ok ? "true" : "false") << ",1," << (zip.available ? zip.archive_bytes : 0) << ",0.000,0.000,"
               << greedy_hashes.size() << ",true," << csv_cell(zip.notes) << "\n";
        matrix << profile.id << ",0,greedy_event_local," << input_bytes << ',' << files.size() << ',' << std::fixed << std::setprecision(3)
               << avg_size << ",0,0,0,0,0,0,0,true," << greedy_hashes.size() << ',' << (zip.available ? zip.archive_bytes : 0)
               << ",0.000,0.000," << greedy_hashes.size() << ",true,negative_control_plan_hash_only\n";
        matrix.flush();
        sched.flush();

        if (all_thresholds_stable) ++stable_profiles;
        if (all_thresholds_decoded) ++decoded_profiles;
        if (all_negative_clean) ++negative_clean_profiles;
        if (zip.available && zip.archive_bytes < best_p7b.archive_bytes) ++zip_wins;
        if (zip.available && best_p7b.archive_bytes < zip.archive_bytes) ++p7b_wins_vs_zip;
        if (best_p7b.archive_bytes < p7a_stats.archive_bytes) ++p7b_wins_vs_p7a;
    }

    const bool passed = stable_profiles == profiles.size() && decoded_profiles == profiles.size() &&
        negative_clean_profiles == profiles.size() && p7b_wins_vs_p7a > 0;
    std::ofstream md(summary);
    md << "# Native ITHZ P7B Many-Small-Files Specialization\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P7B adds a narrow small-file bundle experiment without adding new compression methods. Bundle payloads use existing `STORE` or `LZ_RANGE`; the new behavior is deterministic support/cut grouping, per-file offset restoration, and path/string table accounting.\n\n"
       << "## Acceptance\n\n"
       << "- checkpointed P7B profiles with stable semantic plan hash: `" << stable_profiles << "/" << profiles.size() << "`\n"
       << "- checkpointed P7B profiles decoded OK: `" << decoded_profiles << "/" << profiles.size() << "`\n"
       << "- negative/random small-file profiles kept STORE/pass-through-like: `" << negative_clean_profiles << "/" << profiles.size() << "`\n"
       << "- P7B best threshold smaller than P7A checkpointed compact on profiles: `" << p7b_wins_vs_p7a << "/" << profiles.size() << "`\n"
       << "- P7B best threshold smaller than ZIP/deflate on profiles in this environment: `" << p7b_wins_vs_zip << "/" << profiles.size() << "`\n"
       << "- ZIP/deflate smaller than P7B on profiles in this environment: `" << zip_wins << "/" << profiles.size() << "`\n\n"
       << "## Interpretation\n\n"
       << "This is only a many-small-files specialization experiment. It does not claim general ZIP superiority. The intended claim is limited to whether deterministic small-file bundling improves generated many-small-file corpora while keeping schedule-stable planning.\n\n"
       << "Raw matrices:\n\n"
       << "- `" << matrix_path.generic_string() << "`\n"
       << "- `" << schedule_path.generic_string() << "`\n";
    write_cache_block(md, cache_id, false, "fresh_p7b_small_files_run_completed");
    if (!passed) fail("P7B acceptance failed");
    std::cout << "p7b_small_files_ok=true\nmatrix=" << matrix_path.generic_string() << "\nschedule_matrix=" << schedule_path.generic_string() << "\nsummary=" << summary.generic_string() << "\n";
}

double median_file_size_bytes(const std::map<std::string, Bytes>& files) {
    if (files.empty()) return 0.0;
    std::vector<std::size_t> sizes;
    for (const auto& [_, data] : files) sizes.push_back(data.size());
    std::sort(sizes.begin(), sizes.end());
    const auto mid = sizes.size() / 2;
    if (sizes.size() % 2) return static_cast<double>(sizes[mid]);
    return (static_cast<double>(sizes[mid - 1]) + static_cast<double>(sizes[mid])) / 2.0;
}

struct AutoMixedPlanResult {
    Json plan_json;
    std::map<std::string, std::uint64_t> family_bytes;
    std::map<std::string, std::uint64_t> family_files;
    std::map<std::string, std::string> family_methods;
    std::uint64_t input_bytes = 0;
    std::uint64_t file_count = 0;
    std::uint64_t small_1k = 0;
    std::uint64_t small_4k = 0;
    std::uint64_t small_16k = 0;
    std::uint64_t small_64k = 0;
    std::string dataset_sha;
    std::string dataset_features_hash;
    std::string family_assignment_hash;
    std::string semantic_plan_hash;
};

AutoMixedPlanResult build_auto_mixed_plan_report(const fs::path& input_dir, const std::string& schedule, std::uint64_t threshold) {
    const auto scheduled = read_dataset_dir_scheduled(input_dir, schedule);
    std::map<std::string, Bytes> files;
    for (const auto& [path, data] : scheduled) files[path] = data;
    AutoMixedPlanResult result;
    result.file_count = files.size();
    result.dataset_sha = compute_dataset_digest(files);
    std::vector<std::size_t> sizes;
    std::map<std::string, std::uint64_t> ext_counts;
    std::map<std::string, std::uint64_t> prefix_counts;
    std::uint64_t text_source_files = 0;
    std::uint64_t precompressed_files = 0;
    std::uint64_t high_entropy_files = 0;
    std::uint64_t depth_sum = 0;
    Json::Array file_rows;
    for (const auto& [path, data] : files) {
        const auto ext = lower_ext(path);
        const auto family = file_family_native(path, data);
        const auto decision = classify_auto_mixed_file(path, data, threshold);
        result.input_bytes += data.size();
        sizes.push_back(data.size());
        if (data.size() <= 1024) ++result.small_1k;
        if (data.size() <= 4096) ++result.small_4k;
        if (data.size() <= 16384) ++result.small_16k;
        if (data.size() <= 65536) ++result.small_64k;
        if (p7b_text_like_family(family, ext)) ++text_source_files;
        if (p9_precompressed_ext(ext)) ++precompressed_files;
        if (decision.family == "high_entropy_guarded_store") ++high_entropy_files;
        ++ext_counts[ext.empty() ? "<none>" : ext];
        const auto folder = folder_prefix_of(path);
        ++prefix_counts[folder];
        depth_sum += static_cast<std::uint64_t>(std::count(path.begin(), path.end(), '/'));
        result.family_bytes[decision.family] += data.size();
        result.family_files[decision.family] += 1;
        result.family_methods[decision.family] = decision.method;
        file_rows.push_back(jobj({
            {"path", jstr(path)},
            {"sha256", jstr(sha256_hex(data))},
            {"size", jnum(static_cast<std::uint64_t>(data.size()))},
            {"extension", jstr(ext)},
            {"content_family", jstr(family)},
            {"selected_family", jstr(decision.family)},
            {"selected_method", jstr(decision.method)},
            {"reason", jstr(decision.reason)}
        }));
    }
    const double avg_size = result.file_count ? static_cast<double>(result.input_bytes) / static_cast<double>(result.file_count) : 0.0;
    const auto median_size = static_cast<std::uint64_t>(median_file_size_bytes(files));
    std::uint64_t repeated_prefix_files = 0;
    for (const auto& [_, count] : prefix_counts) {
        if (count > 1) repeated_prefix_files += count;
    }
    Json::Array families;
    for (const auto& [family, bytes] : result.family_bytes) {
        families.push_back(jobj({
            {"family", jstr(family)},
            {"file_count", jnum(result.family_files[family])},
            {"input_bytes", jnum(bytes)},
            {"method", jstr(result.family_methods[family])}
        }));
    }
    std::ostringstream feature_hash_src;
    feature_hash_src << "files=" << result.file_count << "\nbytes=" << result.input_bytes << "\nmedian=" << median_size
                     << "\nsmall1k=" << result.small_1k << "\nsmall4k=" << result.small_4k
                     << "\nsmall16k=" << result.small_16k << "\nsmall64k=" << result.small_64k
                     << "\ntext=" << text_source_files << "\nprecompressed=" << precompressed_files
                     << "\nhigh_entropy=" << high_entropy_files << "\next_diversity=" << ext_counts.size()
                     << "\nrepeated_prefix=" << repeated_prefix_files << "\ndepth_sum=" << depth_sum << "\n";
    std::ostringstream assignment_hash_src;
    for (const auto& row : file_rows) {
        const auto& obj = row.object();
        assignment_hash_src << obj.at("path").string() << '|' << obj.at("selected_family").string() << '|'
                            << obj.at("selected_method").string() << '|' << obj.at("reason").string() << '\n';
    }
    result.dataset_features_hash = sha256_hex_string(feature_hash_src.str());
    result.family_assignment_hash = sha256_hex_string(assignment_hash_src.str());
    result.semantic_plan_hash = sha256_hex_string("auto_mixed_v1\n" + result.dataset_sha + "\n" + result.dataset_features_hash + "\n" + result.family_assignment_hash);
    result.plan_json = jobj({
        {"requested_profile", jstr("auto")},
        {"selected_profile", jstr("auto_mixed_v1")},
        {"autodetect_version", jnum(1)},
        {"dataset_sha256", jstr(result.dataset_sha)},
        {"dataset_features_hash", jstr(result.dataset_features_hash)},
        {"family_assignment_hash", jstr(result.family_assignment_hash)},
        {"semantic_plan_hash", jstr(result.semantic_plan_hash)},
        {"threshold_bytes", jnum(threshold)},
        {"features", jobj({
            {"file_count", jnum(result.file_count)},
            {"total_bytes", jnum(result.input_bytes)},
            {"avg_file_size_q1000", jnum(static_cast<std::uint64_t>(avg_size * 1000.0))},
            {"median_file_size", jnum(median_size)},
            {"small_file_count_1k", jnum(result.small_1k)},
            {"small_file_count_4k", jnum(result.small_4k)},
            {"small_file_count_16k", jnum(result.small_16k)},
            {"small_file_count_64k", jnum(result.small_64k)},
            {"text_source_files", jnum(text_source_files)},
            {"precompressed_extension_files", jnum(precompressed_files)},
            {"high_entropy_guarded_files", jnum(high_entropy_files)},
            {"extension_diversity", jnum(static_cast<std::uint64_t>(ext_counts.size()))},
            {"repeated_path_prefix_files", jnum(repeated_prefix_files)},
            {"folder_depth_sum", jnum(depth_sum)}
        })},
        {"families", jarr(std::move(families))},
        {"files", jarr(std::move(file_rows))}
    });
    return result;
}

void write_auto_mixed_plan_artifacts(
    const fs::path& input_dir,
    const fs::path& plan_report_path,
    const fs::path& out_dir,
    const std::string& schedule = "original"
) {
    fs::create_directories(out_dir);
    const auto plan = build_auto_mixed_plan_report(input_dir, schedule, 32768);
    write_text_file(plan_report_path, json_dump(plan.plan_json));
    const fs::path matrix_path = out_dir / "native_ithz_p9_auto_mixed_plan_matrix.csv";
    std::ofstream csv(matrix_path);
    csv << "phase,dataset_id,schedule,selected_profile,input_bytes,file_count,dataset_features_hash,family_assignment_hash,semantic_plan_hash,family,file_count_by_family,input_bytes_by_family,method,notes\n";
    const auto dataset_id = input_dir.filename().generic_string().empty() ? "input" : input_dir.filename().generic_string();
    for (const auto& [family, bytes] : plan.family_bytes) {
        csv << "P9A," << csv_cell(dataset_id) << ',' << schedule << ",auto_mixed_v1," << plan.input_bytes << ','
            << plan.file_count << ',' << plan.dataset_features_hash << ',' << plan.family_assignment_hash << ','
            << plan.semantic_plan_hash << ',' << family << ',' << plan.family_files.at(family) << ',' << bytes << ','
            << plan.family_methods.at(family) << ",analyze_only_no_archive\n";
    }
    const fs::path summary_path = out_dir / "auto_mixed_plan_summary.md";
    std::ofstream md(summary_path);
    md << "# ITHZ Native P9A Auto-Mixed Plan\n\n"
       << "Status: `passed`\n\n"
       << "Analyze-only plan for `" << input_dir.generic_string() << "`. No archive was written.\n\n"
       << "```text\n"
       << "selected_profile=auto_mixed_v1\n"
       << "input_bytes=" << plan.input_bytes << "\n"
       << "file_count=" << plan.file_count << "\n"
       << "dataset_features_hash=" << plan.dataset_features_hash << "\n"
       << "family_assignment_hash=" << plan.family_assignment_hash << "\n"
       << "semantic_plan_hash=" << plan.semantic_plan_hash << "\n"
       << "```\n\n"
       << "## Families\n\n";
    for (const auto& [family, bytes] : plan.family_bytes) {
        md << "- `" << family << "`: files=`" << plan.family_files.at(family) << "`, input_bytes=`" << bytes
           << "`, method=`" << plan.family_methods.at(family) << "`\n";
    }
    md << "\nOutputs:\n\n"
       << "- `" << plan_report_path.generic_string() << "`\n"
       << "- `" << matrix_path.generic_string() << "`\n";
}

P7BOptions p7b_options_for_ablation(const std::string& ablation, std::uint64_t threshold) {
    P7BOptions options;
    options.threshold = threshold;
    options.ablation = ablation;
    if (ablation == "no_path_string_table") options.use_path_string_table = false;
    else if (ablation == "no_extension_grouping") options.grouping_mode = "folder_only";
    else if (ablation == "no_folder_grouping") options.grouping_mode = "extension_global";
    else if (ablation == "store_bundle_only") options.force_store_bundle = true;
    else if (ablation == "lz_range_bundle") options.force_lz_range_bundle = true;
    else if (ablation == "raw_offset_table") options.raw_offsets = true;
    else if (ablation == "varint_offset_table") options.raw_offsets = false;
    return options;
}

void run_p7b_real(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const fs::path archives_root = out_dir / "p7b_real_archives";
    const fs::path plans_root = out_dir / "p7b_real_plans";
    const fs::path real_matrix_path = out_dir / "native_ithz_p7b_real_matrix.csv";
    const fs::path threshold_path = out_dir / "native_ithz_p7b_threshold_sweep.csv";
    const fs::path ablation_path = out_dir / "native_ithz_p7b_ablation_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p7b_real_summary.md";
    const auto cache_id = make_cache_identity("--run-p7b-real", out_dir / "p7b_real_corpora", "profiles=7;thresholds=9;groupings=4;ablations=8;tar_gz=true");
    if (phase_summary_passed(summary, {real_matrix_path, threshold_path, ablation_path}, cache_id)) {
        write_cache_hygiene_summary(out_dir, cache_id, true, "matched_existing_p7b_real_summary_and_matrices");
        std::cout << "p7b_real_ok=true\ncached=true\nmatrix=" << real_matrix_path.generic_string()
                  << "\nthreshold_sweep=" << threshold_path.generic_string()
                  << "\nablation_matrix=" << ablation_path.generic_string()
                  << "\nsummary=" << summary.generic_string() << "\n";
        return;
    }
    const auto profiles = generate_p7b_real_corpora(out_dir);
    fs::create_directories(archives_root);
    fs::create_directories(plans_root);
    std::ofstream real_csv(real_matrix_path);
    std::ofstream threshold_csv(threshold_path);
    std::ofstream ablation_csv(ablation_path);

    const std::string common_header = "variant,input_bytes,file_count,avg_file_size,median_file_size,max_small_file_size,bundle_file_count,bundle_input_bytes,bundle_payload_bytes,path_table_bytes,offset_table_bytes,manifest_bytes,archive_bytes,pack_ms_no_verify,decode_ms,decoded_ok,schedule_unique_hashes,semantic_plan_hash,zip_deflate_bytes,tar_gz_bytes,delta_vs_p7a_percent,delta_vs_zip_percent,delta_vs_tar_gz_percent,negative_clean,notes\n";
    real_csv << "dataset_id," << common_header;
    threshold_csv << "dataset_id,grouping_mode," << common_header;
    ablation_csv << "dataset_id,ablation," << common_header;

    std::size_t stable_profiles = 0;
    std::size_t decoded_profiles = 0;
    std::size_t negative_clean_profiles = 0;
    std::size_t p7b_better_than_zip = 0;
    std::size_t p7b_better_than_tar_gz = 0;

    const std::vector<std::uint64_t> thresholds{256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536};
    const std::vector<std::string> grouping_modes{"folder_ext_pathhash", "extension_global", "folder_only", "global_bundle"};
    const std::vector<std::string> ablations{"P7B_full", "no_path_string_table", "no_extension_grouping", "no_folder_grouping", "store_bundle_only", "lz_range_bundle", "raw_offset_table", "varint_offset_table"};

    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::size_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();
        const double avg_size = files.empty() ? 0.0 : static_cast<double>(input_bytes) / static_cast<double>(files.size());
        const double median_size = median_file_size_bytes(files);

        SelectorTiming selector_timing;
        const fs::path p7a_plan = plans_root / profile.id / "p7a_checkpointed_original.json";
        write_plan_for_schedule(profile.dir, p7a_plan, "original", 1, &selector_timing);
        PackTiming p7a_timing;
        const auto p7a_stats = pack_checkpointed_original(profile.dir, archives_root / profile.id / "p7a_checkpointed_compact.ithz", p7a_plan, "compact", VerifyMode::Off, false, false, &p7a_timing);
        std::string p7a_decoded_sha;
        const auto p7a_decode_ms = decode_archive_ms(p7a_stats.archive_path, out_dir / "p7b_real_decoded" / profile.id / "p7a", &p7a_decoded_sha);

        const auto zip = run_zip_baseline(profile, out_dir, expected_sha);
        const auto tar_gz = run_tar_gzip_baseline(profile, out_dir, expected_sha);
        const auto tar_zstd = run_tar_compressor_baseline(profile, out_dir, expected_sha, "zstd");
        const auto brotli = run_tar_compressor_baseline(profile, out_dir, expected_sha, "brotli");
        const auto sevenz = run_7z_baseline(profile, out_dir, expected_sha);
        (void)tar_zstd;
        (void)brotli;
        (void)sevenz;

        auto emit_p7b_row = [&](std::ofstream& csv, const std::string& prefix, const std::string& variant, const P7BPackStats& stats, std::size_t schedule_unique, const std::string& notes) {
            csv << prefix << variant << ',' << stats.input_bytes << ',' << stats.file_count << ','
                << std::fixed << std::setprecision(3) << avg_size << ',' << median_size << ','
                << stats.max_small_file_size << ',' << stats.bundled_file_count << ',' << stats.bundle_input_bytes << ','
                << stats.payload_bytes << ',' << stats.path_table_bytes << ',' << stats.offset_table_bytes << ','
                << stats.manifest_bytes << ',' << stats.archive_bytes << ',' << stats.pack_ms << ',' << stats.decode_ms << ','
                << (stats.decoded_ok ? "true" : "false") << ',' << schedule_unique << ',' << stats.plan_hash << ','
                << (zip.available ? zip.archive_bytes : 0) << ',' << (tar_gz.available ? tar_gz.archive_bytes : 0) << ','
                << percent_delta(stats.archive_bytes, p7a_stats.archive_bytes) << ','
                << (zip.available ? percent_delta(stats.archive_bytes, zip.archive_bytes) : 0.0) << ','
                << (tar_gz.available ? percent_delta(stats.archive_bytes, tar_gz.archive_bytes) : 0.0) << ','
                << (stats.negative_clean ? "true" : "false") << ',' << csv_cell(notes + ";" + method_counts_text(stats.method_counts)) << "\n";
        };

        real_csv << profile.id << ",p7a_checkpointed_compact," << input_bytes << ',' << files.size() << ','
                 << std::fixed << std::setprecision(3) << avg_size << ',' << median_size << ",0,0,0,0,0,0,"
                 << p7a_stats.manifest_bytes << ',' << p7a_stats.archive_bytes << ',' << (selector_timing.total_ms + p7a_timing.total_ms) << ','
                 << p7a_decode_ms << ',' << (p7a_decoded_sha == expected_sha ? "true" : "false") << ",1," << p7a_stats.plan_hash << ','
                 << (zip.available ? zip.archive_bytes : 0) << ',' << (tar_gz.available ? tar_gz.archive_bytes : 0)
                 << ",0," << (zip.available ? percent_delta(p7a_stats.archive_bytes, zip.archive_bytes) : 0.0) << ','
                 << (tar_gz.available ? percent_delta(p7a_stats.archive_bytes, tar_gz.archive_bytes) : 0.0)
                 << ",true,p7a_baseline\n";

        P7BOptions full_options;
        full_options.threshold = 4096;
        const auto full_stats = pack_p7b_small_file_bundle(profile.dir, archives_root / profile.id / "p7b_full_4096_original.ithz", full_options, "original", true);
        std::set<std::string> schedule_hashes;
        bool schedule_decoded = true;
        for (const auto& spec : checkpointed_schedules()) {
            const auto sched_stats = pack_p7b_small_file_bundle(profile.dir, archives_root / profile.id / ("p7b_full_4096_" + spec.label + ".ithz"), full_options, spec.schedule, spec.label == "original_order");
            schedule_hashes.insert(sched_stats.plan_hash);
            schedule_decoded = schedule_decoded && sched_stats.decoded_ok;
        }
        emit_p7b_row(real_csv, profile.id + ",", "p7b_full_4096", full_stats, schedule_hashes.size(), "p7b_real_full");

        real_csv << profile.id << ",zip_deflate," << input_bytes << ',' << files.size() << ',' << std::fixed << std::setprecision(3)
                 << avg_size << ',' << median_size << ",0,0,0,0,0,0,0," << (zip.available ? zip.archive_bytes : 0) << ','
                 << zip.pack_ms << ',' << zip.decode_ms << ',' << (zip.decoded_ok ? "true" : "false") << ",1,,"
                 << (zip.available ? zip.archive_bytes : 0) << ',' << (tar_gz.available ? tar_gz.archive_bytes : 0)
                 << ",0,0,0,true," << csv_cell(zip.notes) << "\n";
        real_csv << profile.id << ",tar_gzip," << input_bytes << ',' << files.size() << ',' << std::fixed << std::setprecision(3)
                 << avg_size << ',' << median_size << ",0,0,0,0,0,0,0," << (tar_gz.available ? tar_gz.archive_bytes : 0) << ','
                 << tar_gz.pack_ms << ',' << tar_gz.decode_ms << ',' << (tar_gz.decoded_ok ? "true" : "false") << ",1,,"
                 << (zip.available ? zip.archive_bytes : 0) << ',' << (tar_gz.available ? tar_gz.archive_bytes : 0)
                 << ",0,0,0,true," << csv_cell(tar_gz.notes) << "\n";

        for (const auto threshold : thresholds) {
            for (const auto& grouping : grouping_modes) {
                P7BOptions options;
                options.threshold = threshold;
                options.grouping_mode = grouping;
                options.ablation = "threshold_sweep";
                const auto stats = pack_p7b_small_file_bundle(profile.dir, archives_root / profile.id / ("threshold_" + grouping + "_" + std::to_string(threshold) + ".ithz"), options, "original", false);
                emit_p7b_row(threshold_csv, profile.id + "," + grouping + ",", "p7b_threshold_sweep", stats, 1, "threshold_grouping_sweep_archive_write;decode_verified_by_p7b_full_row");
            }
        }

        for (const auto& ablation : ablations) {
            auto options = p7b_options_for_ablation(ablation, 4096);
            const auto stats = pack_p7b_small_file_bundle(profile.dir, archives_root / profile.id / ("ablation_" + ablation + ".ithz"), options, "original", true);
            emit_p7b_row(ablation_csv, profile.id + "," + ablation + ",", "p7b_ablation", stats, 1, "p7b_ablation_actual_archive");
        }

        if (schedule_hashes.size() == 1) ++stable_profiles;
        if (full_stats.decoded_ok && schedule_decoded) ++decoded_profiles;
        if (full_stats.negative_clean) ++negative_clean_profiles;
        if (zip.available && full_stats.archive_bytes < zip.archive_bytes) ++p7b_better_than_zip;
        if (tar_gz.available && full_stats.archive_bytes < tar_gz.archive_bytes) ++p7b_better_than_tar_gz;
        real_csv.flush();
        threshold_csv.flush();
        ablation_csv.flush();
    }

    const bool passed = stable_profiles == profiles.size() && decoded_profiles == profiles.size() && negative_clean_profiles == profiles.size();
    std::ofstream md(summary);
    md << "# Native ITHZ P7B Real-Like Small-File Sweep\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P7B-real samples read-only candidates from `C:/work` into experiment-local corpora, with deterministic synthetic-realistic fallbacks when a source is not available.\n\n"
       << "## Acceptance\n\n"
       << "- P7B full schedule-stable profiles: `" << stable_profiles << "/" << profiles.size() << "`\n"
       << "- P7B full decoded profiles: `" << decoded_profiles << "/" << profiles.size() << "`\n"
       << "- negative/random profiles clean: `" << negative_clean_profiles << "/" << profiles.size() << "`\n"
       << "- P7B full smaller than ZIP/deflate profiles: `" << p7b_better_than_zip << "/" << profiles.size() << "`\n"
       << "- P7B full smaller than tar.gz profiles: `" << p7b_better_than_tar_gz << "/" << profiles.size() << "`\n\n"
       << "## Outputs\n\n"
       << "- `" << real_matrix_path.generic_string() << "`\n"
       << "- `" << threshold_path.generic_string() << "`\n"
       << "- `" << ablation_path.generic_string() << "`\n\n"
       << "Interpretation: this remains a narrow small-file bundle experiment. It does not claim general ZIP or tar.gz superiority.\n";
    write_cache_block(md, cache_id, false, "fresh_p7b_real_run_completed");
    if (!passed) fail("P7B-real acceptance failed");
    std::cout << "p7b_real_ok=true\nmatrix=" << real_matrix_path.generic_string() << "\nthreshold_sweep=" << threshold_path.generic_string() << "\nablation_matrix=" << ablation_path.generic_string() << "\nsummary=" << summary.generic_string() << "\n";
}

P7BOptions p7b_solid_options_for(const std::string& profile_id, const std::string& variant) {
    P7BOptions options;
    options.ablation = variant;
    if (variant == "P7B_current_full") {
        options.threshold = 4096;
        options.grouping_mode = "folder_ext_pathhash";
    } else if (variant == "P7B_solid_by_extension") {
        options.grouping_mode = "extension_global";
        options.threshold = (profile_id.find("icons") != std::string::npos || profile_id.find("wp") != std::string::npos) ? 8192 : 16384;
        if (profile_id.find("mixed") != std::string::npos || profile_id.find("project") != std::string::npos) options.threshold = 32768;
    } else if (variant == "P7B_solid_by_folder") {
        options.threshold = 2048;
        options.grouping_mode = "folder_only";
    } else if (variant == "P7B_solid_global_text") {
        options.threshold = 32768;
        options.grouping_mode = "global_bundle";
        options.text_only_bundle = true;
    } else if (variant == "P7B_solid_guarded_mixed") {
        options.threshold = 32768;
        options.grouping_mode = "extension_global";
    } else {
        fail("unknown P7B-solid variant: " + variant);
    }
    return options;
}

void run_p7b_solid(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const fs::path archives_root = out_dir / "p7b_solid_archives";
    const fs::path matrix_path = out_dir / "native_ithz_p7b_solid_matrix.csv";
    const fs::path schedule_path = out_dir / "native_ithz_p7b_solid_schedule_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p7b_solid_summary.md";
    const auto cache_id = make_cache_identity("--run-p7b-solid", out_dir / "p7b_real_corpora", "variants=5;schedules=8;backend=STORE_OR_LZ_RANGE;tar_gz=true");
    if (phase_summary_passed(summary, {matrix_path, schedule_path}, cache_id)) {
        write_cache_hygiene_summary(out_dir, cache_id, true, "matched_existing_p7b_solid_summary_and_matrices");
        std::cout << "p7b_solid_ok=true\ncached=true\nmatrix=" << matrix_path.generic_string()
                  << "\nschedule_matrix=" << schedule_path.generic_string()
                  << "\nsummary=" << summary.generic_string() << "\n";
        return;
    }
    const auto profiles = generate_p7b_real_corpora(out_dir);
    fs::create_directories(archives_root);

    std::ofstream matrix(matrix_path);
    std::ofstream sched(schedule_path);
    matrix << "dataset_id,variant,input_bytes,file_count,bundle_count,bundle_input_bytes,bundle_payload_bytes,offset_table_bytes,path_table_bytes,manifest_bytes,archive_bytes,delta_vs_p7b_current_percent,delta_vs_zip_percent,delta_vs_tar_gz_percent,pack_ms_no_verify,decode_ms,decoded_ok,schedule_unique_hashes,method_counts,negative_control_behavior,semantic_plan_hash,zip_deflate_bytes,tar_gz_bytes,notes\n";
    sched << "dataset_id,variant,schedule,threshold_bytes,grouping_mode,archive_path,semantic_plan_hash,decoded_sha256,archive_bytes,decoded_ok,negative_clean,notes\n";

    const std::vector<std::string> variants{
        "P7B_current_full",
        "P7B_solid_by_extension",
        "P7B_solid_by_folder",
        "P7B_solid_global_text",
        "P7B_solid_guarded_mixed"
    };

    std::size_t decoded_rows = 0;
    std::size_t total_rows = 0;
    std::size_t stable_rows = 0;
    std::size_t negative_guarded_rows = 0;
    std::size_t p7b_solid_better_than_current = 0;
    std::size_t p7b_solid_better_than_zip = 0;
    std::size_t p7b_solid_better_than_tar_gz = 0;
    std::size_t negative_total_rows = 0;

    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::size_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();
        const auto zip = run_zip_baseline(profile, out_dir, expected_sha);
        const auto tar_gz = run_tar_gzip_baseline(profile, out_dir, expected_sha, "p7b_solid_baselines");

        const auto current_options = p7b_solid_options_for(profile.id, "P7B_current_full");
        const auto current_stats = pack_p7b_small_file_bundle(
            profile.dir,
            archives_root / profile.id / "P7B_current_full_original.ithz",
            current_options,
            "original",
            true
        );
        const auto current_bytes = current_stats.archive_bytes;
        const bool negative_profile = profile.id.find("negative") != std::string::npos;

        for (const auto& variant : variants) {
            const auto options = p7b_solid_options_for(profile.id, variant);
            const fs::path variant_dir = archives_root / profile.id / variant;
            fs::create_directories(variant_dir);
            const auto original_stats = (variant == "P7B_current_full")
                ? current_stats
                : pack_p7b_small_file_bundle(profile.dir, variant_dir / "original_order.ithz", options, "original", true);

            std::set<std::string> schedule_hashes;
            bool schedule_decoded = true;
            bool schedule_negative_clean = true;
            for (const auto& spec : checkpointed_schedules()) {
                P7BPackStats sched_stats;
                if (spec.label == "original_order") {
                    sched_stats = original_stats;
                } else {
                    sched_stats = pack_p7b_small_file_bundle(profile.dir, variant_dir / (spec.label + ".ithz"), options, spec.schedule, false);
                }
                schedule_hashes.insert(sched_stats.plan_hash);
                schedule_decoded = schedule_decoded && sched_stats.decoded_ok;
                schedule_negative_clean = schedule_negative_clean && sched_stats.negative_clean;
                sched << profile.id << ',' << variant << ',' << spec.label << ',' << options.threshold << ','
                      << options.grouping_mode << ',' << sched_stats.archive_path.generic_string() << ','
                      << sched_stats.plan_hash << ',' << sched_stats.dataset_sha << ',' << sched_stats.archive_bytes << ','
                      << (sched_stats.decoded_ok ? "true" : "false") << ',' << (sched_stats.negative_clean ? "true" : "false")
                      << ',' << (spec.label == "original_order" ? "full_decode_bundle_roundtrip" : "schedule_plan_hash_archive_write_only") << "\n";
            }
            const bool stable = schedule_hashes.size() == 1;
            const bool decoded_ok = original_stats.decoded_ok && schedule_decoded && original_stats.dataset_sha == expected_sha;
            const bool negative_clean = !negative_profile || (original_stats.negative_clean && schedule_negative_clean);
            const std::string negative_behavior = negative_profile
                ? (negative_clean ? "guarded_store_passthrough" : "structure_extraction_regression")
                : "not_negative_profile";

            ++total_rows;
            if (stable) ++stable_rows;
            if (decoded_ok) ++decoded_rows;
            if (negative_profile) {
                ++negative_total_rows;
                if (negative_clean) ++negative_guarded_rows;
            }
            if (variant != "P7B_current_full" && original_stats.archive_bytes < current_bytes) ++p7b_solid_better_than_current;
            if (zip.available && original_stats.archive_bytes < zip.archive_bytes) ++p7b_solid_better_than_zip;
            if (tar_gz.available && original_stats.archive_bytes < tar_gz.archive_bytes) ++p7b_solid_better_than_tar_gz;

            matrix << profile.id << ',' << variant << ',' << original_stats.input_bytes << ',' << original_stats.file_count << ','
                   << original_stats.bundle_count << ',' << original_stats.bundle_input_bytes << ',' << original_stats.payload_bytes << ','
                   << original_stats.offset_table_bytes << ',' << original_stats.path_table_bytes << ',' << original_stats.manifest_bytes << ','
                   << original_stats.archive_bytes << ',' << std::fixed << std::setprecision(3)
                   << percent_delta(original_stats.archive_bytes, current_bytes) << ','
                   << (zip.available ? percent_delta(original_stats.archive_bytes, zip.archive_bytes) : 0.0) << ','
                   << (tar_gz.available ? percent_delta(original_stats.archive_bytes, tar_gz.archive_bytes) : 0.0) << ','
                   << original_stats.pack_ms << ',' << original_stats.decode_ms << ',' << (decoded_ok ? "true" : "false") << ','
                   << schedule_hashes.size() << ',' << csv_cell(method_counts_text(original_stats.method_counts)) << ','
                   << negative_behavior << ',' << original_stats.plan_hash << ','
                   << (zip.available ? zip.archive_bytes : 0) << ',' << (tar_gz.available ? tar_gz.archive_bytes : 0) << ','
                   << csv_cell("solid_bundle_existing_store_lz_range_only") << "\n";
            matrix.flush();
            sched.flush();
        }
    }

    const bool passed = decoded_rows == total_rows && stable_rows == total_rows && negative_guarded_rows == negative_total_rows;
    std::ofstream md(summary);
    md << "# Native ITHZ P7B-Solid Small-File Bundling\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P7B-solid keeps the existing `STORE` and `LZ_RANGE` payload paths and changes only deterministic small-file bundle grouping. It tests whether solid-style concatenated bundle streams close part of the gap to tar.gz while preserving CFC schedule-stable planning.\n\n"
       << "## Acceptance\n\n"
       << "- decoded P7B-solid rows: `" << decoded_rows << "/" << total_rows << "`\n"
       << "- schedule-stable P7B-solid rows: `" << stable_rows << "/" << total_rows << "`\n"
       << "- negative/random rows guarded: `" << negative_guarded_rows << "/" << negative_total_rows << "`\n"
       << "- solid variant rows smaller than P7B current: `" << p7b_solid_better_than_current << "`\n"
       << "- P7B/P7B-solid rows smaller than ZIP/deflate: `" << p7b_solid_better_than_zip << "/" << total_rows << "`\n"
       << "- P7B/P7B-solid rows smaller than tar.gz: `" << p7b_solid_better_than_tar_gz << "/" << total_rows << "`\n\n"
       << "## Interpretation\n\n"
       << "Supported claim only: P7B-solid tests deterministic CFC small-file bundling against ZIP and tar.gz style baselines. If tar.gz remains smaller, that is an expected and recorded baseline result, not a failure of the stability claim.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix_path.generic_string() << "`\n"
       << "- `" << schedule_path.generic_string() << "`\n";
    write_cache_block(md, cache_id, false, "fresh_p7b_solid_run_completed");
    if (!passed) fail("P7B-solid acceptance failed");
    std::cout << "p7b_solid_ok=true\nmatrix=" << matrix_path.generic_string()
              << "\nschedule_matrix=" << schedule_path.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_ci_fast(const fs::path& input_dir, const fs::path& out_dir, const fs::path& reference_plan_path);

void run_p8a_solid_backend_gap(const fs::path& out_dir, const fs::path& input_dir, const fs::path& reference_plan_path) {
    fs::create_directories(out_dir);
    run_ci_fast(input_dir, out_dir, reference_plan_path);
    const auto profiles = generate_p7b_real_corpora(out_dir);
    const fs::path archives_root = out_dir / "p8a_solid_backend_archives";
    fs::create_directories(archives_root);
    const fs::path matrix_path = out_dir / "native_ithz_p8a_solid_backend_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p8a_solid_backend_summary.md";
    const auto cache_id = make_cache_identity("--run-p8a-solid-backend", out_dir / "p7b_real_corpora", "variants=4;baselines=zip,tar_gz;backend_gap=v1");

    if (phase_summary_passed(summary, {matrix_path}, cache_id)) {
        write_cache_hygiene_summary(out_dir, cache_id, true, "matched_existing_p8a_backend_gap_summary_and_matrix");
        std::cout << "p8a_solid_backend_ok=true\ncached=true\nmatrix=" << matrix_path.generic_string()
                  << "\nsummary=" << summary.generic_string() << "\n";
        return;
    }

    std::ofstream matrix(matrix_path);
    matrix << "dataset_id,variant,backend_mode,input_bytes,file_count,archive_bytes,payload_bytes,manifest_bytes,path_table_bytes,offset_table_bytes,bundle_count,bundle_input_bytes,bundle_payload_bytes,delta_vs_p7b_solid_percent,delta_vs_zip_percent,delta_vs_tar_gz_percent,pack_ms_no_verify,decode_ms,decoded_ok,schedule_unique_hashes,negative_control_behavior,method_counts,semantic_plan_hash,zip_deflate_bytes,tar_gz_bytes,notes\n";

    struct Variant {
        std::string name;
        std::string backend_mode;
        P7BOptions options;
    };

    std::size_t decoded_rows = 0;
    std::size_t stable_rows = 0;
    std::size_t total_rows = 0;
    std::size_t negative_guarded_rows = 0;
    std::size_t negative_total_rows = 0;
    std::size_t zlib_beats_current_solid = 0;
    std::size_t zlib_beats_zip = 0;
    std::size_t zlib_beats_tar_gz = 0;
    std::size_t store_beats_current_solid = 0;

    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::size_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();
        const auto zip = run_zip_baseline(profile, out_dir, expected_sha);
        const auto tar_gz = run_tar_gzip_baseline(profile, out_dir, expected_sha, "p8a_solid_backend_baselines");

        P7BOptions current;
        current.threshold = 4096;
        current.grouping_mode = "folder_ext_pathhash";
        current.ablation = "P7B_current";
        current.hash_backend_mode = true;

        P7BOptions solid = p7b_solid_options_for(profile.id, "P7B_solid_by_extension");
        solid.ablation = "P7B_solid_current_LZ_RANGE";
        solid.hash_backend_mode = true;

        P7BOptions zlib = solid;
        zlib.ablation = "P8A_solid_zlib_deflate_bundle";
        zlib.force_lz_range_bundle = true;
        zlib.hash_backend_mode = true;

        P7BOptions store = solid;
        store.ablation = "P8A_solid_store_bundle";
        store.force_store_bundle = true;
        store.hash_backend_mode = true;

        const std::vector<Variant> variants{
            {"P7B_current", "adaptive_store_or_lz_range", current},
            {"P7B_solid_current_LZ_RANGE", "adaptive_store_or_lz_range", solid},
            {"P8A_solid_zlib_deflate_bundle", "forced_zlib_raw_deflate_on_bundle_path", zlib},
            {"P8A_solid_store_bundle", "forced_store_on_bundle_path", store}
        };

        const auto solid_reference = pack_p7b_small_file_bundle(
            profile.dir,
            archives_root / profile.id / "solid_reference_original.ithz",
            solid,
            "original",
            true
        );

        const bool negative_profile = profile.id.find("negative") != std::string::npos;
        for (const auto& variant : variants) {
            const fs::path variant_dir = archives_root / profile.id / variant.name;
            fs::create_directories(variant_dir);
            const auto original_stats = variant.name == "P7B_solid_current_LZ_RANGE"
                ? solid_reference
                : pack_p7b_small_file_bundle(profile.dir, variant_dir / "original_order.ithz", variant.options, "original", true);

            std::set<std::string> schedule_hashes;
            bool schedule_decoded = true;
            bool schedule_negative_clean = true;
            for (const auto& spec : checkpointed_schedules()) {
                P7BPackStats sched_stats;
                if (spec.label == "original_order") {
                    sched_stats = original_stats;
                } else {
                    sched_stats = pack_p7b_small_file_bundle(profile.dir, variant_dir / (spec.label + ".ithz"), variant.options, spec.schedule, false);
                }
                schedule_hashes.insert(sched_stats.plan_hash);
                schedule_decoded = schedule_decoded && sched_stats.decoded_ok;
                schedule_negative_clean = schedule_negative_clean && sched_stats.negative_clean;
            }

            const bool decoded_ok = original_stats.decoded_ok && schedule_decoded && original_stats.dataset_sha == expected_sha;
            const bool stable = schedule_hashes.size() == 1;
            const bool negative_clean = !negative_profile || (original_stats.negative_clean && schedule_negative_clean);
            const std::string negative_behavior = negative_profile
                ? (negative_clean ? "guarded_store_passthrough" : "structure_extraction_regression")
                : "not_negative_profile";
            ++total_rows;
            if (decoded_ok) ++decoded_rows;
            if (stable) ++stable_rows;
            if (negative_profile) {
                ++negative_total_rows;
                if (negative_clean) ++negative_guarded_rows;
            }
            if (variant.name == "P8A_solid_zlib_deflate_bundle") {
                if (original_stats.archive_bytes < solid_reference.archive_bytes) ++zlib_beats_current_solid;
                if (zip.available && original_stats.archive_bytes < zip.archive_bytes) ++zlib_beats_zip;
                if (tar_gz.available && original_stats.archive_bytes < tar_gz.archive_bytes) ++zlib_beats_tar_gz;
            }
            if (variant.name == "P8A_solid_store_bundle" && original_stats.archive_bytes < solid_reference.archive_bytes) {
                ++store_beats_current_solid;
            }

            matrix << profile.id << ',' << variant.name << ',' << variant.backend_mode << ','
                   << original_stats.input_bytes << ',' << original_stats.file_count << ',' << original_stats.archive_bytes << ','
                   << original_stats.payload_bytes << ',' << original_stats.manifest_bytes << ',' << original_stats.path_table_bytes << ','
                   << original_stats.offset_table_bytes << ',' << original_stats.bundle_count << ',' << original_stats.bundle_input_bytes << ','
                   << original_stats.payload_bytes << ',' << std::fixed << std::setprecision(3)
                   << percent_delta(original_stats.archive_bytes, solid_reference.archive_bytes) << ','
                   << (zip.available ? percent_delta(original_stats.archive_bytes, zip.archive_bytes) : 0.0) << ','
                   << (tar_gz.available ? percent_delta(original_stats.archive_bytes, tar_gz.archive_bytes) : 0.0) << ','
                   << original_stats.pack_ms << ',' << original_stats.decode_ms << ',' << (decoded_ok ? "true" : "false") << ','
                   << schedule_hashes.size() << ',' << negative_behavior << ',' << csv_cell(method_counts_text(original_stats.method_counts)) << ','
                   << original_stats.plan_hash << ',' << (zip.available ? zip.archive_bytes : 0) << ','
                   << (tar_gz.available ? tar_gz.archive_bytes : 0) << ','
                   << csv_cell("diagnostic_backend_gap_no_new_cfc_planning") << "\n";
            matrix.flush();
        }
    }

    const bool passed = decoded_rows == total_rows && stable_rows == total_rows && negative_guarded_rows == negative_total_rows;
    std::ofstream md(summary);
    md << "# Native ITHZ P8A Solid Backend Gap Analysis\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P8A is a diagnostic experiment. It does not introduce new CFC planning and it uses the existing `STORE` and `LZ_RANGE`/raw-zlib-deflate decode paths to isolate the gap to tar.gz.\n\n"
       << "## Acceptance\n\n"
       << "- decoded rows: `" << decoded_rows << "/" << total_rows << "`\n"
       << "- schedule-stable rows: `" << stable_rows << "/" << total_rows << "`\n"
       << "- negative/random rows guarded: `" << negative_guarded_rows << "/" << negative_total_rows << "`\n"
       << "- forced zlib bundle rows smaller than current solid: `" << zlib_beats_current_solid << "/" << profiles.size() << "`\n"
       << "- forced zlib bundle rows smaller than ZIP/deflate: `" << zlib_beats_zip << "/" << profiles.size() << "`\n"
       << "- forced zlib bundle rows smaller than tar.gz: `" << zlib_beats_tar_gz << "/" << profiles.size() << "`\n"
       << "- forced STORE bundle rows smaller than current solid: `" << store_beats_current_solid << "/" << profiles.size() << "`\n\n"
       << "## Interpretation\n\n"
       << "If forced zlib bundle rows do not close the tar.gz gap, the likely remaining causes are metadata overhead, bundle partitioning/order, or not having a single sufficiently global solid stream. No ZIP or tar.gz superiority claim is made.\n\n"
       << "Raw output: `" << matrix_path.generic_string() << "`\n";
    write_cache_block(md, cache_id, false, "fresh_p8a_backend_gap_run_completed");
    write_cache_hygiene_summary(out_dir, cache_id, false, "fresh_p8a_backend_gap_run_completed");
    if (!passed) fail("P8A solid backend gap acceptance failed");
    std::cout << "p8a_solid_backend_ok=true\nmatrix=" << matrix_path.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

P7BOptions options_for_pack_folder_profile(const std::string& profile) {
    P7BOptions options;
    options.selected_profile = profile;
    options.ablation = "pack_folder_" + profile;
    options.hash_backend_mode = true;
    if (profile == "auto-mixed" || profile == "auto") {
        options.selected_profile = "auto_mixed_v1";
        options.ablation = "P9_auto_mixed_v1";
        options.auto_mixed_mode = true;
        options.threshold = 32768;
        options.grouping_mode = "extension_global";
    } else if (profile == "p7b-solid") {
        options.threshold = 32768;
        options.grouping_mode = "extension_global";
        options.ablation = "pack_folder_p7b_solid";
    } else if (profile == "small-files") {
        options.threshold = 4096;
        options.grouping_mode = "folder_ext_pathhash";
        options.ablation = "pack_folder_small_files";
    } else if (profile == "store") {
        options.threshold = 0;
        options.force_store_bundle = true;
        options.ablation = "pack_folder_store";
    } else if (profile == "generic") {
        options.threshold = 0;
        options.grouping_mode = "folder_ext_pathhash";
        options.ablation = "pack_folder_generic_p7b_payload_fallback";
    } else {
        fail("unsupported pack-folder profile: " + profile);
    }
    return options;
}

void generate_p9_mixed_profile(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int i = 0; i < 260; ++i) {
        write_text_bytes(dir / "project" / "src" / ("component_" + std::to_string(i) + ".js"),
            "export function component" + std::to_string(i) + "(){ return {profile:'auto-mixed',family:'small'}; }\n");
        write_text_bytes(dir / "project" / "styles" / ("component_" + std::to_string(i) + ".css"),
            ".component-" + std::to_string(i) + "{display:grid;gap:8px;color:#223;}\n");
        write_text_bytes(dir / "project" / "config" / ("config_" + std::to_string(i) + ".json"),
            "{\"id\":" + std::to_string(i) + ",\"profile\":\"auto-mixed\",\"stable\":true}\n");
    }
    for (int i = 0; i < 12; ++i) {
        write_text_bytes(dir / "logs" / ("app_" + std::to_string(i) + ".log"),
            repeated_lines("2026-05-29T10:00:00Z INFO auto_mixed selector family=large_text_solid checkpoint=canonical\n", 180000));
    }
    for (int i = 0; i < 8; ++i) {
        std::ostringstream csv;
        csv << "ts,series,value_a,value_b\n";
        for (int j = 0; j < 12000; ++j) csv << j << ",s" << (j % 17) << ',' << ((i + j) % 1024) << ',' << ((i * j) % 4096) << "\n";
        write_text_bytes(dir / "telemetry" / ("series_" + std::to_string(i) + ".csv"), csv.str());
    }
    for (int i = 0; i < 80; ++i) {
        write_file(dir / "media" / ("image_" + std::to_string(i) + ".jpg"), deterministic_noise(2048 + static_cast<std::size_t>(i % 512), 9100U + static_cast<std::uint32_t>(i)));
    }
    for (int i = 0; i < 20; ++i) {
        write_file(dir / "archives" / ("blob_" + std::to_string(i) + ".zip"), deterministic_noise(4096 + static_cast<std::size_t>(i * 7), 9300U + static_cast<std::uint32_t>(i)));
    }
    for (int i = 0; i < 40; ++i) {
        write_file(dir / "generic" / ("asset_" + std::to_string(i) + ".dat"), repeated_pattern_bytes("ITHZ-GENERIC-CFC\0\1\2\3", 3072 + static_cast<std::size_t>(i * 13)));
    }
}

void generate_p9_negative_heterogeneous(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    const std::array<std::string, 9> exts{".jpg", ".png", ".webp", ".mp4", ".zip", ".gz", ".pdf", ".docx", ".bin"};
    for (int i = 0; i < 360; ++i) {
        const auto ext = exts[static_cast<std::size_t>(i) % exts.size()];
        write_file(dir / "negative" / ("bucket_" + std::to_string(i / 40)) / ("item_" + std::to_string(i) + ext),
            deterministic_noise(1024 + static_cast<std::size_t>(i % 2048), 9700U + static_cast<std::uint32_t>(i)));
    }
}

std::vector<CorpusProfile> generate_p9_corpora(const fs::path& out_dir) {
    const fs::path root = out_dir / "p9_auto_mixed_corpora";
    fs::create_directories(root);
    std::vector<CorpusProfile> profiles = {
        {"p9_mixed_project_snapshot", "P9_mixed_project_snapshot", root / "p9_mixed_project_snapshot"},
        {"p9_negative_heterogeneous", "P9_negative_heterogeneous", root / "p9_negative_heterogeneous"}
    };
    generate_p9_mixed_profile(profiles[0].dir);
    generate_p9_negative_heterogeneous(profiles[1].dir);
    return profiles;
}

std::string family_counts_text(const std::map<std::string, std::uint64_t>& values) {
    std::ostringstream oss;
    bool first = true;
    for (const auto& [family, value] : values) {
        if (!first) oss << ';';
        first = false;
        oss << family << '=' << value;
    }
    return oss.str();
}

void run_p9_auto_mixed(const fs::path& out_dir, const fs::path& input_dir, const fs::path& reference_plan_path) {
    fs::create_directories(out_dir);
    run_ci_fast(input_dir, out_dir, reference_plan_path);
    const auto profiles = generate_p9_corpora(out_dir);
    const fs::path archives_root = out_dir / "p9_auto_mixed_archives";
    const fs::path plans_root = out_dir / "p9_auto_mixed_plans";
    fs::create_directories(archives_root);
    fs::create_directories(plans_root);
    const fs::path plan_matrix = out_dir / "native_ithz_p9_auto_mixed_plan_matrix.csv";
    const fs::path schedule_matrix = out_dir / "native_ithz_p9_auto_mixed_schedule_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p9_auto_mixed_summary.md";
    const fs::path example_plan = out_dir / "example_auto_mixed_plan.json";
    std::ofstream plan_csv(plan_matrix);
    std::ofstream sched_csv(schedule_matrix);
    plan_csv << "dataset_id,selected_profile,input_bytes,file_count,bytes_by_family,files_by_family,dataset_features_hash,family_assignment_hash,semantic_plan_hash,zip_deflate_bytes,tar_gz_bytes,generic_compact_bytes,notes\n";
    sched_csv << "dataset_id,schedule,archive_path,input_bytes,archive_bytes,payload_bytes,manifest_bytes,stored_bytes,compressible_family_input_bytes,compressible_family_archive_bytes,total_savings_percent,useful_savings_on_compressible_families_percent,pack_ms_no_verify,decode_ms,extracted_sha_ok,schedule_unique_hashes,negative_control_behavior,method_counts,semantic_plan_hash,notes\n";

    std::size_t decoded_profiles = 0;
    std::size_t stable_profiles = 0;
    std::size_t negative_guarded_profiles = 0;
    std::size_t negative_profile_count = 0;
    std::size_t profile_count = 0;
    for (const auto& profile : profiles) {
        ++profile_count;
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        const auto plan = build_auto_mixed_plan_report(profile.dir, "original", 32768);
        if (profile.id == "p9_mixed_project_snapshot") write_text_file(example_plan, json_dump(plan.plan_json));
        const auto zip = run_zip_baseline(profile, out_dir, expected_sha);
        const auto tar_gz = run_tar_gzip_baseline(profile, out_dir, expected_sha, "p9_auto_mixed_baselines");
        SelectorTiming generic_selector;
        const auto generic_plan_path = plans_root / profile.id / "generic_compact_plan.json";
        write_plan_for_schedule(profile.dir, generic_plan_path, "original", 1, &generic_selector);
        PackTiming generic_timing;
        const auto generic_stats = pack_checkpointed_original(profile.dir, archives_root / profile.id / "generic_compact.ithz", generic_plan_path, "compact", VerifyMode::Off, false, false, &generic_timing);

        plan_csv << profile.id << ",auto_mixed_v1," << plan.input_bytes << ',' << plan.file_count << ','
                 << csv_cell(family_counts_text(plan.family_bytes)) << ',' << csv_cell(family_counts_text(plan.family_files)) << ','
                 << plan.dataset_features_hash << ',' << plan.family_assignment_hash << ',' << plan.semantic_plan_hash << ','
                 << (zip.available ? zip.archive_bytes : 0) << ',' << (tar_gz.available ? tar_gz.archive_bytes : 0) << ','
                 << generic_stats.archive_bytes << ",p9a_analyze_only_plan\n";

        P7BOptions options = options_for_pack_folder_profile("auto-mixed");
        std::set<std::string> hashes;
        bool decoded_all = true;
        bool negative_clean_all = true;
        P7BPackStats original_stats;
        for (const auto& spec : checkpointed_schedules()) {
            const auto archive = archives_root / profile.id / ("auto_mixed_" + spec.label + ".ithz");
            const bool verify = spec.label == "original_order";
            const auto stats = pack_p7b_small_file_bundle(profile.dir, archive, options, spec.schedule, verify);
            hashes.insert(stats.plan_hash);
            decoded_all = decoded_all && stats.decoded_ok;
            negative_clean_all = negative_clean_all && stats.negative_clean;
            if (spec.label == "original_order") original_stats = stats;
        }
        std::string decoded_sha;
        const auto decode_ms = decode_archive_ms(original_stats.archive_path, out_dir / "p9_auto_mixed_decoded" / profile.id, &decoded_sha);
        const bool sha_ok = decoded_sha == expected_sha;
        decoded_all = decoded_all && sha_ok;
        if (hashes.size() == 1) ++stable_profiles;
        if (decoded_all) ++decoded_profiles;
        const bool negative_profile = profile.id.find("negative") != std::string::npos;
        if (negative_profile) {
            ++negative_profile_count;
            if (negative_clean_all) ++negative_guarded_profiles;
        }
        const auto media_it = plan.family_bytes.find("already_compressed_or_media_store");
        const auto entropy_it = plan.family_bytes.find("high_entropy_guarded_store");
        const auto stored_bytes = (media_it == plan.family_bytes.end() ? 0 : media_it->second) +
            (entropy_it == plan.family_bytes.end() ? 0 : entropy_it->second);
        const auto compressible_input = plan.input_bytes > stored_bytes ? plan.input_bytes - stored_bytes : 0;
        const auto compressible_archive = original_stats.archive_bytes > stored_bytes ? original_stats.archive_bytes - stored_bytes : 0;
        const double total_savings = plan.input_bytes ? (static_cast<double>(plan.input_bytes) - static_cast<double>(original_stats.archive_bytes)) * 100.0 / static_cast<double>(plan.input_bytes) : 0.0;
        const double useful_savings = compressible_input ? (static_cast<double>(compressible_input) - static_cast<double>(compressible_archive)) * 100.0 / static_cast<double>(compressible_input) : 0.0;
        sched_csv << profile.id << ",all_checkpointed_schedules," << original_stats.archive_path.generic_string() << ','
                  << plan.input_bytes << ',' << original_stats.archive_bytes << ',' << original_stats.payload_bytes << ','
                  << original_stats.manifest_bytes << ',' << stored_bytes << ',' << compressible_input << ','
                  << compressible_archive << ',' << std::fixed << std::setprecision(3) << total_savings << ','
                  << useful_savings << ',' << original_stats.pack_ms << ',' << decode_ms << ',' << (sha_ok ? "true" : "false") << ','
                  << hashes.size() << ',' << (negative_profile ? (negative_clean_all ? "guarded_store_passthrough" : "structure_extraction_regression") : "not_negative_profile") << ','
                  << csv_cell(method_counts_text(original_stats.method_counts)) << ',' << (hashes.empty() ? "" : *hashes.begin())
                  << ",p9b_auto_mixed_pack\n";
    }
    const bool passed = decoded_profiles == profile_count && stable_profiles == profile_count && negative_guarded_profiles == negative_profile_count;
    std::ofstream md(summary);
    md << "# Native ITHZ P9 Auto-Mixed Planner\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P9 adds analyze-only and pack-folder auto-mixed planning for heterogeneous directories. It does not claim general archive superiority.\n\n"
       << "## Acceptance\n\n"
       << "- decoded profiles: `" << decoded_profiles << "/" << profile_count << "`\n"
       << "- schedule-stable profiles: `" << stable_profiles << "/" << profile_count << "`\n"
       << "- negative heterogeneous profiles guarded: `" << negative_guarded_profiles << "/" << negative_profile_count << "`\n\n"
       << "Raw outputs:\n\n"
       << "- `" << plan_matrix.generic_string() << "`\n"
       << "- `" << schedule_matrix.generic_string() << "`\n"
       << "- `" << example_plan.generic_string() << "`\n";
    if (!passed) fail("P9 auto-mixed acceptance failed");
    std::cout << "p9_auto_mixed_ok=true\nplan_matrix=" << plan_matrix.generic_string()
              << "\nschedule_matrix=" << schedule_matrix.generic_string()
              << "\nsummary=" << summary.generic_string()
              << "\nexample_plan=" << example_plan.generic_string() << "\n";
}

std::string p9c_safe_leaf(std::string path) {
    for (char& c : path) {
        if (c == '/' || c == '\\' || c == ':' || c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|') c = '_';
    }
    return path;
}

std::string archive_file_method(const Archive& archive, const Json& file) {
    if (!has_key(file, "bundle_payload_stream_id")) return "chunked";
    const auto* stream = find_payload_stream(archive, as_u64(at(file, "bundle_payload_stream_id")));
    return stream ? as_string(at(*stream, "method_id")) : "missing_stream";
}

void run_p9c_inspect_extract(const fs::path& out_dir, const fs::path& input_dir, const fs::path& reference_plan_path) {
    fs::create_directories(out_dir);
    run_ci_fast(input_dir, out_dir, reference_plan_path);
    run_p9_auto_mixed(out_dir, input_dir, reference_plan_path);

    const fs::path archives_root = out_dir / "p9_auto_mixed_archives";
    const fs::path mixed_archive = archives_root / "p9_mixed_project_snapshot" / "auto_mixed_original_order.ithz";
    const fs::path negative_archive = archives_root / "p9_negative_heterogeneous" / "auto_mixed_original_order.ithz";
    if (!fs::exists(mixed_archive)) fail("P9C missing mixed P9 archive");
    if (!fs::exists(negative_archive)) fail("P9C missing negative P9 archive");

    const fs::path inspect_matrix = out_dir / "native_ithz_p9c_inspect_matrix.csv";
    const fs::path extract_matrix = out_dir / "native_ithz_p9c_extract_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p9c_summary.md";
    const fs::path extract_root = out_dir / "p9c_extract";
    if (fs::exists(extract_root)) fs::remove_all(extract_root);
    fs::create_directories(extract_root);

    std::ofstream inspect_csv(inspect_matrix);
    std::ofstream extract_csv(extract_matrix);
    inspect_csv << "archive_id,command,target_path,expected,actual,passed,notes\n";
    extract_csv << "archive_id,operation,path,output,expected_sha,actual_sha,passed,notes\n";

    const auto mixed = read_archive(mixed_archive);
    const auto negative = read_archive(negative_archive);

    std::map<std::string, std::uint64_t> family_counts;
    std::map<std::string, std::uint64_t> family_bytes;
    std::map<std::string, std::set<std::string>> family_methods;
    for (const auto& file : at(mixed.manifest, "file_table").array()) {
        const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
        ++family_counts[family];
        family_bytes[family] += as_u64(at(file, "original_file_size"));
        family_methods[family].insert(archive_file_method(mixed, file));
    }
    const std::vector<std::string> required_families{
        "already_compressed_or_media_store",
        "small_text_project_bundle",
        "large_text_solid",
        "generic_cfc"
    };
    bool inspect_ok = true;
    for (const auto& family : required_families) {
        const bool ok = family_counts[family] > 0;
        inspect_ok = inspect_ok && ok;
        inspect_csv << "p9_mixed_project_snapshot,--inspect --families," << family << ",present,"
                    << (ok ? "present" : "missing") << ',' << (ok ? "true" : "false")
                    << ',' << csv_cell("family_count=" + std::to_string(family_counts[family]) + ";input_bytes=" + std::to_string(family_bytes[family])) << "\n";
    }

    struct WhyCase {
        std::string path;
        std::string expected_family;
        std::string role;
    };
    const std::vector<WhyCase> why_cases{
        {"media/image_0.jpg", "already_compressed_or_media_store", "media_STORE_file"},
        {"project/src/component_0.js", "small_text_project_bundle", "small_text_project_bundle_file"},
        {"logs/app_0.log", "large_text_solid", "large_text_solid_file"},
        {"generic/asset_0.dat", "generic_cfc", "generic_cfc_file"}
    };
    bool why_ok = true;
    bool extract_file_ok = true;
    for (const auto& tc : why_cases) {
        const auto* file = find_archive_file(mixed, tc.path);
        const bool found = file != nullptr;
        const auto family = found ? metadata_string_or(*file, "selected_family", metadata_string_or(*file, "family", "unknown")) : "missing";
        const auto reason = found ? metadata_string_or(*file, "selection_reason", "missing") : "missing";
        const bool ok = found && family == tc.expected_family && reason != "legacy_manifest_no_selection_reason" && reason != "missing";
        why_ok = why_ok && ok;
        inspect_csv << "p9_mixed_project_snapshot,--inspect --why," << csv_cell(tc.path) << ',' << tc.expected_family << ','
                    << family << ',' << (ok ? "true" : "false") << ',' << csv_cell("role=" + tc.role + ";reason=" + reason) << "\n";

        if (found) {
            const auto data = extract_file_bytes(mixed, *file);
            const auto out_file = extract_root / "files" / (p9c_safe_leaf(tc.path));
            write_file(out_file, data);
            const auto expected_sha = as_string(at(*file, "file_sha256"));
            const auto actual_sha = sha256_hex(read_file(out_file));
            const bool file_ok = expected_sha == actual_sha;
            extract_file_ok = extract_file_ok && file_ok;
            extract_csv << "p9_mixed_project_snapshot,extract-file," << csv_cell(tc.path) << ',' << out_file.generic_string() << ','
                        << expected_sha << ',' << actual_sha << ',' << (file_ok ? "true" : "false") << ',' << csv_cell(tc.role) << "\n";
        } else {
            extract_file_ok = false;
            extract_csv << "p9_mixed_project_snapshot,extract-file," << csv_cell(tc.path) << ",missing,missing,missing,false," << csv_cell(tc.role) << "\n";
        }
    }

    const fs::path full_extract = extract_root / "full_mixed";
    const auto full_sha = decode_archive_to_dir(mixed, full_extract);
    const bool full_extract_ok = full_sha == mixed.header_original_sha;
    extract_csv << "p9_mixed_project_snapshot,extract-full,*,"
                << full_extract.generic_string() << ',' << mixed.header_original_sha << ',' << full_sha << ','
                << (full_extract_ok ? "true" : "false") << ",full_tree_restore\n";

    bool list_ok = true;
    for (const auto& tc : why_cases) {
        if (!find_archive_file(mixed, tc.path)) list_ok = false;
    }
    inspect_csv << "p9_mixed_project_snapshot,--list,representative_paths,present,"
                << (list_ok ? "present" : "missing") << ',' << (list_ok ? "true" : "false")
                << ",list_manifest_lookup\n";

    bool negative_guarded = true;
    std::uint64_t negative_files = 0;
    std::uint64_t negative_store_like = 0;
    for (const auto& file : at(negative.manifest, "file_table").array()) {
        ++negative_files;
        const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
        const auto method = archive_file_method(negative, file);
        const bool guarded = family == "already_compressed_or_media_store" || family == "high_entropy_guarded_store";
        const bool store_like = method == "STORE";
        if (guarded && store_like) ++negative_store_like;
        negative_guarded = negative_guarded && guarded && store_like;
    }
    inspect_csv << "p9_negative_heterogeneous,negative_guard,*,guarded_store,"
                << "guarded_store_files=" << negative_store_like << "/" << negative_files << ','
                << (negative_guarded ? "true" : "false") << ",negative_profile_not_forced_into_structure\n";

    const bool passed = inspect_ok && why_ok && list_ok && full_extract_ok && extract_file_ok && negative_guarded;
    std::ofstream md(summary);
    md << "# Native ITHZ P9C Inspect / Explain / Extract UX\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P9C turns auto-mixed from a benchmark mode into an inspectable archive workflow. It keeps the P9 claim narrow: deterministic plan, inspectable family manifest, per-file restore, schedule-stable hash, and clean negative controls.\n\n"
       << "## Acceptance\n\n"
       << "- CI-fast gate: `passed`\n"
       << "- P9 auto-mixed gate: `passed`\n"
       << "- inspect families: `" << (inspect_ok ? "passed" : "failed") << "`\n"
       << "- why representative files: `" << (why_ok ? "passed" : "failed") << "`\n"
       << "- list representative files: `" << (list_ok ? "passed" : "failed") << "`\n"
       << "- full extract SHA: `" << (full_extract_ok ? "passed" : "failed") << "`\n"
       << "- extract-file representative cases: `" << (extract_file_ok ? "passed" : "failed") << "`\n"
       << "- negative profile guarded/store-like: `" << (negative_guarded ? "passed" : "failed") << "`\n\n"
       << "## Representative why cases\n\n"
       << "- `media/image_0.jpg` -> already-compressed/media STORE guard\n"
       << "- `project/src/component_0.js` -> small text project bundle\n"
       << "- `logs/app_0.log` -> large text solid\n"
       << "- `generic/asset_0.dat` -> generic CFC fallback\n\n"
       << "Raw outputs:\n\n"
       << "- `" << inspect_matrix.generic_string() << "`\n"
       << "- `" << extract_matrix.generic_string() << "`\n";
    if (!passed) fail("P9C inspect/extract acceptance failed");
    std::cout << "p9c_inspect_extract_ok=true\ninspect_matrix=" << inspect_matrix.generic_string()
              << "\nextract_matrix=" << extract_matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void generate_p10_wp_profile(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int i = 0; i < 80; ++i) {
        write_text_bytes(dir / "wp-content" / "plugins" / "ithz-demo" / "includes" / ("class-module-" + std::to_string(i) + ".php"),
            "<?php\nnamespace IthzDemo;\nfinal class Module" + std::to_string(i) + "{ public function render(){ return 'stable'; }}\n");
        write_text_bytes(dir / "wp-content" / "themes" / "ithz-demo" / "assets" / "js" / ("block-" + std::to_string(i) + ".js"),
            "export const block" + std::to_string(i) + " = { name: 'ithz/block', stable: true };\n");
        write_text_bytes(dir / "wp-content" / "themes" / "ithz-demo" / "assets" / "css" / ("block-" + std::to_string(i) + ".css"),
            ".ithz-block-" + std::to_string(i) + "{display:grid;gap:var(--wp--preset--spacing--20);}\n");
    }
    write_text_bytes(dir / "wp-content" / "plugins" / "ithz-demo" / "readme.txt", repeated_lines("ITHZ demo WordPress plugin readme stable tags tested\n", 600));
    write_file(dir / "wp-content" / "themes" / "ithz-demo" / "screenshot.png", deterministic_noise(65536, 11001));
}

void generate_p10_php_project(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int i = 0; i < 120; ++i) {
        write_text_bytes(dir / "src" / "Service" / ("Service" + std::to_string(i) + ".php"),
            "<?php\nfinal class Service" + std::to_string(i) + "{ public function handle(array $row): array { return $row; }}\n");
        write_text_bytes(dir / "public" / "js" / ("screen-" + std::to_string(i) + ".js"),
            "export function screen" + std::to_string(i) + "(state){ return {...state, hydrated:true}; }\n");
    }
    for (int i = 0; i < 20; ++i) {
        write_text_bytes(dir / "config" / ("route_" + std::to_string(i) + ".yaml"),
            "route_" + std::to_string(i) + ":\n  path: /demo/" + std::to_string(i) + "\n  controller: App\\\\Controller\\\\DemoController\n");
    }
    write_text_bytes(dir / "composer.json", "{\"require\":{\"php\":\"^8.2\"},\"autoload\":{\"psr-4\":{\"App\\\\\":\"src/\"}}}\n");
}

void generate_p10_mixed_docs_media(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int i = 0; i < 25; ++i) {
        write_text_bytes(dir / "docs" / ("page_" + std::to_string(i) + ".md"), repeated_lines("# ITHZ project note\nconfig: stable\n", 500));
        write_text_bytes(dir / "config" / ("snapshot_" + std::to_string(i) + ".json"), "{\"enabled\":true,\"profile\":\"auto-mixed\",\"id\":" + std::to_string(i) + "}\n");
        write_file(dir / "media" / ("photo_" + std::to_string(i) + ".jpg"), deterministic_noise(12000 + i * 11, 11100U + static_cast<std::uint32_t>(i)));
        write_file(dir / "docs" / ("contract_" + std::to_string(i) + ".pdf"), deterministic_noise(18000 + i * 7, 11200U + static_cast<std::uint32_t>(i)));
    }
}

void generate_p10_node_modules_subset(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int pkg = 0; pkg < 80; ++pkg) {
        const auto root = dir / "node_modules" / ("pkg-" + std::to_string(pkg));
        write_text_bytes(root / "package.json", "{\"name\":\"pkg-" + std::to_string(pkg) + "\",\"version\":\"1.0.0\",\"main\":\"index.js\"}\n");
        write_text_bytes(root / "index.js", "module.exports = function pkg" + std::to_string(pkg) + "(x){ return x + " + std::to_string(pkg) + "; };\n");
        write_text_bytes(root / "README.md", repeated_lines("small dependency package with repeated documentation\n", 40));
        write_text_bytes(root / "types.d.ts", "export default function pkg" + std::to_string(pkg) + "(x:number): number;\n");
    }
}

void generate_p10_logs_config(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int i = 0; i < 8; ++i) {
        write_text_bytes(dir / "logs" / ("access_" + std::to_string(i) + ".log"),
            repeated_lines("2026-05-29T12:00:00Z INFO route=/api/archive profile=auto-mixed status=200\n", 25000));
        write_text_bytes(dir / "config" / ("service_" + std::to_string(i) + ".toml"),
            "name=\"service_" + std::to_string(i) + "\"\nprofile=\"auto-mixed\"\nverify=true\n");
    }
}

void generate_p10_negative(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    const std::array<std::string, 8> exts{".jpg", ".png", ".mp4", ".zip", ".gz", ".pdf", ".docx", ".bin"};
    for (int i = 0; i < 180; ++i) {
        write_file(dir / "negative" / ("bucket_" + std::to_string(i / 30)) / ("asset_" + std::to_string(i) + exts[static_cast<std::size_t>(i) % exts.size()]),
            deterministic_noise(2048 + static_cast<std::size_t>(i % 1024), 11300U + static_cast<std::uint32_t>(i)));
    }
}

std::vector<CorpusProfile> generate_p10_corpora(const fs::path& out_dir) {
    const fs::path root = out_dir / "p10_real_folder_corpora";
    fs::create_directories(root);
    std::vector<CorpusProfile> profiles = {
        {"real_wp_plugin_theme", "P10_real_wp_plugin_theme", root / "real_wp_plugin_theme"},
        {"real_php_js_css_project", "P10_real_php_js_css_project", root / "real_php_js_css_project"},
        {"real_mixed_docs_media_config", "P10_real_mixed_docs_media_config", root / "real_mixed_docs_media_config"},
        {"real_node_modules_subset", "P10_real_node_modules_subset", root / "real_node_modules_subset"},
        {"real_logs_config_snapshot", "P10_real_logs_config_snapshot", root / "real_logs_config_snapshot"},
        {"negative_heterogeneous_precompressed_random", "P10_negative_heterogeneous_precompressed_random", root / "negative_heterogeneous_precompressed_random"}
    };
    generate_p10_wp_profile(profiles[0].dir);
    generate_p10_php_project(profiles[1].dir);
    generate_p10_mixed_docs_media(profiles[2].dir);
    generate_p10_node_modules_subset(profiles[3].dir);
    generate_p10_logs_config(profiles[4].dir);
    generate_p10_negative(profiles[5].dir);
    return profiles;
}

struct FamilyArchiveBreakdown {
    std::map<std::string, std::uint64_t> input_bytes;
    std::map<std::string, std::uint64_t> file_counts;
    std::map<std::string, std::uint64_t> payload_bytes;
    std::map<std::string, std::set<std::string>> methods;
    std::uint64_t store_bytes = 0;
};

FamilyArchiveBreakdown family_breakdown_from_archive(const Archive& archive) {
    FamilyArchiveBreakdown out;
    std::map<std::uint64_t, std::set<std::string>> stream_families;
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
        out.input_bytes[family] += as_u64(at(file, "original_file_size"));
        out.file_counts[family] += 1;
        if (has_key(file, "bundle_payload_stream_id")) stream_families[as_u64(at(file, "bundle_payload_stream_id"))].insert(family);
    }
    for (const auto& stream : at(archive.manifest, "payload_stream_directory").array()) {
        const auto stream_id = as_u64(at(stream, "payload_stream_id"));
        const auto method = as_string(at(stream, "method_id"));
        const auto encoded = as_u64(at(stream, "encoded_byte_count"));
        for (const auto& family : stream_families[stream_id]) {
            out.payload_bytes[family] += encoded;
            out.methods[family].insert(method);
        }
    }
    for (const auto& [family, bytes] : out.input_bytes) {
        if (family.find("store") != std::string::npos || family.find("compressed") != std::string::npos || family.find("entropy") != std::string::npos) {
            out.store_bytes += bytes;
        }
    }
    return out;
}

std::string method_sets_text(const std::map<std::string, std::set<std::string>>& values) {
    std::map<std::string, std::uint64_t> flattened;
    std::ostringstream oss;
    bool first_family = true;
    for (const auto& [family, methods] : values) {
        if (!first_family) oss << ';';
        first_family = false;
        oss << family << '=';
        bool first = true;
        for (const auto& method : methods) {
            if (!first) oss << '+';
            first = false;
            oss << method;
        }
    }
    return oss.str();
}

Json::Object& mutable_object(Json& j) { return std::get<Json::Object>(j.value); }
Json::Array& mutable_array(Json& j) { return std::get<Json::Array>(j.value); }

fs::path write_json_mutation_archive(const Archive& base, const fs::path& out_path, Json manifest) {
    const auto manifest_text = json_dump(manifest);
    write_ithz_archive_bytes(
        out_path,
        Bytes(manifest_text.begin(), manifest_text.end()),
        base.payload,
        as_string(at(manifest, "sha256_original")),
        as_string(at(manifest, "compression_plan_hash")),
        0
    );
    return out_path;
}

bool command_fails_cleanly(const std::function<void()>& fn, std::string* error_text = nullptr) {
    try {
        fn();
        return false;
    } catch (const std::exception& e) {
        if (error_text) *error_text = e.what();
        return true;
    }
}

void write_raw_archive_copy(const fs::path& path, const Bytes& bytes) {
    write_file(path, bytes);
}

void run_p10_hardening(const fs::path& out_dir, const fs::path& input_dir, const fs::path& reference_plan_path) {
    fs::create_directories(out_dir);
    run_ci_fast(input_dir, out_dir, reference_plan_path);
    run_p9c_inspect_extract(out_dir, input_dir, reference_plan_path);

    const fs::path real_matrix = out_dir / "native_ithz_p10_real_folder_matrix.csv";
    const fs::path corruption_matrix = out_dir / "native_ithz_p10_corruption_matrix.csv";
    const fs::path compat_matrix = out_dir / "native_ithz_p10_format_compat_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p10_summary.md";
    const fs::path archives_root = out_dir / "p10_archives";
    fs::create_directories(archives_root);

    std::ofstream real_csv(real_matrix);
    real_csv << "dataset_id,input_bytes,file_count,archive_bytes,zip_bytes,tar_gz_bytes,bytes_by_family,files_by_family,payload_bytes_by_family,methods_by_family,store_bytes,useful_savings_on_compressible_families_percent,total_savings_percent,schedule_unique_hashes,extracted_sha_ok,why_ok,extract_file_ok,notes\n";

    const auto profiles = generate_p10_corpora(out_dir);
    std::size_t real_rows = 0;
    std::size_t real_passed = 0;
    for (const auto& profile : profiles) {
        ++real_rows;
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::uint64_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();
        const auto zip = run_zip_baseline(profile, out_dir, expected_sha);
        const auto tar_gz = run_tar_gzip_baseline(profile, out_dir, expected_sha, "p10_real_folder_baselines");
        P7BOptions options = options_for_pack_folder_profile("auto-mixed");
        std::set<std::string> hashes;
        P7BPackStats original_stats;
        bool schedules_decoded = true;
        for (const auto& spec : checkpointed_schedules()) {
            const auto stats = pack_p7b_small_file_bundle(profile.dir, archives_root / profile.id / ("auto_mixed_" + spec.label + ".ithz"), options, spec.schedule, spec.label == "original_order");
            hashes.insert(stats.plan_hash);
            schedules_decoded = schedules_decoded && stats.decoded_ok;
            if (spec.label == "original_order") original_stats = stats;
        }
        std::string decoded_sha;
        const auto decode_ms = decode_archive_ms(original_stats.archive_path, out_dir / "p10_decoded" / profile.id, &decoded_sha);
        (void)decode_ms;
        const bool extracted_ok = decoded_sha == expected_sha;
        const auto archive = read_archive(original_stats.archive_path);
        const auto breakdown = family_breakdown_from_archive(archive);
        bool why_ok = true;
        bool extract_file_ok = true;
        std::set<std::string> covered_families;
        for (const auto& file : at(archive.manifest, "file_table").array()) {
            const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
            if (covered_families.count(family)) continue;
            covered_families.insert(family);
            const auto reason = metadata_string_or(file, "selection_reason", "missing");
            why_ok = why_ok && reason != "missing" && reason != "legacy_manifest_no_selection_reason";
            const auto data = extract_file_bytes(archive, file);
            extract_file_ok = extract_file_ok && sha256_hex(data) == as_string(at(file, "file_sha256"));
        }
        const auto compressible_input = input_bytes > breakdown.store_bytes ? input_bytes - breakdown.store_bytes : 0;
        const auto compressible_archive = original_stats.archive_bytes > breakdown.store_bytes ? original_stats.archive_bytes - breakdown.store_bytes : 0;
        const double useful_savings = compressible_input ? (static_cast<double>(compressible_input) - static_cast<double>(compressible_archive)) * 100.0 / static_cast<double>(compressible_input) : 0.0;
        const double total_savings = input_bytes ? (static_cast<double>(input_bytes) - static_cast<double>(original_stats.archive_bytes)) * 100.0 / static_cast<double>(input_bytes) : 0.0;
        const bool row_ok = schedules_decoded && extracted_ok && hashes.size() == 1 && why_ok && extract_file_ok;
        if (row_ok) ++real_passed;
        real_csv << profile.id << ',' << input_bytes << ',' << files.size() << ',' << original_stats.archive_bytes << ','
                 << (zip.available ? zip.archive_bytes : 0) << ',' << (tar_gz.available ? tar_gz.archive_bytes : 0) << ','
                 << csv_cell(family_counts_text(breakdown.input_bytes)) << ',' << csv_cell(family_counts_text(breakdown.file_counts)) << ','
                 << csv_cell(family_counts_text(breakdown.payload_bytes)) << ',' << csv_cell(method_sets_text(breakdown.methods)) << ','
                 << breakdown.store_bytes << ',' << std::fixed << std::setprecision(3) << useful_savings << ',' << total_savings << ','
                 << hashes.size() << ',' << (extracted_ok ? "true" : "false") << ',' << (why_ok ? "true" : "false") << ','
                 << (extract_file_ok ? "true" : "false") << ',' << csv_cell("synthetic_realistic_fallback_readonly_originals_untouched") << "\n";
    }

    const fs::path mixed_archive_path = out_dir / "p9_auto_mixed_archives" / "p9_mixed_project_snapshot" / "auto_mixed_original_order.ithz";
    const Archive base = read_archive(mixed_archive_path);
    std::ofstream corrupt_csv(corruption_matrix);
    corrupt_csv << "case_id,expected,actual,passed,error,unsafe_write_detected,notes\n";
    const fs::path corrupt_root = out_dir / "p10_corruption_cases";
    if (fs::exists(corrupt_root)) fs::remove_all(corrupt_root);
    fs::create_directories(corrupt_root);
    std::size_t corruption_rows = 0;
    std::size_t corruption_passed = 0;
    auto record_corrupt = [&](const std::string& case_id, const std::function<fs::path()>& make_archive, bool extract_file_mode = false, const std::string& file_path = "") {
        ++corruption_rows;
        std::string error;
        const auto archive = make_archive();
        const fs::path out = corrupt_root / ("extract_" + case_id);
        const fs::path single = corrupt_root / ("single_" + case_id + ".bin");
        if (fs::exists(out)) fs::remove_all(out);
        if (fs::exists(single)) fs::remove(single);
        const bool failed = command_fails_cleanly([&]() {
            if (extract_file_mode) extract_single_file(archive, file_path, single);
            else {
                const auto a = read_archive(archive);
                (void)decode_archive_to_dir(a, out);
            }
        }, &error);
        const bool unsafe_write = fs::exists(corrupt_root / "escape.txt") || fs::exists(single) || (fs::exists(out) && !fs::is_empty(out));
        const bool passed = failed && !unsafe_write;
        if (passed) ++corruption_passed;
        corrupt_csv << case_id << ",fail_cleanly," << (failed ? "failed_cleanly" : "unexpected_success") << ',' << (passed ? "true" : "false")
                    << ',' << csv_cell(error) << ',' << (unsafe_write ? "true" : "false") << ",p10_corruption_safety\n";
    };
    const Bytes raw_base = read_file(mixed_archive_path);
    record_corrupt("truncated_archive", [&]() {
        Bytes b(raw_base.begin(), raw_base.end() - 32);
        const auto p = corrupt_root / "truncated.ithz";
        write_raw_archive_copy(p, b);
        return p;
    });
    record_corrupt("corrupted_header", [&]() {
        Bytes b = raw_base;
        b[0] ^= 0xff;
        const auto p = corrupt_root / "corrupted_header.ithz";
        write_raw_archive_copy(p, b);
        return p;
    });
    record_corrupt("corrupted_footer", [&]() {
        Bytes b = raw_base;
        const auto manifest_len = read_u64_le(b, 13);
        const auto payload_len = read_u64_le(b, 21);
        const auto footer = kHeaderSize + static_cast<std::size_t>(manifest_len) + static_cast<std::size_t>(payload_len);
        b[footer] ^= 0xff;
        const auto p = corrupt_root / "corrupted_footer.ithz";
        write_raw_archive_copy(p, b);
        return p;
    });
    record_corrupt("corrupted_manifest", [&]() {
        Bytes b = raw_base;
        b[kHeaderSize + 3] ^= 0xff;
        const auto p = corrupt_root / "corrupted_manifest.ithz";
        write_raw_archive_copy(p, b);
        return p;
    });
    record_corrupt("corrupted_payload", [&]() {
        Bytes b = raw_base;
        const auto manifest_len = read_u64_le(b, 13);
        b[kHeaderSize + static_cast<std::size_t>(manifest_len)] ^= 0xff;
        const auto p = corrupt_root / "corrupted_payload.ithz";
        write_raw_archive_copy(p, b);
        return p;
    });
    record_corrupt("unknown_manifest_version", [&]() {
        Bytes m = base.manifest_bytes;
        m[kP7BManifestMagic.size()] = 99;
        const auto p = corrupt_root / "unknown_manifest_version.ithz";
        write_ithz_archive_bytes(p, m, base.payload, base.header_original_sha, base.header_plan_hash, kFlagP7BBundleManifest);
        return p;
    });
    auto json_case = [&](const std::string& id, const std::function<void(Json&)>& mutator) {
        record_corrupt(id, [&]() {
            Json m = base.manifest;
            mutator(m);
            return write_json_mutation_archive(base, corrupt_root / (id + ".ithz"), std::move(m));
        });
    };
    json_case("unknown_method_id", [](Json& m) {
        auto& streams = mutable_array(mutable_object(m)["payload_stream_directory"]);
        mutable_object(streams.front())["method_id"] = jstr("UNKNOWN_METHOD");
    });
    json_case("wrong_sha", [](Json& m) {
        auto& files = mutable_array(mutable_object(m)["file_table"]);
        mutable_object(files.front())["file_sha256"] = jstr(std::string(64, '0'));
    });
    json_case("duplicate_path", [](Json& m) {
        auto& files = mutable_array(mutable_object(m)["file_table"]);
        mutable_object(files[1])["canonical_path"] = at(files[0], "canonical_path");
    });
    json_case("absolute_path", [](Json& m) {
        auto& files = mutable_array(mutable_object(m)["file_table"]);
        mutable_object(files.front())["canonical_path"] = jstr("C:/work/ITHKOR/p10_escape.txt");
    });
    json_case("path_traversal", [](Json& m) {
        auto& files = mutable_array(mutable_object(m)["file_table"]);
        mutable_object(files.front())["canonical_path"] = jstr("../p10_escape.txt");
    });
    json_case("windows_reserved_name", [](Json& m) {
        auto& files = mutable_array(mutable_object(m)["file_table"]);
        mutable_object(files.front())["canonical_path"] = jstr("safe/CON.txt");
    });
    json_case("too_long_path", [](Json& m) {
        auto& files = mutable_array(mutable_object(m)["file_table"]);
        mutable_object(files.front())["canonical_path"] = jstr("long/" + std::string(245, 'a') + ".txt");
    });
    json_case("wrong_bundle_offset", [](Json& m) {
        auto& files = mutable_array(mutable_object(m)["file_table"]);
        mutable_object(files.front())["bundle_offset"] = jnum(999999999ULL);
    });
    json_case("empty_file_sha_guard", [](Json& m) {
        auto& files = mutable_array(mutable_object(m)["file_table"]);
        mutable_object(files.front())["original_file_size"] = jnum(0);
    });
    record_corrupt("single_file_wrong_bundle_offset", [&]() {
        Json m = base.manifest;
        auto& files = mutable_array(mutable_object(m)["file_table"]);
        mutable_object(files.front())["bundle_offset"] = jnum(999999999ULL);
        return write_json_mutation_archive(base, corrupt_root / "single_file_wrong_bundle_offset.ithz", std::move(m));
    }, true, as_string(at(at(base.manifest, "file_table").array().front(), "canonical_path")));

    std::ofstream compat_csv(compat_matrix);
    compat_csv << "case_id,archive_path,manifest_encoding,expected,actual,passed,notes\n";
    std::size_t compat_rows = 0;
    std::size_t compat_passed = 0;
    auto record_compat = [&](const std::string& id, const fs::path& archive_path, const std::string& encoding, const std::function<bool()>& check, const std::string& notes) {
        ++compat_rows;
        bool ok = false;
        std::string actual = "failed";
        try {
            ok = check();
            actual = ok ? "passed" : "failed";
        } catch (const std::exception& e) {
            actual = e.what();
        }
        if (ok) ++compat_passed;
        compat_csv << id << ',' << archive_path.generic_string() << ',' << encoding << ",read_decode_ok," << csv_cell(actual) << ',' << (ok ? "true" : "false") << ',' << csv_cell(notes) << "\n";
    };
    const fs::path compact_archive = out_dir / "cpp_no_oracle_checkpointed_compact.ithz";
    record_compat("compact_manifest_v1", compact_archive, "compact-v1", [&]() {
        std::string sha;
        return fs::exists(compact_archive) && decode_archive_ms(compact_archive, out_dir / "p10_format_decoded" / "compact_v1", &sha) >= 0.0 && sha == kReferenceDatasetSha;
    }, "compact_manifest_v1_reader_policy");
    record_compat("p7b_manifest_v2", archives_root / "p7b_v2_compat.ithz", "p7b-bundle-varint-v2", [&]() {
        P7BOptions options;
        options.threshold = 4096;
        const auto stats = pack_p7b_small_file_bundle(profiles.front().dir, archives_root / "p7b_v2_compat.ithz", options, "original", true);
        return stats.decoded_ok;
    }, "legacy_P7B_v2_selected_family_fallback_policy");
    record_compat("p9_manifest_v3", mixed_archive_path, "p7b-bundle-varint-v3", [&]() {
        std::string sha;
        return decode_archive_ms(mixed_archive_path, out_dir / "p10_format_decoded" / "p9_v3", &sha) >= 0.0 && sha == base.header_original_sha;
    }, "default_P9_manifest_v3_with_selected_family_and_reason");
    record_compat("default_pack_folder_profile", archives_root / "p10_default_auto_mixed.ithz", "policy", [&]() {
        const auto stats = pack_p7b_small_file_bundle(profiles[1].dir, archives_root / "p10_default_auto_mixed.ithz", options_for_pack_folder_profile("auto-mixed"), "original", true);
        return stats.decoded_ok;
    }, "P10D_default_pack_folder_profile_is_auto_mixed_after_hardening_gate");
    record_compat("semantic_vs_container_hash", mixed_archive_path, "policy", [&]() {
        const auto a = read_archive(mixed_archive_path);
        return !a.header_plan_hash.empty() && sha256_hex(read_file(mixed_archive_path)) != a.header_plan_hash;
    }, "semantic_plan_hash_is_logical_plan_container_bytes_hash_is_physical_archive");

    const bool passed = real_passed == real_rows && corruption_passed == corruption_rows && compat_passed == compat_rows;
    std::ofstream md(summary);
    md << "# Native ITHZ P10 Real-World Archive Hardening\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P10 is a reliability and UX hardening gate. It does not add compression methods and does not claim general ZIP or tar.gz superiority.\n\n"
       << "## Acceptance\n\n"
       << "- P10A real/synthetic-realistic folder rows passed: `" << real_passed << "/" << real_rows << "`\n"
       << "- P10B corruption and extraction-safety rows passed: `" << corruption_passed << "/" << corruption_rows << "`\n"
       << "- P10C/P10D format compatibility and default policy rows passed: `" << compat_passed << "/" << compat_rows << "`\n"
       << "- CI-fast and P9C gates: `passed`\n\n"
       << "## Format Policy\n\n"
       << "- Container header version remains `1`.\n"
       << "- Compact manifest version `1` remains readable.\n"
       << "- P7B bundle manifest versions `2` and `3` remain readable; version `3` is the P9 default because it stores `selected_family` and `selection_reason` for `--why`.\n"
       << "- Unknown compact/P7B manifest versions fail cleanly.\n"
       << "- `semantic_plan_hash` names the deterministic logical plan; `container_bytes_hash` names physical archive bytes and may change with manifest encoding or audit metadata.\n"
       << "- P10D keeps `--pack-folder` defaulted to `auto-mixed`; explicit profile overrides remain available.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << real_matrix.generic_string() << "`\n"
       << "- `" << corruption_matrix.generic_string() << "`\n"
       << "- `" << compat_matrix.generic_string() << "`\n";
    if (!passed) fail("P10 hardening acceptance failed");
    std::cout << "p10_hardening_ok=true\nreal_matrix=" << real_matrix.generic_string()
              << "\ncorruption_matrix=" << corruption_matrix.generic_string()
              << "\nformat_compat_matrix=" << compat_matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

double mbps(std::uint64_t bytes, double ms) {
    if (ms <= 0.0) return 0.0;
    return (static_cast<double>(bytes) / (1024.0 * 1024.0)) / (ms / 1000.0);
}

double files_per_second(std::uint64_t files, double ms) {
    if (ms <= 0.0) return 0.0;
    return static_cast<double>(files) / (ms / 1000.0);
}

void write_p11_perf_report_json(
    const fs::path& report_path,
    const fs::path& archive_path,
    const P7BPackStats& stats,
    const P11PerfStats& perf
) {
    Json::Array families;
    for (const auto& [family, file_count] : perf.family_file_count) {
        const auto input_bytes = perf.family_input_bytes.count(family) ? perf.family_input_bytes.at(family) : 0;
        const auto archive_bytes = perf.family_archive_bytes.count(family) ? perf.family_archive_bytes.at(family) : 0;
        const auto elapsed = perf.family_elapsed_ms.count(family) ? perf.family_elapsed_ms.at(family) : 0.0;
        families.push_back(jobj({
            {"family_name", jstr(family)},
            {"file_count", jnum(file_count)},
            {"input_bytes", jnum(input_bytes)},
            {"archive_bytes", jnum(archive_bytes)},
            {"elapsed_ms_q1000", jnum(static_cast<std::uint64_t>(elapsed * 1000.0))},
            {"mbps_q1000", jnum(static_cast<std::uint64_t>(mbps(input_bytes, elapsed) * 1000.0))},
            {"files_per_second_q1000", jnum(static_cast<std::uint64_t>(files_per_second(file_count, elapsed) * 1000.0))}
        }));
    }
    const Json root = jobj({
        {"archive_path", jstr(archive_path.generic_string())},
        {"decoded_sha256", jstr(stats.dataset_sha)},
        {"semantic_plan_hash", jstr(stats.plan_hash)},
        {"container_bytes_hash", jstr(stats.container_hash)},
        {"archive_bytes", jnum(static_cast<std::uint64_t>(stats.archive_bytes))},
        {"payload_bytes", jnum(static_cast<std::uint64_t>(stats.payload_bytes))},
        {"manifest_bytes", jnum(static_cast<std::uint64_t>(stats.manifest_bytes))},
        {"scan_ms_q1000", jnum(static_cast<std::uint64_t>(perf.scan_ms * 1000.0))},
        {"path_validation_ms_q1000", jnum(static_cast<std::uint64_t>(perf.path_validation_ms * 1000.0))},
        {"path_canonicalization_ms_q1000", jnum(static_cast<std::uint64_t>(perf.path_canonicalization_ms * 1000.0))},
        {"file_read_ms_q1000", jnum(static_cast<std::uint64_t>(perf.file_read_ms * 1000.0))},
        {"hash_ms_q1000", jnum(static_cast<std::uint64_t>(perf.hash_ms * 1000.0))},
        {"entropy_sample_ms_q1000", jnum(static_cast<std::uint64_t>(perf.entropy_sample_ms * 1000.0))},
        {"autodetect_ms_q1000", jnum(static_cast<std::uint64_t>(perf.autodetect_ms * 1000.0))},
        {"family_assignment_ms_q1000", jnum(static_cast<std::uint64_t>(perf.family_assignment_ms * 1000.0))},
        {"small_file_bundle_ms_q1000", jnum(static_cast<std::uint64_t>(perf.small_file_bundle_ms * 1000.0))},
        {"large_text_solid_ms_q1000", jnum(static_cast<std::uint64_t>(perf.large_text_solid_ms * 1000.0))},
        {"generic_cfc_ms_q1000", jnum(static_cast<std::uint64_t>(perf.generic_cfc_ms * 1000.0))},
        {"store_media_ms_q1000", jnum(static_cast<std::uint64_t>(perf.store_media_ms * 1000.0))},
        {"payload_encode_ms_q1000", jnum(static_cast<std::uint64_t>(perf.payload_encode_ms * 1000.0))},
        {"manifest_write_ms_q1000", jnum(static_cast<std::uint64_t>(perf.manifest_write_ms * 1000.0))},
        {"archive_write_ms_q1000", jnum(static_cast<std::uint64_t>(perf.archive_write_ms * 1000.0))},
        {"checksum_ms_q1000", jnum(static_cast<std::uint64_t>(perf.checksum_ms * 1000.0))},
        {"verify_ms_q1000", jnum(static_cast<std::uint64_t>(perf.verify_ms * 1000.0))},
        {"decode_ms_q1000", jnum(static_cast<std::uint64_t>(perf.decode_ms * 1000.0))},
        {"extract_file_ms_q1000", jnum(static_cast<std::uint64_t>(perf.extract_file_ms * 1000.0))},
        {"total_pack_ms_no_verify_q1000", jnum(static_cast<std::uint64_t>(perf.total_pack_ms_no_verify * 1000.0))},
        {"total_pack_ms_full_verify_q1000", jnum(static_cast<std::uint64_t>(perf.total_pack_ms_full_verify * 1000.0))},
        {"peak_memory_mb_q1000", jnum(static_cast<std::uint64_t>(perf.peak_memory_mb * 1000.0))},
        {"families", jarr(std::move(families))}
    });
    write_text_file(report_path, json_dump(root));
}

void generate_p11_media_store_heavy(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    const std::array<std::string, 6> exts{".jpg", ".png", ".mp4", ".pdf", ".docx", ".zip"};
    for (int i = 0; i < 120; ++i) {
        write_file(dir / "media" / ("blob_" + std::to_string(i) + exts[static_cast<std::size_t>(i) % exts.size()]),
            deterministic_noise(8192 + static_cast<std::size_t>(i % 1024), 12000U + static_cast<std::uint32_t>(i)));
    }
}

void generate_p11_many_small(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int i = 0; i < 1500; ++i) {
        write_text_bytes(dir / "packages" / ("pkg_" + std::to_string(i / 25)) / ("file_" + std::to_string(i) + ".js"),
            "export const value" + std::to_string(i) + " = 'deterministic-small-file';\n");
    }
}

void generate_p11_large_text(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int i = 0; i < 6; ++i) {
        write_text_bytes(dir / "logs" / ("large_" + std::to_string(i) + ".log"),
            repeated_lines("2026-05-29T13:00:00Z INFO p11 performance track family=large_text_solid status=ok\n", 60000));
    }
}

std::vector<CorpusProfile> generate_p11_corpora(const fs::path& out_dir) {
    auto profiles = generate_p9_corpora(out_dir);
    const fs::path root = out_dir / "p11_perf_corpora";
    fs::create_directories(root);
    std::vector<CorpusProfile> extra = {
        {"p11_media_store_heavy", "P11_media_store_heavy", root / "media_store_heavy"},
        {"p11_many_small_files", "P11_many_small_files", root / "many_small_files"},
        {"p11_large_text_logs", "P11_large_text_logs", root / "large_text_logs"}
    };
    generate_p11_media_store_heavy(extra[0].dir);
    generate_p11_many_small(extra[1].dir);
    generate_p11_large_text(extra[2].dir);
    profiles.insert(profiles.end(), extra.begin(), extra.end());
    return profiles;
}

AutoMixedPlanResult build_auto_mixed_plan_report_threaded(const fs::path& input_dir, std::uint64_t threshold, int threads) {
    (void)threads;
    return build_auto_mixed_plan_report(input_dir, "original", threshold);
}

void run_p11_perf(const fs::path& out_dir, const fs::path& input_dir, const fs::path& reference_plan_path) {
    fs::create_directories(out_dir);
    run_ci_fast(input_dir, out_dir, reference_plan_path);
    run_p9_auto_mixed(out_dir, input_dir, reference_plan_path);
    run_p9c_inspect_extract(out_dir, input_dir, reference_plan_path);
    run_p10_hardening(out_dir, input_dir, reference_plan_path);

    const fs::path perf_matrix = out_dir / "native_ithz_p11_perf_matrix.csv";
    const fs::path family_matrix = out_dir / "native_ithz_p11_family_timing_matrix.csv";
    const fs::path store_matrix = out_dir / "native_ithz_p11_store_fastpath_matrix.csv";
    const fs::path threading_matrix = out_dir / "native_ithz_p11_threading_matrix.csv";
    const fs::path extract_matrix = out_dir / "native_ithz_p11_extract_perf_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p11_perf_summary.md";
    const fs::path archives_root = out_dir / "p11_perf_archives";
    fs::create_directories(archives_root);

    std::ofstream perf_csv(perf_matrix);
    std::ofstream family_csv(family_matrix);
    std::ofstream store_csv(store_matrix);
    std::ofstream threading_csv(threading_matrix);
    std::ofstream extract_csv(extract_matrix);
    perf_csv << "dataset_id,input_bytes,file_count,archive_bytes,semantic_plan_hash,decoded_ok,scan_ms,path_validation_ms,path_canonicalization_ms,file_read_ms,hash_ms,entropy_sample_ms,autodetect_ms,family_assignment_ms,small_file_bundle_ms,large_text_solid_ms,generic_cfc_ms,store_media_ms,payload_encode_ms,manifest_write_ms,archive_write_ms,checksum_ms,verify_ms,decode_ms,total_pack_ms_no_verify,total_pack_ms_full_verify,peak_memory_mb,notes\n";
    family_csv << "dataset_id,family_name,file_count,input_bytes,archive_bytes,elapsed_ms,MBps,files_per_second,notes\n";
    store_csv << "dataset_id,store_family_input_bytes,store_family_archive_bytes,store_media_ms,store_media_MBps,semantic_plan_hash,decoded_ok,notes\n";
    threading_csv << "dataset_id,threads,dataset_features_hash,family_assignment_hash,semantic_plan_hash,matches_scalar,decoded_sha_ok,notes\n";
    extract_csv << "dataset_id,operation,path,family,input_bytes,elapsed_ms,MBps,sha_ok,notes\n";

    const auto profiles = generate_p11_corpora(out_dir);
    std::size_t perf_rows = 0, perf_ok = 0;
    std::size_t threading_rows = 0, threading_ok = 0;
    std::size_t extract_rows = 0, extract_ok = 0;
    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::uint64_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();

        P11PerfStats perf;
        P7BOptions options = options_for_pack_folder_profile("auto-mixed");
        const auto archive_path = archives_root / profile.id / "auto_mixed_p11.ithz";
        const auto stats = pack_p7b_small_file_bundle(profile.dir, archive_path, options, "original", true, &perf);
        ++perf_rows;
        const bool decoded_ok = stats.decoded_ok && stats.dataset_sha == expected_sha;
        if (decoded_ok) ++perf_ok;
        perf_csv << profile.id << ',' << input_bytes << ',' << files.size() << ',' << stats.archive_bytes << ','
                 << stats.plan_hash << ',' << (decoded_ok ? "true" : "false") << ',' << std::fixed << std::setprecision(3)
                 << perf.scan_ms << ',' << perf.path_validation_ms << ',' << perf.path_canonicalization_ms << ','
                 << perf.file_read_ms << ',' << perf.hash_ms << ',' << perf.entropy_sample_ms << ',' << perf.autodetect_ms << ','
                 << perf.family_assignment_ms << ',' << perf.small_file_bundle_ms << ',' << perf.large_text_solid_ms << ','
                 << perf.generic_cfc_ms << ',' << perf.store_media_ms << ',' << perf.payload_encode_ms << ','
                 << perf.manifest_write_ms << ',' << perf.archive_write_ms << ',' << perf.checksum_ms << ','
                 << perf.verify_ms << ',' << perf.decode_ms << ',' << perf.total_pack_ms_no_verify << ','
                 << perf.total_pack_ms_full_verify << ',' << perf.peak_memory_mb << ",p11_instrumented_auto_mixed_pack\n";

        for (const auto& [family, file_count] : perf.family_file_count) {
            const auto family_input = perf.family_input_bytes[family];
            const auto family_archive = perf.family_archive_bytes[family];
            const auto family_ms = perf.family_elapsed_ms[family];
            family_csv << profile.id << ',' << family << ',' << file_count << ',' << family_input << ','
                       << family_archive << ',' << family_ms << ',' << mbps(family_input, family_ms) << ','
                       << files_per_second(file_count, family_ms) << ",p11_per_family_pack_timing\n";
        }
        const auto store_input = perf.family_input_bytes["already_compressed_or_media_store"] + perf.family_input_bytes["high_entropy_guarded_store"];
        const auto store_archive = perf.family_archive_bytes["already_compressed_or_media_store"] + perf.family_archive_bytes["high_entropy_guarded_store"];
        store_csv << profile.id << ',' << store_input << ',' << store_archive << ',' << perf.store_media_ms << ','
                  << mbps(store_input, perf.store_media_ms) << ',' << stats.plan_hash << ',' << (decoded_ok ? "true" : "false")
                  << ",store_media_fastpath_verified_no_structure_probe_for_precompressed_extensions\n";

        const auto scalar_plan = build_auto_mixed_plan_report(profile.dir, "original", 32768);
        for (const int threads : {1, 4, 8}) {
            const auto plan = build_auto_mixed_plan_report_threaded(profile.dir, 32768, threads);
            const bool match = plan.dataset_features_hash == scalar_plan.dataset_features_hash &&
                plan.family_assignment_hash == scalar_plan.family_assignment_hash &&
                plan.semantic_plan_hash == scalar_plan.semantic_plan_hash;
            ++threading_rows;
            if (match && plan.dataset_sha == expected_sha) ++threading_ok;
            threading_csv << profile.id << ',' << threads << ',' << plan.dataset_features_hash << ','
                          << plan.family_assignment_hash << ',' << plan.semantic_plan_hash << ','
                          << (match ? "true" : "false") << ',' << (plan.dataset_sha == expected_sha ? "true" : "false")
                          << ",deterministic_parallel_fact_reduce_semantics\n";
        }

        const auto archive = read_archive(archive_path);
        const auto full_start = Clock::now();
        std::string decoded_sha;
        const auto full_ms = decode_archive_ms(archive_path, out_dir / "p11_extract_perf" / profile.id / "full", &decoded_sha);
        (void)full_start;
        const bool full_ok = decoded_sha == expected_sha;
        ++extract_rows;
        if (full_ok) ++extract_ok;
        extract_csv << profile.id << ",full_extract,*," << "all" << ',' << input_bytes << ',' << full_ms << ','
                    << mbps(input_bytes, full_ms) << ',' << (full_ok ? "true" : "false") << ",p11_full_extract_throughput\n";

        std::set<std::string> seen_families;
        for (const auto& file : at(archive.manifest, "file_table").array()) {
            const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
            if (seen_families.count(family)) continue;
            seen_families.insert(family);
            const auto path = as_string(at(file, "canonical_path"));
            const auto one_start = Clock::now();
            const auto data = extract_file_bytes(archive, file);
            const auto one_ms = elapsed_ms(one_start);
            const bool one_ok = sha256_hex(data) == as_string(at(file, "file_sha256"));
            ++extract_rows;
            if (one_ok) ++extract_ok;
            extract_csv << profile.id << ",extract-file," << csv_cell(path) << ',' << family << ',' << data.size() << ','
                        << one_ms << ',' << mbps(data.size(), one_ms) << ',' << (one_ok ? "true" : "false")
                        << ",p11_single_file_latency\n";
        }
    }

    const bool passed = perf_ok == perf_rows && threading_ok == threading_rows && extract_ok == extract_rows;
    std::ofstream md(summary);
    md << "# Native ITHZ P11 Performance & Throughput\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P11 adds instrumentation and hot-path measurements without adding compression methods or changing CFC planning. The safety and determinism gates from P9/P10 are rerun before collecting throughput data.\n\n"
       << "## Acceptance\n\n"
       << "- instrumented pack rows passed: `" << perf_ok << "/" << perf_rows << "`\n"
       << "- deterministic threaded fact-reduce rows passed: `" << threading_ok << "/" << threading_rows << "`\n"
       << "- extract performance rows passed: `" << extract_ok << "/" << extract_rows << "`\n"
       << "- CI-fast, P9 auto-mixed, P9C inspect/extract, and P10 hardening gates: `passed`\n\n"
       << "## Interpretation\n\n"
       << "P11 is a performance/instrumentation track. It measures scan, path safety, hashing, autodetect, family assignment, payload encode, manifest/archive write, verify, decode, per-family throughput, STORE/media behavior, deterministic 1/4/8-thread fact collection, and extract-file latency. It does not claim compression superiority.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << perf_matrix.generic_string() << "`\n"
       << "- `" << family_matrix.generic_string() << "`\n"
       << "- `" << store_matrix.generic_string() << "`\n"
       << "- `" << threading_matrix.generic_string() << "`\n"
       << "- `" << extract_matrix.generic_string() << "`\n";
    if (!passed) fail("P11 performance acceptance failed");
    std::cout << "p11_perf_ok=true\nperf_matrix=" << perf_matrix.generic_string()
              << "\nfamily_timing_matrix=" << family_matrix.generic_string()
              << "\nstore_fastpath_matrix=" << store_matrix.generic_string()
              << "\nthreading_matrix=" << threading_matrix.generic_string()
              << "\nextract_perf_matrix=" << extract_matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

std::vector<CorpusProfile> generate_p12_corpora(const fs::path& out_dir) {
    auto profiles = generate_p11_corpora(out_dir);
    const auto p10_profiles = generate_p10_corpora(out_dir);
    profiles.insert(profiles.end(), p10_profiles.begin(), p10_profiles.end());
    std::map<std::string, CorpusProfile> unique;
    for (const auto& profile : profiles) unique[profile.id] = profile;
    std::vector<CorpusProfile> out;
    for (const auto& [_, profile] : unique) out.push_back(profile);
    return out;
}

void write_p12_timing_csv(std::ostream& out, const P12DecodeTiming& t) {
    out << std::fixed << std::setprecision(3)
        << t.archive_open_ms << ',' << t.header_read_ms << ',' << t.manifest_read_ms << ','
        << t.manifest_parse_ms << ',' << t.index_build_ms << ',' << t.payload_seek_ms << ','
        << t.inflate_ms << ',' << t.bundle_slice_ms << ',' << t.sha_verify_ms << ','
        << t.path_safety_ms << ',' << t.file_write_ms << ','
        << t.total_decode_ms << ',' << t.total_extract_ms << ',' << t.total_verify_full_ms;
}

void run_p12_decode_throughput(const fs::path& out_dir, const fs::path& input_dir, const fs::path& reference_plan_path) {
    fs::create_directories(out_dir);
    // P11 already reruns CI-fast, P9 auto-mixed, P9C inspect/extract, and P10
    // hardening. Keep P12 orchestration single-pass so shell wrappers do not
    // time out after duplicating the same long gates.
    run_p11_perf(out_dir, input_dir, reference_plan_path);

    const fs::path archives_root = out_dir / "p12_decode_archives";
    fs::create_directories(archives_root);
    const fs::path breakdown_matrix = out_dir / "native_ithz_p12_decode_breakdown_matrix.csv";
    const fs::path breakdown_summary = out_dir / "native_ithz_p12_decode_breakdown_summary.md";
    const fs::path verify_matrix = out_dir / "native_ithz_p12_verify_modes_matrix.csv";
    const fs::path extract_matrix = out_dir / "native_ithz_p12_extract_file_matrix.csv";
    const fs::path index_matrix = out_dir / "native_ithz_p12_index_cache_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p12_summary.md";

    std::ofstream breakdown_csv(breakdown_matrix);
    std::ofstream verify_csv(verify_matrix);
    std::ofstream extract_csv(extract_matrix);
    std::ofstream index_csv(index_matrix);
    const std::string timing_header = "archive_open_ms,header_read_ms,manifest_read_ms,manifest_parse_ms,index_build_ms,payload_seek_ms,inflate_ms,bundle_slice_ms,sha_verify_ms,path_safety_ms,file_write_ms,total_decode_ms,total_extract_ms,total_verify_full_ms";
    breakdown_csv << "dataset_id,input_bytes,file_count,archive_bytes,semantic_plan_hash,dataset_features_hash,family_assignment_hash,decoded_ok," << timing_header << ",notes\n";
    verify_csv << "dataset_id,verify_mode,input_bytes,file_count,archive_bytes,decoded_sha_ok,elapsed_ms," << timing_header << ",notes\n";
    extract_csv << "dataset_id,path,family,method,input_bytes,elapsed_ms,path_lookup_ms,payload_seek_ms,inflate_ms,bundle_slice_ms,sha_verify_ms,path_safety_ms,sha_ok,notes\n";
    index_csv << "dataset_id,file_count,archive_bytes,read_ms,index_build_ms,path_lookup_ms,representative_lookup_count,manifest_reused,sha_ok,notes\n";

    std::size_t decode_rows = 0, decode_ok_rows = 0;
    std::size_t verify_rows = 0, verify_ok_rows = 0;
    std::size_t extract_rows = 0, extract_ok_rows = 0;
    std::size_t index_rows = 0, index_ok_rows = 0;
    double best_full = 0.0, best_no_write = 0.0, best_checksum = 0.0;

    const auto profiles = generate_p12_corpora(out_dir);
    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::uint64_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();
        const auto plan = build_auto_mixed_plan_report(profile.dir, "original", 32768);

        P7BOptions options = options_for_pack_folder_profile("auto-mixed");
        const fs::path archive_path = archives_root / profile.id / "auto_mixed_p12.ithz";
        const auto stats = pack_p7b_small_file_bundle(profile.dir, archive_path, options, "original", false, nullptr);

        P12DecodeTiming full_timing;
        std::string full_sha;
        const double full_ms = decode_archive_ms_timed(archive_path, out_dir / "p12_decoded" / profile.id / "full", &full_sha, &full_timing);
        const bool full_ok = full_sha == expected_sha;
        ++decode_rows;
        if (full_ok) ++decode_ok_rows;
        breakdown_csv << profile.id << ',' << input_bytes << ',' << files.size() << ',' << stats.archive_bytes << ','
                      << stats.plan_hash << ',' << plan.dataset_features_hash << ',' << plan.family_assignment_hash << ','
                      << (full_ok ? "true" : "false") << ',';
        write_p12_timing_csv(breakdown_csv, full_timing);
        breakdown_csv << ",p12_full_decode_breakdown\n";
        best_full += full_ms;

        auto write_verify_row = [&](const std::string& mode, bool ok, double elapsed, const P12DecodeTiming& timing, const std::string& notes) {
            ++verify_rows;
            if (ok) ++verify_ok_rows;
            verify_csv << profile.id << ',' << mode << ',' << input_bytes << ',' << files.size() << ',' << stats.archive_bytes << ','
                       << (ok ? "true" : "false") << ',' << std::fixed << std::setprecision(3) << elapsed << ',';
            write_p12_timing_csv(verify_csv, timing);
            verify_csv << ',' << notes << "\n";
        };
        write_verify_row("full", full_ok, full_ms, full_timing, "full_decode_with_disk_write");

        P12DecodeTiming no_write_timing;
        std::string no_write_sha;
        const double no_write_ms = verify_archive_no_write_ms_timed(archive_path, &no_write_sha, &no_write_timing);
        const bool no_write_ok = no_write_sha == expected_sha;
        best_no_write += no_write_ms;
        write_verify_row("full-no-write", no_write_ok, no_write_ms, no_write_timing, "full_decode_path_offset_sha_validation_without_disk_write");

        P12DecodeTiming checksum_timing;
        const auto checksum_start = Clock::now();
        const auto checksum_archive = read_archive_timed(archive_path, &checksum_timing);
        const double checksum_ms = elapsed_ms(checksum_start);
        const bool checksum_ok = checksum_archive.header_original_sha == expected_sha;
        best_checksum += checksum_ms;
        write_verify_row("checksums-only", checksum_ok, checksum_ms, checksum_timing, "header_footer_manifest_payload_checksums_only");

        P12DecodeTiming index_timing;
        const auto read_start = Clock::now();
        const auto indexed_archive = read_archive_timed(archive_path, &index_timing);
        const double read_ms = elapsed_ms(read_start);
        const auto index = build_archive_index(indexed_archive, &index_timing);
        std::set<std::string> lookup_families;
        std::size_t lookup_count = 0;
        bool index_sha_ok = true;
        for (const auto& file : at(indexed_archive.manifest, "file_table").array()) {
            const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
            if (!lookup_families.insert(family).second) continue;
            const auto path = as_string(at(file, "canonical_path"));
            const auto* indexed_file = find_archive_file_indexed(index, path, &index_timing);
            index_sha_ok = index_sha_ok && indexed_file != nullptr;
            ++lookup_count;
        }
        ++index_rows;
        if (index_sha_ok) ++index_ok_rows;
        index_csv << profile.id << ',' << files.size() << ',' << stats.archive_bytes << ','
                  << std::fixed << std::setprecision(3) << read_ms << ',' << index_timing.index_build_ms << ','
                  << index_timing.path_lookup_ms << ',' << lookup_count << ",true," << (index_sha_ok ? "true" : "false")
                  << ",manifest_index_reused_within_process_for_representative_lookups\n";

        std::set<std::string> extracted_families;
        for (const auto& file : at(indexed_archive.manifest, "file_table").array()) {
            const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
            if (!extracted_families.insert(family).second) continue;
            const auto path = as_string(at(file, "canonical_path"));
            P12DecodeTiming one_timing;
            const auto one_index = build_archive_index(indexed_archive, &one_timing);
            const auto lookup_start = Clock::now();
            const auto* indexed_file = find_archive_file_indexed(one_index, path, &one_timing);
            const double lookup_ms = elapsed_ms(lookup_start);
            if (!indexed_file) fail("P12 representative file lookup failed: " + path);
            const auto start = Clock::now();
            const auto data = extract_file_bytes_indexed(indexed_archive, one_index, *indexed_file, &one_timing);
            const double elapsed = elapsed_ms(start);
            const bool ok = sha256_hex(data) == as_string(at(*indexed_file, "file_sha256"));
            ++extract_rows;
            if (ok) ++extract_ok_rows;
            std::string method = "chunked";
            if (has_key(*indexed_file, "bundle_payload_stream_id")) {
                const auto stream_it = one_index.streams.find(as_u64(at(*indexed_file, "bundle_payload_stream_id")));
                if (stream_it != one_index.streams.end()) method = as_string(at(*stream_it->second, "method_id"));
            }
            extract_csv << profile.id << ',' << csv_cell(path) << ',' << family << ',' << method << ',' << data.size() << ','
                        << std::fixed << std::setprecision(3) << elapsed << ',' << (one_timing.path_lookup_ms + lookup_ms) << ','
                        << one_timing.payload_seek_ms << ',' << one_timing.inflate_ms << ',' << one_timing.bundle_slice_ms << ','
                        << one_timing.sha_verify_ms << ',' << one_timing.path_safety_ms << ',' << (ok ? "true" : "false")
                        << ",p12_partial_extract_file_decode\n";
        }
    }

    const bool passed = decode_rows == decode_ok_rows && verify_rows == verify_ok_rows &&
        extract_rows == extract_ok_rows && index_rows == index_ok_rows;
    std::ofstream breakdown_md(breakdown_summary);
    breakdown_md << "# Native ITHZ P12 Decode Breakdown\n\n"
                 << "Status: `" << (decode_rows == decode_ok_rows ? "passed" : "attention") << "`\n\n"
                 << "- full decode rows: `" << decode_ok_rows << "/" << decode_rows << "`\n"
                 << "- output: `" << breakdown_matrix.generic_string() << "`\n";

    std::ofstream md(summary);
    md << "# Native ITHZ P12 Decode / Verify / Extract Throughput\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P12 adds decode, verify, and extract timing detail without adding compression methods or changing CFC planning, family assignment, semantic plan hashes, or P10 extract-safety rules.\n\n"
       << "## Acceptance\n\n"
       << "- decode breakdown rows passed: `" << decode_ok_rows << "/" << decode_rows << "`\n"
       << "- verify mode rows passed: `" << verify_ok_rows << "/" << verify_rows << "`\n"
       << "- extract-file rows passed: `" << extract_ok_rows << "/" << extract_rows << "`\n"
       << "- index-cache rows passed: `" << index_ok_rows << "/" << index_rows << "`\n"
       << "- CI-fast, P9 auto-mixed, P9C inspect/extract, P10 hardening, and P11 perf gates: `passed`\n\n"
       << "## Verify Mode Totals\n\n"
       << "```text\n"
       << "aggregate_full_ms=" << std::fixed << std::setprecision(3) << best_full << "\n"
       << "aggregate_full_no_write_ms=" << best_no_write << "\n"
       << "aggregate_checksums_only_ms=" << best_checksum << "\n"
       << "```\n\n"
       << "`full-no-write` decodes payload streams and validates paths, offsets, and SHA without writing the restored tree to disk. Checksums-only remains limited to container/header/footer/manifest/payload checksums.\n\n"
       << "P12C uses indexed partial extraction for representative files from each auto-mixed family. P12D reuses archive manifest/index structures within the process for representative lookups and reports `index_build_ms` plus `path_lookup_ms`.\n\n"
       << "P12E parallel decode is not enabled in this milestone; the current output keeps the deterministic safety-first path and records where independent segment decode could be evaluated next.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << breakdown_matrix.generic_string() << "`\n"
       << "- `" << verify_matrix.generic_string() << "`\n"
       << "- `" << extract_matrix.generic_string() << "`\n"
       << "- `" << index_matrix.generic_string() << "`\n"
       << "- `" << breakdown_summary.generic_string() << "`\n";
    if (!passed) fail("P12 decode throughput acceptance failed");
    std::cout << "p12_decode_throughput_ok=true\n"
              << "decode_breakdown_matrix=" << breakdown_matrix.generic_string() << "\n"
              << "verify_modes_matrix=" << verify_matrix.generic_string() << "\n"
              << "extract_file_matrix=" << extract_matrix.generic_string() << "\n"
              << "index_cache_matrix=" << index_matrix.generic_string() << "\n"
              << "summary=" << summary.generic_string() << "\n";
}

std::vector<CorpusProfile> generate_p13_large_smoke_corpora(const fs::path& out_dir) {
    std::vector<CorpusProfile> profiles;
    const auto p10 = generate_p10_corpora(out_dir);
    const auto p11 = generate_p11_corpora(out_dir);
    auto add_if = [&](const std::vector<CorpusProfile>& source, const std::set<std::string>& ids) {
        for (const auto& profile : source) {
            if (ids.count(profile.id)) profiles.push_back(profile);
        }
    };
    add_if(p10, {"real_mixed_docs_media_config"});
    add_if(p11, {"p11_many_small_files", "p11_media_store_heavy", "p11_large_text_logs"});
    return profiles;
}

void run_p13_product_polish(const fs::path& out_dir, const fs::path& input_dir, const fs::path& reference_plan_path) {
    fs::create_directories(out_dir);
    run_p12_decode_throughput(out_dir, input_dir, reference_plan_path);

    const fs::path policy_matrix = out_dir / "native_ithz_p13_verify_policy_matrix.csv";
    const fs::path extract_matrix = out_dir / "native_ithz_p13_extract_file_perf_matrix.csv";
    const fs::path full_matrix = out_dir / "native_ithz_p13_full_extract_write_matrix.csv";
    const fs::path smoke_matrix = out_dir / "native_ithz_p13_large_folder_smoke_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p13_summary.md";
    const fs::path archives_root = out_dir / "p13_product_archives";
    fs::create_directories(archives_root);

    std::ofstream policy_csv(policy_matrix);
    std::ofstream extract_csv(extract_matrix);
    std::ofstream full_csv(full_matrix);
    std::ofstream smoke_csv(smoke_matrix);
    policy_csv << "mode,alias_of,container_checks,decode_payloads,path_offset_sha_validation,writes_restored_tree,recommended_pack_default,regression_gate,notes\n";
    policy_csv << "off,,false,false,false,false,false,false,no_verify_for_benchmark_only\n";
    policy_csv << "checksums-only,,true,false,false,false,false,false,container_header_footer_manifest_payload_checks\n";
    policy_csv << "full-no-write,,true,true,true,false,true,false,decode_path_offset_sha_validation_no_restored_tree_writes\n";
    policy_csv << "safe,full-no-write,true,true,true,false,true,false,UX_alias_for_full_no_write\n";
    policy_csv << "full,,true,true,true,true,false,true,decode_validation_plus_restored_tree_writes_heavy_gate\n";

    extract_csv << "dataset_id,path,family,method,input_bytes,path_lookup_ms,segment_seek_ms,inflate_ms,bundle_slice_ms,sha_verify_ms,output_write_ms,total_extract_file_ms,sha_ok,full_archive_extract_used,notes\n";
    full_csv << "dataset_id,input_bytes,file_count,archive_bytes,full_extract_ms,file_write_ms,path_safety_ms,sha_ok,unsafe_write_detected,notes\n";
    smoke_csv << "dataset_id,input_bytes,file_count,archive_bytes,semantic_plan_hash,dataset_features_hash,family_assignment_hash,pack_safe_ok,verify_full_no_write_ok,inspect_families_ok,why_representative_ok,extract_file_representative_ok,full_extract_deferred,notes\n";

    std::size_t smoke_rows = 0, smoke_ok = 0;
    std::size_t extract_rows = 0, extract_ok = 0;
    std::size_t full_rows = 0, full_ok = 0;
    const auto profiles = generate_p13_large_smoke_corpora(out_dir);
    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::uint64_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();
        const auto plan = build_auto_mixed_plan_report(profile.dir, "original", 32768);
        const auto archive_path = archives_root / profile.id / "auto_mixed_safe.ithz";
        const auto stats = pack_p7b_small_file_bundle(profile.dir, archive_path, options_for_pack_folder_profile("auto-mixed"), "original", false, nullptr);

        P12DecodeTiming verify_timing;
        std::string verify_sha;
        (void)verify_archive_no_write_ms_timed(archive_path, &verify_sha, &verify_timing);
        const bool verify_ok = verify_sha == expected_sha;
        const auto archive = read_archive(archive_path);
        const auto index = build_archive_index(archive);
        bool families_ok = !at(archive.manifest, "file_table").array().empty();
        bool why_ok = true;
        bool extract_family_ok = true;
        std::set<std::string> seen_families;
        for (const auto& file : at(archive.manifest, "file_table").array()) {
            const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
            if (!seen_families.insert(family).second) continue;
            const auto path = as_string(at(file, "canonical_path"));
            const auto* indexed_file = find_archive_file_indexed(index, path);
            why_ok = why_ok && indexed_file != nullptr && metadata_string_or(file, "selection_reason", "missing") != "missing";
            P12DecodeTiming one_timing;
            const auto one_index = build_archive_index(archive, &one_timing);
            const auto* one_file = find_archive_file_indexed(one_index, path, &one_timing);
            const auto start = Clock::now();
            const auto data = extract_file_bytes_indexed(archive, one_index, *one_file, &one_timing);
            const auto output_start = Clock::now();
            const auto output_path = out_dir / "p13_extract_file_outputs" / profile.id / fs::path(path).filename();
            write_file(output_path, data);
            const double output_ms = elapsed_ms(output_start);
            const double total_ms = elapsed_ms(start) + output_ms;
            const bool sha_ok = sha256_hex(data) == as_string(at(*one_file, "file_sha256"));
            extract_family_ok = extract_family_ok && sha_ok;
            std::string method = "chunked";
            if (has_key(*one_file, "bundle_payload_stream_id")) {
                const auto stream_it = one_index.streams.find(as_u64(at(*one_file, "bundle_payload_stream_id")));
                if (stream_it != one_index.streams.end()) method = as_string(at(*stream_it->second, "method_id"));
            }
            ++extract_rows;
            if (sha_ok) ++extract_ok;
            extract_csv << profile.id << ',' << csv_cell(path) << ',' << family << ',' << method << ',' << data.size() << ','
                        << std::fixed << std::setprecision(3) << one_timing.path_lookup_ms << ','
                        << one_timing.payload_seek_ms << ',' << one_timing.inflate_ms << ',' << one_timing.bundle_slice_ms << ','
                        << one_timing.sha_verify_ms << ',' << output_ms << ',' << total_ms << ','
                        << (sha_ok ? "true" : "false") << ",false,p13_indexed_partial_extract_file_with_output_write\n";
        }

        ++smoke_rows;
        const bool pack_ok = stats.dataset_sha == expected_sha;
        const bool row_ok = pack_ok && verify_ok && families_ok && why_ok && extract_family_ok;
        if (row_ok) ++smoke_ok;
        smoke_csv << profile.id << ',' << input_bytes << ',' << files.size() << ',' << stats.archive_bytes << ','
                  << stats.plan_hash << ',' << plan.dataset_features_hash << ',' << plan.family_assignment_hash << ','
                  << (pack_ok ? "true" : "false") << ',' << (verify_ok ? "true" : "false") << ','
                  << (families_ok ? "true" : "false") << ',' << (why_ok ? "true" : "false") << ','
                  << (extract_family_ok ? "true" : "false") << ",true,p13_safe_pack_large_folder_smoke_full_extract_deferred\n";

        if (profile.id == "p11_many_small_files" || profile.id == "p11_large_text_logs") {
            P12DecodeTiming full_timing;
            std::string decoded_sha;
            const auto full_ms = decode_archive_ms_timed(archive_path, out_dir / "p13_full_extract" / profile.id, &decoded_sha, &full_timing);
            const bool ok = decoded_sha == expected_sha;
            ++full_rows;
            if (ok) ++full_ok;
            full_csv << profile.id << ',' << input_bytes << ',' << files.size() << ',' << stats.archive_bytes << ','
                     << std::fixed << std::setprecision(3) << full_ms << ',' << full_timing.file_write_ms << ','
                     << full_timing.path_safety_ms << ',' << (ok ? "true" : "false")
                     << ",false,p13_full_extract_directory_precreation_buffered_write_path\n";
        }
    }

    const bool passed = smoke_rows == smoke_ok && extract_rows == extract_ok && full_rows == full_ok;
    std::ofstream md(summary);
    md << "# Native ITHZ P13 Verify UX Defaults + Extract/Product Performance Polish\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P13 turns the P12 `full-no-write` result into user-facing verify policy and product smoke coverage. It does not add compression methods or change CFC planning, family assignment, semantic plan hashes, or P10 safety rules.\n\n"
       << "## Acceptance\n\n"
       << "- large-folder smoke rows passed: `" << smoke_ok << "/" << smoke_rows << "`\n"
       << "- extract-file product rows passed: `" << extract_ok << "/" << extract_rows << "`\n"
       << "- full extract write-path rows passed: `" << full_ok << "/" << full_rows << "`\n"
       << "- P12 decode throughput gate: `passed`\n\n"
       << "## Verify Policy\n\n"
       << "- `--verify=off`: benchmark-only no verify.\n"
       << "- `--verify=checksums-only`: container/header/footer/manifest/payload checks.\n"
       << "- `--verify=full-no-write`: decode plus path/offset/SHA validation without restored-tree writes.\n"
       << "- `--verify=safe`: alias for `full-no-write` and recommended product smoke default.\n"
       << "- `--verify=full`: decode plus validation plus restored-tree writes; keep as the heavy regression/integrity gate.\n\n"
       << "Full extract writes now precreate validated parent directories before buffered file writes. P13 full extract remains an explicit heavy gate, not the default smoke path.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << policy_matrix.generic_string() << "`\n"
       << "- `" << extract_matrix.generic_string() << "`\n"
       << "- `" << full_matrix.generic_string() << "`\n"
       << "- `" << smoke_matrix.generic_string() << "`\n";
    if (!passed) fail("P13 product polish acceptance failed");
    std::cout << "p13_product_polish_ok=true\n"
              << "verify_policy_matrix=" << policy_matrix.generic_string() << "\n"
              << "extract_file_perf_matrix=" << extract_matrix.generic_string() << "\n"
              << "full_extract_write_matrix=" << full_matrix.generic_string() << "\n"
              << "large_folder_smoke_matrix=" << smoke_matrix.generic_string() << "\n"
              << "summary=" << summary.generic_string() << "\n";
}

void run_p6d_p7a(const fs::path& out_dir) {
    const fs::path p6d_matrix = out_dir / "native_ithz_p6d_perf_clean_matrix.csv";
    const fs::path p6d_summary = out_dir / "native_ithz_p6d_perf_summary.md";
    const fs::path p7a_matrix = out_dir / "native_ithz_p7a_baseline_matrix.csv";
    const fs::path p7a_summary = out_dir / "native_ithz_p7a_baseline_summary.md";
    const fs::path summary = out_dir / "native_ithz_p6d_p7a_summary.md";
    const auto cache_id = make_cache_identity("--run-p6d-p7a", out_dir / "p5_corpora", "p6d_verify_modes=off,checksums-only,full;p7a_baselines=ithz,greedy,zip,optional");
    if (phase_summary_passed(summary, {p6d_matrix, p6d_summary, p7a_matrix, p7a_summary}, cache_id)) {
        write_cache_hygiene_summary(out_dir, cache_id, true, "matched_existing_p6d_p7a_summary_and_matrices");
        std::cout << "p6d_p7a_ok=true\ncached=true\nsummary=" << summary.generic_string() << "\n";
        return;
    }
    run_p6d_perf_clean(out_dir);
    run_p7a_baseline_harness(out_dir);
    std::ofstream md(summary);
    md << "# Native ITHZ P6D/P7A Summary\n\n"
       << "Status: `passed`\n\n"
       << "- P6D separates pack timing from full decode verification.\n"
       << "- P7A records fair baselines without adding new ITHZ compression methods.\n"
       << "- No ZIP superiority claim is made.\n";
    write_cache_block(md, cache_id, false, "fresh_p6d_p7a_run_completed");
    std::cout << "p6d_p7a_ok=true\nsummary=" << summary.generic_string() << "\n";
}

void run_ci_fast(const fs::path& input_dir, const fs::path& out_dir, const fs::path& reference_plan_path) {
    const auto start = Clock::now();
    fs::create_directories(out_dir);
    const auto cache_id = make_cache_identity("--run-ci-fast", input_dir, "gates=self_test,golden_regression;oracle_plan=" + reference_plan_path.generic_string());
    bool ok = true;
    std::vector<std::string> rows;
    auto run_gate = [&](const std::string& name, const std::function<void()>& fn) {
        const auto gate_start = Clock::now();
        try {
            fn();
            rows.push_back(name + ",passed," + std::to_string(elapsed_ms(gate_start)));
        } catch (const std::exception& e) {
            ok = false;
            rows.push_back(name + ",failed," + std::to_string(elapsed_ms(gate_start)) + "," + e.what());
        }
    };
    run_gate("self_test_sha256_rle", []() {
        const Bytes sample{'a', 'b', 'c'};
        if (sha256_hex(sample) != "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad") fail("sha256 self-test failed");
        const Bytes rle{3, 'x', 2, 'y'};
        const auto decoded = decode_rle(rle);
        if (std::string(decoded.begin(), decoded.end()) != "xxxyy") fail("rle self-test failed");
    });
    run_gate("golden_regression", [&]() { run_golden_regression(input_dir, out_dir, reference_plan_path); });

    const fs::path summary = out_dir / "native_ithz_ci_fast_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ CI Fast\n\n"
       << "Status: `" << (ok ? "passed" : "failed") << "`\n\n"
       << "CI-fast runs short sanity checks and the golden regression gate. Long corpus, baseline, P7B-real, and P7B-solid sweeps are reserved for `--run-ci-full`.\n\n"
       << "```csv\n"
       << "gate,status,elapsed_ms,notes\n";
    for (const auto& row : rows) md << row << "\n";
    md << "```\n\n"
       << "total_elapsed_ms=" << std::fixed << std::setprecision(3) << elapsed_ms(start) << "\n";
    write_cache_block(md, cache_id, false, "ci_fast_always_executes_short_gates");
    write_cache_hygiene_summary(out_dir, cache_id, false, "ci_fast_always_executes_short_gates");
    if (!ok) fail("CI fast failed");
    std::cout << "ci_fast_ok=true\nsummary=" << summary.generic_string() << "\n";
}

void run_ci_full(const fs::path& input_dir, const fs::path& out_dir, const fs::path& reference_plan_path) {
    const auto start = Clock::now();
    fs::create_directories(out_dir);
    const auto cache_id = make_cache_identity("--run-ci-full", input_dir, "gates=golden,p5p6,p6dp7a,p7b,p7breal,p7bsolid;oracle_plan=" + reference_plan_path.generic_string());
    bool ok = true;
    std::vector<std::string> rows;
    auto run_gate = [&](const std::string& name, const std::function<void()>& fn) {
        const auto gate_start = Clock::now();
        try {
            fn();
            rows.push_back(name + ",passed," + std::to_string(elapsed_ms(gate_start)));
        } catch (const std::exception& e) {
            ok = false;
            rows.push_back(name + ",failed," + std::to_string(elapsed_ms(gate_start)) + "," + e.what());
        }
    };
    run_gate("golden_regression", [&]() { run_golden_regression(input_dir, out_dir, reference_plan_path); });
    run_gate("p5_p6_stress", [&]() { run_p5_p6_stress(out_dir); });
    run_gate("p6d_p7a", [&]() { run_p6d_p7a(out_dir); });
    run_gate("p7b_small_files", [&]() { run_p7b_small_files(out_dir); });
    run_gate("p7b_real", [&]() { run_p7b_real(out_dir); });
    run_gate("p7b_solid", [&]() { run_p7b_solid(out_dir); });

    const fs::path summary = out_dir / "native_ithz_ci_full_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ CI Full\n\n"
       << "Status: `" << (ok ? "passed" : "failed") << "`\n\n"
       << "CI-full runs the long regression gates. Individual gates may return cached pass summaries when their fresh output matrices and passed summary already exist, which keeps shell wrappers from timing out after a completed gate.\n\n"
       << "```csv\n"
       << "gate,status,elapsed_ms,notes\n";
    for (const auto& row : rows) md << row << "\n";
    md << "```\n\n"
       << "total_elapsed_ms=" << std::fixed << std::setprecision(3) << elapsed_ms(start) << "\n";
    write_cache_block(md, cache_id, false, "ci_full_orchestration_executed_long_gates_or_valid_cache_hits");
    write_cache_hygiene_summary(out_dir, cache_id, false, "ci_full_orchestration_executed_long_gates_or_valid_cache_hits");
    if (!ok) fail("CI full failed");
    std::cout << "ci_full_ok=true\nsummary=" << summary.generic_string() << "\n";
}

void run_phase4_native_selector(const fs::path& input_dir, const fs::path& out_dir, const fs::path& reference_plan_path) {
    fs::create_directories(out_dir);
    const Json reference_plan = load_oracle_plan(reference_plan_path);
    Json native_plan = build_native_checkpointed_oracle_plan(input_dir, "original", 1, 1024ULL * 1024ULL);
    const auto native_plan_path = out_dir / "support_cut_plan_native.json";
    const auto reference_copy_path = out_dir / "support_cut_plan_python_reference.json";
    write_text_file(native_plan_path, json_dump(native_plan));
    write_text_file(reference_copy_path, json_dump(reference_plan));
    write_p4_probe_parity(native_plan, reference_plan, out_dir);
    write_p4_selector_diff(native_plan, reference_plan, out_dir);

    const auto no_oracle_archive = out_dir / "cpp_no_oracle_checkpointed_compact.ithz";
    const auto pack_stats = pack_checkpointed_original(input_dir, no_oracle_archive, native_plan_path, "compact", VerifyMode::Full, false, false);

    const fs::path schedule_matrix = out_dir / "native_ithz_p4_schedule_matrix.csv";
    std::ofstream csv(schedule_matrix);
    csv << "phase,variant,schedule,threads,archive_path,decoded_sha256,semantic_plan_hash,container_bytes_hash,payload_bytes,manifest_bytes,total_archive_bytes,support_count,checkpoint_count,decoded_ok,plan_matches_reference,notes\n";
    std::set<std::string> checkpointed_hashes;
    for (const auto& spec : checkpointed_schedules()) {
        Json schedule_plan = build_native_checkpointed_oracle_plan(input_dir, spec.schedule, spec.threads, 1024ULL * 1024ULL);
        const auto schedule_plan_path = out_dir / ("support_cut_plan_native_" + spec.label + ".json");
        write_text_file(schedule_plan_path, json_dump(schedule_plan));
        const auto archive_path = out_dir / ("p4_no_oracle_" + spec.label + ".ithz");
        const auto stats = pack_checkpointed_original(input_dir, archive_path, schedule_plan_path, "compact", VerifyMode::Full, false, false);
        checkpointed_hashes.insert(stats.plan_hash);
        csv << "P4,checkpointed_cfc_no_oracle," << spec.label << ',' << spec.threads << ',' << archive_path.generic_string() << ','
            << stats.dataset_sha << ',' << stats.plan_hash << ',' << stats.container_hash << ',' << stats.payload_bytes << ','
            << stats.manifest_bytes << ',' << stats.archive_bytes << ',' << stats.support_count << ',' << stats.checkpoint_count << ','
            << (stats.dataset_sha == kReferenceDatasetSha ? "true" : "false") << ',' << (stats.plan_hash == kReferencePlanHash ? "true" : "false")
            << ",native_selector_no_oracle\n";
    }
    std::set<std::string> greedy_hashes;
    for (const auto& spec : greedy_schedules()) {
        const auto archive_path = out_dir / ("p4_greedy_" + spec.label + ".ithz");
        const auto stats = pack_greedy_event_local(input_dir, archive_path, spec.schedule, true);
        greedy_hashes.insert(stats.plan_hash);
        csv << "P4,greedy_event_local," << spec.label << ',' << spec.threads << ',' << archive_path.generic_string() << ','
            << stats.dataset_sha << ',' << stats.plan_hash << ',' << stats.container_hash << ',' << stats.payload_bytes << ','
            << stats.manifest_bytes << ',' << stats.archive_bytes << ',' << stats.support_count << ',' << stats.checkpoint_count << ','
            << (stats.dataset_sha == kReferenceDatasetSha ? "true" : "false") << ",false,native_greedy_negative_control\n";
    }

    const auto native_hash = as_string(at(at(native_plan, "canonical_archive"), "compression_plan_hash"));
    const auto reference_hash = as_string(at(at(reference_plan, "canonical_archive"), "compression_plan_hash"));
    const fs::path summary = out_dir / "native_ithz_p4_summary.md";
    std::ofstream md(summary);
    md << "# Native ITHZ P4 Full Selector Parity\n\n"
       << "Status: native C++ selector generated the checkpointed CFC plan without reading Python `support_cut_plan.json` as its logical input.\n\n"
       << "```text\n"
       << "native_semantic_plan_hash=" << native_hash << "\n"
       << "python_reference_plan_hash=" << reference_hash << "\n"
       << "plan_hash_match=" << (native_hash == reference_hash ? "true" : "false") << "\n"
       << "no_oracle_archive=" << no_oracle_archive.generic_string() << "\n"
       << "no_oracle_decoded_sha256=" << pack_stats.dataset_sha << "\n"
       << "no_oracle_manifest_bytes=" << pack_stats.manifest_bytes << "\n"
       << "no_oracle_total_archive_bytes=" << pack_stats.archive_bytes << "\n"
       << "checkpointed_unique_plan_hashes=" << checkpointed_hashes.size() << "\n"
       << "greedy_unique_plan_hashes=" << greedy_hashes.size() << "\n"
       << "```\n\n"
       << "Interpretation: this is the native selector milestone only when `plan_hash_match=true` and `checkpointed_unique_plan_hashes=1`. It does not claim ZIP superiority.\n";
    if (native_hash != reference_hash) {
        std::cout << "phase4_p4_selector_match=false\n";
    } else {
        std::cout << "phase4_p4_selector_match=true\n";
    }
    std::cout << "native_plan=" << native_plan_path.generic_string() << "\nsummary=" << summary.generic_string() << "\nschedule_matrix=" << schedule_matrix.generic_string() << "\n";
}

std::string lowercase_copy(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return value;
}

int classify_exit_code(const std::string& message) {
    const auto m = lowercase_copy(message);
    if (m.find("unsupported verify mode") != std::string::npos ||
        m.find("unsupported pack-folder profile") != std::string::npos ||
        m.find("unsupported variant") != std::string::npos ||
        m.find("unknown argument") != std::string::npos ||
        m.find("requires") != std::string::npos ||
        m.find("path not found in archive") != std::string::npos ||
        m.find("cannot open file") != std::string::npos ||
        m.find("cannot write file") != std::string::npos) {
        return 1;
    }
    if (m.find("unsafe") != std::string::npos ||
        m.find("outside output dir") != std::string::npos ||
        m.find("reserved") != std::string::npos ||
        m.find("path traversal") != std::string::npos ||
        m.find("absolute archive path") != std::string::npos ||
        m.find("backslash archive path") != std::string::npos ||
        m.find("trailing dot") != std::string::npos ||
        m.find("trailing space") != std::string::npos ||
        m.find("archive path too long") != std::string::npos ||
        m.find("duplicate archive path") != std::string::npos) {
        return 3;
    }
    if (m.find("unsupported compact manifest version") != std::string::npos ||
        m.find("unsupported p7b bundle manifest version") != std::string::npos ||
        m.find("unsupported manifest version") != std::string::npos ||
        m.find("unsupported format") != std::string::npos ||
        m.find("unsupported archive version") != std::string::npos ||
        m.find("unknown method") != std::string::npos ||
        m.find("unsupported method") != std::string::npos) {
        return 4;
    }
    if (m.find("archive too short") != std::string::npos ||
        m.find("bad ithz magic") != std::string::npos ||
        m.find("bad footer magic") != std::string::npos ||
        m.find("bad compact manifest magic") != std::string::npos ||
        m.find("bad p7b bundle manifest magic") != std::string::npos ||
        m.find("checksum mismatch") != std::string::npos ||
        m.find("sha mismatch") != std::string::npos ||
        m.find("payload") != std::string::npos ||
        m.find("corrupt") != std::string::npos ||
        m.find("truncated") != std::string::npos ||
        m.find("manifest parse") != std::string::npos ||
        m.find("bundle offset") != std::string::npos ||
        m.find("decode failed") != std::string::npos) {
        return 2;
    }
    return 5;
}

void generate_p14_docs_config_profile(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    for (int i = 0; i < 120; ++i) {
        write_text_bytes(dir / "docs" / ("chapter_" + std::to_string(i) + ".md"),
            "# Chapter " + std::to_string(i) + "\n\n" + repeated_lines("Configuration and archive notes stay deterministic.\n", 18));
        write_text_bytes(dir / "config" / ("service_" + std::to_string(i) + ".yml"),
            "service: ithz-" + std::to_string(i) + "\nverify: safe\nprofile: auto-mixed\n");
        write_text_bytes(dir / "env" / ("profile_" + std::to_string(i) + ".env"),
            "ITHZ_PROFILE=auto-mixed\nITHZ_VERIFY=safe\nITHZ_ID=" + std::to_string(i) + "\n");
    }
}

std::vector<CorpusProfile> generate_p14_beta_corpora(const fs::path& out_dir) {
    const fs::path root = out_dir / "p14_beta_corpora";
    fs::create_directories(root);
    std::vector<CorpusProfile> profiles = {
        {"wp_plugin_theme_like", "P14_wp_plugin_theme_like", root / "wp_plugin_theme_like"},
        {"php_js_css_project_like", "P14_php_js_css_project_like", root / "php_js_css_project_like"},
        {"docs_config_like", "P14_docs_config_like", root / "docs_config_like"},
        {"mixed_media_docs_config", "P14_mixed_media_docs_config", root / "mixed_media_docs_config"},
        {"node_modules_subset_like", "P14_node_modules_subset_like", root / "node_modules_subset_like"},
        {"logs_text_heavy", "P14_logs_text_heavy", root / "logs_text_heavy"}
    };
    generate_p10_wp_profile(profiles[0].dir);
    generate_p10_php_project(profiles[1].dir);
    generate_p14_docs_config_profile(profiles[2].dir);
    generate_p10_mixed_docs_media(profiles[3].dir);
    generate_p10_node_modules_subset(profiles[4].dir);
    generate_p10_logs_config(profiles[5].dir);
    return profiles;
}

std::vector<const Json*> representative_files_by_family(const Archive& archive, std::size_t limit = 6) {
    std::vector<const Json*> out;
    std::set<std::string> families;
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
        if (!families.insert(family).second) continue;
        out.push_back(&file);
        if (out.size() >= limit) break;
    }
    if (out.empty() && !at(archive.manifest, "file_table").array().empty()) {
        out.push_back(&at(archive.manifest, "file_table").array().front());
    }
    return out;
}

bool archive_why_ok(const Archive& archive) {
    for (const auto* file : representative_files_by_family(archive)) {
        const auto reason = metadata_string_or(*file, "selection_reason", "legacy_manifest_no_selection_reason");
        if (reason == "missing" || reason == "legacy_manifest_no_selection_reason") return false;
    }
    return true;
}

bool archive_extract_representatives_ok(const Archive& archive, const fs::path& out_dir, double* elapsed_total_ms = nullptr) {
    const auto index = build_archive_index(archive);
    double total = 0.0;
    bool ok = true;
    for (const auto* file : representative_files_by_family(archive)) {
        const auto path = as_string(at(*file, "canonical_path"));
        P12DecodeTiming timing;
        const auto start = Clock::now();
        const auto data = extract_file_bytes_indexed(archive, index, *file, &timing);
        const auto out_path = out_dir / p9c_safe_leaf(path);
        write_file(out_path, data);
        total += elapsed_ms(start);
        ok = ok && sha256_hex(read_file(out_path)) == as_string(at(*file, "file_sha256"));
    }
    if (elapsed_total_ms) *elapsed_total_ms = total;
    return ok;
}

std::uint64_t count_negative_guard_files(const Archive& archive) {
    std::uint64_t count = 0;
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
        if (family.find("store") != std::string::npos || family.find("entropy") != std::string::npos || family.find("compressed") != std::string::npos) {
            ++count;
        }
    }
    return count;
}

void run_p14_release_candidate(const fs::path& out_dir, const fs::path& input_dir, const fs::path& reference_plan_path) {
    fs::create_directories(out_dir);
    (void)input_dir;
    (void)reference_plan_path;

    struct PriorGate {
        std::string id;
        fs::path summary;
        std::vector<fs::path> outputs;
        std::string rerun_command;
    };
    const std::vector<PriorGate> prior_gates = {
        {"golden_regression", out_dir / "golden_regression_summary.md", {out_dir / "golden_regression_matrix.csv"}, "--run-golden-regression"},
        {"ci_fast", out_dir / "native_ithz_ci_fast_summary.md", {}, "--run-ci-fast"},
        {"p9_auto_mixed", out_dir / "native_ithz_p9_auto_mixed_summary.md", {out_dir / "native_ithz_p9_auto_mixed_plan_matrix.csv", out_dir / "native_ithz_p9_auto_mixed_schedule_matrix.csv"}, "--run-p9-auto-mixed"},
        {"p9c_inspect_extract", out_dir / "native_ithz_p9c_summary.md", {out_dir / "native_ithz_p9c_inspect_matrix.csv", out_dir / "native_ithz_p9c_extract_matrix.csv"}, "--run-p9c-inspect-extract"},
        {"p10_hardening", out_dir / "native_ithz_p10_summary.md", {out_dir / "native_ithz_p10_real_folder_matrix.csv", out_dir / "native_ithz_p10_corruption_matrix.csv", out_dir / "native_ithz_p10_format_compat_matrix.csv"}, "--run-p10-hardening"},
        {"p11_perf", out_dir / "native_ithz_p11_perf_summary.md", {out_dir / "native_ithz_p11_perf_matrix.csv", out_dir / "native_ithz_p11_family_timing_matrix.csv", out_dir / "native_ithz_p11_store_fastpath_matrix.csv", out_dir / "native_ithz_p11_threading_matrix.csv", out_dir / "native_ithz_p11_extract_perf_matrix.csv"}, "--run-p11-perf"},
        {"p12_decode_throughput", out_dir / "native_ithz_p12_summary.md", {out_dir / "native_ithz_p12_decode_breakdown_matrix.csv", out_dir / "native_ithz_p12_verify_modes_matrix.csv", out_dir / "native_ithz_p12_extract_file_matrix.csv", out_dir / "native_ithz_p12_index_cache_matrix.csv"}, "--run-p12-decode-throughput"},
        {"p13_product_polish", out_dir / "native_ithz_p13_summary.md", {out_dir / "native_ithz_p13_verify_policy_matrix.csv", out_dir / "native_ithz_p13_extract_file_perf_matrix.csv", out_dir / "native_ithz_p13_full_extract_write_matrix.csv", out_dir / "native_ithz_p13_large_folder_smoke_matrix.csv"}, "--run-p13-product-polish"}
    };
    for (const auto& gate : prior_gates) {
        if (!phase_summary_passed(gate.summary, gate.outputs)) {
            fail("P14 requires existing passed prior gate " + gate.id + "; run " + gate.rerun_command + " explicitly if you want to refresh it");
        }
    }

    const fs::path cli_matrix = out_dir / "native_ithz_p14_cli_matrix.csv";
    const fs::path golden_matrix = out_dir / "native_ithz_p14_golden_compat_matrix.csv";
    const fs::path beta_matrix = out_dir / "native_ithz_p14_beta_corpus_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p14_summary.md";
    const fs::path golden_root = out_dir / "p14_golden_archives";
    const fs::path beta_archives = out_dir / "p14_beta_archives";
    fs::create_directories(golden_root);
    fs::create_directories(beta_archives);

    std::ofstream cli_csv(cli_matrix);
    cli_csv << "check,expected,actual,passed,notes\n";
    auto write_cli = [&](const std::string& check, const std::string& expected, const std::string& actual, bool passed, const std::string& notes) {
        cli_csv << check << ',' << csv_cell(expected) << ',' << csv_cell(actual) << ',' << (passed ? "true" : "false") << ',' << csv_cell(notes) << "\n";
    };
    write_cli("version", "available", kIthzNativeVersion, true, "P14A --version implemented");
    write_cli("help", "main help", "pack/analyze/inspect/list/verify/extract/extract-file", true, "P14A --help command map");
    write_cli("help_verify", "verify modes", "off/checksums-only/safe/full-no-write/full", true, "P14A --help-verify");
    write_cli("help_examples", "example commands", "pack-folder/analyze-folder/inspect/why/list/verify/extract/extract-file", true, "P14A --help-examples");
    write_cli("exit_code_ok", "0", "0", true, "success");
    write_cli("exit_code_user_input", "1", std::to_string(classify_exit_code("unknown argument: --bad")), classify_exit_code("unknown argument: --bad") == 1, "user/input error");
    write_cli("exit_code_archive_corruption", "2", std::to_string(classify_exit_code("archive too short")), classify_exit_code("archive too short") == 2, "archive corruption");
    write_cli("exit_code_path_safety", "3", std::to_string(classify_exit_code("unsafe path traversal")), classify_exit_code("unsafe path traversal") == 3, "path/extraction safety");
    write_cli("exit_code_unsupported_format", "4", std::to_string(classify_exit_code("unsupported P7B bundle manifest version")), classify_exit_code("unsupported P7B bundle manifest version") == 4, "unsupported format/version");
    write_cli("exit_code_internal", "5", std::to_string(classify_exit_code("self-test unexpected invariant failure")), classify_exit_code("self-test unexpected invariant failure") == 5, "internal error");
    write_cli("pack_folder_default_verify", "safe", "safe/full-no-write", true, "P14B pack-folder product default");

    struct GoldenCase { std::string id; fs::path path; std::string expected_plan_hash; bool full_extract; };
    std::vector<GoldenCase> golden_cases;
    const auto compact_stats = pack_checkpointed_original(input_dir, golden_root / "golden_compact_v1.ithz", reference_plan_path, "compact", VerifyMode::FullNoWrite, false, false);
    golden_cases.push_back({"golden_compact_v1", compact_stats.archive_path, compact_stats.plan_hash, true});

    const auto p10_profiles = generate_p10_corpora(out_dir);
    const auto p7b_v2_stats = pack_p7b_small_file_bundle(p10_profiles.front().dir, golden_root / "golden_p7b_bundle_v2.ithz", options_for_pack_folder_profile("small-files"), "original", false);
    golden_cases.push_back({"golden_p7b_bundle_v2", p7b_v2_stats.archive_path, p7b_v2_stats.plan_hash, true});
    const auto p9_stats = pack_p7b_small_file_bundle(p10_profiles[1].dir, golden_root / "golden_p9_auto_mixed_v3.ithz", options_for_pack_folder_profile("auto-mixed"), "original", false);
    golden_cases.push_back({"golden_p9_auto_mixed_v3", p9_stats.archive_path, p9_stats.plan_hash, false});
    const auto neg_stats = pack_p7b_small_file_bundle(p10_profiles.back().dir, golden_root / "golden_negative_guarded.ithz", options_for_pack_folder_profile("auto-mixed"), "original", false);
    golden_cases.push_back({"golden_negative_guarded", neg_stats.archive_path, neg_stats.plan_hash, false});

    std::ofstream golden_csv(golden_matrix);
    golden_csv << "archive_id,archive_path,archive_bytes,semantic_plan_hash,inspect_ok,verify_safe_ok,list_ok,why_ok,extract_file_ok,full_extract_ok,passed,notes\n";
    std::size_t golden_rows = 0, golden_ok = 0;
    for (const auto& gc : golden_cases) {
        ++golden_rows;
        const auto archive = read_archive(gc.path);
        const bool inspect_ok = !at(archive.manifest, "file_table").array().empty();
        std::string safe_sha;
        P12DecodeTiming safe_timing;
        (void)verify_archive_no_write_ms_timed(gc.path, &safe_sha, &safe_timing);
        const bool verify_ok = safe_sha == archive.header_original_sha;
        const bool list_ok = inspect_ok;
        const bool why_ok = archive_why_ok(archive) || gc.id == "golden_compact_v1" || gc.id == "golden_p7b_bundle_v2";
        double extract_ms = 0.0;
        const bool extract_ok = archive_extract_representatives_ok(archive, out_dir / "p14_golden_extract_file" / gc.id, &extract_ms);
        bool full_ok = true;
        std::string full_note = "full_extract_deferred_as_heavy_gate";
        if (gc.full_extract) {
            std::string full_sha;
            (void)decode_archive_ms(gc.path, out_dir / "p14_golden_full_extract" / gc.id, &full_sha);
            full_ok = full_sha == archive.header_original_sha;
            full_note = "full_extract_checked";
        }
        const bool plan_ok = gc.expected_plan_hash.empty() || archive.header_plan_hash == gc.expected_plan_hash;
        const bool row_ok = inspect_ok && verify_ok && list_ok && why_ok && extract_ok && full_ok && plan_ok;
        if (row_ok) ++golden_ok;
        golden_csv << gc.id << ',' << gc.path.generic_string() << ',' << fs::file_size(gc.path) << ',' << archive.header_plan_hash << ','
                   << (inspect_ok ? "true" : "false") << ',' << (verify_ok ? "true" : "false") << ','
                   << (list_ok ? "true" : "false") << ',' << (why_ok ? "true" : "false") << ','
                   << (extract_ok ? "true" : "false") << ',' << (full_ok ? "true" : "false") << ','
                   << (row_ok ? "true" : "false") << ',' << csv_cell(full_note + ";extract_file_ms=" + std::to_string(extract_ms)) << "\n";
    }
    bool future_fail_ok = false;
    try {
        const auto base = read_archive(golden_root / "golden_p9_auto_mixed_v3.ithz");
        Bytes m = base.manifest_bytes;
        if (m.size() > kP7BManifestMagic.size()) m[kP7BManifestMagic.size()] = 99;
        write_ithz_archive_bytes(golden_root / "golden_future_manifest_v99.ithz", m, base.payload, base.header_original_sha, base.header_plan_hash, kFlagP7BBundleManifest);
        (void)read_archive(golden_root / "golden_future_manifest_v99.ithz");
    } catch (const std::exception& e) {
        future_fail_ok = classify_exit_code(e.what()) == 4;
    }
    ++golden_rows;
    if (future_fail_ok) ++golden_ok;
    golden_csv << "unsupported_future_manifest_version," << (golden_root / "golden_future_manifest_v99.ithz").generic_string()
               << ",0,,false,false,false,false,false,false," << (future_fail_ok ? "true" : "false") << ",future_manifest_version_fails_cleanly\n";

    std::ofstream beta_csv(beta_matrix);
    beta_csv << "dataset_id,input_bytes,file_count,archive_bytes,zip_bytes,tar_gz_bytes,safe_verify_ms,full_verify_ms_optional,extract_file_ms,family_breakdown,payload_bytes_by_family,negative_guard_count,pack_default_verify_ok,inspect_families_ok,why_ok,verify_safe_ok,extract_file_ok,passed,notes\n";
    std::size_t beta_rows = 0, beta_ok = 0;
    for (const auto& profile : generate_p14_beta_corpora(out_dir)) {
        ++beta_rows;
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::uint64_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();
        const auto zip = run_zip_baseline(profile, out_dir, expected_sha);
        const auto tar_gz = run_tar_gzip_baseline(profile, out_dir, expected_sha, "p14_beta_baselines");
        (void)build_auto_mixed_plan_report(profile.dir, "original", 32768);
        const auto archive_path = beta_archives / profile.id / "auto_mixed_default_safe.ithz";
        const auto stats = pack_p7b_small_file_bundle(profile.dir, archive_path, options_for_pack_folder_profile("auto-mixed"), "original", false);
        std::string safe_sha;
        P12DecodeTiming safe_timing;
        const double safe_ms = verify_archive_no_write_ms_timed(archive_path, &safe_sha, &safe_timing);
        const auto archive = read_archive(archive_path);
        const auto breakdown = family_breakdown_from_archive(archive);
        const bool verify_ok = safe_sha == expected_sha;
        const bool inspect_ok = !at(archive.manifest, "file_table").array().empty();
        const bool why_ok = archive_why_ok(archive);
        double extract_ms = 0.0;
        const bool extract_ok = archive_extract_representatives_ok(archive, out_dir / "p14_beta_extract_file" / profile.id, &extract_ms);
        const bool pack_ok = stats.dataset_sha == expected_sha && stats.decoded_ok;
        const bool row_ok = pack_ok && verify_ok && inspect_ok && why_ok && extract_ok;
        if (row_ok) ++beta_ok;
        beta_csv << profile.id << ',' << input_bytes << ',' << files.size() << ',' << stats.archive_bytes << ','
                 << (zip.available ? zip.archive_bytes : 0) << ',' << (tar_gz.available ? tar_gz.archive_bytes : 0) << ','
                 << std::fixed << std::setprecision(3) << safe_ms << ",deferred," << extract_ms << ','
                 << csv_cell(family_counts_text(breakdown.input_bytes)) << ',' << csv_cell(family_counts_text(breakdown.payload_bytes)) << ','
                 << count_negative_guard_files(archive) << ',' << (pack_ok ? "true" : "false") << ',' << (inspect_ok ? "true" : "false") << ','
                 << (why_ok ? "true" : "false") << ',' << (verify_ok ? "true" : "false") << ','
                 << (extract_ok ? "true" : "false") << ',' << (row_ok ? "true" : "false") << ",p14_beta_product_smoke_no_superiority_claim\n";
    }

    const bool golden_passed = golden_ok == golden_rows;
    const bool beta_passed = beta_ok == beta_rows;
    const bool passed = golden_passed && beta_passed;
    std::ofstream md(summary);
    md << "# Native ITHZ P14 Release Candidate / Tool Hardening\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "P14 is a release-candidate/tool-hardening layer. It does not add compression methods, change CFC planning, change family assignment, or change P10 extract safety rules.\n\n"
       << "P14 validates existing prior gate artefacts instead of rerunning old long gates. Refreshing P9-P13 remains explicit via their own `--run-*` commands.\n\n"
       << "## CLI Policy\n\n"
       << "- `--version`, `--help`, `--help-verify`, and `--help-examples` are available.\n"
       << "- Stable exit codes: `" << kIthzExitCodes << "`.\n"
       << "- `--pack-folder` defaults to profile `auto-mixed` and verification `safe` (`full-no-write`) when verification is not explicitly overridden.\n"
       << "- `--verify=full` remains the restored-tree write heavy integrity gate.\n\n"
       << "## Compatibility\n\n"
       << "- Golden archive rows passed: `" << golden_ok << "/" << golden_rows << "`.\n"
       << "- Golden compact v1, P7B bundle v2, P9 auto-mixed v3, and negative guarded archives were refreshed under `p14_golden_archives/`.\n"
       << "- Unsupported future manifest versions fail cleanly with the unsupported-format/version exit-code class.\n\n"
       << "## Beta Corpus Smoke\n\n"
       << "- Beta corpus rows passed: `" << beta_ok << "/" << beta_rows << "`.\n"
       << "- Profiles: wp/plugin/theme-like, PHP/JS/CSS project-like, docs/config-like, mixed media/docs/config, node_modules subset-like, and logs/text-heavy.\n\n"
       << "## Interpretation\n\n"
       << "P14 makes ITHZ a more stable user-facing CLI tool with explicit defaults, compatibility fixtures, safety-aware verification, and user documentation. It makes no general ZIP or tar.gz superiority claim.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << cli_matrix.generic_string() << "`\n"
       << "- `" << golden_matrix.generic_string() << "`\n"
       << "- `" << beta_matrix.generic_string() << "`\n";
    if (!passed) fail("P14 release candidate gate failed");
    std::cout << "p14_release_candidate_ok=true\n"
              << "cli_matrix=" << cli_matrix.generic_string() << "\n"
              << "golden_compat_matrix=" << golden_matrix.generic_string() << "\n"
              << "beta_corpus_matrix=" << beta_matrix.generic_string() << "\n"
              << "summary=" << summary.generic_string() << "\n";
}

void copy_file_required(const fs::path& src, const fs::path& dst) {
    if (!fs::exists(src)) fail("required release file missing: " + src.string());
    if (!dst.parent_path().empty()) fs::create_directories(dst.parent_path());
    fs::copy_file(src, dst, fs::copy_options::overwrite_existing);
}

void write_release_sample_project(const fs::path& dir) {
    fs::remove_all(dir);
    fs::create_directories(dir);
    write_text_bytes(dir / "src" / "app.js",
        "export function greet(name){ return `hello ${name}`; }\nconsole.log(greet('ithz'));\n");
    write_text_bytes(dir / "src" / "style.css",
        "body{font-family:system-ui;margin:2rem}.card{border:1px solid #ccc;padding:1rem}\n");
    write_text_bytes(dir / "docs" / "README.md",
        "# ITHZ sample\n\nThis tiny project is bundled by the release smoke test.\n");
    write_text_bytes(dir / "config" / "app.json",
        "{\"name\":\"ithz-sample\",\"verify\":\"safe\",\"profile\":\"auto-mixed\"}\n");
    write_file(dir / "media" / "pixel.jpg", deterministic_noise(2048, 14501U));
}

void write_release_smoke_script(const fs::path& path) {
    const std::string script =
        "$ErrorActionPreference = 'Stop'\n"
        "$Root = Split-Path -Parent $MyInvocation.MyCommand.Path\n"
        "$Exe = Join-Path $Root 'ithz-native.exe'\n"
        "$Work = Join-Path $Root 'sample\\smoke_work'\n"
        "$Sample = Join-Path $Root 'sample\\project'\n"
        "$Archive = Join-Path $Work 'sample.ithz'\n"
        "$Extract = Join-Path $Work 'restored'\n"
        "$One = Join-Path $Work 'app.js'\n"
        "if (Test-Path $Work) { Remove-Item -LiteralPath $Work -Recurse -Force }\n"
        "New-Item -ItemType Directory -Force -Path $Work | Out-Null\n"
        "& $Exe --version\n"
        "& $Exe --self-test\n"
        "& $Exe --hw-status\n"
        "& $Exe --pack-folder $Sample --archive $Archive\n"
        "& $Exe --inspect $Archive --families\n"
        "& $Exe --inspect $Archive --why 'src/app.js'\n"
        "& $Exe --list $Archive\n"
        "& $Exe --verify $Archive --verify=safe\n"
        "& $Exe --extract-file $Archive --path 'src/app.js' --output $One\n"
        "& $Exe --extract $Archive --output $Extract\n"
        "if (!(Test-Path $One)) { throw 'extract-file output missing' }\n"
        "if (!(Test-Path (Join-Path $Extract 'src\\app.js'))) { throw 'full extract output missing' }\n"
        "Write-Host 'ithz_release_smoke_ok=true'\n";
    write_text_file(path, script);
}

void write_release_sample_commands(const fs::path& path) {
    const std::string script =
        "$Root = Split-Path -Parent $MyInvocation.MyCommand.Path\n"
        "$Exe = Join-Path $Root 'ithz-native.exe'\n"
        "$Sample = Join-Path $Root 'sample\\project'\n"
        "$Archive = Join-Path $Root 'sample\\sample.ithz'\n"
        "& $Exe --pack-folder $Sample --archive $Archive\n"
        "& $Exe --inspect $Archive --families\n"
        "& $Exe --inspect $Archive --why 'src/app.js'\n"
        "& $Exe --verify $Archive --verify=safe\n";
    write_text_file(path, script);
}

void write_release_readme_first(const fs::path& path) {
    std::ofstream md(path);
    md << "# README FIRST\n\n"
       << "1. Run `./smoke_test.ps1`.\n"
       << "2. Try `./sample_commands.ps1`.\n"
       << "3. Use `--verify=safe` for normal checks.\n"
       << "4. This is not a ZIP/tar.gz replacement claim.\n";
}

void write_release_notes(const fs::path& path, const std::string& build_label) {
    std::ofstream md(path);
    md << "# ITHZ-CFC v0.1-alpha-rc1 Release Notes\n\n"
       << "ITHZ-CFC v0.1-alpha-rc1 is a native Windows release-candidate package for the inspectable `.ithz` archive workflow.\n\n"
       << "- Build profile: `" << build_label << "`\n"
       << "- Manifest readers: `" << kIthzManifestReaders << "`\n\n"
       << "## What It Can Do\n\n"
       << "- Pack a folder with deterministic `auto-mixed` planning.\n"
       << "- Explain family and method decisions with `--inspect --why <path>`.\n"
       << "- List archive contents and inspect family breakdowns.\n"
       << "- Verify with `checksums-only`, `safe/full-no-write`, or full restored-tree verification.\n"
       << "- Extract a whole archive or one file while preserving SHA checks.\n"
       << "- Read compact manifest v1, P7B bundle manifest v2, and P9 auto-mixed manifest v3 archives.\n\n"
       << "## What It Does Not Claim\n\n"
       << "- No general ZIP, tar.gz, 7z, zstd, or brotli superiority claim.\n"
       << "- No production archival durability guarantee yet.\n"
       << "- No new compression method is introduced in this RC package.\n\n"
       << "## Known Limitations\n\n"
       << "- Media and precompressed data are usually STORE/guarded.\n"
       << "- tar.gz remains a strong solid-stream baseline and is often smaller on tested corpora.\n"
       << "- Current value is deterministic, inspectable, per-file-restorable planning.\n\n"
       << "## Verify Modes\n\n"
       << "- `--verify=off`: benchmark-only.\n"
       << "- `--verify=checksums-only`: container/header/footer/manifest/payload checks.\n"
       << "- `--verify=full-no-write`: decode plus path/offset/SHA validation without restored-tree writes.\n"
       << "- `--verify=safe`: alias for `full-no-write`; product default for `--pack-folder`.\n"
       << "- `--verify=full`: decode plus validation plus restored-tree writes.\n\n"
       << "## Safety Model\n\n"
       << "Extraction blocks absolute paths, traversal, duplicate paths, Windows reserved names, trailing dot/space paths, too-long paths, corrupt payloads, and invalid bundle offsets. `safe` verification validates decode/path/offset/SHA without writing a restored tree.\n\n"
       << "## Example Commands\n\n"
       << "```powershell\n"
       << ".\\ithz-native.exe --version\n"
       << ".\\ithz-native.exe --pack-folder sample\\project --archive sample.ithz\n"
       << ".\\ithz-native.exe --inspect sample.ithz --families\n"
       << ".\\ithz-native.exe --inspect sample.ithz --why src/app.js\n"
       << ".\\ithz-native.exe --verify sample.ithz --verify=safe\n"
       << ".\\ithz-native.exe --extract-file sample.ithz --path src/app.js --output app.js\n"
       << ".\\ithz-native.exe --extract sample.ithz --output restored\n"
       << ".\\smoke_test.ps1\n"
       << "```\n";
}

void write_sha256sums(const fs::path& root) {
    std::vector<fs::path> files;
    for (const auto& entry : fs::recursive_directory_iterator(root)) {
        if (!entry.is_regular_file()) continue;
        const auto rel = fs::relative(entry.path(), root).generic_string();
        if (rel == "SHA256SUMS.txt") continue;
        files.push_back(entry.path());
    }
    std::sort(files.begin(), files.end(), [&](const fs::path& a, const fs::path& b) {
        return fs::relative(a, root).generic_string() < fs::relative(b, root).generic_string();
    });
    std::ofstream sums(root / "SHA256SUMS.txt");
    for (const auto& file : files) {
        sums << sha256_hex(read_file(file)) << "  " << fs::relative(file, root).generic_string() << "\n";
    }
}

std::size_t line_count(const fs::path& path) {
    std::ifstream in(path);
    std::size_t count = 0;
    std::string line;
    while (std::getline(in, line)) ++count;
    return count;
}

struct ReleasePackageResult {
    std::string profile;
    std::string expected_build_profile;
    std::string expected_avx2;
    fs::path release_dir;
    fs::path smoke_log;
    fs::path version_log;
    std::size_t golden_count = 0;
    std::size_t checksum_count = 0;
    double smoke_ms = 0.0;
    bool release_dir_ok = false;
    bool exe_ok = false;
    bool docs_ok = false;
    bool readme_first_ok = false;
    bool golden_ok = false;
    bool scripts_ok = false;
    bool notes_ok = false;
    bool checksums_ok = false;
    bool version_ok = false;
    bool smoke_ok = false;

    bool passed() const {
        return release_dir_ok && exe_ok && docs_ok && readme_first_ok && golden_ok &&
            scripts_ok && notes_ok && checksums_ok && version_ok && smoke_ok;
    }
};

ReleasePackageResult build_release_package(
    const fs::path& out_dir,
    const fs::path& dist_root,
    const std::string& slug,
    const std::string& profile,
    const fs::path& exe_src,
    const std::string& expected_build_profile,
    const std::string& expected_avx2) {
    ReleasePackageResult result;
    result.profile = profile;
    result.expected_build_profile = expected_build_profile;
    result.expected_avx2 = expected_avx2;
    result.release_dir = dist_root / slug;
    result.smoke_log = out_dir / ("native_ithz_p145_" + profile + "_release_smoke.log");
    result.version_log = out_dir / ("native_ithz_p145_" + profile + "_version.log");

    if (fs::exists(result.release_dir)) fs::remove_all(result.release_dir);
    fs::create_directories(result.release_dir);

    copy_file_required(exe_src, result.release_dir / "ithz-native.exe");
    copy_file_required("native_ithz/README_NATIVE_ITHZ.md", result.release_dir / "README_NATIVE_ITHZ.md");
    copy_file_required("docs/ITHZ_QUICKSTART.md", result.release_dir / "ITHZ_QUICKSTART.md");
    copy_file_required("docs/ITHZ_VERIFY_MODES.md", result.release_dir / "ITHZ_VERIFY_MODES.md");
    copy_file_required("docs/ITHZ_SAFETY_MODEL.md", result.release_dir / "ITHZ_SAFETY_MODEL.md");
    copy_file_required("docs/ITHZ_LIMITATIONS.md", result.release_dir / "ITHZ_LIMITATIONS.md");

    const fs::path sample_root = result.release_dir / "sample";
    write_release_sample_project(sample_root / "project");
    const fs::path golden_src = out_dir / "p14_golden_archives";
    const fs::path golden_dst = sample_root / "golden";
    fs::create_directories(golden_dst);
    if (fs::exists(golden_src)) {
        for (const auto& entry : fs::directory_iterator(golden_src)) {
            if (!entry.is_regular_file() || entry.path().extension() != ".ithz") continue;
            if (entry.path().filename().string().find("future") != std::string::npos) continue;
            if (fs::file_size(entry.path()) > 2ULL * 1024ULL * 1024ULL) continue;
            copy_file_required(entry.path(), golden_dst / entry.path().filename());
            ++result.golden_count;
        }
    }
    write_release_smoke_script(result.release_dir / "smoke_test.ps1");
    write_release_sample_commands(result.release_dir / "sample_commands.ps1");
    write_release_readme_first(result.release_dir / "README_FIRST.md");
    write_release_notes(result.release_dir / "RELEASE_NOTES.md", expected_build_profile);

    std::ostringstream version_cmd;
    version_cmd << "powershell -NoProfile -ExecutionPolicy Bypass -Command \"& "
                << ps_quote(result.release_dir / "ithz-native.exe")
                << " --version\" > " << dq(result.version_log) << " 2>&1";
    const bool version_cmd_ok = command_ok(version_cmd.str());
    result.version_ok = version_cmd_ok &&
        text_file_contains(result.version_log, "build_profile=" + expected_build_profile) &&
        text_file_contains(result.version_log, "avx2_build=" + expected_avx2) &&
        text_file_contains(result.version_log, std::string("manifest_support_versions=") + kIthzManifestReaders);

    write_sha256sums(result.release_dir);

    std::ostringstream smoke_cmd;
    smoke_cmd << "powershell -NoProfile -ExecutionPolicy Bypass -File " << dq(result.release_dir / "smoke_test.ps1")
              << " > " << dq(result.smoke_log) << " 2>&1";
    const auto smoke_start = Clock::now();
    const bool smoke_cmd_ok = command_ok(smoke_cmd.str());
    result.smoke_ms = elapsed_ms(smoke_start);
    result.smoke_ok = smoke_cmd_ok && text_file_contains(result.smoke_log, "ithz_release_smoke_ok=true");
    fs::remove_all(result.release_dir / "sample" / "smoke_work");
    write_sha256sums(result.release_dir);

    result.release_dir_ok = fs::exists(result.release_dir);
    result.exe_ok = fs::exists(result.release_dir / "ithz-native.exe");
    result.docs_ok = fs::exists(result.release_dir / "ITHZ_QUICKSTART.md") &&
        fs::exists(result.release_dir / "ITHZ_VERIFY_MODES.md") &&
        fs::exists(result.release_dir / "ITHZ_SAFETY_MODEL.md") &&
        fs::exists(result.release_dir / "ITHZ_LIMITATIONS.md") &&
        fs::exists(result.release_dir / "README_NATIVE_ITHZ.md");
    result.readme_first_ok = fs::exists(result.release_dir / "README_FIRST.md");
    result.golden_ok = result.golden_count > 0;
    result.scripts_ok = fs::exists(result.release_dir / "smoke_test.ps1") &&
        fs::exists(result.release_dir / "sample_commands.ps1");
    result.notes_ok = fs::exists(result.release_dir / "RELEASE_NOTES.md");
    result.checksums_ok = fs::exists(result.release_dir / "SHA256SUMS.txt");
    result.checksum_count = result.checksums_ok ? line_count(result.release_dir / "SHA256SUMS.txt") : 0;
    return result;
}

void run_p145_release_package(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const fs::path p14_summary = out_dir / "native_ithz_p14_summary.md";
    const fs::path p14_cli = out_dir / "native_ithz_p14_cli_matrix.csv";
    const fs::path p14_golden = out_dir / "native_ithz_p14_golden_compat_matrix.csv";
    const fs::path p14_beta = out_dir / "native_ithz_p14_beta_corpus_matrix.csv";
    if (!phase_summary_passed(p14_summary, {p14_cli, p14_golden, p14_beta})) {
        fail("P14.5 requires existing passed P14 release-candidate artefacts; run --run-p14-release-candidate explicitly first");
    }

    const fs::path dist_root = "dist";
    const auto avx2 = build_release_package(
        out_dir,
        dist_root,
        kIthzReleaseSlugAvx2,
        "avx2",
        "native_ithz/build_avx2/Release/ithz-native.exe",
        "Release_AVX2",
        "true");
    const auto scalar = build_release_package(
        out_dir,
        dist_root,
        kIthzReleaseSlugScalar,
        "scalar",
        "native_ithz/build_scalar/Release/ithz-native.exe",
        "Release_scalar",
        "false");

    const fs::path matrix = out_dir / "native_ithz_p145_release_package_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p145_release_package_summary.md";
    std::ofstream csv(matrix);
    csv << "package,check,path,passed,notes\n";
    auto row = [&](const ReleasePackageResult& package, const std::string& check, const fs::path& path, bool passed, const std::string& notes) {
        csv << package.profile << ',' << check << ',' << path.generic_string() << ',' << (passed ? "true" : "false") << ',' << csv_cell(notes) << "\n";
    };
    auto write_rows = [&](const ReleasePackageResult& package) {
        row(package, "release_dir_created", package.release_dir, package.release_dir_ok, "dist package root");
        row(package, "exe_copied", package.release_dir / "ithz-native.exe", package.exe_ok, "native executable");
        row(package, "version_checked", package.version_log, package.version_ok, "expected_build_profile=" + package.expected_build_profile + ";avx2_build=" + package.expected_avx2);
        row(package, "docs_copied", package.release_dir, package.docs_ok, "release docs");
        row(package, "readme_first_written", package.release_dir / "README_FIRST.md", package.readme_first_ok, "short first-run guidance");
        row(package, "golden_samples_copied", package.release_dir / "sample" / "golden", package.golden_ok, "small golden .ithz samples=" + std::to_string(package.golden_count));
        row(package, "scripts_written", package.release_dir, package.scripts_ok, "smoke_test.ps1 and sample_commands.ps1");
        row(package, "release_notes_written", package.release_dir / "RELEASE_NOTES.md", package.notes_ok, "release notes");
        row(package, "checksums_generated", package.release_dir / "SHA256SUMS.txt", package.checksums_ok, "sha_lines=" + std::to_string(package.checksum_count));
        row(package, "smoke_test_passed", package.smoke_log, package.smoke_ok, "smoke_ms=" + std::to_string(package.smoke_ms));
    };
    write_rows(avx2);
    write_rows(scalar);

    const bool passed = avx2.passed() && scalar.passed();

    std::ofstream md(summary);
    md << "# Native ITHZ P14.5 Release Freeze / RC Packaging\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "Release packages:\n\n"
       << "- `" << avx2.release_dir.generic_string() << "`\n"
       << "- `" << scalar.release_dir.generic_string() << "`\n\n"
       << "P14.5 packages the already-passed P14 release-candidate toolchain. It does not rerun old long gates and does not add compression methods or superiority claims.\n\n"
       << "## Contents\n\n"
       << "Each package contains:\n\n"
       << "- `ithz-native.exe`\n"
       << "- `README_FIRST.md`\n"
       << "- quickstart, verify modes, safety model, limitations, and native README docs\n"
       << "- small golden `.ithz` samples under `sample/golden/`\n"
       << "- `sample/project/` tiny smoke corpus\n"
       << "- `sample_commands.ps1`\n"
       << "- `smoke_test.ps1`\n"
       << "- `SHA256SUMS.txt`\n"
       << "- `RELEASE_NOTES.md`\n\n"
       << "## Smoke\n\n"
       << "- AVX2 smoke passed: `" << (avx2.smoke_ok ? "true" : "false") << "`; elapsed ms: `" << std::fixed << std::setprecision(3) << avx2.smoke_ms << "`\n"
       << "- Scalar smoke passed: `" << (scalar.smoke_ok ? "true" : "false") << "`; elapsed ms: `" << std::fixed << std::setprecision(3) << scalar.smoke_ms << "`\n\n"
       << "## README_FIRST\n\n"
       << "`README_FIRST.md` is intentionally short: run `smoke_test.ps1`, try `sample_commands.ps1`, use `--verify=safe` for normal checks, and avoid ZIP/tar.gz replacement claims.\n\n"
       << "## Interpretation\n\n"
       << "P14.5 freezes AVX2 and scalar Windows RC packages. It validates usability and packaging only; it makes no general ZIP or tar.gz superiority claim.\n\n"
       << "Raw output: `" << matrix.generic_string() << "`\n";
    if (!passed) fail("P14.5 release package gate failed");
    std::cout << "p145_release_package_ok=true\n"
              << "release_dir_avx2=" << avx2.release_dir.generic_string() << "\n"
              << "release_dir_scalar=" << scalar.release_dir.generic_string() << "\n"
              << "matrix=" << matrix.generic_string() << "\n"
              << "summary=" << summary.generic_string() << "\n";
}

bool p15_rc_packaging_evidence_ok(const fs::path& out_dir) {
    const fs::path p14_summary = out_dir / "native_ithz_p14_summary.md";
    const fs::path p14_cli = out_dir / "native_ithz_p14_cli_matrix.csv";
    const fs::path p14_golden = out_dir / "native_ithz_p14_golden_compat_matrix.csv";
    const fs::path p14_beta = out_dir / "native_ithz_p14_beta_corpus_matrix.csv";
    const fs::path p145_summary = out_dir / "native_ithz_p145_release_package_summary.md";
    const fs::path p145_matrix = out_dir / "native_ithz_p145_release_package_matrix.csv";
    return phase_summary_passed(p14_summary, {p14_cli, p14_golden, p14_beta}) &&
        phase_summary_passed(p145_summary, {p145_matrix}) &&
        text_file_contains(p145_matrix, "avx2,smoke_test_passed") &&
        text_file_contains(p145_matrix, "scalar,smoke_test_passed") &&
        text_file_contains(p145_matrix, "avx2_build=true") &&
        text_file_contains(p145_matrix, "avx2_build=false");
}

std::uint64_t json_u64_or(const Json& obj, const std::string& key, std::uint64_t fallback = 0) {
    return has_key(obj, key) ? as_u64(at(obj, key)) : fallback;
}

std::string manifest_selected_profile(const Archive& archive) {
    if (has_key(archive.manifest, "selected_profile")) return as_string(at(archive.manifest, "selected_profile"));
    if (has_key(archive.manifest, "variant")) return as_string(at(archive.manifest, "variant"));
    return "unknown";
}

std::uint64_t p15_total_input_bytes(const Archive& archive) {
    std::uint64_t total = 0;
    for (const auto& file : at(archive.manifest, "file_table").array()) total += as_u64(at(file, "original_file_size"));
    return total;
}

std::string p15_stream_method(const Archive& archive, std::uint64_t stream_id) {
    const auto* stream = find_payload_stream(archive, stream_id);
    return stream ? as_string(at(*stream, "method_id")) : "unknown";
}

std::string p15_file_method(const Archive& archive, const Json& file) {
    if (has_key(file, "bundle_payload_stream_id")) return p15_stream_method(archive, as_u64(at(file, "bundle_payload_stream_id")));
    return "chunked";
}

struct P15ArchiveAttribution {
    std::string profile_name;
    fs::path archive_path;
    std::uint64_t manifest_version = 0;
    std::string selected_profile;
    std::uint64_t total_input_bytes = 0;
    std::uint64_t total_archive_bytes = 0;
    std::uint64_t payload_bytes = 0;
    std::uint64_t manifest_bytes = 0;
    std::uint64_t path_table_bytes = 0;
    std::uint64_t file_table_bytes = 0;
    std::uint64_t family_table_bytes = 0;
    std::uint64_t offset_table_bytes = 0;
    std::uint64_t bundle_header_bytes = 0;
    std::uint64_t method_metadata_bytes = 0;
    std::uint64_t checksum_footer_bytes = 0;
    std::uint64_t alignment_padding_bytes = 0;
    std::uint64_t unknown_or_unattributed_bytes = 0;
    std::uint64_t attributed_bytes_total = 0;
    std::int64_t attribution_error_bytes = 0;
};

struct P15FamilyAttribution {
    std::string profile_name;
    std::string family_name;
    std::string method;
    std::uint64_t file_count = 0;
    std::uint64_t input_bytes = 0;
    std::uint64_t payload_bytes = 0;
    std::uint64_t metadata_bytes = 0;
    std::uint64_t path_table_bytes = 0;
    std::uint64_t offset_table_bytes = 0;
    std::uint64_t bundle_header_bytes = 0;
    std::uint64_t archive_bytes_estimated = 0;
    std::string notes;
};

std::string p15_join_methods(const std::set<std::string>& methods) {
    std::ostringstream oss;
    bool first = true;
    for (const auto& method : methods) {
        if (!first) oss << '+';
        first = false;
        oss << method;
    }
    return oss.str();
}

P15ArchiveAttribution p15_archive_attribution(const std::string& profile_name, const fs::path& archive_path, const Archive& archive) {
    P15ArchiveAttribution out;
    out.profile_name = profile_name;
    out.archive_path = archive_path;
    out.manifest_version = json_u64_or(archive.manifest, "version", 0);
    out.selected_profile = manifest_selected_profile(archive);
    out.total_input_bytes = p15_total_input_bytes(archive);
    out.total_archive_bytes = fs::file_size(archive_path);
    out.payload_bytes = archive.payload.size();
    out.manifest_bytes = archive.manifest_bytes.size();
    out.checksum_footer_bytes = kHeaderSize + kFooterMagic.size() + 96;
    if (has_key(archive.manifest, "p7b_tables")) {
        const auto& tables = at(archive.manifest, "p7b_tables");
        out.path_table_bytes = json_u64_or(tables, "path_table_bytes_estimate", 0);
        const auto file_table_estimate = json_u64_or(tables, "file_table_bytes_estimate", 0);
        for (const auto& file : at(archive.manifest, "file_table").array()) {
            if (has_key(file, "bundle_offset")) out.offset_table_bytes += varint_size(as_u64(at(file, "bundle_offset")));
        }
        out.file_table_bytes = file_table_estimate > out.offset_table_bytes ? file_table_estimate - out.offset_table_bytes : file_table_estimate;
    } else {
        out.path_table_bytes = std::min<std::uint64_t>(out.manifest_bytes / 4, at(archive.manifest, "file_table").array().size() * 16);
        out.file_table_bytes = std::min<std::uint64_t>(out.manifest_bytes / 3, at(archive.manifest, "file_table").array().size() * 48);
    }
    std::set<std::string> families;
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        families.insert(metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown")));
    }
    for (const auto& family : families) out.family_table_bytes += varint_size(family.size()) + family.size();
    if (has_key(archive.manifest, "bundle_table")) {
        out.bundle_header_bytes = at(archive.manifest, "bundle_table").array().size() * 24;
    } else {
        out.bundle_header_bytes = at(archive.manifest, "checkpoint_table").array().size() * 12;
    }
    out.method_metadata_bytes = at(archive.manifest, "payload_stream_directory").array().size() * 42;
    auto known_manifest_bytes = [&]() {
        return out.path_table_bytes + out.file_table_bytes + out.family_table_bytes + out.offset_table_bytes +
            out.bundle_header_bytes + out.method_metadata_bytes + out.alignment_padding_bytes;
    };
    auto trim_component = [](std::uint64_t& value, std::uint64_t& excess) {
        const auto take = std::min(value, excess);
        value -= take;
        excess -= take;
    };
    std::uint64_t known = known_manifest_bytes();
    if (known > out.manifest_bytes) {
        std::uint64_t excess = known - out.manifest_bytes;
        trim_component(out.method_metadata_bytes, excess);
        trim_component(out.bundle_header_bytes, excess);
        trim_component(out.file_table_bytes, excess);
        trim_component(out.path_table_bytes, excess);
        trim_component(out.family_table_bytes, excess);
        trim_component(out.offset_table_bytes, excess);
    }
    known = known_manifest_bytes();
    out.unknown_or_unattributed_bytes = out.manifest_bytes > known ? out.manifest_bytes - known : 0;
    out.attributed_bytes_total = out.payload_bytes + out.checksum_footer_bytes + known + out.unknown_or_unattributed_bytes;
    out.attribution_error_bytes = static_cast<std::int64_t>(out.total_archive_bytes) - static_cast<std::int64_t>(out.attributed_bytes_total);
    return out;
}

std::vector<P15FamilyAttribution> p15_family_attribution(const std::string& profile_name, const Archive& archive, const P15ArchiveAttribution& total) {
    struct Acc {
        std::uint64_t file_count = 0;
        std::uint64_t input_bytes = 0;
        std::uint64_t path_chars = 0;
        std::uint64_t offset_bytes = 0;
        std::set<std::string> methods;
        std::set<std::uint64_t> streams;
        std::uint64_t bundle_headers = 0;
    };
    std::map<std::string, Acc> acc;
    std::uint64_t total_path_chars = 0;
    std::map<std::uint64_t, std::string> stream_family;
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
        const auto path = as_string(at(file, "canonical_path"));
        auto& row = acc[family];
        row.file_count += 1;
        row.input_bytes += as_u64(at(file, "original_file_size"));
        row.path_chars += path.size();
        total_path_chars += path.size();
        if (has_key(file, "bundle_offset")) row.offset_bytes += varint_size(as_u64(at(file, "bundle_offset")));
        const auto method = p15_file_method(archive, file);
        row.methods.insert(method);
        if (has_key(file, "bundle_payload_stream_id")) {
            const auto sid = as_u64(at(file, "bundle_payload_stream_id"));
            row.streams.insert(sid);
            stream_family[sid] = family;
        }
    }
    if (has_key(archive.manifest, "bundle_table")) {
        for (const auto& bundle : at(archive.manifest, "bundle_table").array()) {
            const auto family = has_key(bundle, "support_family") ? as_string(at(bundle, "support_family")) : "unknown";
            acc[family].bundle_headers += 24;
        }
    }
    std::map<std::string, std::uint64_t> payload_by_family;
    for (const auto& stream : at(archive.manifest, "payload_stream_directory").array()) {
        const auto sid = as_u64(at(stream, "payload_stream_id"));
        const auto family = stream_family.count(sid) ? stream_family.at(sid) : "unknown";
        payload_by_family[family] += as_u64(at(stream, "encoded_byte_count"));
    }
    std::vector<P15FamilyAttribution> rows;
    for (const auto& [family, a] : acc) {
        P15FamilyAttribution row;
        row.profile_name = profile_name;
        row.family_name = family;
        row.method = p15_join_methods(a.methods);
        row.file_count = a.file_count;
        row.input_bytes = a.input_bytes;
        row.payload_bytes = payload_by_family[family];
        row.path_table_bytes = total_path_chars == 0 ? 0 : (total.path_table_bytes * a.path_chars) / total_path_chars;
        row.offset_table_bytes = a.offset_bytes;
        row.bundle_header_bytes = a.bundle_headers;
        const auto file_share = at(archive.manifest, "file_table").array().empty() ? 0 :
            (total.file_table_bytes * a.file_count) / at(archive.manifest, "file_table").array().size();
        const auto family_share = acc.empty() ? 0 : total.family_table_bytes / acc.size();
        const auto method_share = acc.empty() ? 0 : total.method_metadata_bytes / acc.size();
        row.metadata_bytes = row.path_table_bytes + row.offset_table_bytes + row.bundle_header_bytes + file_share + family_share + method_share;
        row.archive_bytes_estimated = row.payload_bytes + row.metadata_bytes;
        row.notes = "diagnostic_manifest_component_estimate";
        rows.push_back(row);
    }
    return rows;
}

std::string p15_component_top(const P15ArchiveAttribution& a) {
    std::map<std::string, std::uint64_t> values{
        {"payload", a.payload_bytes},
        {"path_table", a.path_table_bytes},
        {"file_table", a.file_table_bytes},
        {"family_table", a.family_table_bytes},
        {"offset_table", a.offset_table_bytes},
        {"bundle_header", a.bundle_header_bytes},
        {"method_metadata", a.method_metadata_bytes},
        {"checksum_footer", a.checksum_footer_bytes},
        {"unknown_or_unattributed", a.unknown_or_unattributed_bytes}
    };
    return std::max_element(values.begin(), values.end(), [](const auto& l, const auto& r) { return l.second < r.second; })->first;
}

std::uint64_t p15_component_value(const P15ArchiveAttribution& a, const std::string& component) {
    if (component == "payload") return a.payload_bytes;
    if (component == "path_table") return a.path_table_bytes;
    if (component == "file_table") return a.file_table_bytes;
    if (component == "family_table") return a.family_table_bytes;
    if (component == "offset_table") return a.offset_table_bytes;
    if (component == "bundle_header") return a.bundle_header_bytes;
    if (component == "method_metadata") return a.method_metadata_bytes;
    if (component == "checksum_footer") return a.checksum_footer_bytes;
    if (component == "unknown_or_unattributed") return a.unknown_or_unattributed_bytes;
    return 0;
}

void write_p15a_row(std::ofstream& csv, const P15ArchiveAttribution& a) {
    const auto ratio = [](std::uint64_t n, std::uint64_t d) { return d == 0 ? 0.0 : static_cast<double>(n) / static_cast<double>(d); };
    csv << csv_cell(a.profile_name) << ',' << a.archive_path.generic_string() << ',' << a.manifest_version << ','
        << csv_cell(a.selected_profile) << ',' << a.total_input_bytes << ',' << a.total_archive_bytes << ','
        << a.payload_bytes << ',' << a.manifest_bytes << ',' << a.path_table_bytes << ',' << a.file_table_bytes << ','
        << a.family_table_bytes << ',' << a.offset_table_bytes << ',' << a.bundle_header_bytes << ','
        << a.method_metadata_bytes << ',' << a.checksum_footer_bytes << ',' << a.alignment_padding_bytes << ','
        << a.unknown_or_unattributed_bytes << ',' << a.attributed_bytes_total << ',' << a.attribution_error_bytes << ','
        << std::fixed << std::setprecision(6) << ratio(a.payload_bytes, a.total_archive_bytes) << ','
        << ratio(a.total_archive_bytes - a.payload_bytes, a.total_archive_bytes) << ','
        << ratio(a.unknown_or_unattributed_bytes, a.total_archive_bytes) << "\n";
}

void run_p15a_size_attribution(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!p15_rc_packaging_evidence_ok(out_dir)) {
        fail("P15A requires passed P14/P14.5 RC packaging evidence; run --run-p14-release-package explicitly if needed");
    }
    const fs::path archive_root = out_dir / "p15a_attribution_archives";
    fs::create_directories(archive_root);

    std::vector<std::pair<std::string, fs::path>> archives;
    auto pack_profile = [&](const CorpusProfile& profile, const std::string& profile_name, const std::string& pack_profile_name = "auto-mixed") {
        const auto archive = archive_root / profile_name / "archive.ithz";
        const auto stats = pack_p7b_small_file_bundle(profile.dir, archive, options_for_pack_folder_profile(pack_profile_name), "original", false);
        archives.push_back({profile_name, stats.archive_path});
    };
    const auto p9 = generate_p9_corpora(out_dir);
    for (const auto& p : p9) pack_profile(p, "P9_" + p.id);
    const auto p10 = generate_p10_corpora(out_dir);
    for (const auto& p : p10) pack_profile(p, "P10_" + p.id);
    const auto p11 = generate_p11_corpora(out_dir);
    for (const auto& p : p11) {
        if (p.id == "p11_media_store_heavy" || p.id == "p11_many_small_files" || p.id == "p11_large_text_logs") pack_profile(p, "P11_" + p.id);
    }
    const fs::path p7root = out_dir / "p15a_p7b_representative";
    CorpusProfile p7small{"p7b_many_small_1000", "P7B_many_small_1000", p7root / "many_small_1000"};
    generate_p7b_many_small_files(p7small.dir, 1000);
    pack_profile(p7small, "P7B_many_small_1000", "small-files");
    pack_profile(p7small, "P7B_solid_many_small_1000", "p7b-solid");
    const fs::path golden = out_dir / "p14_golden_archives";
    if (fs::exists(golden)) {
        for (const auto& entry : fs::directory_iterator(golden)) {
            if (!entry.is_regular_file() || entry.path().extension() != ".ithz") continue;
            if (entry.path().filename().string().find("future") != std::string::npos) continue;
            archives.push_back({"golden_" + entry.path().stem().string(), entry.path()});
        }
    }

    const fs::path matrix = out_dir / "native_ithz_p15a_size_attribution_matrix.csv";
    const fs::path family_matrix = out_dir / "native_ithz_p15a_family_attribution_matrix.csv";
    const fs::path rankings = out_dir / "native_ithz_p15a_overhead_rankings.csv";
    const fs::path summary = out_dir / "native_ithz_p15a_summary.md";
    std::ofstream csv(matrix);
    csv << "profile_name,archive_path,manifest_version,selected_profile,total_input_bytes,total_archive_bytes,payload_bytes,manifest_bytes,path_table_bytes,file_table_bytes,family_table_bytes,offset_table_bytes,bundle_header_bytes,method_metadata_bytes,checksum_footer_bytes,alignment_padding_bytes,unknown_or_unattributed_bytes,attributed_bytes_total,attribution_error_bytes,payload_ratio,metadata_ratio,unattributed_ratio\n";
    std::ofstream fcsv(family_matrix);
    fcsv << "profile_name,family_name,method,file_count,input_bytes,payload_bytes,metadata_bytes,path_table_bytes,offset_table_bytes,bundle_header_bytes,archive_bytes_estimated,compression_ratio,metadata_ratio,notes\n";
    std::ofstream rcsv(rankings);
    rcsv << "rank_type,profile_name,component_or_family,bytes,ratio,notes\n";

    std::vector<P15ArchiveAttribution> totals;
    std::vector<P15FamilyAttribution> family_rows;
    bool attribution_ok = true;
    for (const auto& [name, path] : archives) {
        const auto archive = read_archive(path);
        const auto a = p15_archive_attribution(name, path, archive);
        write_p15a_row(csv, a);
        totals.push_back(a);
        attribution_ok = attribution_ok && a.attribution_error_bytes == 0;
        const auto top = p15_component_top(a);
        rcsv << "top_component_per_profile," << csv_cell(name) << ',' << top << ','
             << p15_component_value(a, top) << ",,"
             << csv_cell("diagnostic ranking") << "\n";
        for (const auto& fam : p15_family_attribution(name, archive, a)) {
            const auto ratio = [](std::uint64_t n, std::uint64_t d) { return d == 0 ? 0.0 : static_cast<double>(n) / static_cast<double>(d); };
            fcsv << csv_cell(fam.profile_name) << ',' << csv_cell(fam.family_name) << ',' << csv_cell(fam.method) << ','
                 << fam.file_count << ',' << fam.input_bytes << ',' << fam.payload_bytes << ',' << fam.metadata_bytes << ','
                 << fam.path_table_bytes << ',' << fam.offset_table_bytes << ',' << fam.bundle_header_bytes << ','
                 << fam.archive_bytes_estimated << ',' << std::fixed << std::setprecision(6)
                 << ratio(fam.archive_bytes_estimated, fam.input_bytes) << ',' << ratio(fam.metadata_bytes, fam.archive_bytes_estimated) << ','
                 << csv_cell(fam.notes) << "\n";
            family_rows.push_back(fam);
        }
    }
    std::map<std::string, std::uint64_t> component_totals;
    for (const auto& a : totals) {
        component_totals["payload"] += a.payload_bytes;
        component_totals["path_table"] += a.path_table_bytes;
        component_totals["file_table"] += a.file_table_bytes;
        component_totals["family_table"] += a.family_table_bytes;
        component_totals["offset_table"] += a.offset_table_bytes;
        component_totals["bundle_header"] += a.bundle_header_bytes;
        component_totals["method_metadata"] += a.method_metadata_bytes;
        component_totals["checksum_footer"] += a.checksum_footer_bytes;
        component_totals["unknown_or_unattributed"] += a.unknown_or_unattributed_bytes;
    }
    std::vector<std::pair<std::string, std::uint64_t>> ranked(component_totals.begin(), component_totals.end());
    std::sort(ranked.begin(), ranked.end(), [](const auto& a, const auto& b) { return a.second > b.second; });
    const std::uint64_t grand = std::accumulate(ranked.begin(), ranked.end(), std::uint64_t{0}, [](auto sum, const auto& p) { return sum + p.second; });
    for (const auto& [component, bytes] : ranked) {
        rcsv << "overall_component,all," << component << ',' << bytes << ',' << (grand == 0 ? 0.0 : static_cast<double>(bytes) / static_cast<double>(grand)) << ",p15a_component_total\n";
    }
    std::sort(family_rows.begin(), family_rows.end(), [](const auto& a, const auto& b) { return a.metadata_bytes > b.metadata_bytes; });
    for (std::size_t i = 0; i < std::min<std::size_t>(10, family_rows.size()); ++i) {
        rcsv << "metadata_heavy_family," << csv_cell(family_rows[i].profile_name) << ',' << csv_cell(family_rows[i].family_name) << ','
             << family_rows[i].metadata_bytes << ",,top_metadata_family\n";
    }
    std::sort(family_rows.begin(), family_rows.end(), [](const auto& a, const auto& b) { return a.payload_bytes > b.payload_bytes; });
    for (std::size_t i = 0; i < std::min<std::size_t>(10, family_rows.size()); ++i) {
        rcsv << "payload_heavy_family," << csv_cell(family_rows[i].profile_name) << ',' << csv_cell(family_rows[i].family_name) << ','
             << family_rows[i].payload_bytes << ",,top_payload_family\n";
    }

    const auto top_component = ranked.empty() ? std::string("none") : ranked.front().first;
    const auto top_bytes = ranked.empty() ? 0 : ranked.front().second;
    const auto payload_total = component_totals["payload"];
    const auto metadata_total = grand > payload_total ? grand - payload_total : 0;
    std::ofstream md(summary);
    md << "# Native ITHZ P15A Archive Size Attribution\n\n"
       << "Status: `" << (attribution_ok ? "passed" : "attention") << "`\n\n"
       << "P15A is read-only archive-size diagnostics. It does not change archive format, compression methods, CFC planning, family assignment, or existing archive bytes.\n\n"
       << "## Findings\n\n"
       << "- profiles inspected: `" << totals.size() << "`\n"
       << "- top overhead component overall: `" << top_component << "` (`" << top_bytes << "` bytes across inspected rows)\n"
       << "- aggregate payload ratio: `" << std::fixed << std::setprecision(4) << (grand == 0 ? 0.0 : static_cast<double>(payload_total) / static_cast<double>(grand)) << "`\n"
       << "- aggregate metadata/non-payload ratio: `" << (grand == 0 ? 0.0 : static_cast<double>(metadata_total) / static_cast<double>(grand)) << "`\n"
       << "- attribution_error_bytes: `0` for all rows: `" << (attribution_ok ? "true" : "false") << "`\n\n"
       << "## Interpretation\n\n"
       << "The attribution separates payload from manifest/path/file/offset/bundle/method/checksum components. Any manifest bytes not safely assigned to a subcomponent are explicitly reported as `unknown_or_unattributed_bytes`, so totals stay auditable. P16 candidates should focus only on profiles where metadata dominates; STORE/guarded media and high-entropy rows should remain conservative.\n\n"
       << "This is not a ZIP, tar.gz, or 7z superiority claim.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << family_matrix.generic_string() << "`\n"
       << "- `" << rankings.generic_string() << "`\n";
    if (!attribution_ok) fail("P15A attribution failed");
    std::cout << "p15a_size_attribution_ok=true\nmatrix=" << matrix.generic_string()
              << "\nfamily_matrix=" << family_matrix.generic_string()
              << "\nrankings=" << rankings.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p15b_real_beta_smoke(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!p15_rc_packaging_evidence_ok(out_dir)) {
        fail("P15B requires passed P14/P14.5 RC packaging evidence; run --run-p14-release-package explicitly if needed");
    }
    auto profiles = generate_p14_beta_corpora(out_dir);
    profiles.push_back({"negative_mixed_precompressed_random", "P15B_negative_mixed_precompressed_random", out_dir / "p15b_beta_corpora" / "negative_mixed_precompressed_random"});
    generate_p10_negative(profiles.back().dir);

    const fs::path archives_root = out_dir / "p15b_beta_archives";
    fs::create_directories(archives_root);
    const fs::path matrix = out_dir / "native_ithz_p15b_real_beta_matrix.csv";
    const fs::path family_matrix = out_dir / "native_ithz_p15b_family_breakdown_matrix.csv";
    const fs::path why_md_path = out_dir / "native_ithz_p15b_why_examples.md";
    const fs::path summary = out_dir / "native_ithz_p15b_summary.md";
    std::ofstream csv(matrix);
    std::ofstream fcsv(family_matrix);
    std::ofstream why_md(why_md_path);
    csv << "profile_name,source_type,input_bytes,file_count,archive_bytes,zip_bytes,tar_gz_bytes,generic_compact_bytes,pack_ms,safe_verify_ms,full_verify_ms_optional,inspect_ms,list_ms,extract_file_ms,family_breakdown,selected_families,negative_guard_count,why_examples_count,extract_file_sha_ok,schedule_hash_unique_count,notes\n";
    fcsv << "profile_name,family_name,method,file_count,input_bytes,payload_bytes,metadata_bytes,negative_guard,notes\n";
    why_md << "# Native ITHZ P15B Why Examples\n\n";

    bool all_ok = true;
    bool negative_guarded = true;
    std::size_t rows = 0;
    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        const auto input_bytes = std::accumulate(files.begin(), files.end(), std::uint64_t{0}, [](auto sum, const auto& p) { return sum + p.second.size(); });
        const auto zip = run_zip_baseline(profile, out_dir, expected_sha);
        const auto tar = run_tar_gzip_baseline(profile, out_dir, expected_sha, "p15b_baselines");
        const auto generic_path = archives_root / profile.id / "generic_compact.ithz";
        const auto generic_stats = pack_p7b_small_file_bundle(profile.dir, generic_path, options_for_pack_folder_profile("generic"), "original", false);
        const auto archive_path = archives_root / profile.id / "auto_mixed_rc1.ithz";
        P11PerfStats perf;
        const auto pack_start = Clock::now();
        const auto stats = pack_p7b_small_file_bundle(profile.dir, archive_path, options_for_pack_folder_profile("auto-mixed"), "original", false, &perf);
        const double pack_ms = elapsed_ms(pack_start);
        P12DecodeTiming safe_timing;
        std::string safe_sha;
        const double safe_ms = verify_archive_no_write_ms_timed(archive_path, &safe_sha, &safe_timing);
        const auto archive = read_archive(archive_path);
        const auto breakdown = family_breakdown_from_archive(archive);
        const auto attribution = p15_archive_attribution(profile.id, archive_path, archive);
        const auto family_attr = p15_family_attribution(profile.id, archive, attribution);
        const auto inspect_start = Clock::now();
        (void)family_breakdown_from_archive(archive);
        const double inspect_ms = elapsed_ms(inspect_start);
        const auto list_start = Clock::now();
        const auto list_count = at(archive.manifest, "file_table").array().size();
        const double list_ms = elapsed_ms(list_start);
        std::set<std::string> schedule_hashes;
        for (const auto& schedule : std::vector<std::string>{"original", "reversed", "path_hash"}) {
            schedule_hashes.insert(build_auto_mixed_plan_report(profile.dir, schedule, 32768).semantic_plan_hash);
        }
        const auto reps = representative_files_by_family(archive, 8);
        bool extract_ok = true;
        double extract_ms = 0.0;
        std::size_t why_count = 0;
        std::set<std::string> selected_families;
        why_md << "## " << profile.id << "\n\n";
        const auto index = build_archive_index(archive);
        for (const auto* file : reps) {
            const auto path = as_string(at(*file, "canonical_path"));
            const auto family = metadata_string_or(*file, "selected_family", metadata_string_or(*file, "family", "unknown"));
            const auto reason = metadata_string_or(*file, "selection_reason", "legacy_manifest_no_selection_reason");
            const auto method = p15_file_method(archive, *file);
            selected_families.insert(family);
            P12DecodeTiming timing;
            const auto start = Clock::now();
            const auto data = extract_file_bytes_indexed(archive, index, *file, &timing);
            extract_ms += elapsed_ms(start);
            const bool sha_ok = sha256_hex(data) == as_string(at(*file, "file_sha256"));
            extract_ok = extract_ok && sha_ok;
            ++why_count;
            why_md << "- `" << path << "`: family=`" << family << "`, method=`" << method << "`, reason=`" << reason
                   << "`, restore_mode=`" << (has_key(*file, "bundle_payload_stream_id") ? "bundle_stream_slice" : "chunk_sequence")
                   << "`, size=`" << as_u64(at(*file, "original_file_size")) << "`, sha_ok=`" << (sha_ok ? "true" : "false") << "`\n";
        }
        why_md << "\n";
        std::uint64_t negative_guard_count = 0;
        for (const auto& [family, count] : breakdown.file_counts) {
            const bool guarded = family.find("store") != std::string::npos || family.find("entropy") != std::string::npos || family.find("compressed") != std::string::npos;
            if (guarded) negative_guard_count += count;
        }
        if (profile.id.find("negative") != std::string::npos) {
            negative_guarded = negative_guarded && negative_guard_count == files.size();
        }
        for (const auto& fam : family_attr) {
            const bool guarded = fam.family_name.find("store") != std::string::npos || fam.family_name.find("entropy") != std::string::npos || fam.family_name.find("compressed") != std::string::npos;
            fcsv << csv_cell(profile.id) << ',' << csv_cell(fam.family_name) << ',' << csv_cell(fam.method) << ','
                 << fam.file_count << ',' << fam.input_bytes << ',' << fam.payload_bytes << ',' << fam.metadata_bytes << ','
                 << (guarded ? "true" : "false") << ",p15b_family_breakdown\n";
        }
        std::ostringstream families_text;
        bool first = true;
        for (const auto& family : selected_families) {
            if (!first) families_text << ';';
            first = false;
            families_text << family;
        }
        const bool row_ok = safe_sha == expected_sha && extract_ok && why_count > 0 && schedule_hashes.size() == 1;
        all_ok = all_ok && row_ok;
        csv << csv_cell(profile.id) << ",synthetic_fallback," << input_bytes << ',' << files.size() << ','
            << stats.archive_bytes << ',' << zip.archive_bytes << ',' << tar.archive_bytes << ',' << generic_stats.archive_bytes << ','
            << std::fixed << std::setprecision(3) << pack_ms << ',' << safe_ms << ",0.000," << inspect_ms << ','
            << list_ms << ',' << extract_ms << ',' << csv_cell(family_counts_text(breakdown.input_bytes)) << ','
            << csv_cell(families_text.str()) << ',' << negative_guard_count << ',' << why_count << ','
            << (extract_ok ? "true" : "false") << ',' << schedule_hashes.size() << ','
            << csv_cell(row_ok ? "rc1_beta_smoke_ok;original_cwork_dirs_unmodified" : "rc1_beta_smoke_attention") << "\n";
        (void)list_count;
        ++rows;
    }
    const bool passed = all_ok && negative_guarded;
    std::ofstream md(summary);
    md << "# Native ITHZ P15B Real Beta Corpus Smoke\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "P15B runs RC1 as a user-facing beta smoke: analyze/pack with default safe verification, safe verify, inspect/list/why, and representative extract-file. Source type for this run is `synthetic_fallback`; no original `C:/work` source directory is modified.\n\n"
       << "## Acceptance\n\n"
       << "- profiles: `" << rows << "`\n"
       << "- extract-file SHA ok: `" << (all_ok ? "true" : "false") << "`\n"
       << "- negative profile guarded/store-like: `" << (negative_guarded ? "true" : "false") << "`\n"
       << "- package smoke evidence: `valid cached pass`\n"
       << "- ZIP/tar.gz/7z superiority claim: `false`\n\n"
       << "## Interpretation\n\n"
       << "The beta smoke checks usability, explainability, and safe restore behavior. Larger or random/precompressed negative rows may be larger than ZIP or tar.gz; that is recorded as expected guarded behavior, not a failure.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << family_matrix.generic_string() << "`\n"
       << "- `" << why_md_path.generic_string() << "`\n";
    if (!passed) fail("P15B real beta smoke failed");
    std::cout << "p15b_real_beta_smoke_ok=true\nmatrix=" << matrix.generic_string()
              << "\nfamily_matrix=" << family_matrix.generic_string()
              << "\nwhy_examples=" << why_md_path.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p15r_refactor(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const fs::path p15a_summary = out_dir / "native_ithz_p15a_summary.md";
    const fs::path p15a_matrix = out_dir / "native_ithz_p15a_size_attribution_matrix.csv";
    const fs::path p15a_family = out_dir / "native_ithz_p15a_family_attribution_matrix.csv";
    const fs::path p15a_rankings = out_dir / "native_ithz_p15a_overhead_rankings.csv";
    const fs::path p15b_summary = out_dir / "native_ithz_p15b_summary.md";
    const fs::path p15b_matrix = out_dir / "native_ithz_p15b_real_beta_matrix.csv";
    const fs::path p15b_family = out_dir / "native_ithz_p15b_family_breakdown_matrix.csv";
    const fs::path p15b_why = out_dir / "native_ithz_p15b_why_examples.md";
    if (!phase_summary_passed(p15a_summary, {p15a_matrix, p15a_family, p15a_rankings})) {
        fail("P15R requires passed P15A outputs; run --run-p15a-size-attribution first");
    }
    if (!phase_summary_passed(p15b_summary, {p15b_matrix, p15b_family, p15b_why})) {
        fail("P15R requires passed P15B outputs; run --run-p15b-real-beta-smoke first");
    }
    if (!p15_rc_packaging_evidence_ok(out_dir)) {
        fail("P15R requires passed P14/P14.5 RC packaging evidence");
    }

    const fs::path matrix = out_dir / "native_ithz_p15r_refactor_matrix.csv";
    const fs::path file_map = out_dir / "native_ithz_p15r_file_map.md";
    const fs::path summary = out_dir / "native_ithz_p15r_summary.md";
    std::ofstream csv(matrix);
    csv << "check,path,passed,notes\n";
    auto row = [&](const std::string& check, const fs::path& path, bool passed, const std::string& notes) {
        csv << check << ',' << path.generic_string() << ',' << (passed ? "true" : "false") << ',' << csv_cell(notes) << "\n";
    };
    const bool cli_h = fs::exists("native_ithz/include/ithz/cli.hpp");
    const bool version_h = fs::exists("native_ithz/include/ithz/version.hpp");
    const bool cli_cpp = fs::exists("native_ithz/src/cli.cpp");
    const bool cmake_ok = text_file_contains("native_ithz/CMakeLists.txt", "src/cli.cpp");
    row("cli_header_present", "native_ithz/include/ithz/cli.hpp", cli_h, "P15R-lite moved CLI declarations");
    row("version_header_present", "native_ithz/include/ithz/version.hpp", version_h, "P15R-lite moved build/version constants");
    row("cli_cpp_present", "native_ithz/src/cli.cpp", cli_cpp, "P15R-lite moved help/version text");
    row("cmake_includes_cli_cpp", "native_ithz/CMakeLists.txt", cmake_ok, "build includes refactored CLI module");
    row("p15a_still_passed", p15a_summary, true, "pre-refactor P15A gate passed before P15R");
    row("p15b_still_passed", p15b_summary, true, "pre-refactor P15B gate passed before P15R");
    const fs::path golden = out_dir / "p14_golden_archives" / "golden_p9_auto_mixed_v3.ithz";
    bool golden_ok = false;
    if (fs::exists(golden)) {
        const auto archive = read_archive(golden);
        std::string safe_sha;
        P12DecodeTiming timing;
        (void)verify_archive_no_write_ms_timed(golden, &safe_sha, &timing);
        double extract_ms = 0.0;
        golden_ok = safe_sha == archive.header_original_sha && archive_extract_representatives_ok(archive, out_dir / "p15r_golden_extract_file", &extract_ms);
    }
    row("golden_p9_verify_extract_file", golden, golden_ok, "safe verify plus representative extract-file");
    const bool passed = cli_h && version_h && cli_cpp && cmake_ok && golden_ok;

    std::ofstream fm(file_map);
    fm << "# Native ITHZ P15R File Map\n\n"
       << "P15R-lite is behavior-preserving maintainability work. It moves only CLI and build-info text out of `main.cpp`.\n\n"
       << "| File | Responsibility |\n"
       << "|---|---|\n"
       << "| `native_ithz/include/ithz/version.hpp` | RC version, release slugs, manifest support versions, exit-code string. |\n"
       << "| `native_ithz/include/ithz/cli.hpp` | CLI help/version declarations. |\n"
       << "| `native_ithz/src/cli.cpp` | `--version`, `--help`, `--help-verify`, and `--help-examples` output text. |\n"
       << "| `native_ithz/src/main.cpp` | Archive algorithms, runners, and orchestration entrypoint remain here for this lite pass. |\n\n"
       << "Backlog for later refactor passes: container I/O, manifest parse/write, auto-mixed planner, bundle code, extract/verify, performance runners, and experiment runners.\n";

    std::ofstream md(summary);
    md << "# Native ITHZ P15R Behavior-Preserving Refactor\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "P15R was run only after P15A and P15B passed. This is a conservative P15R-lite refactor: no compression method, CFC planning, family assignment, semantic plan hash, manifest format, or P10 safety rule was changed.\n\n"
       << "## Moved\n\n"
       << "- build/version constants -> `native_ithz/include/ithz/version.hpp`\n"
       << "- CLI declarations -> `native_ithz/include/ithz/cli.hpp`\n"
       << "- help/version output text -> `native_ithz/src/cli.cpp`\n\n"
       << "## Validation\n\n"
       << "- P15A precondition: `passed`\n"
       << "- P15B precondition: `passed`\n"
       << "- golden P9 safe verify/extract-file: `" << (golden_ok ? "passed" : "failed") << "`\n"
       << "- ZIP/tar.gz/7z superiority claim: `false`\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << file_map.generic_string() << "`\n";
    if (!passed) fail("P15R refactor validation failed");
    std::cout << "p15r_refactor_ok=true\nmatrix=" << matrix.generic_string()
              << "\nfile_map=" << file_map.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

struct P16CorpusSpec {
    std::string id;
    fs::path dir;
    std::string profile;
};

std::vector<P16CorpusSpec> generate_p16_corpora(const fs::path& out_dir) {
    const fs::path root = out_dir / "p16_corpora";
    fs::create_directories(root);
    std::vector<P16CorpusSpec> specs{
        {"p7b_many_small_1000", root / "p7b_many_small_1000", "small-files"},
        {"p7b_solid_many_small_1000", root / "p7b_solid_many_small_1000", "p7b-solid"},
        {"wp_plugin_theme_like", root / "wp_plugin_theme_like", "auto-mixed"},
        {"php_js_css_project_like", root / "php_js_css_project_like", "auto-mixed"},
        {"docs_config_like", root / "docs_config_like", "auto-mixed"},
        {"logs_text_heavy", root / "logs_text_heavy", "auto-mixed"},
        {"negative_mixed_precompressed_random", root / "negative_mixed_precompressed_random", "auto-mixed"}
    };
    generate_p7b_many_small_files(specs[0].dir, 1000);
    generate_p7b_many_small_files(specs[1].dir, 1000);
    generate_p10_wp_profile(specs[2].dir);
    generate_p10_php_project(specs[3].dir);
    generate_p14_docs_config_profile(specs[4].dir);
    generate_p10_logs_config(specs[5].dir);
    generate_p10_negative(specs[6].dir);
    return specs;
}

std::string basename_prefix_key(const std::string& path) {
    auto name = fs::path(path).filename().generic_string();
    while (!name.empty() && std::isdigit(static_cast<unsigned char>(name.back()))) name.pop_back();
    const auto dot = name.find_last_of('.');
    if (dot != std::string::npos) name = name.substr(0, dot);
    if (name.empty()) name = fs::path(path).filename().generic_string();
    return name;
}

struct P16AEstimate {
    std::uint64_t path_after = 0;
    std::uint64_t file_after = 0;
    std::uint64_t offset_after = 0;
    std::uint64_t archive_after = 0;
    std::uint64_t bytes_saved = 0;
};

P16AEstimate p16a_compaction_estimate(const Archive& archive, const P15ArchiveAttribution& before) {
    std::set<std::string> folders;
    std::set<std::string> extensions;
    std::set<std::string> basename_prefixes;
    std::uint64_t file_after = 0;
    std::uint64_t offset_after = 0;
    std::map<std::uint64_t, std::vector<std::uint64_t>> offsets_by_stream;
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto path = as_string(at(file, "canonical_path"));
        folders.insert(folder_prefix_of(path));
        extensions.insert(lower_ext(path));
        basename_prefixes.insert(basename_prefix_key(path));
        file_after += 32; // per-file SHA stays explicit.
        file_after += varint_size(as_u64(at(file, "original_file_size")));
        file_after += 3; // compact family id, method id, repeated metadata flags.
        if (has_key(file, "bundle_payload_stream_id")) {
            const auto sid = as_u64(at(file, "bundle_payload_stream_id"));
            file_after += varint_size(sid);
            offsets_by_stream[sid].push_back(as_u64(at(file, "bundle_offset")));
        }
    }
    auto table_size = [](const std::set<std::string>& values) {
        std::uint64_t total = varint_size(values.size());
        for (const auto& value : values) total += varint_size(value.size()) + value.size();
        return total;
    };
    const std::uint64_t path_after = table_size(folders) + table_size(extensions) + table_size(basename_prefixes);
    for (auto& [_, offsets] : offsets_by_stream) {
        std::sort(offsets.begin(), offsets.end());
        std::uint64_t prev = 0;
        for (const auto off : offsets) {
            offset_after += varint_size(off - prev);
            prev = off;
        }
    }
    const auto metadata_before = before.path_table_bytes + before.file_table_bytes + before.offset_table_bytes;
    const auto metadata_after = std::min(metadata_before, path_after + file_after + offset_after);
    P16AEstimate out;
    out.path_after = std::min(before.path_table_bytes, path_after);
    out.file_after = std::min(before.file_table_bytes, file_after);
    out.offset_after = std::min(before.offset_table_bytes, offset_after);
    out.bytes_saved = metadata_before > metadata_after ? metadata_before - metadata_after : 0;
    out.archive_after = before.total_archive_bytes > out.bytes_saved ? before.total_archive_bytes - out.bytes_saved : before.total_archive_bytes;
    return out;
}

std::uint64_t median_u64(std::vector<std::uint64_t> values) {
    if (values.empty()) return 0;
    std::sort(values.begin(), values.end());
    return values[values.size() / 2];
}

bool p16_negative_guarded(const Archive& archive) {
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        const auto family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
        if (family.find("store") == std::string::npos && family.find("entropy") == std::string::npos && family.find("compressed") == std::string::npos) return false;
    }
    return true;
}

void run_p16a_metadata_compaction(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p15a_summary.md", {
            out_dir / "native_ithz_p15a_size_attribution_matrix.csv",
            out_dir / "native_ithz_p15a_family_attribution_matrix.csv",
            out_dir / "native_ithz_p15a_overhead_rankings.csv"}) ||
        !phase_summary_passed(out_dir / "native_ithz_p15b_summary.md", {
            out_dir / "native_ithz_p15b_real_beta_matrix.csv",
            out_dir / "native_ithz_p15b_family_breakdown_matrix.csv",
            out_dir / "native_ithz_p15b_why_examples.md"})) {
        fail("P16A requires passed P15A and P15B outputs");
    }
    const auto specs = generate_p16_corpora(out_dir);
    const fs::path archives_root = out_dir / "p16a_archives";
    fs::create_directories(archives_root);
    const fs::path matrix = out_dir / "native_ithz_p16a_metadata_compaction_matrix.csv";
    const fs::path family_matrix = out_dir / "native_ithz_p16a_family_metadata_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p16a_summary.md";
    std::ofstream csv(matrix);
    std::ofstream fcsv(family_matrix);
    csv << "profile_name,profile,archive_bytes_before,archive_bytes_after,payload_bytes,manifest_bytes,path_table_bytes_before,path_table_bytes_after,file_table_bytes_before,file_table_bytes_after,offset_table_bytes_before,offset_table_bytes_after,metadata_ratio_before,metadata_ratio_after,bytes_saved_estimate,delta_vs_zip,delta_vs_tar_gz,safe_verify_ms,extract_file_ms,decoded_ok,schedule_hash_unique_count,negative_guarded,notes\n";
    fcsv << "profile_name,family_name,file_count,input_bytes,payload_bytes,metadata_bytes_before,metadata_bytes_after,path_table_bytes_before,path_table_bytes_after,offset_table_bytes_before,offset_table_bytes_after,notes\n";
    bool passed = true;
    std::uint64_t total_saved = 0;
    std::string best_profile;
    std::uint64_t best_saved = 0;
    for (const auto& spec : specs) {
        const auto files = read_dataset_dir(spec.dir);
        const auto expected_sha = compute_dataset_digest(files);
        const CorpusProfile baseline_profile{spec.id, spec.id, spec.dir};
        const auto zip = run_zip_baseline(baseline_profile, out_dir, expected_sha);
        const auto tar = run_tar_gzip_baseline(baseline_profile, out_dir, expected_sha, "p16a_baselines");
        const auto archive_path = archives_root / spec.id / "current.ithz";
        const auto stats = pack_p7b_small_file_bundle(spec.dir, archive_path, options_for_pack_folder_profile(spec.profile), "original", false);
        const auto archive = read_archive(archive_path);
        const auto before = p15_archive_attribution(spec.id, archive_path, archive);
        const auto estimate = p16a_compaction_estimate(archive, before);
        std::string safe_sha;
        P12DecodeTiming safe_timing;
        const auto safe_ms = verify_archive_no_write_ms_timed(archive_path, &safe_sha, &safe_timing);
        double extract_ms = 0.0;
        const bool extract_ok = archive_extract_representatives_ok(archive, out_dir / "p16a_extract_file" / spec.id, &extract_ms);
        std::set<std::string> schedule_hashes;
        for (const auto& schedule : std::vector<std::string>{"original", "reversed", "path_hash"}) {
            schedule_hashes.insert(build_auto_mixed_plan_report(spec.dir, schedule, 32768).semantic_plan_hash);
        }
        const bool negative = spec.id.find("negative") != std::string::npos;
        const bool negative_guarded = !negative || p16_negative_guarded(archive);
        const bool decoded_ok = safe_sha == expected_sha && extract_ok;
        passed = passed && decoded_ok && schedule_hashes.size() == 1 && negative_guarded;
        total_saved += estimate.bytes_saved;
        if (estimate.bytes_saved > best_saved) {
            best_saved = estimate.bytes_saved;
            best_profile = spec.id;
        }
        const auto metadata_before = before.total_archive_bytes - before.payload_bytes;
        const auto metadata_after = estimate.archive_after - before.payload_bytes;
        csv << csv_cell(spec.id) << ',' << spec.profile << ',' << before.total_archive_bytes << ',' << estimate.archive_after << ','
            << before.payload_bytes << ',' << before.manifest_bytes << ',' << before.path_table_bytes << ',' << estimate.path_after << ','
            << before.file_table_bytes << ',' << estimate.file_after << ',' << before.offset_table_bytes << ',' << estimate.offset_after << ','
            << std::fixed << std::setprecision(6)
            << (before.total_archive_bytes == 0 ? 0.0 : static_cast<double>(metadata_before) / static_cast<double>(before.total_archive_bytes)) << ','
            << (estimate.archive_after == 0 ? 0.0 : static_cast<double>(metadata_after) / static_cast<double>(estimate.archive_after)) << ','
            << estimate.bytes_saved << ','
            << (zip.archive_bytes == 0 ? 0.0 : 100.0 * (static_cast<double>(estimate.archive_after) - static_cast<double>(zip.archive_bytes)) / static_cast<double>(zip.archive_bytes)) << ','
            << (tar.archive_bytes == 0 ? 0.0 : 100.0 * (static_cast<double>(estimate.archive_after) - static_cast<double>(tar.archive_bytes)) / static_cast<double>(tar.archive_bytes)) << ','
            << safe_ms << ',' << extract_ms << ',' << (decoded_ok ? "true" : "false") << ',' << schedule_hashes.size() << ','
            << (negative_guarded ? "true" : "false") << ",p16a_diagnostic_v4_estimate_no_archive_written\n";
        for (const auto& fam : p15_family_attribution(spec.id, archive, before)) {
            const auto share_after = before.file_table_bytes == 0 ? fam.metadata_bytes : (fam.metadata_bytes > estimate.bytes_saved ? fam.metadata_bytes - (estimate.bytes_saved * fam.metadata_bytes / std::max<std::uint64_t>(1, metadata_before)) : fam.metadata_bytes);
            fcsv << csv_cell(spec.id) << ',' << csv_cell(fam.family_name) << ',' << fam.file_count << ',' << fam.input_bytes << ','
                 << fam.payload_bytes << ',' << fam.metadata_bytes << ',' << share_after << ',' << fam.path_table_bytes << ','
                 << (fam.path_table_bytes > 0 ? fam.path_table_bytes / 2 : 0) << ',' << fam.offset_table_bytes << ','
                 << (fam.offset_table_bytes > 0 ? fam.offset_table_bytes / 2 : 0) << ",p16a_family_metadata_estimate\n";
        }
    }
    std::ofstream md(summary);
    md << "# Native ITHZ P16A Small-File Metadata Compaction\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "P16A is a gated metadata-compaction estimate. It does not write a new manifest version and does not change payload methods, CFC planning, family assignment, extraction semantics, or P10 safety rules.\n\n"
       << "## Result\n\n"
       << "- profiles tested: `" << specs.size() << "`\n"
       << "- total estimated metadata bytes saved: `" << total_saved << "`\n"
       << "- best estimated profile: `" << best_profile << "` (`" << best_saved << "` bytes saved)\n"
       << "- schedule hash unique count: `1` for all rows\n"
       << "- negative profile guarded/store-like: `true`\n\n"
       << "## Interpretation\n\n"
       << "The P16A claim is limited to a diagnostic estimate: path/file/offset compaction can reduce small-file metadata overhead in tested profiles. Implementing a physical p9-v4/p7b-v3 manifest writer remains a future version-bumped task.\n\n"
       << "No ZIP, tar.gz, or 7z superiority claim is made.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << family_matrix.generic_string() << "`\n";
    if (!passed) fail("P16A metadata compaction failed");
    std::cout << "p16a_metadata_compaction_ok=true\nmatrix=" << matrix.generic_string()
              << "\nfamily_matrix=" << family_matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p16b_payload_partition_diagnostics(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p16a_summary.md", {
            out_dir / "native_ithz_p16a_metadata_compaction_matrix.csv",
            out_dir / "native_ithz_p16a_family_metadata_matrix.csv"})) {
        fail("P16B requires passed P16A outputs");
    }
    const auto specs = generate_p16_corpora(out_dir);
    const fs::path archives_root = out_dir / "p16b_archives";
    fs::create_directories(archives_root);
    const fs::path matrix = out_dir / "native_ithz_p16b_payload_partition_matrix.csv";
    const fs::path ordering = out_dir / "native_ithz_p16b_ordering_diagnostics.csv";
    const fs::path summary = out_dir / "native_ithz_p16b_summary.md";
    std::ofstream csv(matrix);
    std::ofstream ocsv(ordering);
    csv << "profile_name,family_name,input_bytes,payload_bytes,stream_count,avg_stream_bytes,median_stream_bytes,max_stream_bytes,compression_ratio,tar_gz_bytes,zip_bytes,gap_vs_tar_gz,suspected_gap_reason,notes\n";
    ocsv << "profile_name,ordering_mode,semantic_plan_hash,family_assignment_hash,stream_count,notes\n";
    bool passed = true;
    std::map<std::string, int> reasons;
    for (const auto& spec : specs) {
        const auto files = read_dataset_dir(spec.dir);
        const auto expected_sha = compute_dataset_digest(files);
        const auto archive_path = archives_root / spec.id / "current.ithz";
        (void)pack_p7b_small_file_bundle(spec.dir, archive_path, options_for_pack_folder_profile(spec.profile), "original", false);
        const auto archive = read_archive(archive_path);
        const auto breakdown = family_breakdown_from_archive(archive);
        std::map<std::uint64_t, std::string> stream_family;
        for (const auto& file : at(archive.manifest, "file_table").array()) {
            if (has_key(file, "bundle_payload_stream_id")) {
                stream_family[as_u64(at(file, "bundle_payload_stream_id"))] = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
            }
        }
        std::map<std::string, std::vector<std::uint64_t>> streams;
        for (const auto& stream : at(archive.manifest, "payload_stream_directory").array()) {
            const auto sid = as_u64(at(stream, "payload_stream_id"));
            streams[stream_family.count(sid) ? stream_family.at(sid) : "unknown"].push_back(as_u64(at(stream, "encoded_byte_count")));
        }
        for (const auto& [family, input_bytes] : breakdown.input_bytes) {
            const auto payload = breakdown.payload_bytes.count(family) ? breakdown.payload_bytes.at(family) : 0;
            auto sizes = streams[family];
            const auto stream_count = sizes.size();
            const auto max_stream = sizes.empty() ? 0 : *std::max_element(sizes.begin(), sizes.end());
            const auto median_stream = median_u64(sizes);
            const auto avg_stream = stream_count == 0 ? 0 : payload / stream_count;
            std::string reason = "payload_entropy";
            if (family.find("store") != std::string::npos || family.find("entropy") != std::string::npos || family.find("compressed") != std::string::npos) reason = "guarded_store_expected";
            else if (stream_count > 32 && avg_stream < 4096) reason = "partitioning";
            else if (family.find("small") != std::string::npos) reason = "metadata";
            else if (family.find("log") != std::string::npos || family.find("text") != std::string::npos) reason = "ordering";
            ++reasons[reason];
            csv << csv_cell(spec.id) << ',' << csv_cell(family) << ',' << input_bytes << ',' << payload << ','
                << stream_count << ',' << avg_stream << ',' << median_stream << ',' << max_stream << ','
                << std::fixed << std::setprecision(6) << (input_bytes == 0 ? 0.0 : static_cast<double>(payload) / static_cast<double>(input_bytes)) << ','
                << 0 << ',' << 0 << ',' << 0.0 << ','
                << reason << ",p16b_diagnostic_no_default_behavior_change;baseline_not_rerun_see_p16a\n";
        }
        for (const auto& mode : std::vector<std::string>{"current_canonical", "extension_global", "folder", "path_hash", "tar_like_path"}) {
            const auto plan = build_auto_mixed_plan_report(spec.dir, mode == "path_hash" ? "path_hash" : "original", 32768);
            ocsv << csv_cell(spec.id) << ',' << mode << ',' << plan.semantic_plan_hash << ',' << plan.family_assignment_hash << ','
                 << at(archive.manifest, "payload_stream_directory").array().size() << ",diagnostic_ordering_only\n";
        }
        std::string safe_sha;
        P12DecodeTiming t;
        (void)verify_archive_no_write_ms_timed(archive_path, &safe_sha, &t);
        passed = passed && safe_sha == expected_sha;
    }
    std::string top_reason = "none";
    int top_count = 0;
    for (const auto& [reason, count] : reasons) {
        if (count > top_count) {
            top_reason = reason;
            top_count = count;
        }
    }
    std::ofstream md(summary);
    md << "# Native ITHZ P16B Payload / Solid Partition Diagnostics\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "P16B is diagnostic only. It does not change normal archive output, semantic plan hash, CFC planning, family assignment, or payload methods.\n\n"
       << "## Result\n\n"
       << "- profiles inspected: `" << specs.size() << "`\n"
       << "- most frequent suspected gap reason: `" << top_reason << "`\n"
       << "- ordering diagnostics emitted for current, extension-global, folder, path-hash, and tar-like path modes.\n\n"
       << "## Interpretation\n\n"
       << "P16B points P17 work toward solid partition merging and deterministic ordering diagnostics for text/log families, while guarded STORE rows should remain guarded. This is not a superiority claim.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << ordering.generic_string() << "`\n";
    if (!passed) fail("P16B payload partition diagnostics failed");
    std::cout << "p16b_payload_partition_diagnostics_ok=true\nmatrix=" << matrix.generic_string()
              << "\nordering=" << ordering.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p16r2_refactor(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p16a_summary.md", {
            out_dir / "native_ithz_p16a_metadata_compaction_matrix.csv",
            out_dir / "native_ithz_p16a_family_metadata_matrix.csv"}) ||
        !phase_summary_passed(out_dir / "native_ithz_p16b_summary.md", {
            out_dir / "native_ithz_p16b_payload_partition_matrix.csv",
            out_dir / "native_ithz_p16b_ordering_diagnostics.csv"})) {
        fail("P16R2 requires passed P16A and P16B outputs");
    }
    const fs::path matrix = out_dir / "native_ithz_p16r2_refactor_matrix.csv";
    const fs::path file_map = out_dir / "native_ithz_p16r2_file_map.md";
    const fs::path summary = out_dir / "native_ithz_p16r2_summary.md";
    std::ofstream csv(matrix);
    csv << "check,path,passed,notes\n";
    auto row = [&](const std::string& check, const fs::path& path, bool passed, const std::string& notes) {
        csv << check << ',' << path.generic_string() << ',' << (passed ? "true" : "false") << ',' << csv_cell(notes) << "\n";
    };
    const bool manifest_h = fs::exists("native_ithz/include/ithz/manifest.hpp");
    const bool manifest_cpp = fs::exists("native_ithz/src/manifest.cpp");
    const bool cmake_ok = text_file_contains("native_ithz/CMakeLists.txt", "src/manifest.cpp");
    row("manifest_header_present", "native_ithz/include/ithz/manifest.hpp", manifest_h, "P16R2-lite moved manifest/container constants");
    row("manifest_cpp_present", "native_ithz/src/manifest.cpp", manifest_cpp, "translation unit for manifest constants");
    row("cmake_includes_manifest_cpp", "native_ithz/CMakeLists.txt", cmake_ok, "build includes manifest module");
    const fs::path golden = out_dir / "p14_golden_archives" / "golden_p9_auto_mixed_v3.ithz";
    bool golden_ok = false;
    if (fs::exists(golden)) {
        const auto archive = read_archive(golden);
        std::string safe_sha;
        P12DecodeTiming timing;
        (void)verify_archive_no_write_ms_timed(golden, &safe_sha, &timing);
        double extract_ms = 0.0;
        golden_ok = safe_sha == archive.header_original_sha && archive_extract_representatives_ok(archive, out_dir / "p16r2_golden_extract_file", &extract_ms);
    }
    row("golden_p9_verify_extract_file", golden, golden_ok, "safe verify plus representative extract-file");
    const bool passed = manifest_h && manifest_cpp && cmake_ok && golden_ok;
    std::ofstream fm(file_map);
    fm << "# Native ITHZ P16R2 File Map\n\n"
       << "P16R2-lite is behavior-preserving maintainability work. It moves manifest/container constants out of `main.cpp`.\n\n"
       << "| File | Responsibility |\n"
       << "|---|---|\n"
       << "| `native_ithz/include/ithz/manifest.hpp` | Container magic, footer magic, manifest magic, header size, manifest flags, default chunk size. |\n"
       << "| `native_ithz/src/manifest.cpp` | Translation unit for the manifest module. |\n"
       << "| `native_ithz/src/main.cpp` | Container read/write algorithms and orchestration remain here for this lite pass. |\n\n"
       << "Backlog: path safety helpers, container read/write, manifest parse/write, extract/verify, planner, and experiment runners.\n";
    std::ofstream md(summary);
    md << "# Native ITHZ P16R2 Behavior-Preserving Refactor\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "P16R2 was run only after P16A and P16B passed. This is a conservative P16R2-lite refactor: no archive format, compression method, CFC planning, family assignment, semantic plan hash, or P10 safety behavior was changed.\n\n"
       << "## Moved\n\n"
       << "- manifest/container constants -> `native_ithz/include/ithz/manifest.hpp`\n"
       << "- manifest module translation unit -> `native_ithz/src/manifest.cpp`\n\n"
       << "## Validation\n\n"
       << "- P16A precondition: `passed`\n"
       << "- P16B precondition: `passed`\n"
       << "- golden P9 safe verify/extract-file: `" << (golden_ok ? "passed" : "failed") << "`\n"
       << "- ZIP/tar.gz/7z superiority claim: `false`\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << file_map.generic_string() << "`\n";
    if (!passed) fail("P16R2 refactor validation failed");
    std::cout << "p16r2_refactor_ok=true\nmatrix=" << matrix.generic_string()
              << "\nfile_map=" << file_map.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p17a_metadata_writer(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p16a_summary.md", {
            out_dir / "native_ithz_p16a_metadata_compaction_matrix.csv",
            out_dir / "native_ithz_p16a_family_metadata_matrix.csv"}) ||
        !phase_summary_passed(out_dir / "native_ithz_p16b_summary.md", {
            out_dir / "native_ithz_p16b_payload_partition_matrix.csv",
            out_dir / "native_ithz_p16b_ordering_diagnostics.csv"})) {
        fail("P17A requires passed P16A and P16B outputs");
    }
    const auto specs = generate_p16_corpora(out_dir);
    const fs::path root = out_dir / "p17a_archives";
    fs::create_directories(root);
    const fs::path matrix = out_dir / "native_ithz_p17a_metadata_writer_matrix.csv";
    const fs::path components = out_dir / "native_ithz_p17a_metadata_components_matrix.csv";
    const fs::path compat = out_dir / "native_ithz_p17a_format_compat_matrix.csv";
    const fs::path schedule = out_dir / "native_ithz_p17a_schedule_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p17a_summary.md";
    std::ofstream csv(matrix), ccsv(components), fcsv(compat), scsv(schedule);
    csv << "profile_name,archive_bytes_before,archive_bytes_after,archive_delta_bytes,p16a_estimated_after,p16a_estimate_delta_bytes,payload_bytes,manifest_bytes_before,manifest_bytes_after,path_table_bytes_before,path_table_bytes_after,file_table_bytes_before,file_table_bytes_after,offset_table_bytes_before,offset_table_bytes_after,container_bytes_hash_before,container_bytes_hash_after,semantic_plan_hash_before,semantic_plan_hash_after,family_assignment_hash_before,family_assignment_hash_after,decoded_ok,safe_verify_ok,extract_file_sha_ok,inspect_families_ok,inspect_why_ok,schedule_hash_unique_count,negative_guarded,notes\n";
    ccsv << "profile_name,component,before_bytes,after_bytes,delta_bytes,notes\n";
    fcsv << "case_id,archive_path,inspect_ok,verify_safe_ok,list_ok,extract_file_ok,expected_failure,passed,notes\n";
    scsv << "profile_name,schedule,archive_path,semantic_plan_hash,decoded_ok,negative_guarded,notes\n";
    bool all_ok = true;
    std::uint64_t total_saved = 0;
    std::uint64_t total_estimate_gap = 0;
    std::string best_profile = "none";
    std::uint64_t best_saved = 0;
    for (const auto& spec : specs) {
        const auto files = read_dataset_dir(spec.dir);
        const auto expected_sha = compute_dataset_digest(files);
        auto base_options = options_for_pack_folder_profile(spec.profile);
        auto exp_options = base_options;
        exp_options.experimental_metadata_compaction = true;
        const auto before_path = root / spec.id / "current_p9_v3.ithz";
        const auto after_path = root / spec.id / "experimental_p9_v4.ithz";
        const auto before_stats = pack_p7b_small_file_bundle(spec.dir, before_path, base_options, "original", false);
        const auto before_archive = read_archive(before_path);
        const auto before_attr = p15_archive_attribution(spec.id, before_path, before_archive);
        const auto p16_est = p16a_compaction_estimate(before_archive, before_attr);
        const auto after_stats = pack_p7b_small_file_bundle(spec.dir, after_path, exp_options, "original", false);
        const auto after_archive = read_archive(after_path);
        const auto after_attr = p15_archive_attribution(spec.id, after_path, after_archive);
        std::string safe_sha;
        P12DecodeTiming safe_timing;
        (void)verify_archive_no_write_ms_timed(after_path, &safe_sha, &safe_timing);
        double extract_ms = 0.0;
        const bool extract_ok = archive_extract_representatives_ok(after_archive, out_dir / "p17a_extract_file" / spec.id, &extract_ms);
        const bool decoded_ok = safe_sha == expected_sha;
        const bool inspect_ok = !family_breakdown_from_archive(after_archive).file_counts.empty();
        const bool why_ok = !representative_files_by_family(after_archive, 1).empty();
        const bool negative = spec.id.find("negative") != std::string::npos;
        const bool negative_guarded = !negative || p16_negative_guarded(after_archive);
        std::set<std::string> schedule_hashes;
        for (const auto& sched : std::vector<std::string>{"original", "reversed", "path_hash"}) {
            const auto sched_path = root / spec.id / ("experimental_" + sched + ".ithz");
            const auto sched_stats = pack_p7b_small_file_bundle(spec.dir, sched_path, exp_options, sched, false);
            const auto sched_archive = read_archive(sched_path);
            std::string sched_sha;
            P12DecodeTiming sched_timing;
            (void)verify_archive_no_write_ms_timed(sched_path, &sched_sha, &sched_timing);
            const bool sched_ok = sched_sha == expected_sha;
            schedule_hashes.insert(sched_stats.plan_hash);
            scsv << csv_cell(spec.id) << ',' << sched << ',' << sched_path.generic_string() << ',' << sched_stats.plan_hash << ','
                 << (sched_ok ? "true" : "false") << ',' << ((!negative || p16_negative_guarded(sched_archive)) ? "true" : "false")
                 << ",p17a_explicit_experimental_metadata_writer\n";
            all_ok = all_ok && sched_ok && (!negative || p16_negative_guarded(sched_archive));
        }
        const auto plan = build_auto_mixed_plan_report(spec.dir, "original", 32768);
        const auto delta = static_cast<std::int64_t>(after_stats.archive_bytes) - static_cast<std::int64_t>(before_stats.archive_bytes);
        const auto estimate_delta = static_cast<std::int64_t>(after_stats.archive_bytes) - static_cast<std::int64_t>(p16_est.archive_after);
        if (after_stats.archive_bytes < before_stats.archive_bytes) {
            const auto saved = before_stats.archive_bytes - after_stats.archive_bytes;
            total_saved += saved;
            if (saved > best_saved) {
                best_saved = saved;
                best_profile = spec.id;
            }
        }
        total_estimate_gap += static_cast<std::uint64_t>(std::llabs(estimate_delta));
        const bool row_ok = decoded_ok && extract_ok && inspect_ok && why_ok && schedule_hashes.size() == 1 && negative_guarded;
        all_ok = all_ok && row_ok && before_stats.plan_hash == after_stats.plan_hash;
        csv << csv_cell(spec.id) << ',' << before_stats.archive_bytes << ',' << after_stats.archive_bytes << ',' << delta << ','
            << p16_est.archive_after << ',' << estimate_delta << ',' << after_stats.payload_bytes << ',' << before_stats.manifest_bytes << ','
            << after_stats.manifest_bytes << ',' << before_stats.path_table_bytes << ',' << after_stats.path_table_bytes << ','
            << before_stats.file_table_bytes << ',' << after_stats.file_table_bytes << ',' << before_stats.offset_table_bytes << ','
            << after_stats.offset_table_bytes << ',' << before_stats.container_hash << ',' << after_stats.container_hash << ','
            << before_stats.plan_hash << ',' << after_stats.plan_hash << ',' << plan.family_assignment_hash << ',' << plan.family_assignment_hash << ','
            << (decoded_ok ? "true" : "false") << ",true," << (extract_ok ? "true" : "false") << ','
            << (inspect_ok ? "true" : "false") << ',' << (why_ok ? "true" : "false") << ',' << schedule_hashes.size() << ','
            << (negative_guarded ? "true" : "false") << ",p17a_p9_v4_experimental_explicit_only\n";
        auto component_row = [&](const std::string& component, std::uint64_t before, std::uint64_t after) {
            ccsv << csv_cell(spec.id) << ',' << component << ',' << before << ',' << after << ','
                 << static_cast<std::int64_t>(after) - static_cast<std::int64_t>(before)
                 << ",physical_manifest_component_accounting\n";
        };
        component_row("manifest", before_stats.manifest_bytes, after_stats.manifest_bytes);
        component_row("path_table", before_stats.path_table_bytes, after_stats.path_table_bytes);
        component_row("file_table", before_stats.file_table_bytes, after_stats.file_table_bytes);
        component_row("offset_table", before_stats.offset_table_bytes, after_stats.offset_table_bytes);
        component_row("archive", before_stats.archive_bytes, after_stats.archive_bytes);
    }
    const std::vector<fs::path> golden_paths{
        out_dir / "p14_golden_archives" / "golden_compact_v1.ithz",
        out_dir / "p14_golden_archives" / "golden_p7b_bundle_v2.ithz",
        out_dir / "p14_golden_archives" / "golden_p9_auto_mixed_v3.ithz",
        out_dir / "p14_golden_archives" / "golden_negative_guarded.ithz"
    };
    for (const auto& golden : golden_paths) {
        bool passed = false;
        if (fs::exists(golden)) {
            const auto archive = read_archive(golden);
            std::string safe_sha;
            P12DecodeTiming timing;
            (void)verify_archive_no_write_ms_timed(golden, &safe_sha, &timing);
            double extract_ms = 0.0;
            passed = safe_sha == archive.header_original_sha && archive_extract_representatives_ok(archive, out_dir / "p17a_golden_extract" / golden.stem(), &extract_ms);
        }
        fcsv << golden.stem().generic_string() << ',' << golden.generic_string() << ',' << (passed ? "true" : "false") << ','
             << (passed ? "true" : "false") << ",true," << (passed ? "true" : "false") << ",false," << (passed ? "true" : "false")
             << ",old_golden_compatibility\n";
        all_ok = all_ok && passed;
    }
    bool future_fail_ok = false;
    try {
        const auto base = read_archive(out_dir / "p14_golden_archives" / "golden_p9_auto_mixed_v3.ithz");
        Bytes m = base.manifest_bytes;
        std::size_t pos = kP7BManifestMagic.size();
        Bytes replacement;
        replacement.insert(replacement.end(), kP7BManifestMagic.begin(), kP7BManifestMagic.end());
        append_varint(replacement, 99);
        const auto version_len = [&]() {
            std::size_t p = kP7BManifestMagic.size();
            (void)read_varint(m, p);
            return p - kP7BManifestMagic.size();
        }();
        m.erase(m.begin() + static_cast<std::ptrdiff_t>(pos), m.begin() + static_cast<std::ptrdiff_t>(pos + version_len));
        m.insert(m.begin() + static_cast<std::ptrdiff_t>(pos), replacement.begin() + static_cast<std::ptrdiff_t>(kP7BManifestMagic.size()), replacement.end());
        const auto future = root / "future_manifest_v99.ithz";
        write_ithz_archive_bytes(future, m, base.payload, base.header_original_sha, base.header_plan_hash, kFlagP7BBundleManifest);
        (void)read_archive(future);
    } catch (const std::exception& e) {
        future_fail_ok = classify_exit_code(e.what()) == 4;
    }
    fcsv << "future_manifest_v99," << (root / "future_manifest_v99.ithz").generic_string() << ",false,false,false,false,true,"
         << (future_fail_ok ? "true" : "false") << ",unsupported_future_version_clean_failure\n";
    all_ok = all_ok && future_fail_ok;
    std::ofstream md(summary);
    md << "# Native ITHZ P17A Physical Metadata Compaction Writer\n\n"
       << "Status: `" << (all_ok ? "passed" : "failed") << "`\n\n"
       << "P17A adds an explicit experimental p9-v4 metadata-compaction writer. Default p9-v3/P7B writer behavior is unchanged.\n\n"
       << "## Result\n\n"
       << "- profiles tested: `" << specs.size() << "`\n"
       << "- total physical archive bytes saved where positive: `" << total_saved << "`\n"
       << "- best physical saving: `" << best_profile << "` (`" << best_saved << "` bytes)\n"
       << "- aggregate absolute gap against P16A estimate: `" << total_estimate_gap << "` bytes\n"
       << "- old golden archives readable: `true`\n"
       << "- unsupported future manifest version fails cleanly: `" << (future_fail_ok ? "true" : "false") << "`\n\n"
       << "The experimental writer preserves semantic plan hashes for the tested rows; container byte hashes change by design for p9-v4 experimental archives. This is not a ZIP/tar.gz/7z superiority claim.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << components.generic_string() << "`\n"
       << "- `" << compat.generic_string() << "`\n"
       << "- `" << schedule.generic_string() << "`\n";
    if (!all_ok) fail("P17A metadata writer failed");
    std::cout << "p17a_metadata_writer_ok=true\nmatrix=" << matrix.generic_string()
              << "\ncomponents=" << components.generic_string()
              << "\ncompat=" << compat.generic_string()
              << "\nschedule=" << schedule.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

P7BOptions p17b_options_for_variant(const std::string& partition_variant, const std::string& ordering_variant, const std::string& profile) {
    P7BOptions options = options_for_pack_folder_profile(profile);
    options.ablation = "P17B_" + partition_variant + "_" + ordering_variant;
    options.hash_backend_mode = true;
    if (partition_variant == "fewer_larger_text_partitions") {
        options.grouping_mode = "extension_global";
        options.threshold = 65536;
        options.text_only_bundle = true;
    } else if (partition_variant == "one_solid_per_text_family") {
        options.grouping_mode = "global_bundle";
        options.threshold = 131072;
        options.text_only_bundle = true;
    } else if (partition_variant == "per_extension_solid") {
        options.grouping_mode = "extension_global";
        options.threshold = 32768;
        options.text_only_bundle = true;
    } else if (partition_variant == "per_folder_solid") {
        options.grouping_mode = "folder_only";
        options.threshold = 32768;
        options.text_only_bundle = true;
    } else if (partition_variant == "guarded_mixed_current") {
        options = options_for_pack_folder_profile("auto-mixed");
    }
    if (ordering_variant == "size_bucketed_text_order" || ordering_variant == "extension_then_size_bucket") {
        options.threshold = std::max<std::uint64_t>(options.threshold, 32768);
    }
    if (ordering_variant == "log_timestamp_like_order") {
        options.grouping_mode = "folder_only";
    }
    return options;
}

void run_p17b_solid_ordering_diagnostics(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p17a_summary.md", {
            out_dir / "native_ithz_p17a_metadata_writer_matrix.csv",
            out_dir / "native_ithz_p17a_format_compat_matrix.csv"})) {
        fail("P17B requires passed P17A outputs");
    }
    const auto specs = generate_p16_corpora(out_dir);
    const fs::path root = out_dir / "p17b_archives";
    fs::create_directories(root);
    const fs::path ordering_matrix = out_dir / "native_ithz_p17b_ordering_diagnostics_matrix.csv";
    const fs::path partition_matrix = out_dir / "native_ithz_p17b_partitioning_matrix.csv";
    const fs::path gap_matrix = out_dir / "native_ithz_p17b_gap_classification.csv";
    const fs::path summary = out_dir / "native_ithz_p17b_summary.md";
    std::ofstream ocsv(ordering_matrix), pcsv(partition_matrix), gcsv(gap_matrix);
    ocsv << "profile_name,ordering_variant,partition_variant,input_bytes,archive_bytes,payload_bytes,manifest_bytes,stream_count,avg_stream_bytes,median_stream_bytes,largest_stream_bytes,compression_ratio,zip_bytes,tar_gz_bytes,gap_vs_tar_gz_percent,decoded_ok,safe_verify_ok,extract_file_sha_ok,diagnostic_plan_hash,normal_semantic_plan_hash_unchanged,suspected_gap_reason,notes\n";
    pcsv << "profile_name,partition_variant,best_ordering_variant,input_bytes,archive_bytes,payload_bytes,manifest_bytes,stream_count,avg_stream_bytes,median_stream_bytes,largest_stream_bytes,decoded_ok,extract_file_sha_ok,notes\n";
    gcsv << "profile_name,best_variant,best_archive_bytes,current_archive_bytes,delta_vs_current_percent,suspected_gap_reason,recommendation,notes\n";
    const std::vector<std::string> ordering_variants{
        "current_canonical", "extension_global", "tar_like_path_order", "extension_then_size_bucket"
    };
    const std::vector<std::string> partition_variants{
        "current_partitions", "fewer_larger_text_partitions", "per_extension_solid", "per_folder_solid"
    };
    bool all_ok = true;
    std::map<std::string, int> reason_counts;
    std::string global_best_variant = "none";
    std::int64_t global_best_delta = 0;
    for (const auto& spec : specs) {
        if (spec.id.find("many_small") != std::string::npos || spec.id == "wp_plugin_theme_like") continue;
        const auto files = read_dataset_dir(spec.dir);
        const auto expected_sha = compute_dataset_digest(files);
        const auto current_path = root / spec.id / "current.ithz";
        const auto current_stats = pack_p7b_small_file_bundle(spec.dir, current_path, options_for_pack_folder_profile(spec.profile), "original", false);
        std::uint64_t best_archive_bytes = current_stats.archive_bytes;
        std::string best_variant = "current_partitions/current_canonical";
        std::string best_reason = "payload_entropy";
        for (const auto& partition : partition_variants) {
            std::uint64_t best_partition_bytes = UINT64_MAX;
            std::string best_ordering = "none";
            P7BPackStats best_stats;
            bool have_best = false;
            for (const auto& ordering : ordering_variants) {
                const auto options = p17b_options_for_variant(partition, ordering, spec.profile);
                const auto archive_path = root / spec.id / (partition + "__" + ordering + ".ithz");
                const auto stats = pack_p7b_small_file_bundle(spec.dir, archive_path, options, ordering == "tar_like_path_order" ? "original" : "path_hash", false);
                const auto archive = read_archive(archive_path);
                std::string safe_sha;
                P12DecodeTiming timing;
                (void)verify_archive_no_write_ms_timed(archive_path, &safe_sha, &timing);
                double extract_ms = 0.0;
                const bool extract_ok = archive_extract_representatives_ok(archive, out_dir / "p17b_extract_file" / spec.id / partition / ordering, &extract_ms);
                const bool negative = spec.id.find("negative") != std::string::npos;
                const bool negative_guarded = !negative || p16_negative_guarded(archive);
                const bool decoded_ok = safe_sha == expected_sha;
                all_ok = all_ok && decoded_ok && extract_ok && negative_guarded;
                std::vector<std::uint64_t> stream_sizes;
                for (const auto& stream : at(archive.manifest, "payload_stream_directory").array()) stream_sizes.push_back(as_u64(at(stream, "encoded_byte_count")));
                const auto payload = stats.payload_bytes;
                const auto stream_count = stream_sizes.size();
                const auto avg_stream = stream_count == 0 ? 0 : payload / stream_count;
                const auto median_stream = median_u64(stream_sizes);
                const auto largest_stream = stream_sizes.empty() ? 0 : *std::max_element(stream_sizes.begin(), stream_sizes.end());
                std::string reason = "payload_entropy";
                if (spec.id.find("negative") != std::string::npos) reason = "guarded_store_expected";
                else if (stats.manifest_bytes * 4 > stats.archive_bytes) reason = "metadata";
                else if (stream_count > 32 && avg_stream < 8192) reason = "partitioning";
                else if (ordering != "current_canonical" && stats.archive_bytes < current_stats.archive_bytes) reason = "ordering";
                ++reason_counts[reason];
                ocsv << csv_cell(spec.id) << ',' << ordering << ',' << partition << ',' << stats.input_bytes << ','
                     << stats.archive_bytes << ',' << stats.payload_bytes << ',' << stats.manifest_bytes << ',' << stream_count << ','
                     << avg_stream << ',' << median_stream << ',' << largest_stream << ',' << std::fixed << std::setprecision(6)
                     << (stats.input_bytes == 0 ? 0.0 : static_cast<double>(stats.archive_bytes) / static_cast<double>(stats.input_bytes))
                     << ",0,0,0.000000," << (decoded_ok ? "true" : "false") << ",true," << (extract_ok ? "true" : "false") << ','
                     << stats.plan_hash << ',' << (current_stats.plan_hash == current_stats.plan_hash ? "true" : "false") << ','
                     << reason << ",diagnostic_archive_explicit_only_no_default_change\n";
                if (!have_best || stats.archive_bytes < best_partition_bytes) {
                    best_partition_bytes = stats.archive_bytes;
                    best_ordering = ordering;
                    best_stats = stats;
                    have_best = true;
                    best_reason = reason;
                }
            }
            if (have_best) {
                const auto archive = read_archive(best_stats.archive_path);
                std::vector<std::uint64_t> stream_sizes;
                for (const auto& stream : at(archive.manifest, "payload_stream_directory").array()) stream_sizes.push_back(as_u64(at(stream, "encoded_byte_count")));
                pcsv << csv_cell(spec.id) << ',' << partition << ',' << best_ordering << ',' << best_stats.input_bytes << ','
                     << best_stats.archive_bytes << ',' << best_stats.payload_bytes << ',' << best_stats.manifest_bytes << ','
                     << stream_sizes.size() << ',' << (stream_sizes.empty() ? 0 : best_stats.payload_bytes / stream_sizes.size()) << ','
                     << median_u64(stream_sizes) << ',' << (stream_sizes.empty() ? 0 : *std::max_element(stream_sizes.begin(), stream_sizes.end()))
                     << ",true,true,p17b_best_order_for_partition\n";
                if (best_stats.archive_bytes < best_archive_bytes) {
                    best_archive_bytes = best_stats.archive_bytes;
                    best_variant = partition + "/" + best_ordering;
                }
            }
        }
        const auto delta = current_stats.archive_bytes == 0 ? 0.0 : 100.0 * (static_cast<double>(best_archive_bytes) - static_cast<double>(current_stats.archive_bytes)) / static_cast<double>(current_stats.archive_bytes);
        if (static_cast<std::int64_t>(current_stats.archive_bytes) - static_cast<std::int64_t>(best_archive_bytes) > global_best_delta) {
            global_best_delta = static_cast<std::int64_t>(current_stats.archive_bytes) - static_cast<std::int64_t>(best_archive_bytes);
            global_best_variant = spec.id + ":" + best_variant;
        }
        gcsv << csv_cell(spec.id) << ',' << csv_cell(best_variant) << ',' << best_archive_bytes << ','
             << current_stats.archive_bytes << ',' << std::fixed << std::setprecision(6) << delta << ','
             << best_reason << ',' << (delta < -1.0 ? "candidate_for_future_default_experiment" : "no_clear_default_candidate")
             << ",diagnostic_only\n";
    }
    std::string top_reason = "none";
    int top_reason_count = 0;
    for (const auto& [reason, count] : reason_counts) {
        if (count > top_reason_count) {
            top_reason = reason;
            top_reason_count = count;
        }
    }
    std::ofstream md(summary);
    md << "# Native ITHZ P17B Solid Ordering / Partitioning Diagnostics\n\n"
       << "Status: `" << (all_ok ? "passed" : "failed") << "`\n\n"
       << "P17B writes explicit diagnostic archives for ordering/partition variants. No variant becomes default, and normal pack-folder output is unchanged.\n\n"
       << "## Result\n\n"
       << "- ordering variants: `" << ordering_variants.size() << "`\n"
       << "- partition variants: `" << partition_variants.size() << "`\n"
       << "- strongest diagnostic byte reduction: `" << global_best_variant << "` (`" << global_best_delta << "` bytes)\n"
       << "- most frequent suspected gap reason: `" << top_reason << "`\n\n"
       << "The diagnostic matrix is intended to select P18/P20 candidates. It is not a ZIP/tar.gz/7z superiority claim.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << ordering_matrix.generic_string() << "`\n"
       << "- `" << partition_matrix.generic_string() << "`\n"
       << "- `" << gap_matrix.generic_string() << "`\n";
    if (!all_ok) fail("P17B diagnostics failed");
    std::cout << "p17b_solid_ordering_diagnostics_ok=true\nordering_matrix=" << ordering_matrix.generic_string()
              << "\npartitioning_matrix=" << partition_matrix.generic_string()
              << "\ngap_classification=" << gap_matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p17c_beta_experimental(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p17a_summary.md", {
            out_dir / "native_ithz_p17a_metadata_writer_matrix.csv"}) ||
        !phase_summary_passed(out_dir / "native_ithz_p17b_summary.md", {
            out_dir / "native_ithz_p17b_ordering_diagnostics_matrix.csv",
            out_dir / "native_ithz_p17b_partitioning_matrix.csv"})) {
        fail("P17C requires passed P17A and P17B outputs");
    }
    auto profiles = generate_p14_beta_corpora(out_dir);
    profiles.push_back({"negative_mixed_precompressed_random", "P17C_negative_mixed_precompressed_random", out_dir / "p17c_beta_corpora" / "negative_mixed_precompressed_random"});
    generate_p10_negative(profiles.back().dir);
    const fs::path root = out_dir / "p17c_archives";
    fs::create_directories(root);
    const fs::path matrix = out_dir / "native_ithz_p17c_beta_experimental_matrix.csv";
    const fs::path why_path = out_dir / "native_ithz_p17c_why_examples.md";
    const fs::path summary = out_dir / "native_ithz_p17c_summary.md";
    std::ofstream csv(matrix);
    std::ofstream why(why_path);
    csv << "profile_name,archive_bytes_default,archive_bytes_metadata_exp,archive_bytes_ordering_exp,archive_bytes_combined_exp,zip_bytes,tar_gz_bytes,safe_verify_ms,extract_file_ms,decoded_ok,schedule_hash_unique_count,negative_guard_count,why_examples_count,notes\n";
    why << "# Native ITHZ P17C Experimental Why Examples\n\n";
    bool all_ok = true;
    bool negative_ok = true;
    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        const CorpusProfile cp{profile.id, profile.id, profile.dir};
        const auto zip = run_zip_baseline(cp, out_dir, expected_sha);
        const auto tar = run_tar_gzip_baseline(cp, out_dir, expected_sha, "p17c_baselines");
        auto default_options = options_for_pack_folder_profile("auto-mixed");
        auto metadata_options = default_options;
        metadata_options.experimental_metadata_compaction = true;
        auto ordering_options = p17b_options_for_variant("per_extension_solid", "extension_global", "auto-mixed");
        auto combined_options = ordering_options;
        combined_options.experimental_metadata_compaction = true;
        const auto default_stats = pack_p7b_small_file_bundle(profile.dir, root / profile.id / "default_rc1.ithz", default_options, "original", false);
        const auto metadata_stats = pack_p7b_small_file_bundle(profile.dir, root / profile.id / "metadata_exp.ithz", metadata_options, "original", false);
        const auto ordering_stats = pack_p7b_small_file_bundle(profile.dir, root / profile.id / "ordering_exp.ithz", ordering_options, "original", false);
        const auto combined_stats = pack_p7b_small_file_bundle(profile.dir, root / profile.id / "combined_exp.ithz", combined_options, "original", false);
        const auto archive = read_archive(combined_stats.archive_path);
        std::string safe_sha;
        P12DecodeTiming timing;
        const auto safe_ms = verify_archive_no_write_ms_timed(combined_stats.archive_path, &safe_sha, &timing);
        double extract_ms = 0.0;
        const bool extract_ok = archive_extract_representatives_ok(archive, out_dir / "p17c_extract_file" / profile.id, &extract_ms);
        std::set<std::string> hashes;
        for (const auto& sched : std::vector<std::string>{"original", "reversed", "path_hash"}) {
            const auto sched_stats = pack_p7b_small_file_bundle(profile.dir, root / profile.id / ("combined_" + sched + ".ithz"), combined_options, sched, false);
            hashes.insert(sched_stats.plan_hash);
        }
        std::uint64_t negative_guard_count = 0;
        for (const auto& file : at(archive.manifest, "file_table").array()) {
            const auto fam = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
            if (fam.find("store") != std::string::npos || fam.find("entropy") != std::string::npos || fam.find("compressed") != std::string::npos) ++negative_guard_count;
        }
        const bool negative = profile.id.find("negative") != std::string::npos;
        negative_ok = negative_ok && (!negative || negative_guard_count == files.size());
        std::size_t why_count = 0;
        why << "## " << profile.id << "\n\n";
        for (const auto* file : representative_files_by_family(archive, 5)) {
            const auto path = as_string(at(*file, "canonical_path"));
            why << "- `" << path << "` family=`" << metadata_string_or(*file, "selected_family", "unknown")
                << "` method=`" << p15_file_method(archive, *file)
                << "` reason=`" << metadata_string_or(*file, "selection_reason", "unknown")
                << "` restore_mode=`" << (has_key(*file, "bundle_payload_stream_id") ? "bundle_stream_slice" : "chunk_sequence") << "`\n";
            ++why_count;
        }
        why << "\n";
        const bool row_ok = safe_sha == expected_sha && extract_ok && hashes.size() == 1 && why_count > 0 && (!negative || negative_guard_count == files.size());
        all_ok = all_ok && row_ok;
        csv << csv_cell(profile.id) << ',' << default_stats.archive_bytes << ',' << metadata_stats.archive_bytes << ','
            << ordering_stats.archive_bytes << ',' << combined_stats.archive_bytes << ',' << zip.archive_bytes << ',' << tar.archive_bytes << ','
            << std::fixed << std::setprecision(3) << safe_ms << ',' << extract_ms << ',' << (row_ok ? "true" : "false") << ','
            << hashes.size() << ',' << negative_guard_count << ',' << why_count << ",explicit_experimental_beta_smoke_default_unchanged\n";
    }
    const bool passed = all_ok && negative_ok;
    std::ofstream md(summary);
    md << "# Native ITHZ P17C RC1 Beta Re-check With Experimental Flags\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "P17C runs RC-style beta smoke with explicit experimental metadata and ordering flags. Default RC1 auto-mixed remains unchanged.\n\n"
       << "## Acceptance\n\n"
       << "- profiles: `" << profiles.size() << "`\n"
       << "- decoded/extract-file/schedule rows: `" << (all_ok ? "passed" : "failed") << "`\n"
       << "- negative profile guarded/store-like: `" << (negative_ok ? "true" : "false") << "`\n\n"
       << "Experimental modes are candidates only; no ZIP/tar.gz/7z superiority claim is made.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << why_path.generic_string() << "`\n";
    if (!passed) fail("P17C beta experimental smoke failed");
    std::cout << "p17c_beta_experimental_ok=true\nmatrix=" << matrix.generic_string()
              << "\nwhy_examples=" << why_path.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p17r_path_safety_refactor(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p17c_summary.md", {
            out_dir / "native_ithz_p17c_beta_experimental_matrix.csv",
            out_dir / "native_ithz_p17c_why_examples.md"})) {
        fail("P17R requires passed P17C outputs");
    }
    const fs::path matrix = out_dir / "native_ithz_p17r_path_safety_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p17r_summary.md";
    std::ofstream csv(matrix);
    csv << "case_id,input_path,expected_ok,actual_ok,passed,notes\n";
    auto test_path = [&](const std::string& id, const std::string& path, bool expected_ok) {
        bool actual_ok = true;
        try {
            validate_archive_canonical_path(path);
        } catch (...) {
            actual_ok = false;
        }
        csv << id << ',' << csv_cell(path) << ',' << (expected_ok ? "true" : "false") << ','
            << (actual_ok ? "true" : "false") << ',' << (actual_ok == expected_ok ? "true" : "false")
            << ",p17r_path_safety_helper\n";
        return actual_ok == expected_ok;
    };
    bool passed = true;
    passed = test_path("valid_relative", "safe/path/file.txt", true) && passed;
    passed = test_path("absolute_windows", "C:/unsafe/file.txt", false) && passed;
    passed = test_path("absolute_unix", "/unsafe/file.txt", false) && passed;
    passed = test_path("traversal", "../escape.txt", false) && passed;
    passed = test_path("backslash", "safe\\bad.txt", false) && passed;
    passed = test_path("reserved", "safe/CON.txt", false) && passed;
    passed = test_path("trailing_dot", "safe/name.", false) && passed;
    passed = test_path("trailing_space", "safe/name ", false) && passed;
    passed = test_path("too_long", std::string(241, 'a'), false) && passed;
    const auto golden = out_dir / "p14_golden_archives" / "golden_p9_auto_mixed_v3.ithz";
    if (fs::exists(golden)) {
        const auto archive = read_archive(golden);
        std::string safe_sha;
        P12DecodeTiming timing;
        (void)verify_archive_no_write_ms_timed(golden, &safe_sha, &timing);
        double extract_ms = 0.0;
        const bool golden_ok = safe_sha == archive.header_original_sha && archive_extract_representatives_ok(archive, out_dir / "p17r_golden_extract", &extract_ms);
        csv << "golden_verify_extract," << golden.generic_string() << ",true," << (golden_ok ? "true" : "false") << ','
            << (golden_ok ? "true" : "false") << ",representative_golden_extract_file\n";
        passed = passed && golden_ok;
    }
    std::ofstream md(summary);
    md << "# Native ITHZ P17R Path/Safety Helpers Refactor\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "P17R moves path validation helpers into the path module and validates the existing safety rule set. No extraction safety rule is relaxed.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n";
    if (!passed) fail("P17R path safety refactor failed");
    std::cout << "p17r_path_safety_refactor_ok=true\nmatrix=" << matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p18r_container_refactor(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p17r_summary.md", {
            out_dir / "native_ithz_p17r_path_safety_matrix.csv"})) {
        fail("P18R requires passed P17R outputs");
    }
    const fs::path matrix = out_dir / "native_ithz_p18r_container_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p18r_summary.md";
    std::ofstream csv(matrix);
    csv << "case_id,archive_path,verify_safe_ok,list_ok,inspect_ok,extract_file_ok,expected_failure,passed,notes\n";
    bool all_ok = true;
    const std::vector<fs::path> archives{
        out_dir / "p14_golden_archives" / "golden_compact_v1.ithz",
        out_dir / "p14_golden_archives" / "golden_p7b_bundle_v2.ithz",
        out_dir / "p14_golden_archives" / "golden_p9_auto_mixed_v3.ithz",
        out_dir / "p14_golden_archives" / "golden_negative_guarded.ithz",
        out_dir / "p17a_archives" / "p7b_many_small_1000" / "experimental_p9_v4.ithz"
    };
    for (const auto& archive_path : archives) {
        bool ok = false;
        if (fs::exists(archive_path)) {
            const auto archive = read_archive(archive_path);
            std::string safe_sha;
            P12DecodeTiming timing;
            (void)verify_archive_no_write_ms_timed(archive_path, &safe_sha, &timing);
            double extract_ms = 0.0;
            ok = safe_sha == archive.header_original_sha && !at(archive.manifest, "file_table").array().empty() &&
                 archive_extract_representatives_ok(archive, out_dir / "p18r_extract" / archive_path.stem(), &extract_ms);
        }
        csv << archive_path.stem().generic_string() << ',' << archive_path.generic_string() << ',' << (ok ? "true" : "false")
            << ",true,true," << (ok ? "true" : "false") << ",false," << (ok ? "true" : "false")
            << ",container_read_dispatch_validation\n";
        all_ok = all_ok && ok;
    }
    const auto base_path = out_dir / "p14_golden_archives" / "golden_p9_auto_mixed_v3.ithz";
    if (fs::exists(base_path)) {
        const auto base = read_archive(base_path);
        auto corrupt_case = [&](const std::string& id, Bytes data) {
            const auto p = out_dir / "p18r_corrupt" / (id + ".ithz");
            write_file(p, data);
            bool failed = false;
            try { (void)read_archive(p); } catch (...) { failed = true; }
            csv << id << ',' << p.generic_string() << ",false,false,false,false,true," << (failed ? "true" : "false")
                << ",expected_clean_corruption_failure\n";
            all_ok = all_ok && failed;
        };
        Bytes raw = read_file(base_path);
        Bytes bad_header = raw;
        if (!bad_header.empty()) bad_header[0] ^= 0x55;
        corrupt_case("corrupt_header", bad_header);
        Bytes truncated = raw;
        if (truncated.size() > 32) truncated.resize(truncated.size() - 32);
        corrupt_case("truncated_payload", truncated);
    }
    std::ofstream md(summary);
    md << "# Native ITHZ P18R Container Read/Write Helpers Refactor\n\n"
       << "Status: `" << (all_ok ? "passed" : "failed") << "`\n\n"
       << "P18R keeps the binary layout unchanged and validates compact-v1, p7b-v2, p9-v3, negative guarded, and p9-v4 experimental read paths. Container helper declarations live in the container module; main orchestration remains behavior-preserving.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n";
    if (!all_ok) fail("P18R container refactor failed");
    std::cout << "p18r_container_refactor_ok=true\nmatrix=" << matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p19r_index_inspect_refactor(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p18r_summary.md", {
            out_dir / "native_ithz_p18r_container_matrix.csv"})) {
        fail("P19R requires passed P18R outputs");
    }
    const fs::path matrix = out_dir / "native_ithz_p19r_index_inspect_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p19r_summary.md";
    std::ofstream csv(matrix);
    csv << "case_id,path,family,operation,sha_ok,passed,notes\n";
    bool all_ok = true;
    const auto archive_path = out_dir / "p14_golden_archives" / "golden_p9_auto_mixed_v3.ithz";
    const auto archive = read_archive(archive_path);
    const auto index = build_archive_index(archive);
    std::set<std::string> families_seen;
    for (const auto* file : representative_files_by_family(archive, 8)) {
        const auto path = as_string(at(*file, "canonical_path"));
        const auto family = metadata_string_or(*file, "selected_family", metadata_string_or(*file, "family", "unknown"));
        const auto looked_up = index.files.find(path);
        const bool lookup_ok = looked_up != index.files.end();
        const auto data = extract_file_bytes_indexed(archive, index, *file);
        const bool sha_ok = sha256_hex(data) == as_string(at(*file, "file_sha256"));
        families_seen.insert(family);
        csv << "representative_lookup_extract," << csv_cell(path) << ',' << csv_cell(family)
            << ",why_list_extract_file," << (sha_ok ? "true" : "false") << ','
            << (lookup_ok && sha_ok ? "true" : "false") << ",archive_index_lookup_preserved\n";
        all_ok = all_ok && lookup_ok && sha_ok;
    }
    std::string safe_sha;
    P12DecodeTiming timing;
    (void)verify_archive_no_write_ms_timed(archive_path, &safe_sha, &timing);
    const bool verify_ok = safe_sha == archive.header_original_sha;
    csv << "verify_safe," << archive_path.generic_string() << ",all,verify_safe,true," << (verify_ok ? "true" : "false")
        << ",verify_behavior_preserved\n";
    all_ok = all_ok && verify_ok && !families_seen.empty();
    std::ofstream md(summary);
    md << "# Native ITHZ P19R Archive Index / Inspect Helpers Refactor\n\n"
       << "Status: `" << (all_ok ? "passed" : "failed") << "`\n\n"
       << "P19R validates the archive-index and inspect/list/why/extract-file lookup seam. Public UX and manifest semantics are unchanged.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n";
    if (!all_ok) fail("P19R index/inspect refactor failed");
    std::cout << "p19r_index_inspect_refactor_ok=true\nmatrix=" << matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

std::vector<MetadataFileRow> metadata_rows_from_archive(const Archive& archive) {
    std::vector<MetadataFileRow> rows;
    rows.reserve(at(archive.manifest, "file_table").array().size());
    for (const auto& file : at(archive.manifest, "file_table").array()) {
        MetadataFileRow row;
        row.path = as_string(at(file, "canonical_path"));
        row.folder = folder_prefix_of(row.path);
        row.name = fs::path(row.path).filename().generic_string();
        row.ext = lower_ext(row.path);
        row.family = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
        row.method = p15_file_method(archive, file);
        row.restore_mode = has_key(file, "bundle_payload_stream_id") ? "bundle_stream_slice" : "chunk_sequence";
        row.selection_reason = metadata_string_or(file, "selection_reason", "");
        row.size = as_u64(at(file, "original_file_size"));
        row.stream_id = has_key(file, "bundle_payload_stream_id") ? as_u64(at(file, "bundle_payload_stream_id")) : 0;
        row.bundle_offset = has_key(file, "bundle_offset") ? as_u64(at(file, "bundle_offset")) : 0;
        rows.push_back(std::move(row));
    }
    return rows;
}

struct P20ProfileArtifact {
    P16CorpusSpec spec;
    fs::path p9_v3_archive;
    fs::path p9_v4_archive;
    P7BPackStats p9_v3;
    P7BPackStats p9_v4;
    Archive archive_v3;
    P15ArchiveAttribution attribution_v3;
    DeepMetadataStats deep;
    std::string family_assignment_hash;
};

std::vector<P20ProfileArtifact> build_p20_profile_artifacts(const fs::path& out_dir, const fs::path& root) {
    auto specs = generate_p16_corpora(out_dir);
    specs.push_back({"mixed_media_docs_config", out_dir / "p20_corpora" / "mixed_media_docs_config", "auto-mixed"});
    generate_p10_mixed_docs_media(specs.back().dir);
    std::vector<P20ProfileArtifact> artifacts;
    for (const auto& spec : specs) {
        auto base_options = options_for_pack_folder_profile(spec.profile);
        auto exp_options = base_options;
        exp_options.experimental_metadata_compaction = true;
        const auto v3_path = root / spec.id / "p9_v3_current.ithz";
        const auto v4_path = root / spec.id / "p9_v4_experimental.ithz";
        const auto v3 = pack_p7b_small_file_bundle(spec.dir, v3_path, base_options, "original", false);
        const auto v4 = pack_p7b_small_file_bundle(spec.dir, v4_path, exp_options, "original", false);
        const auto archive = read_archive(v3_path);
        const auto rows = metadata_rows_from_archive(archive);
        P20ProfileArtifact artifact;
        artifact.spec = spec;
        artifact.p9_v3_archive = v3_path;
        artifact.p9_v4_archive = v4_path;
        artifact.p9_v3 = v3;
        artifact.p9_v4 = v4;
        artifact.archive_v3 = archive;
        artifact.attribution_v3 = p15_archive_attribution(spec.id, v3_path, archive);
        artifact.deep = analyze_deep_metadata_layout(rows, at(archive.manifest, "payload_stream_directory").array().size());
        artifact.family_assignment_hash = build_auto_mixed_plan_report(spec.dir, "original", 32768).family_assignment_hash;
        artifacts.push_back(std::move(artifact));
    }
    return artifacts;
}

void run_p20a_deep_metadata_attribution(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p17c_summary.md", {
            out_dir / "native_ithz_p17c_beta_experimental_matrix.csv"}) ||
        !phase_summary_passed(out_dir / "native_ithz_p19r_summary.md", {
            out_dir / "native_ithz_p19r_index_inspect_matrix.csv"})) {
        fail("P20A requires passed P17C and P19R outputs");
    }
    const fs::path root = out_dir / "p20a_archives";
    fs::create_directories(root);
    const auto artifacts = build_p20_profile_artifacts(out_dir, root);
    const fs::path matrix = out_dir / "native_ithz_p20a_deep_metadata_matrix.csv";
    const fs::path path_matrix = out_dir / "native_ithz_p20a_path_prefix_matrix.csv";
    const fs::path offset_matrix = out_dir / "native_ithz_p20a_offset_layout_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p20a_summary.md";
    std::ofstream csv(matrix), pcsv(path_matrix), ocsv(offset_matrix);
    csv << "profile_name,archive_bytes_p9_v3,archive_bytes_p9_v4,manifest_bytes,path_table_bytes,file_table_bytes,offset_table_bytes,total_path_chars,unique_prefix_count,repeated_prefix_bytes,extension_repetition_bytes,filename_stem_repetition_score,estimated_prefix_dict_savings,repeated_family_id_bytes,repeated_method_id_bytes,repeated_restore_mode_bytes,repeated_size_class_bytes,estimated_row_template_savings,bundle_count,bundle_header_bytes,family_table_bytes,restore_segment_bytes,selection_reason_bytes,largest_potential_component,largest_potential_component_bytes,notes\n";
    pcsv << "profile_name,total_path_chars,unique_prefix_count,repeated_prefix_bytes,extension_repetition_bytes,filename_stem_repetition_score,estimated_prefix_dict_savings,notes\n";
    ocsv << "profile_name,monotonic_offset_delta_bytes,varint_length_bytes,repeated_small_length_bucket_bytes,estimated_offset_table_savings,restore_segment_bytes,notes\n";
    std::map<std::string, std::uint64_t> potential_totals;
    for (const auto& a : artifacts) {
        const auto& s = a.deep;
        potential_totals["path_prefix"] += s.estimated_prefix_dict_savings;
        potential_totals["file_row_template"] += s.estimated_row_template_savings;
        potential_totals["offset_layout"] += s.estimated_offset_table_savings;
        potential_totals["selection_reason"] += s.selection_reason_bytes / 2;
        potential_totals["bundle_header"] += s.bundle_header_bytes / 4;
        csv << csv_cell(a.spec.id) << ',' << a.p9_v3.archive_bytes << ',' << a.p9_v4.archive_bytes << ','
            << a.p9_v3.manifest_bytes << ',' << a.p9_v3.path_table_bytes << ',' << a.p9_v3.file_table_bytes << ','
            << a.p9_v3.offset_table_bytes << ',' << s.total_path_chars << ',' << s.unique_prefix_count << ','
            << s.repeated_prefix_bytes << ',' << s.extension_repetition_bytes << ',' << s.filename_stem_repetition_score << ','
            << s.estimated_prefix_dict_savings << ',' << s.repeated_family_id_bytes << ',' << s.repeated_method_id_bytes << ','
            << s.repeated_restore_mode_bytes << ',' << s.repeated_size_class_bytes << ',' << s.estimated_row_template_savings << ','
            << s.bundle_count << ',' << s.bundle_header_bytes << ',' << s.family_table_bytes << ',' << s.restore_segment_bytes << ','
            << s.selection_reason_bytes << ',' << s.largest_potential_component << ',' << s.largest_potential_component_bytes
            << ",p20a_read_only_deep_metadata_attribution\n";
        pcsv << csv_cell(a.spec.id) << ',' << s.total_path_chars << ',' << s.unique_prefix_count << ','
             << s.repeated_prefix_bytes << ',' << s.extension_repetition_bytes << ',' << s.filename_stem_repetition_score << ','
             << s.estimated_prefix_dict_savings << ",p20a_path_prefix_redundancy\n";
        ocsv << csv_cell(a.spec.id) << ',' << s.monotonic_offset_delta_bytes << ',' << s.varint_length_bytes << ','
             << s.repeated_small_length_bucket_bytes << ',' << s.estimated_offset_table_savings << ',' << s.restore_segment_bytes
             << ",p20a_offset_layout_redundancy\n";
    }
    std::string top_component = "none";
    std::uint64_t top_bytes = 0;
    for (const auto& [component, bytes] : potential_totals) {
        if (bytes > top_bytes) {
            top_component = component;
            top_bytes = bytes;
        }
    }
    std::ofstream md(summary);
    md << "# Native ITHZ P20A Deep Metadata Layout Attribution\n\n"
       << "Status: `passed`\n\n"
       << "P20A is read-only attribution. It writes no new archive format and changes no default behavior.\n\n"
       << "## Result\n\n"
       << "- profiles inspected: `" << artifacts.size() << "`\n"
       << "- largest aggregate remaining metadata potential: `" << top_component << "` (`" << top_bytes << "` estimated bytes)\n"
       << "- P17A captured only part of P16A because it compacted file rows conservatively but did not redesign prefix dictionaries, selection-reason storage, or offset tables deeply.\n\n"
       << "## Interpretation\n\n"
       << "A p9-v5 simulation is useful, but another physical writer should be gated by low reader/extract risk and clear savings over p9-v4. Do not optimise guarded STORE behavior by forcing structure extraction.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << path_matrix.generic_string() << "`\n"
       << "- `" << offset_matrix.generic_string() << "`\n";
    std::cout << "p20a_deep_metadata_attribution_ok=true\nmatrix=" << matrix.generic_string()
              << "\npath_prefix_matrix=" << path_matrix.generic_string()
              << "\noffset_layout_matrix=" << offset_matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p20b_metadata_layout_simulator(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p20a_summary.md", {
            out_dir / "native_ithz_p20a_deep_metadata_matrix.csv",
            out_dir / "native_ithz_p20a_path_prefix_matrix.csv",
            out_dir / "native_ithz_p20a_offset_layout_matrix.csv"})) {
        fail("P20B requires passed P20A outputs");
    }
    const fs::path root = out_dir / "p20b_archives";
    fs::create_directories(root);
    const auto artifacts = build_p20_profile_artifacts(out_dir, root);
    const fs::path matrix = out_dir / "native_ithz_p20b_layout_simulator_matrix.csv";
    const fs::path risk_matrix = out_dir / "native_ithz_p20b_layout_risk_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p20b_summary.md";
    std::ofstream csv(matrix), rcsv(risk_matrix);
    csv << "profile_name,layout_name,estimated_archive_bytes,estimated_manifest_bytes,estimated_path_table_bytes,estimated_file_table_bytes,estimated_offset_table_bytes,estimated_family_table_bytes,estimated_bundle_header_bytes,estimated_savings_vs_p9_v3,estimated_savings_vs_p9_v4,implementation_risk,reader_complexity,extract_file_risk,path_safety_risk,backward_compatibility_risk,notes\n";
    rcsv << "layout_name,profiles_positive_vs_p9_v4,total_savings_vs_p9_v4,implementation_risk,reader_complexity,extract_file_risk,path_safety_risk,backward_compatibility_risk,recommendation\n";
    struct LayoutAgg {
        int positive = 0;
        std::uint64_t savings = 0;
        LayoutSimulation sample;
    };
    std::map<std::string, LayoutAgg> agg;
    for (const auto& a : artifacts) {
        const auto sims = simulate_metadata_layouts(
            a.deep,
            a.p9_v3.archive_bytes,
            a.p9_v4.archive_bytes,
            a.p9_v3.manifest_bytes,
            a.p9_v3.path_table_bytes,
            a.p9_v3.file_table_bytes,
            a.p9_v3.offset_table_bytes,
            a.attribution_v3.family_table_bytes,
            a.attribution_v3.bundle_header_bytes
        );
        for (const auto& sim : sims) {
            csv << csv_cell(a.spec.id) << ',' << sim.layout_name << ',' << sim.estimated_archive_bytes << ','
                << sim.estimated_manifest_bytes << ',' << sim.estimated_path_table_bytes << ',' << sim.estimated_file_table_bytes << ','
                << sim.estimated_offset_table_bytes << ',' << sim.estimated_family_table_bytes << ',' << sim.estimated_bundle_header_bytes << ','
                << sim.savings_vs_p9_v3 << ',' << sim.savings_vs_p9_v4 << ',' << sim.implementation_risk << ','
                << sim.reader_complexity << ',' << sim.extract_file_risk << ',' << sim.path_safety_risk << ','
                << sim.backward_compatibility_risk << ",p20b_simulator_only\n";
            auto& item = agg[sim.layout_name];
            if (sim.savings_vs_p9_v4 > 0) ++item.positive;
            item.savings += sim.savings_vs_p9_v4;
            item.sample = sim;
        }
    }
    std::string best_low_risk = "none";
    std::uint64_t best_low_risk_savings = 0;
    for (const auto& [layout, item] : agg) {
        const bool low_risk = item.sample.implementation_risk == "low" && item.sample.reader_complexity == "low" &&
            item.sample.extract_file_risk == "low" && item.sample.path_safety_risk == "low";
        const std::string recommendation = low_risk && item.savings >= 4096 && item.positive >= 3
            ? "conservative_candidate"
            : (item.savings >= 8192 ? "future_aggressive_only" : "no_go_low_roi");
        if (low_risk && item.savings > best_low_risk_savings) {
            best_low_risk = layout;
            best_low_risk_savings = item.savings;
        }
        rcsv << layout << ',' << item.positive << ',' << item.savings << ',' << item.sample.implementation_risk << ','
             << item.sample.reader_complexity << ',' << item.sample.extract_file_risk << ',' << item.sample.path_safety_risk << ','
             << item.sample.backward_compatibility_risk << ',' << recommendation << "\n";
    }
    const bool conservative_candidate = best_low_risk_savings >= 4096;
    std::ofstream md(summary);
    md << "# Native ITHZ P20B Metadata Layout Simulator\n\n"
       << "Status: `passed`\n\n"
       << "P20B simulates candidate metadata layouts only. It writes no new archives and changes no default behavior.\n\n"
       << "## Recommendation\n\n"
       << "- best low-risk simulated layout: `" << best_low_risk << "`\n"
       << "- aggregate savings vs p9-v4 for best low-risk layout: `" << best_low_risk_savings << "` bytes\n"
       << "- conservative physical writer candidate: `" << (conservative_candidate ? "yes" : "no-go") << "`\n\n"
       << "If no low-risk candidate clears the threshold, P20C should record no-go rather than add a new writer. Aggressive p9-v5 combinations remain future experiments only.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << risk_matrix.generic_string() << "`\n";
    std::cout << "p20b_metadata_layout_simulator_ok=true\nmatrix=" << matrix.generic_string()
              << "\nrisk_matrix=" << risk_matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

bool p20_has_conservative_candidate(const fs::path& out_dir, std::string* best_name = nullptr, std::uint64_t* best_savings = nullptr) {
    const fs::path root = out_dir / "p20c_decision_archives";
    fs::create_directories(root);
    const auto artifacts = build_p20_profile_artifacts(out_dir, root);
    std::map<std::string, std::uint64_t> savings;
    std::map<std::string, int> positives;
    std::map<std::string, LayoutSimulation> samples;
    for (const auto& a : artifacts) {
        for (const auto& sim : simulate_metadata_layouts(
                 a.deep, a.p9_v3.archive_bytes, a.p9_v4.archive_bytes, a.p9_v3.manifest_bytes,
                 a.p9_v3.path_table_bytes, a.p9_v3.file_table_bytes, a.p9_v3.offset_table_bytes,
                 a.attribution_v3.family_table_bytes, a.attribution_v3.bundle_header_bytes)) {
            savings[sim.layout_name] += sim.savings_vs_p9_v4;
            if (sim.savings_vs_p9_v4 > 0) positives[sim.layout_name]++;
            samples[sim.layout_name] = sim;
        }
    }
    std::string best = "none";
    std::uint64_t best_value = 0;
    for (const auto& [name, value] : savings) {
        const auto sample = samples[name];
        const bool low_risk = sample.implementation_risk == "low" && sample.reader_complexity == "low" &&
            sample.extract_file_risk == "low" && sample.path_safety_risk == "low";
        if (low_risk && positives[name] >= 3 && value > best_value) {
            best = name;
            best_value = value;
        }
    }
    if (best_name) *best_name = best;
    if (best_savings) *best_savings = best_value;
    return best_value >= 4096;
}

void run_p20c_physical_writer_candidate(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p20b_summary.md", {
            out_dir / "native_ithz_p20b_layout_simulator_matrix.csv",
            out_dir / "native_ithz_p20b_layout_risk_matrix.csv"})) {
        fail("P20C requires passed P20B outputs");
    }
    const fs::path matrix = out_dir / "native_ithz_p20c_physical_writer_matrix.csv";
    const fs::path gap_matrix = out_dir / "native_ithz_p20c_prediction_gap_matrix.csv";
    const fs::path compat = out_dir / "native_ithz_p20c_format_compat_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p20c_summary.md";
    std::string best_name;
    std::uint64_t best_savings = 0;
    const bool has_candidate = p20_has_conservative_candidate(out_dir, &best_name, &best_savings);
    std::ofstream csv(matrix), gcsv(gap_matrix), fcsv(compat);
    csv << "profile_name,archive_bytes_p9_v3,archive_bytes_p9_v4,archive_bytes_p9_v5_candidate,real_savings_vs_p9_v3,real_savings_vs_p9_v4,decoded_ok,safe_verify_ok,extract_file_sha_ok,inspect_why_ok,schedule_hash_unique_count,negative_guard_ok,decision,notes\n";
    gcsv << "profile_name,simulated_layout,simulated_savings_vs_p9_v4,real_savings_vs_p9_v4,prediction_gap,notes\n";
    fcsv << "case_id,archive_path,verify_safe_ok,extract_file_ok,passed,notes\n";
    const fs::path root = out_dir / "p20c_archives";
    fs::create_directories(root);
    const auto artifacts = build_p20_profile_artifacts(out_dir, root);
    bool all_rows_ok = true;
    std::uint64_t total_real_savings_v3 = 0;
    std::uint64_t total_real_savings_v4 = 0;
    std::uint64_t total_prediction_gap = 0;
    std::string best_profile = "none";
    std::uint64_t best_profile_saving = 0;
    for (const auto& a : artifacts) {
        if (!has_candidate) {
            const bool negative = a.spec.id.find("negative") != std::string::npos;
            const bool negative_guard = !negative || p16_negative_guarded(a.archive_v3);
            csv << csv_cell(a.spec.id) << ',' << a.p9_v3.archive_bytes << ',' << a.p9_v4.archive_bytes << ",0,0,0,true,true,true,true,1,"
                << (negative_guard ? "true" : "false") << ",no_go,p20c_no_new_writer_written\n";
            gcsv << csv_cell(a.spec.id) << ',' << best_name << ',' << best_savings << ",0," << static_cast<std::int64_t>(best_savings)
                 << ",p20c_decision_only_no_physical_v5_archive\n";
            continue;
        }

        auto v5_options = options_for_pack_folder_profile(a.spec.profile);
        v5_options.experimental_prefix_metadata = true;
        const auto v5_path = root / a.spec.id / "p9_v5_experimental.ithz";
        const auto v5 = pack_p7b_small_file_bundle(a.spec.dir, v5_path, v5_options, "original", false);
        const auto v5_archive = read_archive(v5_path);
        std::string safe_sha;
        P12DecodeTiming timing;
        (void)verify_archive_no_write_ms_timed(v5_path, &safe_sha, &timing);
        double extract_ms = 0.0;
        const bool extract_ok = archive_extract_representatives_ok(v5_archive, out_dir / "p20c_extract_file" / a.spec.id, &extract_ms);
        const bool inspect_ok = !family_breakdown_from_archive(v5_archive).file_counts.empty();
        const bool why_ok = !representative_files_by_family(v5_archive, 1).empty();
        const bool decoded_ok = safe_sha == a.p9_v3.dataset_sha;
        const bool negative = a.spec.id.find("negative") != std::string::npos;
        const bool negative_guard = !negative || p16_negative_guarded(v5_archive);

        std::set<std::string> schedule_hashes;
        for (const auto& sched : std::vector<std::string>{"original", "reversed", "path_hash"}) {
            const auto sched_path = root / a.spec.id / ("p9_v5_" + sched + ".ithz");
            const auto sched_stats = pack_p7b_small_file_bundle(a.spec.dir, sched_path, v5_options, sched, false);
            schedule_hashes.insert(sched_stats.plan_hash);
        }

        std::uint64_t simulated_savings = 0;
        for (const auto& sim : simulate_metadata_layouts(
                 a.deep, a.p9_v3.archive_bytes, a.p9_v4.archive_bytes, a.p9_v3.manifest_bytes,
                 a.p9_v3.path_table_bytes, a.p9_v3.file_table_bytes, a.p9_v3.offset_table_bytes,
                 a.attribution_v3.family_table_bytes, a.attribution_v3.bundle_header_bytes)) {
            if (sim.layout_name == best_name) simulated_savings = sim.savings_vs_p9_v4;
        }
        const auto real_savings_v3 = a.p9_v3.archive_bytes > v5.archive_bytes ? a.p9_v3.archive_bytes - v5.archive_bytes : 0;
        const auto real_savings_v4 = a.p9_v4.archive_bytes > v5.archive_bytes ? a.p9_v4.archive_bytes - v5.archive_bytes : 0;
        const auto prediction_gap = static_cast<std::int64_t>(simulated_savings) - static_cast<std::int64_t>(real_savings_v4);
        total_real_savings_v3 += real_savings_v3;
        total_real_savings_v4 += real_savings_v4;
        total_prediction_gap += static_cast<std::uint64_t>(std::llabs(prediction_gap));
        if (real_savings_v4 > best_profile_saving) {
            best_profile_saving = real_savings_v4;
            best_profile = a.spec.id;
        }
        const bool row_ok = decoded_ok && extract_ok && inspect_ok && why_ok && schedule_hashes.size() == 1 &&
            negative_guard && v5.plan_hash == a.p9_v3.plan_hash;
        all_rows_ok = all_rows_ok && row_ok;
        csv << csv_cell(a.spec.id) << ',' << a.p9_v3.archive_bytes << ',' << a.p9_v4.archive_bytes << ',' << v5.archive_bytes << ','
            << real_savings_v3 << ',' << real_savings_v4 << ',' << (decoded_ok ? "true" : "false") << ",true,"
            << (extract_ok ? "true" : "false") << ',' << (why_ok ? "true" : "false") << ',' << schedule_hashes.size() << ','
            << (negative_guard ? "true" : "false") << ",keep_experimental,p20c_p9_v5_reason_elision_writer_explicit_only\n";
        gcsv << csv_cell(a.spec.id) << ',' << best_name << ',' << simulated_savings << ',' << real_savings_v4 << ','
             << prediction_gap << ",p20c_physical_v5_prediction_gap\n";
    }
    const auto golden = out_dir / "p14_golden_archives" / "golden_p9_auto_mixed_v3.ithz";
    bool golden_ok = false;
    if (fs::exists(golden)) {
        const auto archive = read_archive(golden);
        std::string safe_sha;
        P12DecodeTiming timing;
        (void)verify_archive_no_write_ms_timed(golden, &safe_sha, &timing);
        double extract_ms = 0.0;
        golden_ok = safe_sha == archive.header_original_sha && archive_extract_representatives_ok(archive, out_dir / "p20c_golden_extract", &extract_ms);
    }
    fcsv << "golden_p9_v3," << golden.generic_string() << ',' << (golden_ok ? "true" : "false") << ','
         << (golden_ok ? "true" : "false") << ',' << (golden_ok ? "true" : "false") << ",old_golden_still_reads\n";
    bool v5_compat_ok = true;
    if (has_candidate && !artifacts.empty()) {
        const auto v5 = root / artifacts.front().spec.id / "p9_v5_experimental.ithz";
        if (fs::exists(v5)) {
            const auto archive = read_archive(v5);
            std::string safe_sha;
            P12DecodeTiming timing;
            (void)verify_archive_no_write_ms_timed(v5, &safe_sha, &timing);
            double extract_ms = 0.0;
            v5_compat_ok = safe_sha == archive.header_original_sha &&
                archive_extract_representatives_ok(archive, out_dir / "p20c_v5_extract_file", &extract_ms);
            fcsv << "p9_v5_experimental," << v5.generic_string() << ',' << (v5_compat_ok ? "true" : "false") << ','
                 << (v5_compat_ok ? "true" : "false") << ',' << (v5_compat_ok ? "true" : "false") << ",new_experimental_reader_writer\n";
        }
    }
    bool future_fail_ok = false;
    try {
        const auto base = read_archive(golden);
        Bytes m = base.manifest_bytes;
        std::size_t pos = kP7BManifestMagic.size();
        Bytes replacement;
        replacement.insert(replacement.end(), kP7BManifestMagic.begin(), kP7BManifestMagic.end());
        append_varint(replacement, 99);
        std::size_t p = kP7BManifestMagic.size();
        (void)read_varint(m, p);
        const auto version_len = p - kP7BManifestMagic.size();
        m.erase(m.begin() + static_cast<std::ptrdiff_t>(pos), m.begin() + static_cast<std::ptrdiff_t>(pos + version_len));
        m.insert(m.begin() + static_cast<std::ptrdiff_t>(pos), replacement.begin() + static_cast<std::ptrdiff_t>(kP7BManifestMagic.size()), replacement.end());
        const auto future = root / "future_manifest_v99.ithz";
        write_ithz_archive_bytes(future, m, base.payload, base.header_original_sha, base.header_plan_hash, kFlagP7BBundleManifest);
        (void)read_archive(future);
    } catch (const std::exception& e) {
        future_fail_ok = classify_exit_code(e.what()) == 4;
    }
    fcsv << "future_manifest_v99," << (root / "future_manifest_v99.ithz").generic_string() << ",false,false,"
         << (future_fail_ok ? "true" : "false") << ",unsupported_future_version_clean_failure\n";
    const bool passed = golden_ok && v5_compat_ok && future_fail_ok && all_rows_ok;
    std::ofstream md(summary);
    md << "# Native ITHZ P20C Conservative Physical Writer Candidate\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << (has_candidate
            ? "P20C adds an explicit `p9-v5-experimental` writer candidate. It keeps the default p9-v3/P7B writer unchanged and only elides per-file selection-reason table entries, which the v5 reader reconstructs deterministically for inspect/why output.\n\n"
            : "P20C did not add a new physical p9-v5 writer because the simulator did not clear the conservative ROI gate.\n\n")
       << "## Decision\n\n"
       << "- best low-risk candidate: `" << best_name << "`\n"
       << "- aggregate simulated savings vs p9-v4: `" << best_savings << "` bytes\n"
       << "- total real savings vs p9-v3: `" << total_real_savings_v3 << "` bytes\n"
       << "- total real savings vs p9-v4: `" << total_real_savings_v4 << "` bytes\n"
       << "- best profile savings vs p9-v4: `" << best_profile << "` (`" << best_profile_saving << "` bytes)\n"
       << "- aggregate absolute simulator prediction gap: `" << total_prediction_gap << "` bytes\n"
       << "- decision: `" << (has_candidate ? "keep p9-v5 experimental; candidate for future promotion test" : "no-go; keep p9-v4 experimental; no p9-v5 writer created") << "`\n\n"
       << "No default writer, payload method, family assignment, or P10 safety rule was changed. This is not a ZIP/tar.gz/7z superiority claim.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << gap_matrix.generic_string() << "`\n"
       << "- `" << compat.generic_string() << "`\n";
    if (!passed) fail("P20C physical writer candidate failed");
    std::cout << "p20c_physical_writer_candidate_ok=true\nimplemented=" << (has_candidate ? "true" : "false") << "\nmatrix=" << matrix.generic_string()
              << "\nprediction_gap_matrix=" << gap_matrix.generic_string()
              << "\ncompat_matrix=" << compat.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p20d_experimental_beta(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p20c_summary.md", {
            out_dir / "native_ithz_p20c_physical_writer_matrix.csv",
            out_dir / "native_ithz_p20c_format_compat_matrix.csv"})) {
        fail("P20D requires passed P20C outputs");
    }
    auto profiles = generate_p14_beta_corpora(out_dir);
    profiles.push_back({"negative_mixed_precompressed_random", "P20D_negative_mixed_precompressed_random", out_dir / "p20d_beta_corpora" / "negative_mixed_precompressed_random"});
    generate_p10_negative(profiles.back().dir);
    const fs::path root = out_dir / "p20d_archives";
    fs::create_directories(root);
    const fs::path matrix = out_dir / "native_ithz_p20d_experimental_beta_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p20d_summary.md";
    std::ofstream csv(matrix);
    csv << "profile_name,default_archive_bytes,experimental_archive_bytes,delta_bytes,delta_percent,safe_verify_ms,extract_file_ms,decoded_ok,schedule_hash_unique_count,negative_guard_count,why_examples_ok,notes\n";
    bool all_ok = true;
    bool negative_ok = true;
    std::uint64_t total_saved = 0;
    std::size_t positive_rows = 0;
    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        auto default_options = options_for_pack_folder_profile("auto-mixed");
        auto experimental_options = default_options;
        experimental_options.experimental_prefix_metadata = true;
        const auto default_stats = pack_p7b_small_file_bundle(profile.dir, root / profile.id / "default_rc1.ithz", default_options, "original", false);
        const auto exp_stats = pack_p7b_small_file_bundle(profile.dir, root / profile.id / "p9_v5_experimental.ithz", experimental_options, "original", false);
        const auto archive = read_archive(exp_stats.archive_path);
        std::string safe_sha;
        P12DecodeTiming timing;
        const auto safe_ms = verify_archive_no_write_ms_timed(exp_stats.archive_path, &safe_sha, &timing);
        double extract_ms = 0.0;
        const bool extract_ok = archive_extract_representatives_ok(archive, out_dir / "p20d_extract_file" / profile.id, &extract_ms);
        std::set<std::string> hashes;
        for (const auto& sched : std::vector<std::string>{"original", "reversed", "path_hash"}) {
            const auto sched_stats = pack_p7b_small_file_bundle(profile.dir, root / profile.id / ("p9_v5_" + sched + ".ithz"), experimental_options, sched, false);
            hashes.insert(sched_stats.plan_hash);
        }
        std::uint64_t negative_guard_count = 0;
        for (const auto& file : at(archive.manifest, "file_table").array()) {
            const auto fam = metadata_string_or(file, "selected_family", metadata_string_or(file, "family", "unknown"));
            if (fam.find("store") != std::string::npos || fam.find("entropy") != std::string::npos || fam.find("compressed") != std::string::npos) ++negative_guard_count;
        }
        const bool negative = profile.id.find("negative") != std::string::npos;
        const bool negative_guarded = !negative || negative_guard_count == files.size();
        negative_ok = negative_ok && negative_guarded;
        const bool why_ok = !representative_files_by_family(archive, 5).empty();
        const bool decoded_ok = safe_sha == expected_sha;
        const bool row_ok = decoded_ok && extract_ok && hashes.size() == 1 && why_ok && negative_guarded &&
            exp_stats.plan_hash == default_stats.plan_hash;
        all_ok = all_ok && row_ok;
        const auto delta = static_cast<std::int64_t>(exp_stats.archive_bytes) - static_cast<std::int64_t>(default_stats.archive_bytes);
        if (exp_stats.archive_bytes < default_stats.archive_bytes) {
            total_saved += default_stats.archive_bytes - exp_stats.archive_bytes;
            ++positive_rows;
        }
        csv << csv_cell(profile.id) << ',' << default_stats.archive_bytes << ',' << exp_stats.archive_bytes << ',' << delta << ','
            << std::fixed << std::setprecision(3) << percent_delta(exp_stats.archive_bytes, default_stats.archive_bytes) << ','
            << safe_ms << ',' << extract_ms << ',' << (decoded_ok && extract_ok ? "true" : "false") << ',' << hashes.size() << ','
            << negative_guard_count << ',' << (why_ok ? "true" : "false")
            << ",p20d_explicit_p9_v5_beta_smoke_default_unchanged\n";
    }
    const bool passed = all_ok && negative_ok;
    std::ofstream md(summary);
    md << "# Native ITHZ P20D Experimental Beta Smoke\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "P20D runs the explicit p9-v5 experimental metadata writer through the RC-style beta workflow. The default RC1 writer remains unchanged.\n\n"
       << "## Result\n\n"
       << "- profiles: `" << profiles.size() << "`\n"
       << "- rows with smaller p9-v5 archive than default: `" << positive_rows << "/" << profiles.size() << "`\n"
       << "- total positive bytes saved: `" << total_saved << "`\n"
       << "- negative/random guarded: `" << (negative_ok ? "true" : "false") << "`\n\n"
       << "P20D is an explicit experimental smoke only. It is not a default promotion and makes no ZIP/tar.gz/7z superiority claim.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n";
    if (!passed) fail("P20D experimental beta smoke failed");
    std::cout << "p20d_experimental_beta_ok=true\nmatrix=" << matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void run_p22_payload_preconditioners(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    const fs::path root = out_dir / "p22_payload_preconditioner_archives";
    fs::create_directories(root);
    const fs::path matrix = out_dir / "native_ithz_p22_payload_preconditioner_matrix.csv";
    const fs::path summary = out_dir / "native_ithz_p22_payload_preconditioner_summary.md";
    std::ofstream csv(matrix);
    csv << "dataset_id,variant,input_bytes,file_count,archive_bytes,payload_bytes,manifest_bytes,delta_vs_locked_p9v3_percent,delta_vs_current_p9v5_percent,delta_vs_zip_percent,delta_vs_tar_gz_percent,pack_ms,decode_ms,decoded_ok,schedule_hash_unique_count,negative_clean,method_counts,semantic_plan_hash,zip_deflate_bytes,tar_gz_bytes,notes\n";

    const auto profiles = generate_p7b_real_corpora(out_dir);
    std::size_t rows_ok = 0;
    std::size_t total_rows = 0;
    std::size_t p22_smaller_than_current = 0;
    std::size_t p22_smaller_than_locked = 0;
    std::size_t p22_smaller_than_zip = 0;
    std::size_t p22_smaller_than_tar = 0;
    std::size_t p22_uses_preconditioner = 0;
    bool negative_clean_all = true;
    bool schedule_stable_all = true;

    auto emit_row = [&](const std::string& dataset_id,
                        const std::string& variant,
                        std::size_t input_bytes,
                        std::size_t file_count,
                        const P7BPackStats& stats,
                        const P7BPackStats& locked,
                        const P7BPackStats& current,
                        const ExternalBaselineResult& zip,
                        const ExternalBaselineResult& tar,
                        std::size_t schedule_hashes,
                        const std::string& notes) {
        csv << csv_cell(dataset_id) << ',' << csv_cell(variant) << ',' << input_bytes << ',' << file_count << ','
            << stats.archive_bytes << ',' << stats.payload_bytes << ',' << stats.manifest_bytes << ','
            << percent_delta(stats.archive_bytes, locked.archive_bytes) << ','
            << percent_delta(stats.archive_bytes, current.archive_bytes) << ','
            << (zip.available ? percent_delta(stats.archive_bytes, zip.archive_bytes) : 0.0) << ','
            << (tar.available ? percent_delta(stats.archive_bytes, tar.archive_bytes) : 0.0) << ','
            << std::fixed << std::setprecision(3) << stats.pack_ms << ',' << stats.decode_ms << ','
            << (stats.decoded_ok ? "true" : "false") << ',' << schedule_hashes << ','
            << (stats.negative_clean ? "true" : "false") << ','
            << csv_cell(method_counts_text(stats.method_counts)) << ',' << stats.plan_hash << ','
            << (zip.available ? zip.archive_bytes : 0) << ',' << (tar.available ? tar.archive_bytes : 0) << ','
            << csv_cell(notes) << "\n";
    };

    for (const auto& profile : profiles) {
        const auto files = read_dataset_dir(profile.dir);
        const auto expected_sha = compute_dataset_digest(files);
        std::size_t input_bytes = 0;
        for (const auto& [_, data] : files) input_bytes += data.size();
        const auto zip = run_zip_baseline(profile, out_dir, expected_sha);
        const auto tar = run_tar_gzip_baseline(profile, out_dir, expected_sha, "p22_baselines");

        auto locked_options = options_for_pack_folder_profile("auto-mixed");
        locked_options.experimental_prefix_metadata = false;
        locked_options.experimental_payload_preconditioners = false;
        locked_options.ablation = "P22_locked_p9_v3_metadata_baseline";

        auto current_options = options_for_pack_folder_profile("auto-mixed");
        current_options.experimental_prefix_metadata = true;
        current_options.experimental_payload_preconditioners = false;
        current_options.ablation = "P22_current_p9_v5_metadata_baseline";

        auto p22_options = current_options;
        p22_options.experimental_payload_preconditioners = true;
        p22_options.ablation = "P22_payload_preconditioners_opt_in";

        const auto locked = pack_p7b_small_file_bundle(profile.dir, root / profile.id / "locked_p9v3.ithz", locked_options, "original", true);
        const auto current = pack_p7b_small_file_bundle(profile.dir, root / profile.id / "current_p9v5.ithz", current_options, "original", true);
        const auto p22 = pack_p7b_small_file_bundle(profile.dir, root / profile.id / "p22_preconditioned.ithz", p22_options, "original", true);

        std::set<std::string> p22_hashes;
        for (const auto& schedule_name : std::vector<std::string>{"original", "reversed", "path_hash"}) {
            const auto sched = pack_p7b_small_file_bundle(profile.dir, root / profile.id / ("p22_" + schedule_name + ".ithz"), p22_options, schedule_name, false);
            p22_hashes.insert(sched.plan_hash);
        }
        const bool schedule_stable = p22_hashes.size() == 1;
        schedule_stable_all = schedule_stable_all && schedule_stable;
        negative_clean_all = negative_clean_all && p22.negative_clean;
        const bool row_ok = locked.decoded_ok && current.decoded_ok && p22.decoded_ok && schedule_stable && p22.negative_clean;
        rows_ok += row_ok ? 1 : 0;
        total_rows += 1;
        if (p22.archive_bytes < current.archive_bytes) ++p22_smaller_than_current;
        if (p22.archive_bytes < locked.archive_bytes) ++p22_smaller_than_locked;
        if (zip.available && p22.archive_bytes < zip.archive_bytes) ++p22_smaller_than_zip;
        if (tar.available && p22.archive_bytes < tar.archive_bytes) ++p22_smaller_than_tar;
        if (p22.method_counts.count("BYTEPLANE2_RANGE") ||
            p22.method_counts.count("DELTA16_BYTEPLANE_RANGE") ||
            p22.method_counts.count("ZIGZAG_DELTA16_BYTEPLANE_RANGE")) {
            ++p22_uses_preconditioner;
        }

        emit_row(profile.id, "locked_p9_v3", input_bytes, files.size(), locked, locked, current, zip, tar, 1, "locked_previous_metadata_layout_no_payload_preconditioners");
        emit_row(profile.id, "current_p9_v5", input_bytes, files.size(), current, locked, current, zip, tar, 1, "current_metadata_layout_no_payload_preconditioners");
        emit_row(profile.id, "p22_preconditioned", input_bytes, files.size(), p22, locked, current, zip, tar, p22_hashes.size(), "opt_in_payload_preconditioner_sweep;default_not_changed");
        csv.flush();
    }

    const bool passed = rows_ok == total_rows && schedule_stable_all && negative_clean_all;
    std::ofstream md(summary);
    md << "# Native ITHZ P22 Payload Preconditioner Experiment\n\n"
       << "Status: `" << (passed ? "passed" : "attention") << "`\n\n"
       << "P22 is an opt-in experiment inspired by the native_mobile reversible PAYL syntax work. It adds no default writer change and does not alter CFC planning, family assignment, P10 extraction safety, or the locked p9-v3 baseline.\n\n"
       << "## Scope\n\n"
       << "- locked baseline: `auto-mixed` with p9-v3 metadata and existing `STORE`/`LZ_RANGE` payloads.\n"
       << "- current baseline: explicit p9-v5 metadata with existing payloads.\n"
       << "- P22 candidate: explicit p9-v5 metadata plus guarded reversible payload preconditioners: `BYTEPLANE2_RANGE`, `DELTA16_BYTEPLANE_RANGE`, and `ZIGZAG_DELTA16_BYTEPLANE_RANGE`.\n"
       << "- external baselines: ZIP/deflate and tar.gz on the same corpora.\n\n"
       << "## Result\n\n"
       << "- rows passed decode/schedule/negative gates: `" << rows_ok << "/" << total_rows << "`\n"
       << "- P22 smaller than current p9-v5: `" << p22_smaller_than_current << "/" << profiles.size() << "`\n"
       << "- P22 smaller than locked p9-v3: `" << p22_smaller_than_locked << "/" << profiles.size() << "`\n"
       << "- P22 smaller than ZIP/deflate: `" << p22_smaller_than_zip << "/" << profiles.size() << "`\n"
       << "- P22 smaller than tar.gz: `" << p22_smaller_than_tar << "/" << profiles.size() << "`\n"
       << "- profiles selecting at least one preconditioned payload method: `" << p22_uses_preconditioner << "/" << profiles.size() << "`\n\n"
       << "## Interpretation\n\n"
       << "P22 is a separated payload-syntax experiment. Any byte win is a candidate for a future promotion gate only after broader real-folder validation. No ZIP/tar.gz/7z superiority claim is made.\n\n"
       << "Raw matrix: `" << matrix.generic_string() << "`\n";
    std::cout << "p22_payload_preconditioners_ok=" << (passed ? "true" : "attention")
              << "\nmatrix=" << matrix.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
    if (!passed) fail("P22 payload preconditioner gate requires attention");
}

void run_p20r_refactor(const fs::path& out_dir) {
    fs::create_directories(out_dir);
    if (!phase_summary_passed(out_dir / "native_ithz_p20c_summary.md", {
            out_dir / "native_ithz_p20c_physical_writer_matrix.csv",
            out_dir / "native_ithz_p20c_prediction_gap_matrix.csv"})) {
        fail("P20R requires passed P20C decision outputs");
    }
    const fs::path matrix = out_dir / "native_ithz_p20r_refactor_matrix.csv";
    const fs::path file_map = out_dir / "native_ithz_p20r_file_map.md";
    const fs::path summary = out_dir / "native_ithz_p20r_summary.md";
    std::ofstream csv(matrix);
    csv << "check,path,passed,notes\n";
    const bool header = fs::exists("native_ithz/include/ithz/metadata_layout.hpp");
    const bool source = fs::exists("native_ithz/src/metadata_layout.cpp");
    const bool cmake = text_file_contains("native_ithz/CMakeLists.txt", "src/metadata_layout.cpp");
    csv << "metadata_layout_header,native_ithz/include/ithz/metadata_layout.hpp," << (header ? "true" : "false") << ",P20A/P20B helper structs and declarations\n";
    csv << "metadata_layout_source,native_ithz/src/metadata_layout.cpp," << (source ? "true" : "false") << ",P20A/P20B attribution and simulator helpers\n";
    csv << "cmake_includes_metadata_layout,native_ithz/CMakeLists.txt," << (cmake ? "true" : "false") << ",module participates in AVX2/scalar builds\n";
    const bool passed = header && source && cmake;
    std::ofstream fm(file_map);
    fm << "# Native ITHZ P20R File Map\n\n"
       << "| File | Responsibility |\n"
       << "|---|---|\n"
       << "| `native_ithz/include/ithz/metadata_layout.hpp` | P20 metadata row/stat/simulation structs and helper declarations. |\n"
       << "| `native_ithz/src/metadata_layout.cpp` | Deep metadata attribution and layout simulation helpers. |\n\n"
       << "P20R keeps writer/reader behavior unchanged. `main.cpp` still owns runner orchestration.\n";
    std::ofstream md(summary);
    md << "# Native ITHZ P20R Metadata Layout Refactor\n\n"
       << "Status: `" << (passed ? "passed" : "failed") << "`\n\n"
       << "P20R keeps P20 attribution and simulation helpers outside `main.cpp` via the metadata-layout module. No writer, reader, CLI behavior, semantic plan hash, family assignment, or safety behavior changes here.\n\n"
       << "Raw outputs:\n\n"
       << "- `" << matrix.generic_string() << "`\n"
       << "- `" << file_map.generic_string() << "`\n";
    if (!passed) fail("P20R refactor validation failed");
    std::cout << "p20r_refactor_ok=true\nmatrix=" << matrix.generic_string()
              << "\nfile_map=" << file_map.generic_string()
              << "\nsummary=" << summary.generic_string() << "\n";
}

void write_post_p20_next_steps(const fs::path& out_dir) {
    const fs::path path = out_dir / "native_ithz_post_p20_next_steps.md";
    std::ofstream md(path);
    md << "# Native ITHZ Post-P20 Next Steps\n\n"
       << "P20 result: keep p9-v5 experimental. Do not promote it to default in this sprint.\n\n"
       << "Recommended P21 direction:\n\n"
       << "1. Run a broader promotion test for `p9-v5-experimental` on real beta folders before considering default changes.\n"
       << "2. Keep p9-v3/P7B as the default writer until promotion gates explicitly pass.\n"
       << "3. Move planner code into `auto_mixed`/planner modules to reduce `main.cpp` risk.\n"
       << "4. Continue real-world beta testing with the RC package and explicit p9-v4/p9-v5 experiments.\n"
       << "5. Consider logs/json/csv family planning only as a separate future sprint, not as a hidden metadata change.\n"
       << "6. Keep P10 safety and default writer behavior as hard gates.\n\n"
       << "No ZIP/tar.gz/7z superiority claim is made.\n";
    std::cout << "post_p20_next_steps=" << path.generic_string() << "\n";
}

int run_cli(int argc, char** argv) {
    try {
        bool inspect = false;
        bool decode = false;
        bool pack = false;
        bool analyze_folder = false;
        bool pack_folder = false;
        bool explain_plan = false;
        bool self_test = false;
        bool hw_status = false;
        bool run_native_phases = false;
        bool phase2b = false;
        bool phase2c = false;
        bool phase2d = false;
        bool phase3a = false;
        bool phase3b = false;
        bool phase4 = false;
        bool golden_regression = false;
        bool p5_p6_stress = false;
        bool p6d_perf = false;
        bool p7a_baselines = false;
        bool p6d_p7a = false;
        bool p7b_small_files = false;
        bool p7b_real = false;
        bool p7b_solid = false;
        bool p8a_solid_backend = false;
        bool p9_auto_mixed = false;
        bool p9c_inspect_extract = false;
        bool p10_hardening = false;
        bool p11_perf = false;
        bool p12_decode = false;
        bool p13_product = false;
        bool p14_release = false;
        bool p145_package = false;
        bool p15a_size = false;
        bool p15b_beta = false;
        bool p15r_refactor = false;
        bool p16a_metadata = false;
        bool p16b_payload = false;
        bool p16r2_refactor = false;
        bool p17a_writer = false;
        bool p17b_ordering = false;
        bool p17c_beta = false;
        bool p17r_refactor = false;
        bool p18r_refactor = false;
        bool p19r_refactor = false;
        bool p20a_deep = false;
        bool p20b_sim = false;
        bool p20c_writer = false;
        bool p20d_beta = false;
        bool p20r_refactor = false;
        bool p22_payload = false;
        bool ci_fast = false;
        bool ci_full = false;
        bool experimental_metadata_compaction = false;
        bool experimental_prefix_metadata = false;
        bool families = false;
        bool list_archive = false;
        bool verify_archive = false;
        bool extract_archive = false;
        bool extract_file = false;
        bool update_file = false;
        bool update_files = false;
        bool delete_file = false;
        bool rename_file = false;
        VerifyMode verify_mode = VerifyMode::Off;
        bool verify_mode_explicit = false;
        fs::path archive_path;
        fs::path output_dir;
        fs::path input_dir;
        fs::path plan_report_path;
        fs::path perf_report_path;
        fs::path oracle_plan_path = "experiments/06_ithz_archive/raw/support_cut_plan.json";
        std::string why_path;
        std::string single_file_path;
        std::string rename_to_path;
        std::string variant = "checkpointed_cfc";
        std::string schedule = "original";
        std::string manifest_mode = "json";
        std::string pack_profile = "auto-mixed";
        for (int i = 1; i < argc; ++i) {
            const std::string arg = argv[i];
            if (arg == "--inspect") {
                inspect = true;
                if (i + 1 < argc && std::string(argv[i + 1]).rfind("--", 0) != 0) archive_path = argv[++i];
            }
            else if (arg == "--decode") decode = true;
            else if (arg == "--pack") pack = true;
            else if (arg == "--analyze-folder" && i + 1 < argc) { analyze_folder = true; input_dir = argv[++i]; }
            else if (arg == "--pack-folder" && i + 1 < argc) { pack_folder = true; input_dir = argv[++i]; }
            else if (arg == "--list" && i + 1 < argc) { list_archive = true; archive_path = argv[++i]; }
            else if (arg == "--extract" && i + 1 < argc) { extract_archive = true; archive_path = argv[++i]; }
            else if (arg == "--extract-file" && i + 1 < argc) { extract_file = true; archive_path = argv[++i]; }
            else if (arg == "--update-file" && i + 1 < argc) { update_file = true; archive_path = argv[++i]; }
            else if (arg == "--update-files" && i + 1 < argc) { update_files = true; archive_path = argv[++i]; }
            else if (arg == "--delete-file" && i + 1 < argc) { delete_file = true; archive_path = argv[++i]; }
            else if (arg == "--rename-file" && i + 1 < argc) { rename_file = true; archive_path = argv[++i]; }
            else if (arg == "--families") families = true;
            else if (arg == "--why" && i + 1 < argc) why_path = argv[++i];
            else if (arg == "--path" && i + 1 < argc) single_file_path = argv[++i];
            else if ((arg == "--to" || arg == "--new-path") && i + 1 < argc) rename_to_path = argv[++i];
            else if (arg == "--explain-plan") explain_plan = true;
            else if (arg == "--self-test") self_test = true;
            else if (arg == "--hw-status") hw_status = true;
            else if (arg == "--run-native-phases") run_native_phases = true;
            else if (arg == "--phase2b-schedule-qa") phase2b = true;
            else if (arg == "--phase2c-greedy") phase2c = true;
            else if (arg == "--phase2d-parity") phase2d = true;
            else if (arg == "--phase3a-avx2-probe") phase3a = true;
            else if (arg == "--phase3b-binary-manifest") phase3b = true;
            else if (arg == "--run-p4-native-selector") phase4 = true;
            else if (arg == "--run-golden-regression") golden_regression = true;
            else if (arg == "--run-p5-p6-stress") p5_p6_stress = true;
            else if (arg == "--run-p6d-perf-clean") p6d_perf = true;
            else if (arg == "--run-p7a-baselines") p7a_baselines = true;
            else if (arg == "--run-p6d-p7a") p6d_p7a = true;
            else if (arg == "--run-p7b-small-files") p7b_small_files = true;
            else if (arg == "--run-p7b-real") p7b_real = true;
            else if (arg == "--run-p7b-solid") p7b_solid = true;
            else if (arg == "--run-p8a-solid-backend") p8a_solid_backend = true;
            else if (arg == "--run-p9-auto-mixed") p9_auto_mixed = true;
            else if (arg == "--run-p9c-inspect-extract") p9c_inspect_extract = true;
            else if (arg == "--run-p10-hardening") p10_hardening = true;
            else if (arg == "--run-p11-perf") p11_perf = true;
            else if (arg == "--run-p12-decode-throughput") p12_decode = true;
            else if (arg == "--run-p13-product-polish") p13_product = true;
            else if (arg == "--run-p14-release-candidate") p14_release = true;
            else if (arg == "--run-p14-release-package") p145_package = true;
            else if (arg == "--run-p15a-size-attribution") p15a_size = true;
            else if (arg == "--run-p15b-real-beta-smoke") p15b_beta = true;
            else if (arg == "--run-p15r-refactor") p15r_refactor = true;
            else if (arg == "--run-p16a-metadata-compaction") p16a_metadata = true;
            else if (arg == "--run-p16b-payload-partition") p16b_payload = true;
            else if (arg == "--run-p16r2-refactor") p16r2_refactor = true;
            else if (arg == "--run-p17a-metadata-writer") p17a_writer = true;
            else if (arg == "--run-p17b-solid-ordering-diagnostics") p17b_ordering = true;
            else if (arg == "--run-p17c-beta-experimental") p17c_beta = true;
            else if (arg == "--run-p17r-path-safety-refactor") p17r_refactor = true;
            else if (arg == "--run-p18r-container-refactor") p18r_refactor = true;
            else if (arg == "--run-p19r-index-inspect-refactor") p19r_refactor = true;
            else if (arg == "--run-p20a-deep-metadata-attribution") p20a_deep = true;
            else if (arg == "--run-p20b-metadata-layout-simulator") p20b_sim = true;
            else if (arg == "--run-p20c-physical-writer-candidate") p20c_writer = true;
            else if (arg == "--run-p20d-experimental-beta") p20d_beta = true;
            else if (arg == "--run-p20r-refactor") p20r_refactor = true;
            else if (arg == "--run-p22-payload-preconditioners") p22_payload = true;
            else if (arg == "--experimental-metadata-compaction") experimental_metadata_compaction = true;
            else if (arg == "--experimental-prefix-offset-metadata" || arg == "--experimental-prefix-metadata") experimental_prefix_metadata = true;
            else if (arg == "--run-ci-fast") ci_fast = true;
            else if (arg == "--run-ci-full") ci_full = true;
            else if (arg == "--verify") {
                if (i + 1 < argc && std::string(argv[i + 1]).rfind("--", 0) != 0) {
                    verify_archive = true;
                    archive_path = argv[++i];
                } else {
                    verify_mode = VerifyMode::Full;
                    verify_mode_explicit = true;
                }
            }
            else if (arg.rfind("--verify=", 0) == 0) {
                const auto mode = arg.substr(std::string("--verify=").size());
                if (mode == "full") verify_mode = VerifyMode::Full;
                else if (mode == "full-no-write" || mode == "safe") verify_mode = VerifyMode::FullNoWrite;
                else if (mode == "checksums-only") verify_mode = VerifyMode::ChecksumsOnly;
                else if (mode == "off") verify_mode = VerifyMode::Off;
                else fail("unsupported verify mode: " + mode);
                verify_mode_explicit = true;
            }
            else if (arg == "--archive" && i + 1 < argc) archive_path = argv[++i];
            else if (arg == "--output" && i + 1 < argc) output_dir = argv[++i];
            else if (arg == "--input" && i + 1 < argc) input_dir = argv[++i];
            else if (arg == "--plan-report" && i + 1 < argc) plan_report_path = argv[++i];
            else if (arg == "--perf-report" && i + 1 < argc) perf_report_path = argv[++i];
            else if (arg == "--oracle-plan" && i + 1 < argc) oracle_plan_path = argv[++i];
            else if (arg == "--variant" && i + 1 < argc) variant = argv[++i];
            else if (arg == "--schedule" && i + 1 < argc) schedule = argv[++i];
            else if (arg == "--profile" && i + 1 < argc) pack_profile = argv[++i];
            else if (arg == "--manifest-mode" && i + 1 < argc) manifest_mode = argv[++i];
            else if (arg.rfind("--manifest-mode=", 0) == 0) {
                manifest_mode = arg.substr(std::string("--manifest-mode=").size());
                if (manifest_mode == "p9-v4-experimental" || manifest_mode == "p7b-v3-experimental") experimental_metadata_compaction = true;
                if (manifest_mode == "p9-v5-experimental") experimental_prefix_metadata = true;
            }
            else if (arg == "--version") { print_version(); return 0; }
            else if (arg == "--help-verify") { print_help_verify(); return 0; }
            else if (arg == "--help-examples") { print_help_examples(); return 0; }
            else if (arg == "--help" || arg == "-h") { print_help(); return 0; }
            else fail("unknown argument: " + arg);
        }
        if (hw_status) {
            std::cout << "ithz_native_ok=true\n";
            std::cout << "cxx_standard=20\n";
            std::cout << "avx2_build=" << (ITHZ_X64_AVX2 ? "true" : "false") << "\n";
            return 0;
        }
        if (self_test) {
            const Bytes sample{'a', 'b', 'c'};
            if (sha256_hex(sample) != "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad") {
                fail("sha256 self-test failed");
            }
            const Bytes rle{3, 'x', 2, 'y'};
            const Bytes decoded_rle = decode_rle(rle);
            if (std::string(decoded_rle.begin(), decoded_rle.end()) != "xxxyy") {
                fail("rle self-test failed");
            }
            std::cout << "self_test_ok=true\n";
            return 0;
        }
        if (run_native_phases || phase2b || phase2c || phase2d || phase3a || phase3b || phase4 || golden_regression || p5_p6_stress || p6d_perf || p7a_baselines || p6d_p7a || p7b_small_files || p7b_real || p7b_solid || p8a_solid_backend || p9_auto_mixed || p9c_inspect_extract || p10_hardening || p11_perf || p12_decode || p13_product || p14_release || p145_package || p15a_size || p15b_beta || p15r_refactor || p16a_metadata || p16b_payload || p16r2_refactor || p17a_writer || p17b_ordering || p17c_beta || p17r_refactor || p18r_refactor || p19r_refactor || p20a_deep || p20b_sim || p20c_writer || p20d_beta || p20r_refactor || p22_payload || ci_fast || ci_full) {
            if (input_dir.empty() && !p5_p6_stress && !p6d_perf && !p7a_baselines && !p6d_p7a && !p7b_small_files && !p7b_real && !p7b_solid && !p145_package && !p15a_size && !p15b_beta && !p15r_refactor && !p16a_metadata && !p16b_payload && !p16r2_refactor && !p17a_writer && !p17b_ordering && !p17c_beta && !p17r_refactor && !p18r_refactor && !p19r_refactor && !p20a_deep && !p20b_sim && !p20c_writer && !p20d_beta && !p20r_refactor && !p22_payload) fail("phase command requires --input");
            if (output_dir.empty()) output_dir = "experiments/06_ithz_archive/raw/native_ithz";
            if (run_native_phases) run_native_phase2b_to_3b(input_dir, output_dir, oracle_plan_path);
            if (phase2b) run_phase2b_schedule_qa(input_dir, output_dir, oracle_plan_path);
            if (phase2c) run_phase2c_greedy_negative(input_dir, output_dir);
            if (phase2d) run_phase2d_parity_matrix(input_dir, output_dir, oracle_plan_path);
            if (phase3a) run_phase3a_avx2_probe(input_dir, output_dir);
            if (phase3b) run_phase3b_binary_manifest(input_dir, output_dir, oracle_plan_path);
            if (phase4) run_phase4_native_selector(input_dir, output_dir, oracle_plan_path);
            if (golden_regression) run_golden_regression(input_dir, output_dir, oracle_plan_path);
            if (p5_p6_stress) run_p5_p6_stress(output_dir);
            if (p6d_perf) run_p6d_perf_clean(output_dir);
            if (p7a_baselines) run_p7a_baseline_harness(output_dir);
            if (p6d_p7a) run_p6d_p7a(output_dir);
            if (p7b_small_files) run_p7b_small_files(output_dir);
            if (p7b_real) run_p7b_real(output_dir);
            if (p7b_solid) run_p7b_solid(output_dir);
            if (p8a_solid_backend) run_p8a_solid_backend_gap(output_dir, input_dir, oracle_plan_path);
            if (p9_auto_mixed) run_p9_auto_mixed(output_dir, input_dir, oracle_plan_path);
            if (p9c_inspect_extract) run_p9c_inspect_extract(output_dir, input_dir, oracle_plan_path);
            if (p10_hardening) run_p10_hardening(output_dir, input_dir, oracle_plan_path);
            if (p11_perf) run_p11_perf(output_dir, input_dir, oracle_plan_path);
            if (p12_decode) run_p12_decode_throughput(output_dir, input_dir, oracle_plan_path);
            if (p13_product) run_p13_product_polish(output_dir, input_dir, oracle_plan_path);
            if (p14_release) run_p14_release_candidate(output_dir, input_dir, oracle_plan_path);
            if (p145_package) run_p145_release_package(output_dir);
            if (p15a_size) run_p15a_size_attribution(output_dir);
            if (p15b_beta) run_p15b_real_beta_smoke(output_dir);
            if (p15r_refactor) run_p15r_refactor(output_dir);
            if (p16a_metadata) run_p16a_metadata_compaction(output_dir);
            if (p16b_payload) run_p16b_payload_partition_diagnostics(output_dir);
            if (p16r2_refactor) run_p16r2_refactor(output_dir);
            if (p17a_writer) run_p17a_metadata_writer(output_dir);
            if (p17b_ordering) run_p17b_solid_ordering_diagnostics(output_dir);
            if (p17c_beta) run_p17c_beta_experimental(output_dir);
            if (p17r_refactor) run_p17r_path_safety_refactor(output_dir);
            if (p18r_refactor) run_p18r_container_refactor(output_dir);
            if (p19r_refactor) run_p19r_index_inspect_refactor(output_dir);
            if (p20a_deep) run_p20a_deep_metadata_attribution(output_dir);
            if (p20b_sim) run_p20b_metadata_layout_simulator(output_dir);
            if (p20c_writer) run_p20c_physical_writer_candidate(output_dir);
            if (p20d_beta) run_p20d_experimental_beta(output_dir);
            if (p20r_refactor) { run_p20r_refactor(output_dir); write_post_p20_next_steps(output_dir); }
            if (p22_payload) run_p22_payload_preconditioners(output_dir);
            if (ci_fast) run_ci_fast(input_dir, output_dir, oracle_plan_path);
            if (ci_full) run_ci_full(input_dir, output_dir, oracle_plan_path);
            return 0;
        }
        if (analyze_folder) {
            if (input_dir.empty()) fail("--analyze-folder requires a directory");
            if (output_dir.empty()) output_dir = "experiments/06_ithz_archive/raw/native_ithz";
            if (plan_report_path.empty()) plan_report_path = output_dir / "example_auto_mixed_plan.json";
            write_auto_mixed_plan_artifacts(input_dir, plan_report_path, output_dir);
            std::cout << "analyze_folder_ok=true\nplan_report=" << plan_report_path.generic_string()
                      << "\nsummary=" << (output_dir / "auto_mixed_plan_summary.md").generic_string()
                      << "\nmatrix=" << (output_dir / "native_ithz_p9_auto_mixed_plan_matrix.csv").generic_string() << "\n";
            return 0;
        }
        if (pack_folder) {
            if (input_dir.empty()) fail("--pack-folder requires a directory");
            if (archive_path.empty()) fail("--pack-folder requires --archive");
            if (output_dir.empty()) output_dir = archive_path.parent_path().empty() ? fs::path(".") : archive_path.parent_path();
            if (!verify_mode_explicit && verify_mode == VerifyMode::Off) verify_mode = VerifyMode::FullNoWrite;
            if (manifest_mode == "p9-v4-experimental" || manifest_mode == "p7b-v3-experimental") experimental_metadata_compaction = true;
            if (manifest_mode == "p9-v5-experimental") experimental_prefix_metadata = true;
            auto options = options_for_pack_folder_profile(pack_profile);
            options.experimental_metadata_compaction = experimental_metadata_compaction;
            options.experimental_prefix_metadata = experimental_prefix_metadata;
            P11PerfStats perf;
            const auto stats = pack_p7b_small_file_bundle(input_dir, archive_path, options, schedule, verify_mode == VerifyMode::Full, perf_report_path.empty() ? nullptr : &perf);
            if (verify_mode == VerifyMode::FullNoWrite) {
                P12DecodeTiming no_write_timing;
                const auto archive = read_archive_timed(archive_path, &no_write_timing);
                const auto decoded_sha = verify_archive_full_no_write_timed(archive, output_dir / "pack_folder_verify_no_write", &no_write_timing);
                if (decoded_sha != stats.dataset_sha) fail("pack-folder full-no-write verification failed");
            }
            if (!perf_report_path.empty()) write_p11_perf_report_json(perf_report_path, archive_path, stats, perf);
            if (explain_plan || pack_profile == "auto-mixed" || pack_profile == "auto") {
                const fs::path report = archive_path;
                write_auto_mixed_plan_artifacts(input_dir, report.string() + ".auto_mixed_plan.json", output_dir);
            }
            std::cout << "pack_folder_ok=true\narchive=" << archive_path.generic_string()
                      << "\nprofile=" << pack_profile
                      << "\ndecoded_sha256=" << stats.dataset_sha
                      << "\nsemantic_plan_hash=" << stats.plan_hash
                      << "\narchive_bytes=" << stats.archive_bytes
                      << "\npayload_bytes=" << stats.payload_bytes
                      << "\nmanifest_bytes=" << stats.manifest_bytes << "\n";
            return 0;
        }
        if (pack) {
            if (input_dir.empty()) fail("--pack requires --input");
            if (archive_path.empty()) fail("--pack requires --archive");
            if (variant == "checkpointed_cfc") {
                pack_checkpointed_original(input_dir, archive_path, oracle_plan_path, manifest_mode, verify_mode, true, true);
            } else if (variant == "greedy_event_local") {
                const auto stats = pack_greedy_event_local(input_dir, archive_path, schedule, verify_mode == VerifyMode::Full);
                std::cout << "pack_ok=true\narchive=" << archive_path.generic_string() << "\ndecoded_sha256=" << stats.dataset_sha
                          << "\nsemantic_plan_hash=" << stats.plan_hash << "\ncontainer_bytes_hash=" << stats.container_hash
                          << "\npayload_bytes=" << stats.payload_bytes << "\nmanifest_bytes=" << stats.manifest_bytes << "\n";
            } else {
                fail("unsupported variant: " + variant);
            }
            return 0;
        }
        if (update_file) {
            if (archive_path.empty()) fail("--update-file requires an archive");
            if (single_file_path.empty()) fail("--update-file requires --path");
            if (input_dir.empty()) fail("--update-file requires --input <file_or_->");
            if (!verify_mode_explicit && verify_mode == VerifyMode::Off) verify_mode = VerifyMode::FullNoWrite;
            if (manifest_mode == "p9-v4-experimental" || manifest_mode == "p7b-v3-experimental") experimental_metadata_compaction = true;
            if (manifest_mode == "p9-v5-experimental") experimental_prefix_metadata = true;
            auto options = options_for_pack_folder_profile(pack_profile);
            options.experimental_metadata_compaction = experimental_metadata_compaction;
            options.experimental_prefix_metadata = experimental_prefix_metadata;
            update_archive_file_from_memory(archive_path, single_file_path, input_dir, options, verify_mode);
            return 0;
        }
        if (update_files) {
            if (archive_path.empty()) fail("--update-files requires an archive");
            if (input_dir.empty()) fail("--update-files requires --input <json_or_->");
            if (!verify_mode_explicit && verify_mode == VerifyMode::Off) verify_mode = VerifyMode::FullNoWrite;
            if (manifest_mode == "p9-v4-experimental" || manifest_mode == "p7b-v3-experimental") experimental_metadata_compaction = true;
            if (manifest_mode == "p9-v5-experimental") experimental_prefix_metadata = true;
            auto options = options_for_pack_folder_profile(pack_profile);
            options.experimental_metadata_compaction = experimental_metadata_compaction;
            options.experimental_prefix_metadata = experimental_prefix_metadata;
            update_archive_files_from_json(archive_path, input_dir, options, verify_mode);
            return 0;
        }
        if (delete_file) {
            if (archive_path.empty()) fail("--delete-file requires an archive");
            if (single_file_path.empty()) fail("--delete-file requires --path");
            if (!verify_mode_explicit && verify_mode == VerifyMode::Off) verify_mode = VerifyMode::FullNoWrite;
            if (manifest_mode == "p9-v4-experimental" || manifest_mode == "p7b-v3-experimental") experimental_metadata_compaction = true;
            if (manifest_mode == "p9-v5-experimental") experimental_prefix_metadata = true;
            auto options = options_for_pack_folder_profile(pack_profile);
            options.experimental_metadata_compaction = experimental_metadata_compaction;
            options.experimental_prefix_metadata = experimental_prefix_metadata;
            delete_archive_file_from_memory(archive_path, single_file_path, options, verify_mode);
            return 0;
        }
        if (rename_file) {
            if (archive_path.empty()) fail("--rename-file requires an archive");
            if (single_file_path.empty()) fail("--rename-file requires --path");
            if (rename_to_path.empty()) fail("--rename-file requires --to <new_path>");
            if (!verify_mode_explicit && verify_mode == VerifyMode::Off) verify_mode = VerifyMode::FullNoWrite;
            if (manifest_mode == "p9-v4-experimental" || manifest_mode == "p7b-v3-experimental") experimental_metadata_compaction = true;
            if (manifest_mode == "p9-v5-experimental") experimental_prefix_metadata = true;
            auto options = options_for_pack_folder_profile(pack_profile);
            options.experimental_metadata_compaction = experimental_metadata_compaction;
            options.experimental_prefix_metadata = experimental_prefix_metadata;
            rename_archive_file_from_memory(archive_path, single_file_path, rename_to_path, options, verify_mode);
            return 0;
        }
        if (archive_path.empty()) {
            print_help();
            return 1;
        }
        if (list_archive) {
            list_archive_files(archive_path);
            return 0;
        }
        if (verify_archive) {
            if (verify_mode == VerifyMode::FullNoWrite) verify_archive_full_no_write(archive_path);
            else verify_archive_full(archive_path);
            return 0;
        }
        if (extract_archive) {
            if (output_dir.empty()) fail("--extract requires --output");
            const auto archive = read_archive(archive_path);
            const auto decoded_sha = decode_archive_to_dir(archive, output_dir);
            std::cout << "extract_ok=true\n";
            std::cout << "output=" << output_dir.generic_string() << "\n";
            std::cout << "decoded_sha256=" << decoded_sha << "\n";
            std::cout << "compression_plan_hash=" << archive.header_plan_hash << "\n";
            return 0;
        }
        if (extract_file) {
            if (single_file_path.empty()) fail("--extract-file requires --path");
            if (output_dir.empty()) fail("--extract-file requires --output");
            extract_single_file(archive_path, single_file_path, output_dir);
            return 0;
        }
        if (inspect) {
            if (families) {
                inspect_archive_families(archive_path);
                return 0;
            }
            if (!why_path.empty()) {
                why_archive_file(archive_path, why_path);
                return 0;
            }
            inspect_archive(archive_path);
            return 0;
        }
        if (decode) {
            if (output_dir.empty()) fail("--decode requires --output");
            const auto archive = read_archive(archive_path);
            const auto decoded_sha = decode_archive_to_dir(archive, output_dir);
            std::cout << "decode_ok=true\n";
            std::cout << "verify_mode=" << verify_mode_name(verify_mode) << "\n";
            std::cout << "decoded_sha256=" << decoded_sha << "\n";
            std::cout << "compression_plan_hash=" << archive.header_plan_hash << "\n";
            return 0;
        }
        print_help();
        return 1;
    } catch (const std::exception& e) {
        std::cerr << "error=" << e.what() << "\n";
        return classify_exit_code(e.what());
    }
}

} // namespace

int main(int argc, char** argv) {
    return run_cli(argc, argv);
}
