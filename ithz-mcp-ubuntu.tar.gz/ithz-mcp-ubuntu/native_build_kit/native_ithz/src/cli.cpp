#include "ithz/cli.hpp"

#include "ithz/version.hpp"

#include <iostream>

namespace ithz {

void print_version() {
    std::cout << "ithz_native_version=" << kIthzNativeVersion << "\n"
              << "container_header_version=1\n"
              << "manifest_support_versions=" << kIthzManifestReaders << "\n"
              << "manifest_readers=" << kIthzManifestReaders << "\n"
              << "default_profile=auto-mixed\n"
              << "pack_folder_default_verify=safe\n"
              << "safe_verify_alias=full-no-write\n"
              << "exit_codes=" << kIthzExitCodes << "\n"
              << "build_profile=" << (ITHZ_X64_AVX2 ? "Release_AVX2" : "Release_scalar") << "\n"
              << "avx2_build=" << (ITHZ_X64_AVX2 ? "true" : "false") << "\n";
}

void print_help_verify() {
    std::cout << "ITHZ verify modes\n"
              << "  --verify=off             Write or operate without post-write verification. Benchmark only.\n"
              << "  --verify=checksums-only  Check container header/footer plus manifest and payload checksums. No payload decode.\n"
              << "  --verify=full-no-write   Decode payloads and validate path/offset/SHA without writing a restored tree.\n"
              << "  --verify=safe            Alias for full-no-write; product default for --pack-folder.\n"
              << "  --verify=full            Decode, validate, and write a restored tree. Heavy regression/integrity gate.\n"
              << "\nExit codes: " << kIthzExitCodes << "\n";
}

void print_help_examples() {
    std::cout << "ITHZ common commands\n"
              << "  ithz-native --pack-folder project --archive project.ithz\n"
              << "  ithz-native --pack-folder project --archive project.ithz --verify=full\n"
              << "  ithz-native --analyze-folder project --plan-report auto_mixed_plan.json\n"
              << "  ithz-native --inspect project.ithz --families\n"
              << "  ithz-native --inspect project.ithz --why src/app.js\n"
              << "  ithz-native --list project.ithz\n"
              << "  ithz-native --verify project.ithz --verify=safe\n"
              << "  ithz-native --extract project.ithz --output restored\n"
              << "  ithz-native --extract-file project.ithz --path src/app.js --output app.js\n"
              << "  ithz-native --update-file project.ithz --path prompts/prompt_log.jsonl --input - --verify=safe\n"
              << "  ithz-native --update-files project.ithz --input updates.json --verify=safe\n"
              << "  ithz-native --rename-file project.ithz --path docs/old.txt --to docs/new.txt --verify=safe\n"
              << "  ithz-native --delete-file project.ithz --path docs/old.txt --verify=safe\n";
}

void print_help() {
    std::cout << "ithz-native --version\n"
              << "ithz-native --help | --help-verify | --help-examples\n"
              << "ithz-native --inspect <file.ithz> [--families|--why <path>]\n"
              << "ithz-native --list <file.ithz>\n"
              << "ithz-native --verify <file.ithz> [--verify=safe|full]\n"
              << "ithz-native --extract <file.ithz> --output <dir>\n"
              << "ithz-native --extract-file <file.ithz> --path <path> --output <file_or_dir|->\n"
              << "ithz-native --update-file <file.ithz> --path <path> --input <file_or_-> [--profile auto-mixed] [--verify=safe|full]\n"
              << "ithz-native --update-files <file.ithz> --input <updates_json_or_-> [--profile auto-mixed] [--verify=safe|full]\n"
              << "ithz-native --rename-file <file.ithz> --path <old_path> --to <new_path> [--profile auto-mixed] [--verify=safe|full]\n"
              << "ithz-native --delete-file <file.ithz> --path <path> [--profile auto-mixed] [--verify=safe|full]\n"
              << "ithz-native --inspect --archive <file.ithz>\n"
              << "ithz-native --decode --archive <file.ithz> --output <dir> [--verify=off|checksums-only|safe|full-no-write|full]\n"
              << "ithz-native --pack --input <dataset_dir> --archive <out.ithz> --variant checkpointed_cfc|greedy_event_local --schedule <name> --manifest-mode json|compact [--verify=off|checksums-only|safe|full-no-write|full]\n"
              << "ithz-native --analyze-folder <dir> --plan-report <auto_mixed_plan.json> [--output <dir>]\n"
              << "ithz-native --pack-folder <dir> --archive <out.ithz> [--profile auto-mixed|generic|small-files|p7b-solid|store] [--explain-plan] [--perf-report <perf.json>] [--verify=off|checksums-only|safe|full-no-write|full]\n"
              << "verify modes: checksums-only=container/header/footer/manifest/payload checks; safe/full-no-write=decode plus path/offset/SHA validation without restored-tree writes; full=decode plus validation plus restored-tree writes.\n"
              << "ithz-native --run-native-phases --input <dataset_dir> --output <dir>\n"
              << "ithz-native --phase2b-schedule-qa --input <dataset_dir> --output <dir>\n"
              << "ithz-native --phase2c-greedy --input <dataset_dir> --output <dir>\n"
              << "ithz-native --phase2d-parity --input <dataset_dir> --output <dir>\n"
              << "ithz-native --phase3a-avx2-probe --input <dataset_dir> --output <dir>\n"
              << "ithz-native --phase3b-binary-manifest --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-p4-native-selector --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-golden-regression --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-p5-p6-stress --output <dir>\n"
              << "ithz-native --run-p6d-perf-clean --output <dir>\n"
              << "ithz-native --run-p7a-baselines --output <dir>\n"
              << "ithz-native --run-p6d-p7a --output <dir>\n"
              << "ithz-native --run-p7b-small-files --output <dir>\n"
              << "ithz-native --run-p7b-real --output <dir>\n"
              << "ithz-native --run-p7b-solid --output <dir>\n"
              << "ithz-native --run-p8a-solid-backend --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-p9-auto-mixed --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-p9c-inspect-extract --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-p10-hardening --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-p11-perf --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-p12-decode-throughput --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-p13-product-polish --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-p14-release-candidate --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-p14-release-package --output <dir>\n"
              << "ithz-native --run-p15a-size-attribution --output <dir>\n"
              << "ithz-native --run-p15b-real-beta-smoke --output <dir>\n"
              << "ithz-native --run-p15r-refactor --output <dir>\n"
              << "ithz-native --run-p16a-metadata-compaction --output <dir>\n"
              << "ithz-native --run-p16b-payload-partition --output <dir>\n"
              << "ithz-native --run-p16r2-refactor --output <dir>\n"
              << "ithz-native --run-p17a-metadata-writer --output <dir>\n"
              << "ithz-native --run-p17b-solid-ordering-diagnostics --output <dir>\n"
              << "ithz-native --run-p17c-beta-experimental --output <dir>\n"
              << "ithz-native --run-p17r-path-safety-refactor --output <dir>\n"
              << "ithz-native --run-p18r-container-refactor --output <dir>\n"
              << "ithz-native --run-p19r-index-inspect-refactor --output <dir>\n"
              << "ithz-native --run-p20a-deep-metadata-attribution --output <dir>\n"
              << "ithz-native --run-p20b-metadata-layout-simulator --output <dir>\n"
              << "ithz-native --run-p20c-physical-writer-candidate --output <dir>\n"
              << "ithz-native --run-p20d-experimental-beta --output <dir>\n"
              << "ithz-native --run-p20r-refactor --output <dir>\n"
              << "ithz-native --run-p22-payload-preconditioners --output <dir>\n"
              << "ithz-native --pack-folder project --archive out.ithz --experimental-metadata-compaction\n"
              << "ithz-native --pack-folder project --archive out.ithz --manifest-mode p9-v5-experimental\n"
              << "ithz-native --run-ci-fast --input <dataset_dir> --output <dir>\n"
              << "ithz-native --run-ci-full --input <dataset_dir> --output <dir>\n"
              << "ithz-native --self-test\n"
              << "ithz-native --hw-status\n";
}

} // namespace ithz
