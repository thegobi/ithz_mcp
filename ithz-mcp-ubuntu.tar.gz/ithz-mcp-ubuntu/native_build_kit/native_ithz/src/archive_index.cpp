#include "ithz/archive_index.hpp"

namespace ithz {

const char* archive_index_refactor_note() {
    return "archive index lookup seam active";
}

} // namespace ithz
