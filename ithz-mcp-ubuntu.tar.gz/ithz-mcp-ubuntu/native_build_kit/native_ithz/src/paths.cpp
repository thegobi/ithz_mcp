#include "ithz/paths.hpp"

#include <algorithm>
#include <cctype>
#include <stdexcept>
#include <vector>

namespace fs = std::filesystem;

namespace ithz {

bool is_windows_reserved_name(std::string component) {
    const auto dot = component.find('.');
    if (dot != std::string::npos) component = component.substr(0, dot);
    std::transform(component.begin(), component.end(), component.begin(), [](unsigned char c) { return static_cast<char>(std::toupper(c)); });
    static const std::vector<std::string> reserved{
        "CON", "PRN", "AUX", "NUL",
        "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
    };
    return std::find(reserved.begin(), reserved.end(), component) != reserved.end();
}

void validate_archive_canonical_path(const std::string& path) {
    if (path.empty()) throw std::runtime_error("unsafe archive path: empty");
    if (path.size() > 240) throw std::runtime_error("unsafe archive path: too long");
    if (path.find('\\') != std::string::npos) throw std::runtime_error("unsafe archive path: backslash");
    const fs::path p(path);
    if (p.is_absolute() || p.has_root_name() || p.has_root_directory()) throw std::runtime_error("unsafe archive path: absolute");
    std::size_t start = 0;
    while (start <= path.size()) {
        const auto slash = path.find('/', start);
        const auto component = path.substr(start, slash == std::string::npos ? std::string::npos : slash - start);
        if (component.empty() || component == "." || component == "..") throw std::runtime_error("unsafe archive path component: " + path);
        if (component.find(':') != std::string::npos) throw std::runtime_error("unsafe archive path component: colon");
        if (component.back() == ' ' || component.back() == '.') throw std::runtime_error("unsafe archive path component: trailing dot/space");
        if (is_windows_reserved_name(component)) throw std::runtime_error("unsafe archive path component: reserved name");
        if (slash == std::string::npos) break;
        start = slash + 1;
    }
}

std::filesystem::path safe_extract_target(const std::filesystem::path& output_dir, const std::string& archive_path) {
    validate_archive_canonical_path(archive_path);
    const auto root = fs::weakly_canonical(output_dir);
    const auto target = fs::weakly_canonical(root / fs::path(archive_path));
    auto normalized = [](fs::path p) {
        auto text = p.generic_string();
        std::transform(text.begin(), text.end(), text.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        return text;
    };
    const auto root_text = normalized(root);
    const auto target_text = normalized(target);
    if (target_text != root_text && target_text.rfind(root_text + "/", 0) != 0) {
        throw std::runtime_error("unsafe extract target outside output dir");
    }
    return target;
}

} // namespace ithz
