#include "ithz/container.hpp"

#include "ithz/manifest.hpp"

namespace ithz {

std::size_t container_header_size() {
    return kHeaderSize;
}

const char* container_refactor_note() {
    return "container constants and helper seam active";
}

} // namespace ithz
