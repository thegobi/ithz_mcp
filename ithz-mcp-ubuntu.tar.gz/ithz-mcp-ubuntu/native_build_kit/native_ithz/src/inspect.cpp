#include "ithz/inspect.hpp"

namespace ithz {

const char* inspect_refactor_note() {
    return "inspect/list/why presentation seam active";
}

} // namespace ithz
