#include "ithz/metadata_layout.hpp"

#include <algorithm>
#include <map>
#include <set>

namespace ithz {

std::uint64_t metadata_varint_size(std::uint64_t value) {
    std::uint64_t n = 1;
    while (value >= 0x80) {
        value >>= 7;
        ++n;
    }
    return n;
}

namespace {

std::string stem_key(std::string name) {
    const auto dot = name.find_last_of('.');
    if (dot != std::string::npos) name = name.substr(0, dot);
    while (!name.empty() && name.back() >= '0' && name.back() <= '9') name.pop_back();
    return name.empty() ? std::string("_") : name;
}

template <typename K>
std::uint64_t repeated_bytes(const std::map<K, std::uint64_t>& counts, std::uint64_t assumed_bytes_per_repeat) {
    std::uint64_t total = 0;
    for (const auto& [_, count] : counts) {
        if (count > 1) total += (count - 1) * assumed_bytes_per_repeat;
    }
    return total;
}

std::uint64_t clamp_saving(std::uint64_t value, std::uint64_t limit) {
    return std::min(value, limit);
}

} // namespace

DeepMetadataStats analyze_deep_metadata_layout(const std::vector<MetadataFileRow>& rows, std::uint64_t bundle_count) {
    DeepMetadataStats out;
    out.bundle_count = bundle_count;
    std::map<std::string, std::uint64_t> folder_counts;
    std::map<std::string, std::uint64_t> ext_counts;
    std::map<std::string, std::uint64_t> stem_counts;
    std::map<std::string, std::uint64_t> family_counts;
    std::map<std::string, std::uint64_t> method_counts;
    std::map<std::string, std::uint64_t> restore_counts;
    std::map<std::uint64_t, std::uint64_t> size_bucket_counts;
    std::map<std::uint64_t, std::vector<std::uint64_t>> offsets_by_stream;

    for (const auto& row : rows) {
        out.total_path_chars += row.path.size();
        folder_counts[row.folder]++;
        ext_counts[row.ext]++;
        stem_counts[stem_key(row.name)]++;
        family_counts[row.family]++;
        method_counts[row.method]++;
        restore_counts[row.restore_mode]++;
        size_bucket_counts[row.size <= 64 ? 64 : row.size <= 256 ? 256 : row.size <= 1024 ? 1024 : row.size <= 4096 ? 4096 : 65536]++;
        offsets_by_stream[row.stream_id].push_back(row.bundle_offset);
        out.selection_reason_bytes += row.selection_reason.size();
        out.restore_segment_bytes += metadata_varint_size(row.stream_id) + metadata_varint_size(row.bundle_offset) + metadata_varint_size(row.size);
        out.varint_length_bytes += metadata_varint_size(row.size);
    }

    out.unique_prefix_count = folder_counts.size();
    for (const auto& row : rows) {
        if (folder_counts[row.folder] > 1) out.repeated_prefix_bytes += row.folder.size();
        if (ext_counts[row.ext] > 1) out.extension_repetition_bytes += row.ext.size();
    }
    out.filename_stem_repetition_score = repeated_bytes(stem_counts, 2);
    out.estimated_prefix_dict_savings = out.repeated_prefix_bytes / 2 + out.extension_repetition_bytes / 2 + out.filename_stem_repetition_score;

    out.repeated_family_id_bytes = repeated_bytes(family_counts, 1);
    out.repeated_method_id_bytes = repeated_bytes(method_counts, 1);
    out.repeated_restore_mode_bytes = repeated_bytes(restore_counts, 1);
    out.repeated_size_class_bytes = repeated_bytes(size_bucket_counts, 1);
    out.estimated_row_template_savings =
        (out.repeated_family_id_bytes + out.repeated_method_id_bytes + out.repeated_restore_mode_bytes + out.repeated_size_class_bytes) / 2;

    for (auto& [_, offsets] : offsets_by_stream) {
        std::sort(offsets.begin(), offsets.end());
        std::uint64_t prev = 0;
        for (const auto offset : offsets) {
            out.monotonic_offset_delta_bytes += metadata_varint_size(offset - prev);
            prev = offset;
        }
    }
    out.repeated_small_length_bucket_bytes = repeated_bytes(size_bucket_counts, 1);
    out.estimated_offset_table_savings = rows.size() > out.monotonic_offset_delta_bytes
        ? (rows.size() - out.monotonic_offset_delta_bytes) / 2 + out.repeated_small_length_bucket_bytes / 2
        : out.repeated_small_length_bucket_bytes / 2;

    out.bundle_header_bytes = bundle_count * 8;
    out.family_table_bytes = family_counts.size() * 4 + method_counts.size();

    std::map<std::string, std::uint64_t> potentials{
        {"path_prefix", out.estimated_prefix_dict_savings},
        {"file_row_template", out.estimated_row_template_savings},
        {"offset_layout", out.estimated_offset_table_savings},
        {"selection_reason", out.selection_reason_bytes / 2},
        {"bundle_header", out.bundle_header_bytes / 4}
    };
    for (const auto& [name, value] : potentials) {
        if (value > out.largest_potential_component_bytes) {
            out.largest_potential_component = name;
            out.largest_potential_component_bytes = value;
        }
    }
    return out;
}

std::vector<LayoutSimulation> simulate_metadata_layouts(
    const DeepMetadataStats& stats,
    std::uint64_t archive_bytes_p9_v3,
    std::uint64_t archive_bytes_p9_v4,
    std::uint64_t manifest_bytes_p9_v3,
    std::uint64_t path_table_bytes,
    std::uint64_t file_table_bytes,
    std::uint64_t offset_table_bytes,
    std::uint64_t family_table_bytes,
    std::uint64_t bundle_header_bytes
) {
    auto make = [&](std::string name, std::uint64_t path_save, std::uint64_t file_save, std::uint64_t offset_save,
                    std::uint64_t family_save, std::uint64_t bundle_save, std::string risk, std::string reader) {
        const std::uint64_t savings =
            clamp_saving(path_save, path_table_bytes) +
            clamp_saving(file_save, file_table_bytes) +
            clamp_saving(offset_save, offset_table_bytes) +
            clamp_saving(family_save, family_table_bytes) +
            clamp_saving(bundle_save, bundle_header_bytes);
        LayoutSimulation sim;
        sim.layout_name = std::move(name);
        sim.estimated_path_table_bytes = path_table_bytes > path_save ? path_table_bytes - path_save : 0;
        sim.estimated_file_table_bytes = file_table_bytes > file_save ? file_table_bytes - file_save : 0;
        sim.estimated_offset_table_bytes = offset_table_bytes > offset_save ? offset_table_bytes - offset_save : 0;
        sim.estimated_family_table_bytes = family_table_bytes > family_save ? family_table_bytes - family_save : 0;
        sim.estimated_bundle_header_bytes = bundle_header_bytes > bundle_save ? bundle_header_bytes - bundle_save : 0;
        sim.estimated_manifest_bytes = manifest_bytes_p9_v3 > savings ? manifest_bytes_p9_v3 - savings : manifest_bytes_p9_v3;
        sim.estimated_archive_bytes = archive_bytes_p9_v3 > savings ? archive_bytes_p9_v3 - savings : archive_bytes_p9_v3;
        sim.savings_vs_p9_v3 = archive_bytes_p9_v3 > sim.estimated_archive_bytes ? archive_bytes_p9_v3 - sim.estimated_archive_bytes : 0;
        sim.savings_vs_p9_v4 = archive_bytes_p9_v4 > sim.estimated_archive_bytes ? archive_bytes_p9_v4 - sim.estimated_archive_bytes : 0;
        sim.implementation_risk = risk;
        sim.reader_complexity = reader;
        sim.extract_file_risk = reader == "high" ? "medium" : "low";
        sim.path_safety_risk = "low";
        sim.backward_compatibility_risk = risk == "high" ? "medium" : "low";
        return sim;
    };

    return {
        make("current_p9_v3", 0, 0, 0, 0, 0, "low", "low"),
        make("p9_v4_file_row_compaction", 0, stats.estimated_row_template_savings / 2, stats.estimated_offset_table_savings / 4, 0, 0, "low", "low"),
        make("p9_v5_prefix_dict_sim", stats.estimated_prefix_dict_savings, 0, 0, 0, 0, "low", "low"),
        make("p9_v5_prefix_dict_plus_offset_delta_sim", stats.estimated_prefix_dict_savings, 0, stats.estimated_offset_table_savings, 0, 0, "medium", "medium"),
        make("p9_v5_prefix_dict_plus_file_row_templates_sim", stats.estimated_prefix_dict_savings, stats.estimated_row_template_savings, 0, stats.family_table_bytes / 4, 0, "medium", "medium"),
        make("p7b_v3_bundle_offset_table_sim", 0, 0, stats.estimated_offset_table_savings, 0, stats.bundle_header_bytes / 4, "low", "low"),
        make("p9_v5_aggressive_sim", stats.estimated_prefix_dict_savings, stats.estimated_row_template_savings, stats.estimated_offset_table_savings, stats.family_table_bytes / 2, stats.bundle_header_bytes / 2, "high", "high"),
        make("guarded_store_minimal_metadata_sim", stats.estimated_prefix_dict_savings / 2, stats.estimated_row_template_savings / 2, stats.estimated_offset_table_savings / 2, stats.family_table_bytes / 4, stats.bundle_header_bytes / 4, "medium", "medium")
    };
}

} // namespace ithz
