#include "ithz/safety.hpp"

namespace ithz {

static_assert(kIthzSafetyPolicy[0] != '\0');

} // namespace ithz
