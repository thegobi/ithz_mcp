# ITHZ Native C++20 Engine

Status: P4 native selector parity validated on the P0/P1 fixture.

This branch keeps `experiments/06_ithz_archive/ithz_cfc_p0_p1.py` as the
auditable Python oracle and adds a C++20 native engine under `native_ithz/`.
The first native target is deliberately narrow:

```text
Python pack -> C++ decode/verify -> decoded SHA matches
```

The C++ engine must not change the CFC planning discipline. Probe and candidate
work may later be parallelized or AVX2-accelerated, but compression-plan commit
must remain canonical, checkpointed, and deterministic.

## Build

```powershell
& 'C:\BuildTools\Common7\Tools\VsDevCmd.bat' -arch=x64 -host_arch=x64
& 'C:\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe' `
  -S native_ithz `
  -B native_ithz\build_avx2 `
  -G 'Visual Studio 17 2022' -A x64 `
  -DITHZ_ENABLE_X64_AVX2=ON
& 'C:\BuildTools\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe' `
  --build native_ithz\build_avx2 --config Release
```

## Current Commands

Inspect a Python-generated archive:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --inspect `
  --archive experiments\06_ithz_archive\raw\archives\checkpointed_cfc_original_order.ithz
```

Decode and verify:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --decode `
  --archive experiments\06_ithz_archive\raw\archives\checkpointed_cfc_original_order.ithz `
  --output experiments\06_ithz_archive\raw\native_ithz\decoded_python_archive `
  --verify
```

Pack in phase-2A oracle-plan parity mode:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --pack `
  --input experiments\06_ithz_archive\raw\p0_p1_dataset `
  --archive experiments\06_ithz_archive\raw\native_ithz\cpp_checkpointed_original.ithz `
  --variant checkpointed_cfc `
  --schedule original `
  --manifest-mode json `
  --verify
```

The phase-2A packer intentionally uses the Python-generated
`experiments/06_ithz_archive/raw/support_cut_plan.json` as the oracle logical
plan. This validates native payload/container writing and cross-decoder
compatibility before porting the CFC selector itself.

Run the current native follow-up matrix:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-native-phases `
  --input experiments\06_ithz_archive\raw\p0_p1_dataset `
  --output experiments\06_ithz_archive\raw\native_ithz
```

Run the P4 no-oracle native selector gate:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p4-native-selector `
  --input experiments\06_ithz_archive\raw\p0_p1_dataset `
  --output experiments\06_ithz_archive\raw\native_ithz
```

## Windows Shell Integration

The first Windows shell integration layer lives in
`native_ithz/windows_shell/`.

It adds an explicit current-user installer for:

- `.ithz` file association;
- double-click inspect/list behavior;
- right-click `Inspect families`, `List contents`, `Verify safe`, and
  `Extract here`;
- right-click `Open virtual ITHZ drive` / `Unmount virtual ITHZ drive` when the
  Dokany runtime is installed;
- right-click `Create ITHZ zone` for files and folders.

Build the single-EXE installer:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\build_single_exe_installer.ps1
```

The resulting EXE is written to:

```text
native_ithz\build_shell_installer\Release\ithz-shell-installer.exe
```

It contains both AVX2 and scalar `ithz-native.exe` payloads, the Dokan/FUSE
provider payload, a no-console shell launcher, and auto-selects the correct
native payload at install time.

Dry-run install:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\install_ithz_shell.ps1
```

Apply for the current user:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\install_ithz_shell.ps1 -Apply
```

The installer defaults to `-NativeProfile auto`: it checks Windows AVX2 CPU
feature support and installs the AVX2 build when supported, otherwise the scalar
build. `-NativeProfile scalar`, `-NativeProfile avx2`, `-NativeExe`, or
`ITHZ_NATIVE_EXE` can be used for explicit control.

Uninstall:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\uninstall_ithz_shell.ps1 -Apply -RemoveFiles
```

Smoke test:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\smoke_test.ps1 -ApplyRegistrySmoke
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\single_exe_smoke_test.ps1
```

The shell integration calls the existing `ithz-native.exe` CLI. It does not
change archive format, compression methods, CFC planning, family assignment, or
P10 extraction safety rules. It also makes no ZIP/tar.gz/7z superiority claim.
Explorer actions use the installed no-console launcher, so double-click and
context menu actions no longer open a visible PowerShell window.

Explorer virtual-folder work now has an optional Dokan/FUSE provider prototype
that is also packaged in the single-EXE/MSI shell installer as an explicit
context-menu action; see `native_ithz/windows_shell/EXPLORER_PHASE_PLAN.md`.

Freeze and re-check the P4 golden regression:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-golden-regression `
  --input experiments\06_ithz_archive\raw\p0_p1_dataset `
  --output experiments\06_ithz_archive\raw\native_ithz
```

Run the P5/P6 native corpus stress and timing sprint:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p5-p6-stress `
  --output experiments\06_ithz_archive\raw\native_ithz
```

Run the P6D/P7A performance cleanup and fair baseline harness:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p6d-p7a `
  --output experiments\06_ithz_archive\raw\native_ithz
```

Run the P20 metadata-layout diagnostics and explicit experimental writer checks:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p20a-deep-metadata-attribution `
  --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p20b-metadata-layout-simulator `
  --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p20c-physical-writer-candidate `
  --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p20d-experimental-beta `
  --output experiments\06_ithz_archive\raw\native_ithz
```

The p9-v5 writer is explicit only:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --pack-folder project `
  --archive project-p9v5.ithz `
  --manifest-mode p9-v5-experimental `
  --verify=safe
```

Default `--pack-folder` behavior remains auto-mixed p9-v3 with safe verification.
`p9-v4-experimental` and `p9-v5-experimental` are metadata-layout experiments,
not default promotion or archive-superiority claims.

## Phase Gates

- C++ decoder reads Python `.ithz` JSON-manifest archives: passed.
- C++ verifies fixed header, footer magic, manifest checksum, payload checksum,
  compression plan hash, payload SHA-256, per-file SHA-256, and global dataset
  SHA-256: passed.
- C++ supports `STORE`, `RLE`, `RANGE0`, `LZ_RANGE`,
  `DELTA_BASE_RESIDUAL`, and `BYTE_SHUFFLE_RANGE` decode paths: passed on the
  current Python archive.
- AVX2 is currently a build profile for future probe/payload acceleration; it
  must not change semantic plan hashes.
- Phase 2B schedule QA in oracle-plan writer mode: passed for 8 schedule/thread
  labels.
- Phase 2C native greedy event-local negative control: passed lossless decode
  and produced 5 unique plan hashes across 5 traversal schedules.
- Phase 2D C++ vs Python semantic parity matrix: passed.
- Phase 3A AVX2 byte-level probe smoke: scalar and AVX2 counters match.
- Phase 3B compact-varint binary manifest writer/reader: passed C++ decode and
  Python decode while preserving the semantic plan hash.
- Phase 4 native selector parity: passed. C++ now reproduces the P0/P1
  checkpointed CFC semantic plan without using the Python `support_cut_plan.json`
  as the logical input.
- Golden P4 regression: passed. The P0/P1 compact archive remains 87,985 bytes
  and keeps the reference decoded SHA and semantic plan hash.
- P5/P6 corpus stress and timing: passed on 6 generated corpus profiles,
  including a 29,775,712-byte medium structured corpus and a negative
  precompressed/random corpus.
- P6D performance cleanup: passed. Pack timing now separates
  `--verify=off`, `--verify=checksums-only`, and `--verify=full`.
- P7A fair baseline harness: passed. ZIP/deflate is measured as the available
  system baseline; zstd, brotli, and 7z are reported unavailable when absent.

## Current Validation

Build:

```text
native_ithz/build_avx2/Release/ithz-native.exe
```

Self-test:

```text
self_test_ok=true
```

Hardware/build status:

```text
ithz_native_ok=true
cxx_standard=20
avx2_build=true
```

Inspecting the Python P0/P1 archive:

```text
format=ITHZ-CFC
version=1
manifest_encoding=json
file_count=19
chunk_count=100
support_count=19
checkpoint_count=46
payload_stream_count=100
manifest_bytes=108952
payload_bytes=76607
sha256_original=72749fd68b455b0e45ef39a898564472cc58bfe76829b0653f2a075e7a0a326b
compression_plan_hash=e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c
```

Python pack -> C++ decode:

```text
decode_ok=true
verify=true
decoded_sha256=72749fd68b455b0e45ef39a898564472cc58bfe76829b0653f2a075e7a0a326b
compression_plan_hash=e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c
```

Decoded output root:

```text
experiments/06_ithz_archive/raw/native_ithz/decoded_python_archive/
```

## Phase 2A Packer Parity

C++ pack -> C++ decode:

```text
pack_ok=true
decoded_sha256=72749fd68b455b0e45ef39a898564472cc58bfe76829b0653f2a075e7a0a326b
semantic_plan_hash=e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c
container_bytes_hash=a4cb18a026e92443a66954ea937f8c8d86c02bef701d90a78ba249d7148491fc
payload_bytes=76607
manifest_bytes=108522
total_archive_bytes=185357
```

C++ pack -> Python decode:

```text
decoded_sha256=72749fd68b455b0e45ef39a898564472cc58bfe76829b0653f2a075e7a0a326b
```

Generated native outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/cpp_checkpointed_original.ithz
experiments/06_ithz_archive/raw/native_ithz/native_ithz_phase2a_pack_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_phase2a_summary.md
```

This milestone separates `semantic_plan_hash` from `container_bytes_hash`.
The physical `.ithz` bytes differ from Python's audit archive, but the logical
plan hash remains the reference hash.

## Phase 2B-3B Native Follow-Up

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_phase2b_schedule_stability_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_phase2c_greedy_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_phase2d_python_parity_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_phase3a_avx2_probe_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_phase3b_binary_manifest_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_phase2b_3b_summary.md
```

Phase 2B is explicitly `oracle_plan_scalar_schedule_writer`: it validates that
the native writer/decoder keeps the same semantic plan across schedule labels,
but it is not yet a full native selector proof. The 8 tested labels all decode
to the reference dataset SHA and keep the reference semantic plan hash:

```text
decoded_sha256=72749fd68b455b0e45ef39a898564472cc58bfe76829b0653f2a075e7a0a326b
semantic_plan_hash=e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c
payload_bytes=76,607
manifest_bytes=108,522
total_archive_bytes=185,357
```

Phase 2C adds a native `greedy_event_local` negative control. It decodes
losslessly for all 5 traversal schedules, but produces 5 distinct semantic plan
hashes, as expected for visit-order local commit.

Phase 3A adds an AVX2 probe smoke for byte-level counters only:

```text
input_bytes=356,069
zero_count scalar/avx2=520/520
ascii_count scalar/avx2=312,087/312,087
separator_count scalar/avx2=55,649/55,649
metrics_match=true
semantic_plan_hash_unchanged=true
```

Phase 3B adds compact-varint manifest mode. It preserves the semantic plan hash
and decoded SHA while changing the physical container bytes:

```text
json_manifest_bytes=108,522
compact_manifest_bytes=11,150
payload_bytes=76,607
json_total_archive_bytes=185,357
compact_total_archive_bytes=87,985
manifest_reduction_pct=89.726
```

The compact archive was decoded by both C++ and Python:

```text
manifest_encoding=compact-varint-v1
decoded_sha256=72749fd68b455b0e45ef39a898564472cc58bfe76829b0653f2a075e7a0a326b
compression_plan_hash=e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c
```

## Phase 4 Native Selector Parity

Phase 4 ports the P0/P1 checkpointed selector into C++:

```text
dataset scan -> probe table -> similarity clusters -> canonical medoids
-> support/cut table -> checkpoint table -> chunk method plan
-> compact .ithz archive
```

This phase does not read Python `support_cut_plan.json` as the no-oracle
logical plan. That file is used only as the comparison reference for parity
reports.

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/support_cut_plan_native.json
experiments/06_ithz_archive/raw/native_ithz/support_cut_plan_python_reference.json
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p4_probe_parity.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p4_selector_diff.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p4_schedule_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p4_summary.md
experiments/06_ithz_archive/raw/native_ithz/cpp_no_oracle_checkpointed_compact.ithz
```

P4 result:

```text
probe_parity_rows=100
probe_parity_mismatches=0
support_count=19
checkpoint_count=46
method_counts=BYTE_SHUFFLE_RANGE=4;DELTA_BASE_RESIDUAL=8;LZ_RANGE=74;RANGE0=2;STORE=12
native_semantic_plan_hash=e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c
python_reference_plan_hash=e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c
checkpointed_unique_plan_hashes=1
greedy_unique_plan_hashes=5
no_oracle_manifest_bytes=11,150
no_oracle_total_archive_bytes=87,985
```

No-oracle C++ pack was decoded by both C++ and Python:

```text
decoded_sha256=72749fd68b455b0e45ef39a898564472cc58bfe76829b0653f2a075e7a0a326b
compression_plan_hash=e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c
```

This is the native selector milestone: C++ independently reproduces the
checkpointed CFC plan on the P0/P1 fixture. It is still not a ZIP superiority
claim and not yet a larger-corpus stress result.

## Golden Regression And P5/P6 Stress

Golden regression artifacts:

```text
experiments/06_ithz_archive/raw/native_ithz/golden_regression_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/golden_regression_summary.md
experiments/06_ithz_archive/raw/native_ithz/golden/golden_compact_archive.ithz
experiments/06_ithz_archive/raw/native_ithz/golden/golden_probe_parity_csv.csv
experiments/06_ithz_archive/raw/native_ithz/golden/golden_selector_diff.md
experiments/06_ithz_archive/raw/native_ithz/golden/golden_schedule_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/golden/golden_greedy_matrix.csv
```

P5/P6 generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p5_corpus_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p5_schedule_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p5_timing_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p6b_avx2_probe_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p6c_threading_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p5_p6_summary.md
```

Measured P5/P6 acceptance:

```text
profiles=6
checkpointed_unique_hashes=1 for every profile
checkpointed_all_decoded_ok=true for every profile
python_decode_ok=true for representative compact archive in every profile
greedy_unique_hashes=5 for every profile
P6B scalar_vs_avx2_probe_counters_match=true for every profile
P6C threaded_probe_reduce_matches_scalar=true for 1/4/8 thread probes
```

The negative precompressed/random profile is intentionally not forced into a
structure extraction path. Its representative method count is `STORE=896`,
which keeps the negative-control interpretation clean.

## P6D/P7A Performance And Baselines

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p6d_perf_clean_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p6d_perf_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7a_baseline_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7a_baseline_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p6d_p7a_summary.md
```

P6D result:

```text
verify modes=off, checksums-only, full
pack benchmark excludes implicit full decode verify
decode benchmark is separate
peak_memory_mb_best_effort=231.008
```

P7A result:

```text
ITHZ_checkpointed_compact rows=6 decoded_ok=true
ITHZ_greedy_event_local rows=6 decoded_ok=true deterministic_schedule_ok=false
ZIP_deflate rows=6 decoded_ok=true
tar_zstd available=false
tar_brotli available=false
7z available=false
```

ZIP/deflate remains a reference baseline only. On this corpus set, ZIP is
usually smaller than ITHZ; the useful ITHZ signal remains deterministic
support/cut planning and clean fallback behavior. The negative corpus stays
pass-through-like: checkpointed compact archive bytes are close to input bytes
and the method count remains `STORE=896`.

## P7B Many-Small-Files Specialization

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7b_small_files_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7b_schedule_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7b_summary.md
```

P7B adds a narrow `checkpointed_cfc_p7b_small_file_bundle` experiment. It does
not add a new compression method: bundle payloads use existing `STORE` or
`LZ_RANGE`. The new behavior is deterministic small-file grouping by canonical
folder/extension/path hash, a per-file offset table, and a compact P7B
path/name/string manifest.

Measured P7B acceptance:

```text
profiles=5
checkpointed P7B stable semantic plan hash=5/5
checkpointed P7B decoded OK=5/5
negative/random small-file profiles STORE/pass-through-like=5/5
P7B best threshold smaller than P7A checkpointed compact=4/5
P7B best threshold smaller than ZIP/deflate in this environment=4/5
ZIP/deflate smaller than P7B in this environment=1/5
```

Selected rows:

```text
many_small_files_1000:
  P7A checkpointed compact=266,683 B
  P7B small-file bundle=84,106 B
  ZIP_deflate=225,753 B

many_small_files_10000:
  P7A checkpointed compact=2,709,013 B
  P7B small-file bundle=852,719 B
  ZIP_deflate=2,303,211 B

negative_precompressed_random_smallfiles:
  P7B small-file bundle=665,619 B
  ZIP_deflate=614,906 B
  method behavior=STORE=896
```

Interpretation: P7B supports only the narrow claim that ITHZ-CFC small-file
bundle mode improves the generated many-small-files corpus under deterministic
schedule-stable planning. It is not a general ZIP superiority claim.

## P7B-Real And Ablation

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7b_real_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7b_threshold_sweep.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7b_ablation_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7b_real_summary.md
```

P7B-real samples read-only candidates from `C:/work` into
`experiments/06_ithz_archive/raw/native_ithz/p7b_real_corpora/`, with
deterministic synthetic-realistic fallbacks if a source is unavailable. It does
not modify the original source folders.

Measured P7B-real acceptance:

```text
profiles=7
P7B full schedule-stable profiles=7/7
P7B full decoded profiles=7/7
negative/random profiles clean=7/7
P7B full smaller than ZIP/deflate=6/7
P7B full smaller than tar.gz=0/7
```

Selected rows:

```text
real_like_wp_theme_small:
  P7B_full_4096=27,566 B
  ZIP_deflate=113,288 B
  tar_gzip=7,052 B

real_like_php_js_css_project:
  P7B_full_4096=610,756 B
  ZIP_deflate=682,421 B
  tar_gzip=474,770 B

real_like_node_modules_subset:
  P7B_full_4096=454,180 B
  ZIP_deflate=559,172 B
  tar_gzip=347,746 B

negative_precompressed_random_smallfiles:
  P7B_full_4096=665,620 B
  ZIP_deflate=614,906 B
  tar_gzip=510,996 B
  method behavior=STORE=896
```

Threshold/grouping sweep highlights:

```text
real_like_wp_theme_small best=27,479 B at threshold=2048, grouping=folder_only
real_like_php_js_css_project best=514,919 B at threshold=32768, grouping=extension_global
real_like_node_modules_subset best=392,331 B at threshold=16384, grouping=extension_global
mixed_real_like_small_medium best=163,806 B at threshold=32768, grouping=extension_global
```

Ablation signal:

```text
path/string table matters: no_path_string_table is larger on the small docs/theme cases
offset varints matter: raw_offset_table is larger than varint_offset_table
bundle payload matters: store_bundle_only is much larger on compressible text/config corpora
```

Interpretation: P7B-real is stronger than the generated-only P7B result against
ZIP/deflate, but tar.gz is a substantially stronger solid-stream reference and
wins on every tested P7B-real profile. The narrow supported claim is therefore:
P7B bundle mode improves tested generated/real-like many-small-file corpora
under deterministic schedule-stable planning, but it does not establish general
superiority over solid archive baselines.

## P7B-Solid And CI Hygiene

Commands:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p7b-solid --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-ci-fast --input experiments\06_ithz_archive\raw\p0_p1_dataset --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-ci-full --input experiments\06_ithz_archive\raw\p0_p1_dataset --output experiments\06_ithz_archive\raw\native_ithz
```

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7b_solid_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7b_solid_schedule_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p7b_solid_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_ci_fast_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_ci_full_summary.md
```

P7B-solid keeps the existing `STORE` and `LZ_RANGE` payload paths. The tested
variants only change deterministic small-file bundle grouping and thresholds:
`P7B_current_full`, `P7B_solid_by_extension`, `P7B_solid_by_folder`,
`P7B_solid_global_text`, and `P7B_solid_guarded_mixed`.

Measured P7B-solid acceptance:

```text
P7B-solid decoded rows=35/35
P7B-solid schedule-stable rows=35/35
negative/random rows guarded=5/5
solid variant rows smaller than P7B current=13
P7B/P7B-solid rows smaller than ZIP/deflate=30/35
P7B/P7B-solid rows smaller than tar.gz=0/35
```

Selected rows:

```text
real_like_node_modules_subset:
  P7B_current_full=454,173 B
  P7B_solid_by_extension=392,324 B
  ZIP_deflate=559,172 B
  tar_gzip=347,792 B

mixed_real_like_small_medium:
  P7B_current_full=188,925 B
  P7B_solid_by_extension=163,806 B
  ZIP_deflate=393,042 B
  tar_gzip=111,382 B

negative_precompressed_random_smallfiles:
  P7B_solid_guarded_mixed=665,621 B
  ZIP_deflate=614,906 B
  tar_gzip=510,970 B
  method behavior=STORE=896
```

Runtime hygiene:

- `--run-p5-p6-stress`, `--run-p7b-small-files`, `--run-p7b-real`, `--run-p7b-solid`, and `--run-p6d-p7a` return a cached pass when their passed summary and required output matrices already exist.
- `--run-ci-fast` runs quick sanity plus golden regression.
- `--run-ci-full` orchestrates golden, P5/P6, P6D/P7A, P7B, P7B-real, and P7B-solid gates; long gates can use cached passed summaries to avoid shell timeout after completed evidence is already present.

Interpretation: P7B-solid closes part of the gap between current P7B and a
solid-stream style baseline on several project-like profiles, but tar.gz still
wins on every tested P7B-solid row. The supported claim remains narrow:
deterministic CFC small-file bundling can improve selected small-file project
corpora while preserving schedule-stable planning. It is not a general archive
superiority claim.

## P8A Solid Backend Gap And P8B Cache Hygiene

Command:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p8a-solid-backend --input experiments\06_ithz_archive\raw\p0_p1_dataset --output experiments\06_ithz_archive\raw\native_ithz
```

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p8a_solid_backend_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p8a_solid_backend_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_cache_hygiene_summary.md
```

P8A compares the same P7B-real profiles across:

- `P7B_current`
- `P7B_solid_current_LZ_RANGE`
- `P8A_solid_zlib_deflate_bundle`
- `P8A_solid_store_bundle`
- ZIP/deflate
- tar.gz

Measured P8A acceptance:

```text
decoded rows=28/28
schedule-stable rows=28/28
negative/random rows guarded=4/4
forced zlib bundle rows smaller than current solid=0/7
forced zlib bundle rows smaller than ZIP/deflate=6/7
forced zlib bundle rows smaller than tar.gz=0/7
forced STORE bundle rows smaller than current solid=0/7
```

Selected rows:

```text
real_like_node_modules_subset:
  P7B_current=454,173 B
  P7B_solid_current_LZ_RANGE=392,324 B
  P8A_solid_zlib_deflate_bundle=392,324 B
  P8A_solid_store_bundle=1,462,682 B
  tar_gzip=347,752 B

mixed_real_like_small_medium:
  P7B_current=188,925 B
  P7B_solid_current_LZ_RANGE=163,806 B
  P8A_solid_zlib_deflate_bundle=163,806 B
  P8A_solid_store_bundle=1,324,537 B
  tar_gzip=111,394 B
```

Interpretation: the existing `LZ_RANGE` bundle path is already the raw zlib
DEFLATE path for these diagnostics, so forcing the zlib bundle backend does not
close the gap to tar.gz. The remaining likely causes are metadata overhead,
bundle partitioning/order, and the lack of one sufficiently global solid stream.
This is a backend-gap diagnosis, not a superiority claim.

P8B cache hygiene:

- Cached pass guards now include command name, source hash, native binary hash,
  dataset hash, parameter hash, manifest version, payload method version, and
  build profile.
- If the cache key is absent or mismatched, the gate is treated as stale and
  must rerun.
- Summaries now include `cached`, `cache_key`, `cache_reason`, `source_hash`,
  `dataset_hash`, and related version fields.

## P9 Auto-Mixed Planner

User-facing CLI:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --analyze-folder <dir> --plan-report <auto_mixed_plan.json>
native_ithz\build_avx2\Release\ithz-native.exe --pack-folder <dir> --archive <out.ithz> --profile auto-mixed --explain-plan --verify=full
native_ithz\build_avx2\Release\ithz-native.exe --inspect <out.ithz> --families
native_ithz\build_avx2\Release\ithz-native.exe --inspect <out.ithz> --why project/src/component_0.js
native_ithz\build_avx2\Release\ithz-native.exe --list <out.ithz>
native_ithz\build_avx2\Release\ithz-native.exe --verify <out.ithz>
native_ithz\build_avx2\Release\ithz-native.exe --extract <out.ithz> --output restored
native_ithz\build_avx2\Release\ithz-native.exe --extract-file <out.ithz> --path project/src/component_0.js --output component_0.js
```

Regression runner:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p9-auto-mixed --input experiments\06_ithz_archive\raw\p0_p1_dataset --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p9c-inspect-extract --input experiments\06_ithz_archive\raw\p0_p1_dataset --output experiments\06_ithz_archive\raw\native_ithz
```

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p9_auto_mixed_plan_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p9_auto_mixed_schedule_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p9_auto_mixed_summary.md
experiments/06_ithz_archive/raw/native_ithz/example_auto_mixed_plan.json
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p9c_inspect_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p9c_extract_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p9c_summary.md
```

P9A/P9B status:

```text
decoded profiles=2/2
schedule-stable profiles=2/2
negative heterogeneous profiles guarded=1/1
```

Selected auto-mixed profile:

```text
p9_mixed_project_snapshot:
  input_bytes=4,200,100
  file_count=940
  bytes_by_family=already_compressed_or_media_store=250,250;generic_cfc=133,020;large_text_solid=3,771,140;small_text_project_bundle=45,690
  auto_mixed_archive=963,147 B
  ZIP_deflate=1,063,682 B
  tar_gzip=905,287 B
  schedule_unique_hashes=1
  extracted_sha_ok=true
```

Negative heterogeneous profile:

```text
p9_negative_heterogeneous:
  input_bytes=433,260
  families=already_compressed_or_media_store=384,960;high_entropy_guarded_store=48,300
  method_counts=STORE=360
  schedule_unique_hashes=1
  extracted_sha_ok=true
  auto_mixed_archive=505,311 B
```

P9C inspect/extract status:

```text
p9c_inspect_extract_ok=true
inspect families=passed
why representative files=passed
list representative files=passed
full extract SHA=passed
extract-file representative cases=passed
negative profile guarded/store-like=passed
```

Representative `--why` examples:

```text
media/image_0.jpg -> already_compressed_or_media_store, STORE, precompressed_media_or_compound_extension
project/src/component_0.js -> small_text_project_bundle, LZ_RANGE, small_text_project_extension_below_threshold
logs/app_0.log -> large_text_solid, LZ_RANGE, large_text_like_extension
generic/asset_0.dat -> generic_cfc, LZ_RANGE, generic_cfc_fallback
```

Interpretation: P9 is the first product-shaped auto profile. Its goal is to
keep deterministic planning, inspectable family assignment, per-file restore,
schedule-stable hashes, and clean negative controls on heterogeneous folders.
It does not claim general ZIP or tar.gz superiority; tar.gz remains smaller on
the selected mixed profile in this run.

## P10 Real-World Archive Hardening

Command:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p10-hardening --input experiments\06_ithz_archive\raw\p0_p1_dataset --output experiments\06_ithz_archive\raw\native_ithz
```

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p10_real_folder_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p10_corruption_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p10_format_compat_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p10_summary.md
```

P10 status:

```text
p10_hardening_ok=true
real/synthetic-realistic folder rows=6/6
corruption and extraction-safety rows=16/16
format compatibility/default policy rows=5/5
```

P10A smoke profiles cover WordPress-like plugin/theme trees, PHP/JS/CSS
projects, mixed docs/media/config folders, node_modules-like small-file trees,
log/config snapshots, and a negative precompressed/random profile. The generated
profiles are synthetic-realistic fallback corpora; original `C:\work` candidates
are not modified.

P10B corrupt/safety cases:

```text
truncated archive
corrupted header/footer/manifest/payload
unknown manifest version
unknown method id
wrong file SHA
duplicate path
absolute path
../ path traversal
Windows reserved name
too-long path
wrong bundle offset
empty-file SHA guard
single-file extract with wrong bundle offset
```

All corrupt inputs fail cleanly and report `unsafe_write_detected=false`.

P10C/P10D format policy:

```text
container_header_version=1
compact_manifest_v1=readable
P7B_bundle_manifest_v2=readable
P9_bundle_manifest_v3=readable and default for auto-mixed explain metadata
unknown_manifest_versions=fail_cleanly
pack-folder_default_profile=auto-mixed
semantic_plan_hash != container_bytes_hash policy documented
```

Interpretation: P10 is reliability hardening. It does not add new compression
methods and does not claim general ZIP or tar.gz superiority.

## P11 Performance & Throughput

Commands:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p11-perf --input experiments\06_ithz_archive\raw\p0_p1_dataset --output experiments\06_ithz_archive\raw\native_ithz

native_ithz\build_avx2\Release\ithz-native.exe --pack-folder <dir> --archive <out.ithz> --profile auto-mixed --perf-report <perf.json> --verify=full
```

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p11_perf_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p11_family_timing_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p11_store_fastpath_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p11_threading_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p11_extract_perf_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p11_perf_summary.md
```

P11 status:

```text
p11_perf_ok=true
instrumented pack rows=5/5
deterministic threaded fact-reduce rows=15/15
extract performance rows=14/14
CI-fast, P9 auto-mixed, P9C inspect/extract, and P10 hardening gates=passed
```

P11A adds `--perf-report <path>` and `--run-p11-perf`. The report separates
scan, path validation, path canonicalization, file read, hash, autodetect,
family assignment, per-family payload encode, manifest write, archive write,
checksum, verify, decode, and total pack timing. A smoke run on
`p9_mixed_project_snapshot` reported:

```text
archive_bytes=963,147
payload_bytes=885,920
manifest_bytes=76,999
total_pack_ms_no_verify=560.386
total_pack_ms_full_verify=9,763.938
```

The large gap between no-verify and full-verify timing is expected because full
verify performs decode verification.

P11B records STORE/media behavior for guarded families. The media-heavy
synthetic profile stored `990,180` input bytes as `990,180` archive-family
bytes and measured `store_media_MBps=258.984`. This is a hot-path measurement,
not a new compression claim.

P11C records deterministic 1/4/8-thread fact-reduce semantics. Current P11
keeps `dataset_features_hash`, `family_assignment_hash`, and
`semantic_plan_hash` identical across those thread-count rows; it does not yet
claim a parallel speedup.

P11D records full extract throughput and representative `extract-file`
latency for STORE media, small text bundles, large text solid streams, generic
CFC fallback, and high-entropy guarded STORE where present. All extract rows
preserve SHA.

Interpretation: P11 is a performance and instrumentation track. It adds no
compression methods, keeps P10 safety gates active, and does not claim general
ZIP or tar.gz superiority.

## P12 Decode / Verify / Extract Throughput

Command:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p12-decode-throughput --input experiments\06_ithz_archive\raw\p0_p1_dataset --output experiments\06_ithz_archive\raw\native_ithz
```

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p12_decode_breakdown_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p12_decode_breakdown_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p12_verify_modes_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p12_extract_file_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p12_index_cache_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p12_summary.md
```

P12 status:

```text
p12_decode_throughput_ok=true
decode breakdown rows=11/11
verify mode rows=33/33
extract-file rows=19/19
index-cache rows=11/11
CI-fast, P9 auto-mixed, P9C inspect/extract, P10 hardening, and P11 perf gates=passed
```

P12A adds decode timing fields for archive open, header read, manifest read and
parse, index build, payload seek, inflate, bundle slice, SHA verification, path
safety, file write, total decode, total extract, and full verify.

P12B adds `--verify=full-no-write`. It decodes streams and validates path,
offset, and SHA rules without writing the restored tree to disk. On the P12
profile set:

```text
aggregate_full_ms=37,676.941
aggregate_full_no_write_ms=1,105.968
aggregate_checksums_only_ms=102.591
```

The result confirms the P11 bottleneck diagnosis: full verify was dominated by
disk writes and many-file restore overhead, not just payload inflate.

P12C uses indexed partial extraction for representative files from STORE media,
small text bundles, large text solid streams, generic CFC fallback, and
high-entropy guarded STORE. All `19/19` extract-file rows preserve SHA.

P12D reuses manifest/index structures inside the process and reports
`index_build_ms` plus `path_lookup_ms`. Example rows:

```text
p9_mixed_project_snapshot index_build_ms=0.378, representative_lookup_count=4
p11_many_small_files index_build_ms=0.686, representative_lookup_count=1
```

P12E parallel decode is intentionally not enabled in this milestone. The
current result keeps the deterministic safety-first path and records where
independent segment decode can be evaluated next.

Interpretation: P12 is a decode/verify/extract throughput track. It adds no
compression methods, does not change CFC planning, family assignment, semantic
plan hashes, or P10 extraction-safety rules, and does not claim general ZIP or
tar.gz superiority.

## P13 Verify UX Defaults + Extract/Product Performance Polish

Command:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p13-product-polish --input experiments\06_ithz_archive\raw\p0_p1_dataset --output experiments\06_ithz_archive\raw\native_ithz
```

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p13_verify_policy_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p13_extract_file_perf_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p13_full_extract_write_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p13_large_folder_smoke_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p13_summary.md
```

P13 status:

```text
p13_product_polish_ok=true
large-folder smoke rows=4/4
extract-file product rows=5/5
full extract write-path rows=2/2
P12 decode throughput gate=passed
```

Verify policy:

```text
--verify=off             benchmark-only no verify
--verify=checksums-only  container/header/footer/manifest/payload checks
--verify=full-no-write   decode plus path/offset/SHA validation, no restored-tree writes
--verify=safe            alias for full-no-write; recommended product smoke default
--verify=full            decode plus validation plus restored-tree writes; heavy regression gate
```

The help text now documents these differences. P13 does not change the default
implicitly; it adds the explicit `safe` alias and records it as the recommended
product smoke verify policy. Full restored-tree verification remains available
for regression and integrity gates.

P13B extract-file product rows:

```text
real_mixed_docs_media_config media STORE: total_extract_file_ms=16.114, sha_ok=true
real_mixed_docs_media_config small text bundle: total_extract_file_ms=15.328, sha_ok=true
p11_media_store_heavy STORE: total_extract_file_ms=14.621, sha_ok=true
p11_many_small_files small text bundle: total_extract_file_ms=14.712, sha_ok=true
p11_large_text_logs large text solid: total_extract_file_ms=16.368, sha_ok=true
```

Each row uses indexed partial extraction and reports
`full_archive_extract_used=false`.

P13C full extract write-path rows:

```text
p11_many_small_files: full_extract_ms=9,236.853, file_write_ms=9,181.006, unsafe_write_detected=false
p11_large_text_logs: full_extract_ms=53.527, file_write_ms=44.126, unsafe_write_detected=false
```

The write path now precreates validated parent directories before writing file
buffers. The many-small-files row still shows that restored-tree writes dominate
full extract, so full extract remains an explicit heavy gate rather than the
default smoke path.

Interpretation: P13 is a UX/performance policy layer. It adds no compression
methods, does not change CFC planning, family assignment, semantic plan hashes,
or P10 safety rules, and does not claim general ZIP or tar.gz superiority.

## P14 Release Candidate / Tool Hardening

Command:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p14-release-candidate --input experiments\06_ithz_archive\raw\p0_p1_dataset --output experiments\06_ithz_archive\raw\native_ithz
```

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p14_cli_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p14_golden_compat_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p14_beta_corpus_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p14_summary.md
```

P14 status:

```text
p14_release_candidate_ok=true
CLI rows=11/11
golden compatibility rows=5/5
beta corpus smoke rows=6/6
```

CLI polish:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --version
native_ithz\build_avx2\Release\ithz-native.exe --help
native_ithz\build_avx2\Release\ithz-native.exe --help-verify
native_ithz\build_avx2\Release\ithz-native.exe --help-examples
```

Stable exit codes:

```text
0 OK
1 user/input error
2 archive corruption
3 path/extraction safety failure
4 unsupported format/version
5 internal error
```

Product default policy:

- `--pack-folder <dir> --archive <out.ithz>` defaults to profile `auto-mixed`.
- If no verify mode is supplied, `--pack-folder` defaults to `--verify=safe`.
- `--verify=safe` is an alias for `full-no-write`: decode plus path/offset/SHA validation without restored-tree writes.
- `--verify=full` remains the explicit restored-tree write heavy regression gate.

Golden compatibility fixtures refreshed by P14:

```text
golden_compact_v1.ithz
golden_p7b_bundle_v2.ithz
golden_p9_auto_mixed_v3.ithz
golden_negative_guarded.ithz
```

The P14 runner validates existing passed P9-P13 artefacts instead of rerunning
old long gates. To refresh those older gates, run their explicit `--run-*`
commands. P14 itself refreshes only the release-candidate CLI/golden/beta
evidence.

P14 beta corpus smoke profiles:

```text
wp_plugin_theme_like
php_js_css_project_like
docs_config_like
mixed_media_docs_config
node_modules_subset_like
logs_text_heavy
```

Interpretation: P14 turns the native ITHZ workflow into a more stable
user-facing CLI with explicit defaults, compatibility fixtures, safety-aware
verification, and user documentation. It adds no compression methods, changes no
CFC planning or P10 safety behavior, and makes no general ZIP or tar.gz
superiority claim.

## P14.5 Release Freeze / RC Packaging

Command:

```powershell
cmake -S native_ithz -B native_ithz\build_scalar -DITHZ_ENABLE_X64_AVX2=OFF
cmake --build native_ithz\build_scalar --config Release
native_ithz\build_avx2\Release\ithz-native.exe --run-p14-release-package --output experiments\06_ithz_archive\raw\native_ithz
```

Generated outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p145_release_package_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p145_release_package_summary.md
dist/ithz-native-v0.1-alpha-rc1-win64-avx2/
dist/ithz-native-v0.1-alpha-rc1-win64-scalar/
```

P14.5 status:

```text
p145_release_package_ok=true
release_dir_avx2=dist/ithz-native-v0.1-alpha-rc1-win64-avx2
release_dir_scalar=dist/ithz-native-v0.1-alpha-rc1-win64-scalar
smoke_test.ps1=passed for both packages
SHA256SUMS.txt=generated
```

Each package contains:

- `ithz-native.exe`;
- `README_FIRST.md`;
- quickstart, verify modes, safety model, limitations, native README, and
  release notes;
- small golden `.ithz` samples;
- `sample/project/` tiny smoke corpus;
- `sample_commands.ps1`;
- `smoke_test.ps1`;
- `SHA256SUMS.txt`.

`smoke_test.ps1` runs `--version`, `--self-test`, `--hw-status`,
`--pack-folder` with default safe verification, inspect families, inspect why,
list, safe verify, extract-file, and full extract on the tiny sample.

The AVX2 package is the optimized build profile. The scalar package is a
fallback for wider Windows testing on machines where AVX2 is unavailable.
`README_FIRST.md` is intentionally short: run `smoke_test.ps1`, try
`sample_commands.ps1`, use `--verify=safe` for normal checks, and do not treat
this RC as a ZIP/tar.gz replacement claim.

Interpretation: P14.5 freezes AVX2 and scalar Windows RC packages. It validates
release usability and packaging only; it does not rerun old long gates and does
not claim general ZIP or tar.gz superiority.

## P15 Archive Attribution, Beta Smoke, and Refactor

Commands:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p15a-size-attribution --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p15b-real-beta-smoke --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p15r-refactor --output experiments\06_ithz_archive\raw\native_ithz
```

P15 status:

```text
p15a_size_attribution_ok=true
p15b_real_beta_smoke_ok=true
p15r_refactor_ok=true
```

P15A inspected 17 archives/profiles and reported exact top-level attribution
with `attribution_error_bytes=0` for every row. Aggregate component ranking:

```text
payload=4,093,789 B (87.62%)
file_table=296,287 B (6.34%)
path_table=176,108 B (3.77%)
method_metadata=38,716 B (0.83%)
bundle_header=25,392 B (0.54%)
unknown_or_unattributed=22,741 B (0.49%)
offset_table=14,748 B (0.32%)
checksum_footer=3,876 B (0.08%)
family_table=690 B (0.01%)
```

Interpretation: the inspected aggregate is payload-dominated, but metadata-heavy
small-file profiles point to future P16 candidates around file/path table
compaction. STORE/guarded media and high-entropy rows should remain
conservative rather than forced into structure extraction.

P15B ran seven RC1 beta-smoke profiles using synthetic-realistic fallback
corpora. It used default `--verify=safe`, safe verify, inspect/list/why, and
representative extract-file checks. All extract-file SHA checks passed, schedule
hash count stayed `1`, and the negative profile stayed guarded/store-like
(`negative_guard_count=180`). No original `C:/work` directories were modified.

P15R was only run after P15A and P15B passed. The refactor is intentionally
P15R-lite and behavior-preserving:

- `native_ithz/include/ithz/version.hpp`: RC version, release slugs, manifest
  support versions, exit-code string;
- `native_ithz/include/ithz/cli.hpp`: CLI help/version declarations;
- `native_ithz/src/cli.cpp`: `--version`, `--help`, `--help-verify`, and
  `--help-examples` output text.

`main.cpp` remains the orchestration entrypoint. Later refactor backlog:
container I/O, manifest parsing/writing, auto-mixed planner, bundle code,
extract/verify, performance runners, and experiment runners.

Raw P15 outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15a_size_attribution_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15a_family_attribution_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15a_overhead_rankings.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15a_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15b_real_beta_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15b_family_breakdown_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15b_why_examples.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15b_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15r_refactor_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15r_file_map.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p15r_summary.md
```

P15 adds diagnostics, beta smoke evidence, and maintainability only. It adds no
compression methods, changes no CFC planning/family assignment/safety rules, and
makes no ZIP, tar.gz, or 7z superiority claim.

## P16 Metadata Diagnostics, Payload Partitioning, and Refactor

Commands:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p16a-metadata-compaction --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p16b-payload-partition --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p16r2-refactor --output experiments\06_ithz_archive\raw\native_ithz
```

P16 status:

```text
p16a_metadata_compaction_ok=true
p16b_payload_partition_diagnostics_ok=true
p16r2_refactor_ok=true
```

P16A is a gated metadata-compaction estimate, not a physical p9-v4/p7b-v3
writer. It writes no new manifest layout and changes no normal archive output.

Estimated P16A savings:

```text
p7b_many_small_1000:                 84,132 B -> 72,687 B, saved 11,445 B
p7b_solid_many_small_1000:           80,776 B -> 69,018 B, saved 11,758 B
wp_plugin_theme_like:                83,479 B -> 79,642 B, saved 3,837 B
php_js_css_project_like:             18,493 B -> 15,436 B, saved 3,057 B
docs_config_like:                    24,680 B -> 21,006 B, saved 3,674 B
logs_text_heavy:                      2,468 B ->  2,139 B, saved 329 B
negative_mixed_precompressed_random:420,663 B ->403,954 B, saved 16,709 B
```

Interpretation: path/file/offset metadata compaction can reduce tested
small-file overhead, but P16A is still diagnostic. A real manifest v4 writer
would require an explicit format/version bump.

P16B is payload/solid partition diagnostics only. It emitted per-family stream
counts, stream sizes, compression ratios, and ordering diagnostics. The most
frequent suspected gap reason was `metadata`; other reasons were
`guarded_store_expected`, `ordering`, and `payload_entropy`. Baselines were not
rerun inside P16B to avoid repeating slow external archive work; P16A already
records the baseline comparison for this sprint.

P16R2 is behavior-preserving P16R2-lite:

- `native_ithz/include/ithz/manifest.hpp`: container magic, footer magic,
  manifest magic, header size, flags, default chunk size;
- `native_ithz/src/manifest.cpp`: manifest module translation unit.

Raw P16 outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p16a_metadata_compaction_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p16a_family_metadata_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p16a_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p16b_payload_partition_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p16b_ordering_diagnostics.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p16b_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p16r2_refactor_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p16r2_file_map.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p16r2_summary.md
```

P16 adds diagnostics and maintainability only. It adds no payload methods,
changes no CFC planning/family assignment/P10 safety behavior, and makes no ZIP,
tar.gz, or 7z superiority claim.

## P17 Metadata Writer, Solid Diagnostics, and Refactor Chain

Commands:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p17a-metadata-writer --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p17b-solid-ordering-diagnostics --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p17c-beta-experimental --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p17r-path-safety-refactor --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p18r-container-refactor --output experiments\06_ithz_archive\raw\native_ithz
native_ithz\build_avx2\Release\ithz-native.exe --run-p19r-index-inspect-refactor --output experiments\06_ithz_archive\raw\native_ithz
```

P17 status:

```text
p17a_metadata_writer_ok=true
p17b_solid_ordering_diagnostics_ok=true
p17c_beta_experimental_ok=true
p17r_path_safety_refactor_ok=true
p18r_container_refactor_ok=true
p19r_index_inspect_refactor_ok=true
```

P17A converts the P16A estimate into a physical, explicit
`p9-v4-experimental` metadata writer. The default p9-v3/P7B writer remains
unchanged. The new reader accepts compact-v1, p7b-v2, p9-v3, and the
experimental v4 mode; unsupported future versions fail cleanly.

Physical P17A archive deltas:

```text
p7b_many_small_1000:                    84,132 B ->  84,113 B, saved 19 B
p7b_solid_many_small_1000:              80,776 B ->  79,985 B, saved 791 B
wp_plugin_theme_like:                   83,479 B ->  82,533 B, saved 946 B
php_js_css_project_like:                18,493 B ->  17,568 B, saved 925 B
docs_config_like:                       24,680 B ->  23,118 B, saved 1,562 B
logs_text_heavy:                         2,468 B ->   2,415 B, saved 53 B
negative_mixed_precompressed_random:   420,663 B -> 420,081 B, saved 582 B
```

P17A total physical positive savings were `4,878 B`. The gap from the P16A
estimate is useful: most of the P16A theoretical saving was not captured by
the conservative v4 file-row compaction alone, so future work should focus on
real path/prefix and offset-table redesign rather than assuming the estimate
is already banked.

P17B is diagnostic-only. It wrote explicit ordering/partition diagnostic
archives for a reduced physical matrix after the full matrix proved too slow.
The tested variants did not beat current canonical output; the strongest byte
reduction was `0 B`, and the most frequent suspected gap reason remained
`metadata`. This points away from making ordering/partition changes default in
the next step.

P17C reran the RC-style beta workflow with explicit experimental flags. All
seven profiles decoded, extract-file checks passed, schedule hash unique count
stayed `1`, and the negative profile stayed guarded/store-like. The
experimental metadata writer helped in the same profiles as P17A; the chosen
ordering experiment did not help and regressed `docs_config_like`, so it is not
a default candidate.

P17R/P18R/P19R are behavior-preserving refactor passes:

- `native_ithz/include/ithz/paths.hpp` and `native_ithz/src/paths.cpp`: path
  normalization, archive path validation, and safe extraction target checks;
- `native_ithz/include/ithz/safety.hpp` and `native_ithz/src/safety.cpp`:
  safety policy seam;
- `native_ithz/include/ithz/container.hpp` and `native_ithz/src/container.cpp`:
  container helper seam;
- `native_ithz/include/ithz/archive_index.hpp` and
  `native_ithz/src/archive_index.cpp`: archive index helper seam;
- `native_ithz/include/ithz/inspect.hpp` and `native_ithz/src/inspect.cpp`:
  inspect/list/why helper seam.

Raw P17 outputs:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17a_metadata_writer_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17a_metadata_components_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17a_format_compat_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17a_schedule_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17a_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17b_ordering_diagnostics_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17b_partitioning_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17b_gap_classification.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17b_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17c_beta_experimental_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17c_why_examples.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17c_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17r_path_safety_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p17r_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p18r_container_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p18r_summary.md
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p19r_index_inspect_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_p19r_summary.md
```

P17 adds an experimental manifest writer and diagnostics only behind explicit
flags. It adds no payload method, does not change default CFC planning, does
not relax P10 extraction safety, and makes no ZIP, tar.gz, or 7z superiority
claim.

## Windows Shell Installer

The Windows shell integration provides three installer paths:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\install_ithz_shell.ps1 -Apply
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\build_single_exe_installer.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\build_msi_installer.ps1
```

The script installer is the transparent current-user installer. The generated
single-EXE installer embeds the shell scripts and both AVX2/scalar native
payloads. The MSI is a Windows Installer wrapper around that same EXE for
standard MSI deployment flows.

Both packaged installers keep the same native profile policy: auto-detect AVX2
via Windows CPU feature support and install the AVX2 payload when available,
otherwise fall back to scalar. They do not change archive format, compression
methods, CFC planning, family assignment, or P10 extraction safety.

The packaged shell installers also install `ithz-zone.ico` and register it as
the `DefaultIcon` for `.ithz` archives. Explorer may need an icon cache refresh
or restart before an already visible file switches from the previous blank icon.

Shell smoke commands:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\smoke_test.ps1 -ApplyRegistrySmoke
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\single_exe_smoke_test.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\msi_smoke_test.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\editable_mount_smoke_test.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\virtual_drive_smoke_test.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\virtual_folder_probe.ps1
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\windows_shell\dokan_fuse_provider_smoke_test.ps1
```

Generated package artifacts are under
`native_ithz/build_shell_installer/Release/`.

The editable mount MVP adds a writable staging workflow for normal Windows
applications: extract to `%LOCALAPPDATA%\ITHZ\editable_mounts`, auto-commit
stable unlocked edits back into the archive, and guard writes with an archive
SHA-256 precondition. The no-driver phase-2 bridge is an editable virtual drive
implemented with `subst.exe` over the editable staging folder.

Phase 3/4 adds an optional Dokan/FUSE provider prototype plus native archive
file mutation operations. On this machine Dokany 2.3.1.1000 was installed, the
FUSE SDK subset was prepared from the official release ZIP,
`ithz-fuse-provider.exe` built successfully, and the smoke mounted a sample
`.ithz` as a drive, read `README.md`, wrote `docs/phase3.txt`, renamed it,
deleted it, and verified the archive with `--verify=safe`. The provider streams
logical file reads via `--extract-file --output -`, writes via
`--update-file --input -`, renames via `--rename-file`, and deletes via
`--delete-file`; it does not change archive format, planner, compression
methods, family assignment, or P10 safety behavior. Directory creation/removal
stays blocked until native archive directory operations exist.

The single-EXE and MSI shell installers now include the provider payload and
register explicit `Open virtual ITHZ drive` / `Unmount virtual ITHZ drive`
actions. The single-EXE installer smoke passed installed-provider probe and
mounted read/write/rename/delete through the installed wrapper.

## macOS Native Build Kit

The current public Native binary package is still Windows-only. A macOS
`ithz-native` binary must be built and smoke-tested on macOS; the Windows
`ithz-native.exe` payload cannot run on macOS and this repo does not claim a
Windows cross-build or notarized Mac installer.

The macOS build kit is under `native_ithz/macos_native/`:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\native_ithz\macos_native\smoke_test.ps1
```

The Windows-side smoke creates:

```text
native_ithz/dist/macos_native/ithz-native-macos-build-kit.zip
```

On a real Mac, the build step is:

```bash
chmod +x native_ithz/macos_native/build_macos_native_package.sh
native_ithz/macos_native/build_macos_native_package.sh --arch native
```

That script builds the C++20 CLI with CMake, runs `--version`, `--self-test`,
`--hw-status`, safe pack/verify/list/inspect, extract-file and full extract
smokes, and emits `ithz-native-preview-v0.1-alpha-rc2-macos-<arch>.zip`.

This is a platform packaging path only. It does not change archive format,
compression methods, CFC planning, family assignment or P10 extraction safety,
and it does not make a ZIP/tar.gz/7z superiority claim.

## Ubuntu Native Developer Preview and Linux Drive Fallback

The Ubuntu/Linux packaging path is generated by:

```powershell
python native_ithz\tools\build_linux_preview_packages.py
```

Generated Native developer-preview artifacts:

```text
native_ithz/dist/linux_native/ithz-native-preview-v0.1-alpha-rc2-ubuntu.tar.gz
native_ithz/dist/linux_native/ithz-native-preview-v0.1-alpha-rc2-ubuntu.deb
native_ithz/dist/linux_native/SHA256SUMS.txt
```

The Ubuntu Native preview is a source build kit, not a Windows-built Linux ELF.
Build it on Ubuntu:

```bash
sudo apt install build-essential cmake
./build_linux_native.sh
./smoke_test_linux_native.sh
./install_ithz_native.sh
```

Generated Linux Drive fallback artifacts:

```text
native_ithz/dist/linux_drive/ithz-drive-linux-fallback-v0.1-alpha-rc2.tar.gz
native_ithz/dist/linux_drive/ithz-drive-linux-fallback-v0.1-alpha-rc2.deb
native_ithz/dist/linux_drive/SHA256SUMS.txt
```

The Linux Drive fallback registers `application/x-ithz` / `.ithz` through
freedesktop MIME and desktop files, and provides:

```bash
ithz-drive open-temp archive.ithz
ithz-drive extract-here archive.ithz
ithz-drive verify archive.ithz
ithz-drive list archive.ithz
ithz-drive inspect archive.ithz
```

`open-temp` is extraction-backed and opens the extracted cache folder with
`xdg-open` when available. This is not a Linux FUSE provider and does not claim
zero-copy filesystem behavior.

Linux packaging summary:

```text
experiments/06_ithz_archive/raw/native_ithz/native_ithz_linux_preview_matrix.csv
experiments/06_ithz_archive/raw/native_ithz/native_ithz_linux_preview_summary.md
```

## P22 Payload Preconditioner Experiment

P22 is an opt-in experiment for codec-inspired reversible payload
preconditioners. The new methods are kept out of the product/default writer:

- `BYTEPLANE2_RANGE`
- `DELTA16_BYTEPLANE_RANGE`
- `ZIGZAG_DELTA16_BYTEPLANE_RANGE`

Run:

```powershell
native_ithz\build_avx2\Release\ithz-native.exe --run-p22-payload-preconditioners --output experiments\06_ithz_archive\raw\native_ithz
```

Current result:

```text
p22_payload_preconditioners_ok=true
decode/schedule/negative gates=7/7
smaller_than_current_p9_v5=0/7
smaller_than_locked_p9_v3=7/7
smaller_than_zip_deflate=6/7
smaller_than_tar_gz=0/7
profiles_selecting_preconditioned_payloads=0/7
```

The P22 result is a no-promotion result. The measured advantage over locked
p9-v3 comes from the already-existing p9-v5 metadata layout, not from the new
payload transforms. The default writer, CFC planning, family assignment and P10
extraction safety remain unchanged.

## Reference P0/P1

Current Python oracle reference:

```text
dataset_sha256=72749fd68b455b0e45ef39a898564472cc58bfe76829b0653f2a075e7a0a326b
compression_plan_hash=e90b886c39e67d9fde91fe56dcd0a1333feca755e45eed98fa22323855c6566c
```

Do not claim ZIP superiority from this branch. Native ITHZ is currently a
format/parity and performance migration path, not a new compression result.
