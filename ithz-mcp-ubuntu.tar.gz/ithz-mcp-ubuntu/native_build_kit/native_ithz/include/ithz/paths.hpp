#pragma once

#include <filesystem>
#include <string>

namespace ithz {

bool is_windows_reserved_name(std::string component);
void validate_archive_canonical_path(const std::string& path);
std::filesystem::path safe_extract_target(const std::filesystem::path& output_dir, const std::string& archive_path);

} // namespace ithz
