#pragma once

namespace ithz {

const char* archive_index_refactor_note();

} // namespace ithz
