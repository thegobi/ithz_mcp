#pragma once

namespace ithz {

inline constexpr const char* kIthzNativeVersion = "ITHZ-CFC v0.1-alpha-rc1";
inline constexpr const char* kIthzReleaseSlugAvx2 = "ithz-native-v0.1-alpha-rc1-win64-avx2";
inline constexpr const char* kIthzReleaseSlugScalar = "ithz-native-v0.1-alpha-rc1-win64-scalar";
inline constexpr const char* kIthzManifestReaders = "compact-v1;p7b-v2;p9-v3;p9-v4-experimental;p9-v5-experimental";
inline constexpr const char* kIthzExitCodes = "0=OK;1=user_input;2=archive_corruption;3=path_safety;4=unsupported_format;5=internal";

} // namespace ithz
