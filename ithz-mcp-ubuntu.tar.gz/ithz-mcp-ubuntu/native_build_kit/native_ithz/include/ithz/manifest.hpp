#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace ithz {

inline constexpr std::array<std::uint8_t, 7> kMagic{{'I', 'T', 'H', 'Z', 'C', 'F', 'C'}};
inline constexpr std::array<std::uint8_t, 7> kFooterMagic{{'I', 'T', 'H', 'Z', 'E', 'N', 'D'}};
inline constexpr std::array<std::uint8_t, 8> kCompactManifestMagic{{'I', 'T', 'H', 'Z', 'C', 'M', 'P', '1'}};
inline constexpr std::array<std::uint8_t, 8> kP7BManifestMagic{{'I', 'T', 'H', 'Z', 'P', '7', 'B', '1'}};
inline constexpr std::size_t kHeaderSize = 7 + 2 + 4 + 8 + 8 + 32 + 32 + 32;
inline constexpr std::uint32_t kFlagCompactManifest = 1;
inline constexpr std::uint32_t kFlagP7BBundleManifest = 2;
inline constexpr std::size_t kDefaultChunkSize = 4096;

} // namespace ithz
