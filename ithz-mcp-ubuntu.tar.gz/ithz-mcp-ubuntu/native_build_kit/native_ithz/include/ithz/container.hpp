#pragma once

#include <cstddef>

namespace ithz {

std::size_t container_header_size();
const char* container_refactor_note();

} // namespace ithz
