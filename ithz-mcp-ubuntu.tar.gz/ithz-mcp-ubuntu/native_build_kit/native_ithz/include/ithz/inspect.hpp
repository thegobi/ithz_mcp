#pragma once

namespace ithz {

const char* inspect_refactor_note();

} // namespace ithz
