#pragma once

namespace ithz {

void print_version();
void print_help_verify();
void print_help_examples();
void print_help();

} // namespace ithz
