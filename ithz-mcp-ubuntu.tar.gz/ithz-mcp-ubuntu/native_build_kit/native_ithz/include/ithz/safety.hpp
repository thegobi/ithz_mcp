#pragma once

#include "ithz/paths.hpp"

namespace ithz {

inline constexpr const char* kIthzSafetyPolicy =
    "reject absolute paths, traversal, backslashes, reserved names, trailing dot/space, too-long paths";

} // namespace ithz
