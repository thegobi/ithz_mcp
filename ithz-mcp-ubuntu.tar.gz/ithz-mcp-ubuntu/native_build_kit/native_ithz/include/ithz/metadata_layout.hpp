#pragma once

#include <cstdint>
#include <map>
#include <string>
#include <vector>

namespace ithz {

struct MetadataFileRow {
    std::string path;
    std::string folder;
    std::string name;
    std::string ext;
    std::string family;
    std::string method;
    std::string restore_mode;
    std::string selection_reason;
    std::uint64_t size = 0;
    std::uint64_t stream_id = 0;
    std::uint64_t bundle_offset = 0;
};

struct DeepMetadataStats {
    std::uint64_t total_path_chars = 0;
    std::uint64_t unique_prefix_count = 0;
    std::uint64_t repeated_prefix_bytes = 0;
    std::uint64_t extension_repetition_bytes = 0;
    std::uint64_t filename_stem_repetition_score = 0;
    std::uint64_t estimated_prefix_dict_savings = 0;
    std::uint64_t repeated_family_id_bytes = 0;
    std::uint64_t repeated_method_id_bytes = 0;
    std::uint64_t repeated_restore_mode_bytes = 0;
    std::uint64_t repeated_size_class_bytes = 0;
    std::uint64_t estimated_row_template_savings = 0;
    std::uint64_t monotonic_offset_delta_bytes = 0;
    std::uint64_t varint_length_bytes = 0;
    std::uint64_t repeated_small_length_bucket_bytes = 0;
    std::uint64_t estimated_offset_table_savings = 0;
    std::uint64_t bundle_count = 0;
    std::uint64_t bundle_header_bytes = 0;
    std::uint64_t family_table_bytes = 0;
    std::uint64_t restore_segment_bytes = 0;
    std::uint64_t selection_reason_bytes = 0;
    std::uint64_t largest_potential_component_bytes = 0;
    std::string largest_potential_component;
};

struct LayoutSimulation {
    std::string layout_name;
    std::uint64_t estimated_archive_bytes = 0;
    std::uint64_t estimated_manifest_bytes = 0;
    std::uint64_t estimated_path_table_bytes = 0;
    std::uint64_t estimated_file_table_bytes = 0;
    std::uint64_t estimated_offset_table_bytes = 0;
    std::uint64_t estimated_family_table_bytes = 0;
    std::uint64_t estimated_bundle_header_bytes = 0;
    std::uint64_t savings_vs_p9_v3 = 0;
    std::uint64_t savings_vs_p9_v4 = 0;
    std::string implementation_risk = "low";
    std::string reader_complexity = "low";
    std::string extract_file_risk = "low";
    std::string path_safety_risk = "low";
    std::string backward_compatibility_risk = "low";
};

std::uint64_t metadata_varint_size(std::uint64_t value);
DeepMetadataStats analyze_deep_metadata_layout(const std::vector<MetadataFileRow>& rows, std::uint64_t bundle_count);
std::vector<LayoutSimulation> simulate_metadata_layouts(
    const DeepMetadataStats& stats,
    std::uint64_t archive_bytes_p9_v3,
    std::uint64_t archive_bytes_p9_v4,
    std::uint64_t manifest_bytes_p9_v3,
    std::uint64_t path_table_bytes,
    std::uint64_t file_table_bytes,
    std::uint64_t offset_table_bytes,
    std::uint64_t family_table_bytes,
    std::uint64_t bundle_header_bytes
);

} // namespace ithz
