# Linux ithz-native build kit

This build kit compiles the native ITHZ archive transport on an Ubuntu/Linux host.

Requirements:

- `cmake`.
- A C++20 compiler such as `g++` or `clang++`.

Typical Ubuntu setup:

```sh
sudo apt update
sudo apt install build-essential cmake
./build_linux_native_package.sh
```

User-local install:

```sh
./install_linux_native.sh
ithz-native-resolve
```

The fallback archive commands `ithz-verify`, `ithz-list`, `ithz-extract-here` and `ithz-open-temp`
resolve the binary through `ITHZ_NATIVE_EXE`, package-local `native/ithz-native`,
`~/.local/share/ithz-mcp/native/ithz-native`, `/opt/ithz-mcp/native/ithz-native` or PATH.

This is an extraction-backed fallback path, not a Linux Drive/FUSE provider.
