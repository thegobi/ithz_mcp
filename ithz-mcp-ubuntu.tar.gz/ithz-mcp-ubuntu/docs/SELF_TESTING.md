# Self Testing

Regression levels:

- `run-ci-fast`: py/CLI smoke for MCP0-MCP2.
- `run-ci-full`: all stage runners through MCP7.
- `run-mcp8-hardening`: MCP8A-MCP8E plus MCP8R.
- `run-mcp9f-native-ithz`: read-only native ITHZ dogfood import and question packs.
- `run-mcp10-markdown-minimal`: MCP10A-MCP10F plus MCP10R.
- `run-context-quality-regression`: expected decision/gate/risk/forbidden terms and secret absence checks.
- `run-mcp11-external-client`: MCP11A-MCP11E plus MCP11R, including scripted stdio client smoke and RC4 packaging.
- `run-mcp12-prompt-memory`: prompt/response memory summary, redaction, context commit linking and team sync local-only skip.
- `run-mcp13-host-compat`: MCP-style initialize/tools/list/tools/call scripted smoke plus native `project.ithz` archive build/search/context-pack checks.
- `run-mcp17-append-index-snapshot`: append-only event log, derived current index, searchable event evidence, snapshot creation and secret-like event blocking.
- `run-mcp20-agent-history-import`: project-scoped local agent-history import with author/time provenance.
- `run-mcp21-production-readiness`: fresh/adopted/shared project scenarios, host installer/config smokes and product candidate package smoke.
- `run-mcp22-auto-checkpoint`: write-enabled automatic native checkpointing, read-only write blocking, invalid-surrogate Unicode sanitization, compact MCP `tools/call` response shape and queued checkpoint worker completion.
- `run-mcp23-install-project`: one-command current-directory install semantics plus compact native archive index savings.
- `run-mcp25-macos-package`: product candidate package smoke plus POSIX launcher/installer static checks for macOS MCP usage.
- `run-mcp26-memory-synthesis`: deterministic memory synthesis, archive lock fail-fast handling and large-archive snapshot auto-defer.
- `run-mcp27-project-ledger`: first-class project ledger projections, `ithz_can_i_claim`, read/write MCP schema boundaries and Windows no-window native subprocess configuration.
- `run-mcp28-ubuntu-package`: product candidate package smoke plus Ubuntu/Linux tarball and `.deb` static checks, Linux host installer checks, Linux native build-kit checks, extraction-backed fallback command checks and no-secret packaging checks.
- `run-mcp29-memory-effectiveness`: native context-pack usefulness regression. It checks that selected evidence appears before broad synthesis, exact evidence gaps are shown for weak/no-match queries, file-navigation queries prefer concrete source candidates, platform-sensitive queries do not start from opposite-platform installer evidence, packs stay under budget, and live ITHKOR archive checks remain read-only.

Stage summaries live under `experiments/`.

