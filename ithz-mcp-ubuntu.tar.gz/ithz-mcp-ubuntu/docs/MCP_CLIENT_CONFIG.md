# MCP Client Config

Use `python -m ithz_mcp mcp-config-template --client codex` to generate a local read-only stdio MCP config. Supported templates: `codex`, `claude-code`, `antigravity` and `generic-jsonrpc`.

Generated configs include `agent_policy.memory_first=true`. Hosts that respect MCP server instructions/config metadata should call `ithz_context_status` and `ithz_archive_get_context_pack` before broad codebase reads.

Real MCP host mode uses `python -m ithz_mcp mcp-server --project <project> --mode read-only --protocol mcp` and supports `initialize`, `tools/list` and `tools/call`. The `initialize` response includes memory-first instructions. Hard enforcement still depends on the host tool-permission model.

The MCP `initialize` response and generated host config include best-effort ITHZ-MCP branding metadata: `serverInfo.title=ITHZ-MCP`, an SVG icon data URI and the package-local `src/ithz_mcp/assets/ithz-mcp.svg` path. Hosts that support icon metadata may display it; hosts that do not support local MCP icons will keep their default generic MCP/source icon.
