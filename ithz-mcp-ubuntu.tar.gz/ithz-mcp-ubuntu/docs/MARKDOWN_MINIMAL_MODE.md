# Markdown Minimal Mode

Markdown files are bootstrap and human-readable documentation.

Long-term agent work memory should live in `.ithz-context/`:

```text
.ithz-context/
  config.json
  project_context.jsonl
  index.json
  checkpoints/
  decisions/
  prompts/
  experiment-results/
  context-commits/
  refs/
  branches/
  packs/
  logs/
  tmp/
```

MCP10 only audits and plans migration. It does not delete or move Markdown files.
