# ITHZ MCP Promotion Outreach

Last updated: 2026-06-21.

## Public Positioning

Short name: ITHZ MCP

Primary public URL: https://ithz.dev/mcp/

Contact: dev@ithz.dev

Category: Memory / Knowledge Management / DevTools

One-line description:

> Local-first deterministic project memory for AI agents: context packs, decisions, gates, risks, scoped claims, reviewer notes and explicit checkpoints in project-owned files.

Longer description:

> ITHZ MCP is a local-first deterministic project-memory layer for AI agents. It stores context packs, durable decisions, gates, risks, scoped claims, reviewer notes and explicit checkpoints in project-owned files, while Git remains the code transport and history. It is not a Git replacement, production database, cloud sync product or universal RAG replacement.

Suggested tags:

```text
mcp, ai-agents, project-memory, deterministic-memory, context-packs, devtools, local-first, knowledge-management, codex, claude-code, cursor
```

## Deployed Or Verified Promotion Channels

1. Public PyPI package: https://pypi.org/project/ithz-mcp/0.1.0a1/
2. PyPI discovery metadata: summary, project URLs, keywords and classifiers in `0.1.0a1`.
3. Libraries.io package page: https://libraries.io/pypi/ithz-mcp
4. mcpservers.org submission.
5. MCP Playground registry submission.
6. AI SuperHub free directory submission.
7. Public product pages: https://ithz.dev/mcp/ and https://ithz.dev/sk/mcp/
8. LLM discovery file: https://ithz.dev/llms.txt
9. Search crawler access: https://ithz.dev/robots.txt
10. IndexNow URL notification for MCP, SK MCP, download, pricing and `llms.txt`.
11. Official MCP Registry: `dev.ithz/ithz-mcp` version `0.1.0a1`, active.
12. AI ToolsXplorer free directory submission.
13. Seminal AI directory submission.
14. SubmitALLAI directory submission.
15. ToolAIze directory submission.
16. The Next AI free directory submission.
17. zPlatform free editorial-review submission.
18. ToolWise free directory submission.
19. ToolHunter free directory submission.
20. TipSeason free directory submission.
21. Global AI Tools free directory submission.
22. Public GitHub distribution repository updated for MCP discovery: https://github.com/thegobi/ithz_mcp
23. MCP.Directory submission using public GitHub and PyPI metadata.
24. ToolRoute MCP server submission using public GitHub metadata.
25. Glama discovery metadata added to the public GitHub distribution repository.
26. MCP Market free queue submission.
27. LobeHub MCP marketplace request issue.
28. Awesome MCP Servers pull request.
29. GitHub Partnerships MCP discovery request email.
30. GitHub repository About metadata and topics.
31. GitHub `v0.1.0a1` public alpha tag and pre-release.
32. Public GitHub README discovery badges for PyPI, MCP Registry and GitHub release.
33. patriksimek Awesome MCP Servers pull request.
34. TensorBlock MCP Index server submission issue.
35. TensorBlock MCP Index pull request.
36. appcypher Awesome MCP Servers public fork proposal branch; upstream repository currently disables pull requests.

## Submitted

### mcpservers.org

Status: submitted successfully on 2026-06-18.

Submission URL: https://mcpservers.org/submit

Payload:

```text
Server Name: ITHZ MCP
Short Description: Local-first deterministic project memory for AI agents: context packs, decisions, gates, risks, claims ledger and explicit checkpoints in project-owned files.
Link: https://ithz.dev/mcp/
Category: Memory
Contact Email: dev@ithz.dev
```

Result shown by site:

```text
Submission Successful!
Your MCP server "ITHZ MCP" has been submitted successfully.
Your submission will be reviewed within 12 hours.
```

### AI SuperHub

Status: free listing submitted successfully on 2026-06-20.

Submission URL: https://www.aisuperhub.io/ai-tools/submit/free

Payload summary:

```text
Email: dev@ithz.dev
Tool Name: ITHZ MCP
Category: Development
Short Description: Local deterministic project memory for AI coding agents and MCP-compatible development workflows.
Website URL: https://ithz.dev/mcp/
Secondary URL: https://ithz.dev/download/#mcp-download
Advertising interest: No, not at this time
```

Result shown by site:

```text
Submission Received!
Thank you for submitting your tool. Our team will review it shortly.
We've received your tool submission. We'll review it and get back to you soon.
```

### MCP Playground

Status: submitted successfully on 2026-06-20.

Submission URL: https://mcpplaygroundonline.com/mcp-registry

Payload summary:

```text
Server Name: dev.ithz/ithz-mcp
Display Title: ITHZ MCP
Transport: STDIO
npm / PyPI Package: ithz-mcp
Website / Docs URL: https://ithz.dev/mcp/
Contact: dev@ithz.dev
```

Result shown by site:

```text
Submission received!
We'll review your server and publish it shortly.
```

### AI ToolsXplorer

Status: submitted successfully on 2026-06-20.

Submission URL: https://www.aitoolsxplorer.in/submit-tool

Payload summary:

```text
Tool Name: ITHZ MCP
Website URL: https://ithz.dev/mcp/
Category: Code Assistants
Contact Email: dev@ithz.dev
Free Tier Available: yes
```

Result shown by site:

```text
Thank You for Your Submission!
We've received your AI tool submission. You'll receive an email notification when your tool is published.
```

### Seminal AI

Status: submitted successfully on 2026-06-20.

Submission URL: https://seminal.ai/submit-tool/

Payload summary:

```text
Tool Name: ITHZ MCP
Website URL: https://ithz.dev/mcp/
Category: Coding
Contact Email: dev@ithz.dev
```

Result shown by site:

```text
Dakujeme!
Formular bol uspesne odoslany.
```

### SubmitALLAI

Status: submitted successfully on 2026-06-20.

Submission URL: https://submitallai.com/submit-ai-tool/

Payload summary:

```text
Tool Name: ITHZ MCP
Website URL: https://ithz.dev/mcp/
Category: Coding
Pricing: Free
Contact Email: dev@ithz.dev
```

Result shown by site:

```text
Thank you! Your tool was submitted and is pending review.
```

### ToolAIze

Status: submitted successfully on 2026-06-20.

Submission URL: https://toolaize.com/submit

Payload summary:

```text
Tool Name: ITHZ MCP
Website URL: https://ithz.dev/mcp/
Category: Coding, Developer Tools, AI Agents
Contact Email: dev@ithz.dev
```

Result shown by site:

```text
Submission Successful
Thank you for your submission!
We have received your information and will review it as soon as possible.
```

### The Next AI

Status: free listing submitted successfully on 2026-06-20.

Submission URL: https://www.thenextai.com/submit-ai-tool/

Payload summary:

```text
Tool Name: ITHZ MCP
Website URL: https://ithz.dev/mcp/
Category: Developer Tools
Pricing: Free
Contact Email: dev@ithz.dev
Quick check: 4 + 2 = 6
```

Result shown by site:

```text
Submitted!
Thanks for submitting your tool to The Next AI.
```

### zPlatform

Status: submitted successfully on 2026-06-20.

Submission URL: https://zplatform.ai/submit-ai-tool/

Payload summary:

```text
Tool Name: ITHZ MCP
Website URL: https://ithz.dev/mcp/
Category: AI Productivity
Contact Email: dev@ithz.dev
Pitch included PyPI and official MCP Registry references.
```

Result shown by site:

```text
Tool submitted! We will acknowledge within 48 hours and add it to the review queue.
```

### ToolWise

Status: submitted successfully on 2026-06-20.

Submission URL: https://toolwise.ai/submit-tool

Payload summary:

```text
Tool Name: ITHZ MCP
Website URL: https://ithz.dev/mcp/
Category: Workflow Automation
Pricing Model: Free
Contact Email: dev@ithz.dev
```

Result shown by site:

```text
Tool submitted!
We'll review your submission and publish it within 48 hours.
```

### ToolHunter

Status: submitted successfully on 2026-06-20.

Submission URL: https://toolhunter.ai/submit-a-tool

Payload summary:

```text
Tool Name: ITHZ MCP
Website URL: https://ithz.dev/mcp/
Category: Developer Tools
Pricing Model: Free
Contact Email: dev@ithz.dev
Relationship: I built this tool
```

Result shown by site:

```text
Submission #1874
Thanks for submitting!
We'll review ITHZ MCP and get back to you at dev@ithz.dev.
```

### TipSeason

Status: submitted successfully on 2026-06-20.

Submission URL: https://www.tipseason.com/ai-tools/submit-free

Payload summary:

```text
Tool Name: ITHZ MCP
Website URL: https://ithz.dev/mcp/
Category: Development
Pricing Model: Free
Advertising interest: No, not at this time
Contact Email: dev@ithz.dev
```

Result shown by site:

```text
Submission Received!
We've received your tool submission. We'll review it and get back to you soon.
```

### Global AI Tools

Status: submitted successfully on 2026-06-20.

Submission URL: https://globalaitools.digital/#submit-tool

Payload summary:

```text
Tool Name: ITHZ MCP
Website URL: https://ithz.dev/mcp/
Category: Development
Pricing Model: Free / Freemium
Contact Email: dev@ithz.dev
```

Result shown by site:

```text
Thank You!
We'll review your submission and get back to you soon.
```

### GitHub Distribution Repository

Status: public repository updated on 2026-06-20.

Repository URL: https://github.com/thegobi/ithz_mcp

Commit:

```text
5a55a31 Improve public MCP package metadata
```

Scope:

```text
Updated README.md as a public MCP/package landing page.
Added root server.json for MCP discovery.
Refreshed SHA256SUMS.txt for the updated public metadata files.
Kept the repository as a distribution/package repo, not a full source mirror.
```

Public verification:

```text
https://raw.githubusercontent.com/thegobi/ithz_mcp/main/server.json
name = dev.ithz/ithz-mcp
package = ithz-mcp
repository.id = 1254086025
```

GitHub About metadata:

```text
Updated through authenticated GitHub UI on 2026-06-21.
Description: Local-first deterministic project memory for AI coding agents and MCP workflows.
Website: https://ithz.dev/mcp/
Topics: mcp, pypi, devtools, ai-agents, local-first, coding-agents, model-context-protocol, project-memory
Verified on the public repository page after GitHub displayed "Your repository details have been saved."
```

GitHub tag and release:

```text
Tag pushed: v0.1.0a1
Release URL: https://github.com/thegobi/ithz_mcp/releases/tag/v0.1.0a1
Release title: ITHZ MCP 0.1.0a1 public alpha
Release label: Pre-release
Release points to commit 22a5632 and includes public PyPI, MCP Registry and docs links.
```

Discovery badge update:

```text
Commit: a51c9c6 Add public discovery badges
Scope: Added README badges linking to PyPI, the official MCP Registry entry and the GitHub v0.1.0a1 pre-release.
Also refreshed README.md in SHA256SUMS.txt.
```

### MCP.Directory

Status: submitted successfully on 2026-06-20.

Submission URL: https://mcp.directory/submit

Payload summary:

```text
GitHub Repository URL: https://github.com/thegobi/ithz_mcp
PyPI Package: ithz-mcp
Short Description: Local-first project memory for AI coding agents and MCP workflows.
Contact Email: dev@ithz.dev
```

Result shown by site:

```text
Server Submitted!
We'll review your server and publish it within 24 hours. You'll receive an email notification when it's live.
```

### ToolRoute

Status: submitted successfully on 2026-06-20.

Submission URL: https://toolroute.io/submit

Payload summary:

```text
GitHub Repository URL: https://github.com/thegobi/ithz_mcp
Server Name: ITHZ MCP
Vendor / Maintainer: ITHZ.dev
Workflow: Knowledge Management
Vertical: DevTools
Capabilities: code-repositories, file-management, knowledge-bases
Transport Type: stdio
Install Method: pip
License: Other
Contact Email: dev@ithz.dev
```

Result shown by site:

```text
Server Submitted!
In review: typically approved within 48 hours.
```

### Glama

Status: GitHub discovery metadata added on 2026-06-20.

Repository URL: https://github.com/thegobi/ithz_mcp

Commit:

```text
22a5632 Add Glama MCP discovery metadata
```

Scope:

```text
Added root glama.json with maintainer metadata.
Refreshed SHA256SUMS.txt.
Glama crawler discovery is expected to follow from the public GitHub repository.
```

Expected Glama path used by downstream PR:

```text
https://glama.ai/mcp/servers/thegobi/ithz_mcp
https://glama.ai/mcp/servers/thegobi/ithz_mcp/badges/score.svg
```

### MCP Market

Status: free queue submitted successfully on 2026-06-20.

Submission URL: https://mcpmarket.com/submit

Payload summary:

```text
Type: MCP Server
GitHub Repository URL: https://github.com/thegobi/ithz_mcp
Contact Email: dev@ithz.dev
Listing option: Free Queue
```

Result shown by site:

```text
Success
Submitted! You're in the free queue - current wait is ~4-6 weeks. We'll email you when it's live.
```

### LobeHub MCP Marketplace

Status: GitHub request issue opened on 2026-06-20; self-service CLI flow attempted on 2026-06-21.

Issue URL: https://github.com/lobehub/lobehub/issues/16124

Payload summary:

```text
Title: [Request] Add ITHZ MCP to the MCP marketplace
Official MCP Registry identifier: dev.ithz/ithz-mcp
Registry entry: https://registry.modelcontextprotocol.io/v0.1/servers/dev.ithz%2Fithz-mcp/versions/latest
Website / docs: https://ithz.dev/mcp/
Repository: https://github.com/thegobi/ithz_mcp
PyPI package: https://pypi.org/project/ithz-mcp/
Transport: stdio
Install package: ithz-mcp
```

Follow-up:

```text
Maintainer comment says marketplace submissions moved from GitHub issues to @lobehub/market-cli self-service.
CLI login was attempted through Google/LobeHub OAuth with thegobi@gmail.com.
The final OAuth consent page redirects to http://localhost:51234/callback; the in-app browser blocks automated localhost callback completion, so a manual click on the final Authorize step is still required.
No marketplace submit was completed in this pass.
```

### Awesome MCP Servers

Status: pull request opened on 2026-06-20.

Pull request URL: https://github.com/punkpeye/awesome-mcp-servers/pull/8405

Fork branch:

```text
https://github.com/thegobi/awesome-mcp-servers/tree/codex/add-ithz-mcp
```

Commit:

```text
1cb2328 Add ITHZ MCP to memory servers
```

Result:

```text
Added ITHZ MCP to the Knowledge & Memory section.
GitHub Actions labels changed to has-emoji and has-glama after the badge/tag fix.
Checks shown as passed; PR remains open for maintainer review.
```

### patriksimek Awesome MCP Servers 2

Status: pull request opened on 2026-06-21.

Pull request URL: https://github.com/patriksimek/awesome-mcp-servers-2/pull/17

Fork branch:

```text
https://github.com/thegobi/awesome-mcp-servers-appcypher/tree/codex/add-ithz-mcp-patriksimek
```

Commit:

```text
e1895ef Add ITHZ MCP
```

Result:

```text
Added ITHZ MCP to the AI Services section.
GitHub compare showed 1 commit, 1 file changed and able to merge before submission.
```

### TensorBlock MCP Index

Status: server submission issue and pull request opened on 2026-06-21.

Issue URL: https://github.com/TensorBlock/awesome-mcp-servers/issues/835

Pull request URL: https://github.com/TensorBlock/awesome-mcp-servers/pull/837

Fork branch:

```text
https://github.com/thegobi/awesome-mcp-servers-tensorblock/tree/codex/add-ithz-mcp
```

Commit:

```text
8add1d6 Add ITHZ MCP
```

Result:

```text
Submitted the official TensorBlock add-server issue form with Knowledge Management & Memory, stdio, no-auth, PyPI, docs and registry metadata.
Opened a direct PR adding one entry to docs/knowledge-management--memory.md.
GitHub compare showed 1 commit, 1 file changed and able to merge before submission.
```

### appcypher Awesome MCP Servers

Status: public fork proposal branch published on 2026-06-21, but upstream PR creation is disabled.

Fork branch:

```text
https://github.com/thegobi/awesome-mcp-servers-appcypher/tree/codex/add-ithz-mcp
```

Commit:

```text
9857e66 Add ITHZ MCP
```

Result:

```text
Added ITHZ MCP to the AI Services section in a public fork branch.
GitHub compare showed 1 commit and 1 file changed, but appcypher/awesome-mcp-servers displays: "An owner of this repository has disabled the ability to open pull requests."
```

### GitHub MCP Discovery / Partnerships

Status: request email sent on 2026-06-21.

Recipient:

```text
partnerships@github.com
```

Payload summary:

```text
Requested inclusion of dev.ithz/ithz-mcp in GitHub MCP discovery / github.com/mcp surfaces.
Included official MCP Registry entry, product page, PyPI package and public GitHub distribution repository.
Disclosed maintainer affiliation and free alpha preview status.
```

Gmail result:

```text
Sent from thegobi@gmail.com
message id = 19ee8ebe93184966
```

## PyPI Package Publication

### ithz-mcp

Status: published successfully on 2026-06-20.

Primary public package URL: https://pypi.org/project/ithz-mcp/0.1.0a1/

Package name checked: `ithz-mcp`

PyPI JSON endpoint checked:

```text
https://pypi.org/pypi/ithz-mcp/json
```

Current public metadata after `0.1.0a1` upload:

```text
version = 0.1.0a1
summary = Local-first deterministic project memory for AI coding agents and MCP workflows.
Homepage = https://ithz.dev/mcp/
Documentation = https://ithz.dev/mcp/
Download = https://ithz.dev/download/#mcp-download
PyPI = https://pypi.org/project/ithz-mcp/
```

Published artifacts:

```text
dist/ithz_mcp-0.1.0a0-py3-none-any.whl
dist/ithz_mcp-0.1.0a0.tar.gz
dist/ithz_mcp-0.1.0a1-py3-none-any.whl
dist/ithz_mcp-0.1.0a1.tar.gz
```

Validation performed:

```text
python -m build
python -m twine check dist\ithz_mcp-0.1.0a1.tar.gz dist\ithz_mcp-0.1.0a1-py3-none-any.whl
python -m venv .tmp-pypi-smoke
.\.tmp-pypi-smoke\Scripts\python.exe -m pip install --quiet --no-cache-dir ithz-mcp==0.1.0a1
.\.tmp-pypi-smoke\Scripts\python.exe -m ithz_mcp version
python -m twine upload --non-interactive dist\ithz_mcp-0.1.0a1.tar.gz dist\ithz_mcp-0.1.0a1-py3-none-any.whl
```

Credential state:

```text
After manual PyPI login by the account owner, an account-scoped API token was created for the initial publish and stored outside the repo in the local Python keyring:
service = pypi.org
username = __token__
```

Upload result:

```text
Uploading distributions to https://upload.pypi.org/legacy/
Uploading ithz_mcp-0.1.0a1-py3-none-any.whl
Uploading ithz_mcp-0.1.0a1.tar.gz
View at:
https://pypi.org/project/ithz-mcp/0.1.0a1/
```

Public install smoke:

```powershell
python -m venv <temp>
<temp>\Scripts\python.exe -m pip install --quiet --no-cache-dir ithz-mcp==0.1.0a1
<temp>\Scripts\python.exe -m ithz_mcp version
```

Result: public PyPI install succeeded and reported `version = 0.1.0a1`.

### PyPI-Linked Discovery

Status: live public discovery surfaces verified on 2026-06-20.

```text
PyPI project page: https://pypi.org/project/ithz-mcp/
PyPI JSON API: https://pypi.org/pypi/ithz-mcp/json
Libraries.io package page: https://libraries.io/pypi/ithz-mcp
```

The Libraries.io page became available after PyPI publication and returns HTTP 200.

## Public Search Discovery

### ITHZ.dev LLM and Search Signals

Status: deployed and verified on 2026-06-20.

Verified URLs:

```text
https://ithz.dev/mcp/
https://ithz.dev/sk/mcp/
https://ithz.dev/llms.txt
https://ithz.dev/robots.txt
https://ithz.dev/02ee8a6c08d1df3eab899fc578f11c91.txt
```

IndexNow submission:

```text
Endpoint: https://api.indexnow.org/indexnow
Status: HTTP 200
Submitted URLs:
- https://ithz.dev/mcp/
- https://ithz.dev/sk/mcp/
- https://ithz.dev/download/
- https://ithz.dev/pricing/
- https://ithz.dev/llms.txt
```

## Attempted But Not Completed

### HyzenPro

URL: https://hyzenpro.com/submit-ai-tool/

Status: attempted on 2026-06-20. The form saved the tool for review, but the site reported missing SMTP configuration, so this is a weak/partial submission until confirmed by the operator.

Result shown by site:

```text
Your tool was saved for review, but submission emails are not configured yet.
Please finish the SMTP setup in Vercel.
Missing: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS.
```

### mcp.so

URL: https://mcp.so/submit

Status: attempted again on 2026-06-20. Google OAuth selected `thegobi@gmail.com` and consent was granted for name, profile photo and email, but mcp.so returned to the submit page without an authenticated session. Submitting the completed form still showed `Please Sign in to submit a server.`

Payload used:

```json
{
  "mcpServers": {
    "ithz_mcp": {
      "command": "python",
      "args": [
        "-m",
        "ithz_mcp",
        "mcp-server",
        "--project",
        "/path/to/project",
        "--mode",
        "read-only",
        "--protocol",
        "direct",
        "--storage-profile",
        "native-archive"
      ]
    }
  }
}
```

### Smithery

URL: https://smithery.ai/servers/new

Status: Google login/registration completed on 2026-06-20, but publish was skipped because the current Smithery flow requires a public HTTP MCP server URL. ITHZ MCP is currently a local-first stdio/PyPI MCP server, so using the docs URL as an MCP endpoint would be inaccurate.

Observed required field:

```text
MCP Server URL*: The HTTP URL where your MCP server is accessible.
```

Follow-up on 2026-06-21:

```text
Prepared a read-only public Streamable HTTP-style MCP endpoint in the ITHZ.dev WordPress theme at /mcp/http.
The endpoint exposes only product/install/link/safety information and does not expose local project memory, source code, raw prompts or write operations.
Local PHP lint passed for wp-theme/ithz-dev/functions.php.
Remote deploy was not completed because the available WebSupport SSH account uid6252114 with key doucim_websupport_ed25519 can access doucim.com/web, but did not contain ithz.dev/web or the ithz-dev theme path.
```

Suggested endpoint after deploying the prepared theme change:

```text
https://ithz.dev/mcp/http
```

### AI Hunter

URL: https://ai-hunter.io/submit-a-tool/

Status: attempted on 2026-06-20. Form fields accepted ITHZ MCP details, category `Developer Tools`, pricing `Free`, but server returned a generic processing error.

Result shown by site:

```text
An error occurred while processing the form. Please try again.
```

### SubmitAItools

URL: https://submitaitools.org/submit/

Status: attempted on 2026-06-20, but the submit page returned `Server Error (500)`.

### GPTBot

URL: https://gptbot.io/submit-ai-tool

Status: inspected on 2026-06-20. Public page currently exposes a waitlist/login flow rather than an immediate tool submission form.

### Altern

URL: https://altern.ai/submit

Status: inspected on 2026-06-20. Redirects to login before submission (`/login?redirect=/submit`).

### iDharma MCP Trust Registry

URL: https://idharma.us/trust-registry

Chosen tier: Listed

Status: attempted on 2026-06-18, but the form returned `Spam detected.` after browser automation. Keep as manual follow-up.

Suggested manual payload:

```text
Listing tier: Listed
Service / company name: ITHZ MCP
Contact email: dev@ithz.dev
MCP server URL: https://ithz.dev/mcp/
Website: https://ithz.dev/
Category: AI agent memory, MCP, DevTools, local-first project memory
Description: ITHZ MCP is a local-first deterministic project-memory layer for AI agents. It stores context packs, durable decisions, gates, risks, scoped claims, reviewer notes and explicit checkpoints in project-owned files, while Git remains the code transport and history.
```

### AgenticSkills

URL: https://agenticskills.io/submit?type=mcp

Status: attempted on 2026-06-20. The MCP-specific form accepted ITHZ MCP data, category `Knowledge & Memory`, compatibility selections and contact details, but the site returned an internal queue message instead of accepting the submission.

Result shown by site:

```text
Submission review queue is not configured.
```

### AICentralResources

URL: https://www.aicentralresources.com/get-listed

Status: inspected on 2026-06-20. Public copy advertises a free listing, but the actual submission path requires account creation or social login before `/submit-tool`.

### image2promptai

URL: https://image2promptai.com/submit-tool

Status: attempted on 2026-06-20, but browser navigation failed with `ERR_NAME_NOT_RESOLVED`.

### AI You Imagine

URL: https://aiyouimagine.com/submit

Status: inspected on 2026-06-20. The submit route returned HTTP/browser 404.

### AIToolMela

URL: https://aitoolmela.com/submit

Status: attempted on 2026-06-20. The form accepted the ITHZ MCP payload with category `AI Code Tools` and pricing `Free`, then entered `Submitting...` and returned to the form without a success message. Treat as unconfirmed.

### WorkHerholic

URL: https://workherholic.com/ai-tools/submit

Status: attempted on 2026-06-20. The form accepted the payload after rejecting the cookie prompt, but submission failed and the category dropdown was blocked by overlapping ad/dropdown behavior.

Result shown by site:

```text
Failed to submit tool. Please try again.
```

### ToolsVerse

URL: https://www.toolsverse.tools/submit

Status: attempted on 2026-06-20. The form accepted the payload after rejecting the cookie prompt, but clicking submit only serialized the values into the page query string and reset the form without a success message. Treat as broken/unconfirmed.

### AI Tools Pin

URL: https://aitoolspin.com/submit-tool.html

Status: inspected on 2026-06-20. The page documents a JSON submission format, but the embedded submit iframe remained at `Loading submission form...` and exposed no actionable form fields.

### Flaex MCP Directory

URL: https://www.flaex.ai/mcp-servers?submit=true

Status: inspected on 2026-06-20. The directory is relevant and has a `Submit MCP Server` CTA, but clicking it did not expose a form for anonymous submission.

### AI Center

URL: https://aicenter.ai/submit-tools

Status: inspected on 2026-06-20. Relevant categories and tags exist (`Coding`, `developer-tools`, `memory-assistant`), but submission requires a paid plan starting at $15, so it was skipped for the free-promotion campaign.

## Official Registry And Follow-Up Channels

### Official MCP Registry

Docs:

- https://modelcontextprotocol.io/registry/about
- https://modelcontextprotocol.io/registry/package-types
- https://modelcontextprotocol.io/registry/authentication
- https://modelcontextprotocol.io/registry/registry-aggregators

Status: published successfully on 2026-06-20.

Published server:

```text
name = dev.ithz/ithz-mcp
version = 0.1.0a1
status = active
isLatest = true
publishedAt = 2026-06-20T10:08:01.955083Z
```

Completed gates:

```text
https://ithz.dev/.well-known/mcp-registry-auth returned HTTP 200 with the expected Ed25519 public proof.
mcp-publisher validate
mcp-publisher login http --domain ithz.dev --private-key <from-keyring>
mcp-publisher publish
```

Publish result:

```text
Publishing to https://registry.modelcontextprotocol.io...
✓ Successfully published
✓ Server dev.ithz/ithz-mcp version 0.1.0a1
```

Public registry verification:

```text
https://registry.modelcontextprotocol.io/v0.1/servers?search=dev.ithz%2Fithz-mcp
https://registry.modelcontextprotocol.io/v0.1/servers/dev.ithz%2Fithz-mcp/versions/latest
```

Private key state:

```text
The Ed25519 HTTP auth private seed is stored outside the repo in the local Python keyring:
service = mcp-registry
username = ithz.dev-ed25519-private-hex
```

### MCP.Directory

URL: https://mcp.directory/submit

Status: completed on 2026-06-20 after the public GitHub distribution repository was updated.

Submitted payload:

```text
GitHub Repository URL: https://github.com/thegobi/ithz_mcp
PyPI Package: ithz-mcp
Short Description: Local-first deterministic project memory for AI agents: context packs, decisions, gates, risks, scoped claims and explicit checkpoints in project-owned files.
Email: dev@ithz.dev
```

### ToolRoute

URL: https://toolroute.io/submit

Status: completed on 2026-06-20 after the public GitHub distribution repository was updated.

Submitted payload:

```text
GitHub Repository URL: https://github.com/thegobi/ithz_mcp
Server Name: ITHZ MCP
Vendor / Maintainer: ITHZ.dev
One-line Description: Local-first deterministic project memory for AI agents.
Contact Email: dev@ithz.dev
Primary Workflow: Knowledge Management
Primary Vertical: DevTools
Capabilities: code-repositories, file-management, knowledge-bases
Transport Type: stdio
Install Method: pip or Binary
License: Other unless an explicit OSI license is chosen
Notes: Project-owned memory zone for AI-assisted development; Git remains code history and transport.
```

### MCP Market / Glama / Smithery / LobeHub

Current issue: these discovery sites often require a public GitHub repository plus account/login, public package metadata, or a GitHub issue/PR flow.

Suggested order:

1. Use the public distribution repository: https://github.com/thegobi/ithz_mcp
2. Use PyPI package metadata: https://pypi.org/project/ithz-mcp/
3. Submit to Glama, MCP Market and Smithery where they expose a working free route.
4. For LobeHub, use their request flow or GitHub fallback issue only when logged in.

### mcp.so

URL: https://mcp.so/

Submission route: GitHub issue from the site's Submit link.

Suggested issue body:

```text
Title: Submit MCP Server: ITHZ MCP

Hi, thanks for maintaining mcp.so.

I would like to submit ITHZ MCP.

Description:
Local-first deterministic project memory for AI agents: context packs, decisions, gates, risks, scoped claims, reviewer notes and explicit checkpoints in project-owned files.

Links:
- Public docs: https://ithz.dev/mcp/
- Download page: https://ithz.dev/download/#mcp-download

Suggested category:
Memory / Knowledge Management / Developer Tools

Disclosure:
I am affiliated with ITHZ.dev. ITHZ MCP is currently free during alpha preview.
```

### awesome-mcp-servers

URL: https://github.com/punkpeye/awesome-mcp-servers

Preferred route: pull request after a public source/package link exists.

Candidate entry:

```text
- [ITHZ MCP](https://ithz.dev/mcp/) - Local-first deterministic project memory for AI agents: context packs, decisions, gates, risks, scoped claims and explicit checkpoints in project-owned files.
```

## Outreach Copy

### Hacker News / Reddit

Use only in communities where self-promotion is welcome, and disclose authorship.

```text
I built ITHZ MCP, a free local-first MCP server/CLI for project-owned AI-agent memory.

The idea is simple: Git keeps code history, while the project keeps agent work memory in explicit files. ITHZ MCP gives agents deterministic context packs, durable decisions, gates, risks, reviewer notes, scoped claims and end-of-task checkpoints instead of relying only on hidden chat history or repeated full-repo scans.

It is not a Git replacement, cloud sync service, production database or magic token-saving claim. It is an alpha preview for developers and AI-agent power users who want auditable project memory next to the repo.

Docs: https://ithz.dev/mcp/
```

### Directory Note

```text
ITHZ MCP is currently free during alpha preview. The product is local-first and stdio-based; no remote hosted endpoint is required. Public docs are available at https://ithz.dev/mcp/.
```
