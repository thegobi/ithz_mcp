# ITHZ Project Ledger

`project_ledger_v1` makes `project.ithz` more than a context source. It is an append-only audit ledger for AI-assisted projects.

The ledger stores:

- decisions;
- gates;
- risks and must-not-break rules;
- scoped claims;
- blocked claims;
- checkpoints;
- replication pack records;
- reviewer notes.

Markdown remains the bootstrap. `project.ithz` is the memory zone.

## First-class Layers

Inside `project.ithz`:

```text
claims/claim_log.jsonl
claims/blocked_claim_log.jsonl
replication/replication_pack_log.jsonl
review/reviewer_notes.jsonl
ledger/project_ledger_summary.json
indexes/claim_index.json
```

These files are deterministic projections from the append-only event log. If a projection is stale or missing, it can be rebuilt from `events/events.jsonl`.

## CLI

```powershell
python -m ithz_mcp ithz-add-claim --project . --claim-id claim_special_ithkor --text "Special ITHKOR has scoped finite/QPU diagnostic support." --scope finite/qpu --supporting-gate D20
python -m ithz_mcp ithz-block-claim --project . --claim-id blocked_gravity_claim --text "ITHKOR proves gravity" --reason "No physical D claim is authorized." --blocking-gate D20
python -m ithz_mcp ithz-can-i-claim --project . --claim "ITHKOR proves gravity?"
python -m ithz_mcp ithz-add-reviewer-note --project . --target D20 --text "First verify summary_found and status_matches_expected."
python -m ithz_mcp ithz-create-replication-pack-record --project . --pack-id D20 --witnesses 15 --positive 12 --negative-stop 3 --public-safe
python -m ithz_mcp ithz-get-project-ledger-summary --project .
```

## MCP Tools

Read-only:

- `ithz_list_allowed_claims`
- `ithz_list_blocked_claims`
- `ithz_get_claim_evidence`
- `ithz_can_i_claim`
- `ithz_get_project_ledger_summary`

Write-enabled only:

- `ithz_add_claim`
- `ithz_block_claim`
- `ithz_add_reviewer_note`
- `ithz_create_replication_pack_record`

Write tools are not exposed in the read-only profile.

## Safety

- Secret-like claim, reason, reviewer or manifest text is blocked before storage.
- Claims are scoped and evidence-bound; unsupported claims should return `not_found_needs_evidence`.
- Blocked claims are preserved as audit records and can point to blocking gates.
- ITHZ-MCP does not replace Git, production databases, cloud sync, code review, or source inspection.
