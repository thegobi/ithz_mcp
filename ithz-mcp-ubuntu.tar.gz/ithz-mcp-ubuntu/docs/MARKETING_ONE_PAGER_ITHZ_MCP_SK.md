# ITHZ-MCP

## Lokálna projektová pamäť pre AI agentov

ITHZ-MCP robí z práce s AI agentom auditovateľný, opakovateľný proces. Kód
ostáva v Gite, krátky štartovací kontext ostáva v `project.md` a dlhodobá
pracovná pamäť agenta sa ukladá do lokálneho archívu `project.ithz`.

### Prečo je to užitočné

- Agent nezačína každý task naslepo, ale najprv číta projektovú pamäť.
- Rozhodnutia, gates, riziká a ďalšie kroky zostávajú dohľadateľné.
- Tvrdenia o projekte sa dajú povoliť, obmedziť alebo zablokovať cez ledger.
- Tím vie zdieľať nielen kód, ale aj pracovný kontext a reviewer poznámky.
- Citlivý obsah je redigovaný alebo blokovaný; raw prompty nie sú default.
- Git ostáva transport a história kódu; ITHZ-MCP dopĺňa pamäť práce.

### Hlavné vlastnosti

- `project.md` bootstrap: jasné pravidlá, zdroje pravdy a štartovací postup.
- Native `project.ithz`: lokálny Information-Theoretic Hashed Zone archív.
- Memory-first workflow: status, context pack, až potom cielené čítanie súborov.
- Deterministické context packy, search a current-memory synthesis.
- Read-only MCP profil pre bezpečné vyhľadávanie bez zápisu.
- Write-enabled MCP profil pre explicitné checkpointy a task handoff.
- Automatické native checkpointy na konci dokončených úloh.
- Project Ledger: decisions, gates, risks, scoped claims, blocked claims,
  reviewer notes a replication packs.
- Workflow profily pre rôznych vývojárov alebo vetvy práce.
- Prompt/response memory vo forme deterministických summary a hashov.
- Memory zones: nearest, parent, sibling/manual a cross-zone context packy.
- Git-aware diff/merge: stabilný textový diff `project.ithz` a merge driver.
- One-command installer: projektový intake, host config a bezpečné defaults.
- Agent-history import s redakciou a provenance.
- Compact-v2 indexy: vysokosignálové summary bez default snapshotovania zdrojákov.
- Snapshoty, rýchle lock failure a queued finalization pre veľké archívy.
- Native executable auto výber: AVX2/scalar fallback, safe verify path.
- ITHZ Invariant Diff: material, semantic a claim-boundary zmeny v JSON/HTML.

### Výsledok pre tím

ITHZ-MCP znižuje kontextový drift medzi taskmi, zlepšuje handoff, dáva reviewerom
auditnú stopu a pomáha agentom robiť menšie, presnejšie a overiteľnejšie zásahy.
Nie je to produkčná databáza, cloud sync ani náhrada Gitu. Je to lokálna
deterministická pamäť pre AI-assisted prácu.
