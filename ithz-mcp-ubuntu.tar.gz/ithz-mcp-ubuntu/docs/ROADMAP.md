# Roadmap

| Stage | Status |
| --- | --- |
| Stage 0 import and skeleton | done |
| MCP0 local context archive CLI | done |
| MCP1 read-only MCP server | done |
| MCP2 write-back checkpoints | done |
| MCP3 memory benchmark and beta adoption | done |
| MCP4 context VCS timeline | done |
| MCP5 Git integration | done |
| MCP6 team memory sync | done |
| MCP7 productization and dogfooding | done |
| MCP8 beta hardening and RC2 | done |
| MCP9F native ITHZ dogfooding | done |
| MCP10 Markdown-minimal memory compiler workflow | done |
| MCP11 MCP config, scoring v2, quality regression and RC4 | done |
| MCP12 prompt/response memory capture | done |
| MCP13 real MCP host compatibility and native archive memory | done |
| MCP16 Git merge driver for project.ithz | done |
| MCP17 append-only memory/index/snapshot model | done |
| MCP18 project intake and end-of-task checkpoint | done |
| MCP19 workflow branch profiles | done |
| MCP20 agent history import | done |
| MCP21 production-readiness scenarios and product candidate package | done |
| MCP22 automatic native checkpoints | done |
| MCP23 one-command project install and compact native index | done |
| MCP23.2 bounded real LLM first-install intake | done |
| MCP25 macOS MCP package | done |
| MCP26 current-memory synthesis and archive maintenance hardening | done |
| MCP27 project ledger v1 | done |
| MCP28 Ubuntu MCP package | done: Python stdio MCP package, Linux host installers, Linux native source build kit, and extraction-backed `.ithz` fallback commands |

Next recommended work: publish the refreshed product-candidate installers on `ithz.dev/download`, then manually verify project-ledger tools and automatic checkpoint behavior in each real host UI.
