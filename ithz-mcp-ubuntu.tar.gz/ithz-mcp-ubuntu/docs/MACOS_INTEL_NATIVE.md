# macOS Intel ithz-native

`ithz-native` is the native CLI runtime that creates, verifies, reads and
updates `project.ithz`. The Python MCP server can run on macOS without it, but
native archive storage needs a real macOS Mach-O binary.

## Build

Preferred CI build:

```sh
# GitHub Actions
.github/workflows/build-macos-native.yml
```

The workflow runs on `macos-13`, verifies `uname -m == x86_64`, builds with:

```sh
native_ithz/macos_native/build_macos_native_package.sh --arch x86_64
```

and uploads:

```text
ithz-native-preview-v0.1-alpha-rc2-macos-x86_64.zip
SHA256SUMS-macos-x86_64.txt
```

This is a local or CI artifact, not a promised public `ithz.dev/downloads`
file. If the artifact is not supplied, do not try guessed download URLs; use
the macOS MCP/Git/Drive fallback and report that native archive storage is
deferred until a compatible macOS `ithz-native` binary is available.

Local Intel Mac build:

```sh
chmod +x native_ithz/macos_native/build_macos_native_package.sh
native_ithz/macos_native/build_macos_native_package.sh --arch x86_64
```

## Install

```sh
# Only after obtaining the trusted local or CI artifact:
unzip ithz-native-preview-v0.1-alpha-rc2-macos-x86_64.zip
cd ithz-native-preview-v0.1-alpha-rc2-macos-x86_64
chmod +x install_macos_native.sh smoke_test.sh sample_commands.sh bin/ithz-native
./smoke_test.sh
./install_macos_native.sh
export ITHZ_NATIVE_EXE="$HOME/.local/share/ithz-mcp/native/ithz-native"
```

## Cursor

From the target project:

```sh
ITHZ_NATIVE_EXE="$HOME/.local/share/ithz-mcp/native/ithz-native" \
ITHZ_MCP_STORAGE_PROFILE=native-archive \
/path/to/ithz-mcp-macos/host_installers_macos/install_cursor_mcp.sh --project "$PWD" --apply
```

Restart Cursor. Then ask the agent to read `project.md`, call ITHZ-MCP status,
and request a native archive context pack before broad code reading.

## Safety

- Do not replace an existing `project.ithz`; verify and reuse it.
- Do not enable write tools until read-only native status works.
- Do not store secrets or raw private prompts without redaction.
- This does not replace Git, a production database, cloud sync, host chat
  history, vector databases or every retrieval system.
