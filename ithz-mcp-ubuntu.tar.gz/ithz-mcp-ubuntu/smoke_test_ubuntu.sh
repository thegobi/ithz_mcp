#!/usr/bin/env sh
set -eu
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
"$DIR/ithz_mcp_server.sh" version
"$DIR/ithz_mcp_server.sh" self-test --verbose
"$DIR/ithz_mcp_server.sh" init-project --project "$DIR/sample_project"
"$DIR/ithz_mcp_server.sh" build-index --project "$DIR/sample_project"
"$DIR/ithz_mcp_server.sh" get-context-pack --project "$DIR/sample_project" --query "decision gate" --out "$DIR/ubuntu_context_pack.md"
"$DIR/ithz_mcp_server.sh" mcp-config-template --project "$DIR/sample_project" --client codex --storage-profile legacy --out "$DIR/codex_mcp_config.ubuntu.sample.json"
"$DIR/ithz_mcp_server.sh" mcp-config-validate --config "$DIR/codex_mcp_config.ubuntu.sample.json"
"$DIR/ithz_mcp_server.sh" mcp-client-smoke --config "$DIR/codex_mcp_config.ubuntu.sample.json" --out "$DIR/ubuntu_client_transcript.jsonl"
