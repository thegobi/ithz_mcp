#!/usr/bin/env sh
set -eu
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
"$DIR/ithz_mcp_server.sh" version
"$DIR/ithz_mcp_server.sh" init-project --project "$DIR/sample_project"
"$DIR/ithz_mcp_server.sh" build-index --project "$DIR/sample_project"
"$DIR/ithz_mcp_server.sh" get-context-pack --project "$DIR/sample_project" --query "decision gate" --out "$DIR/sample_pack.md"
STORAGE_PROFILE="${ITHZ_MCP_STORAGE_PROFILE:-legacy}"
if [ "$STORAGE_PROFILE" = "native-archive" ] && [ -x "$DIR/native/ithz-native" ]; then export ITHZ_NATIVE_EXE="${ITHZ_NATIVE_EXE:-$DIR/native/ithz-native}"; fi
"$DIR/ithz_mcp_server.sh" mcp-config-template --project "$DIR/sample_project" --client codex --storage-profile "$STORAGE_PROFILE" --out "$DIR/codex_mcp_config.macos.sample.json"
"$DIR/ithz_mcp_server.sh" mcp-config-validate --config "$DIR/codex_mcp_config.macos.sample.json"
