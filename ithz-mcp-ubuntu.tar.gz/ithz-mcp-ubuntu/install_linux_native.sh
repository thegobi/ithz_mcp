#!/usr/bin/env sh
set -eu
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
INSTALL_DIR="${ITHZ_NATIVE_INSTALL_DIR:-$HOME/.local/share/ithz-mcp/native}"
mkdir -p "$INSTALL_DIR"
ITHZ_NATIVE_OUT="$INSTALL_DIR" "$DIR/build_linux_native_package.sh"
chmod +x "$INSTALL_DIR/ithz-native"
"$INSTALL_DIR/ithz-native" --version
echo "Installed Linux ithz-native to $INSTALL_DIR/ithz-native"
