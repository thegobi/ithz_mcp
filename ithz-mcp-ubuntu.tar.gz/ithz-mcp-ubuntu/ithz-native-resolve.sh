#!/usr/bin/env sh
set -eu
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
candidates="${ITHZ_NATIVE_EXE:-} $DIR/native/ithz-native $HOME/.local/share/ithz-mcp/native/ithz-native /opt/ithz-mcp/native/ithz-native"
for c in $candidates; do
  if [ -n "$c" ] && [ -x "$c" ]; then printf '%s\n' "$c"; exit 0; fi
done
if command -v ithz-native >/dev/null 2>&1; then command -v ithz-native; exit 0; fi
echo "ithz-native not found. Run ./build_linux_native_package.sh on Ubuntu, or set ITHZ_NATIVE_EXE=/path/to/ithz-native." >&2
exit 127
