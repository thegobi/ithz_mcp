# ITHZ-MCP v0.1 product candidate

Build: `product-candidate-mcp28-ubuntu-native-zlib.20260609.1`

This package is a production-test candidate for local deterministic project memory. It includes native `project.ithz` storage, memory-first MCP configs, host installer scripts, prompt/response summary memory, durable instruction memory, workflow profiles, Git merge driver support, shared-project smoke coverage, deterministic current-memory synthesis, Project Ledger v1 for claims/blocked claims/replication packs/reviewer notes, fast archive-lock diagnostics and auto-deferred large-archive snapshots.

Windows native archive subprocess calls are launched without a visible console window where the platform supports `CREATE_NO_WINDOW`.

macOS: the Python stdio MCP server and POSIX host installers are included. Generated macOS host configs use `legacy` storage. Native `project.ithz` storage on macOS requires a compatible `ithz-native` binary in `native/ithz-native` or `ITHZ_NATIVE_EXE`.

It does not replace Git, a production database, cloud sync, external host history, vector databases or every retrieval system.
