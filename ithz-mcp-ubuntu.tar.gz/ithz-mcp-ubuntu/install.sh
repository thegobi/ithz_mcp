#!/usr/bin/env sh
set -eu
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PREFIX="${PREFIX:-$HOME/.local/share/ithz-mcp}"
BIN_DIR="${BIN_DIR:-$HOME/.local/bin}"
mkdir -p "$PREFIX" "$BIN_DIR"
tar -C "$SCRIPT_DIR" -cf - . | tar -C "$PREFIX" -xf -
write_wrapper() {
  name="$1"
  target="$2"
  cat > "$BIN_DIR/$name" <<EOF
#!/usr/bin/env sh
exec "$PREFIX/$target" "\$@"
EOF
  chmod +x "$BIN_DIR/$name"
}
write_wrapper ithz-mcp ithz_mcp_server.sh
write_wrapper ithz-mcp-server ithz_mcp_server.sh
write_wrapper ithz-native-resolve ithz-native-resolve.sh
write_wrapper ithz-verify ithz-verify.sh
write_wrapper ithz-list ithz-list.sh
write_wrapper ithz-extract-here ithz-extract-here.sh
write_wrapper ithz-open-temp ithz-open-temp.sh
chmod +x "$PREFIX/ithz_mcp_server.sh" "$PREFIX"/*.sh 2>/dev/null || true
echo "Installed ITHZ-MCP to $PREFIX"
echo "Add $BIN_DIR to PATH if needed, then run: ithz-mcp version"
