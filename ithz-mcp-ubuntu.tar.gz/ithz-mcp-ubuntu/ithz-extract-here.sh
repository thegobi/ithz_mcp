#!/usr/bin/env sh
set -eu
if [ "$#" -lt 1 ]; then echo "Usage: ithz-extract-here ARCHIVE.ithz [OUT_DIR]" >&2; exit 2; fi
ARCHIVE="$1"
OUT="${2:-${ARCHIVE%.ithz}_extracted}"
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ -x "$DIR/ithz-native-resolve.sh" ]; then NATIVE="$($DIR/ithz-native-resolve.sh)"; else NATIVE="$(ithz-native-resolve)"; fi
mkdir -p "$OUT"
exec "$NATIVE" --extract "$ARCHIVE" --output "$OUT"
