#!/usr/bin/env sh
set -eu
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export PYTHONPATH="$DIR/src:$DIR${PYTHONPATH:+:$PYTHONPATH}"
PYTHON_BIN="${PYTHON:-python3}"
exec "$PYTHON_BIN" "$DIR/mcp_client_smoke.py"
