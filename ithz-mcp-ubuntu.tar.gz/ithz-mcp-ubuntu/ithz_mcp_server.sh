#!/usr/bin/env sh
set -eu
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PYTHON_BIN="${PYTHON:-python3}"
export PYTHONPATH="$DIR/src:$DIR${PYTHONPATH:+:$PYTHONPATH}"
exec "$PYTHON_BIN" -m ithz_mcp "$@"
