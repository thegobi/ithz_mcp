#!/usr/bin/env sh
set -eu
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
SRC="${ITHZ_NATIVE_SOURCE:-$DIR/native_build_kit/native_ithz}"
BUILD="${ITHZ_NATIVE_BUILD:-${XDG_CACHE_HOME:-$HOME/.cache}/ithz-mcp/native_build}"
OUT="${ITHZ_NATIVE_OUT:-$DIR/native}"
command -v cmake >/dev/null 2>&1 || { echo "cmake is required" >&2; exit 1; }
if ! command -v c++ >/dev/null 2>&1 && ! command -v g++ >/dev/null 2>&1 && ! command -v clang++ >/dev/null 2>&1; then
  echo "A C++20 compiler is required (for example: sudo apt install build-essential cmake)." >&2
  exit 1
fi
mkdir -p "$BUILD" "$OUT"
rm -rf "$BUILD"/*
cmake -S "$SRC" -B "$BUILD" -DCMAKE_BUILD_TYPE=Release -DITHZ_ENABLE_X64_AVX2=OFF
cmake --build "$BUILD" --config Release --target ithz-native
BIN="$BUILD/ithz-native"
if [ ! -x "$BIN" ] && [ -x "$BUILD/Release/ithz-native" ]; then BIN="$BUILD/Release/ithz-native"; fi
if [ ! -x "$BIN" ]; then echo "Built ithz-native not found" >&2; exit 1; fi
cp "$BIN" "$OUT/ithz-native"
chmod +x "$OUT/ithz-native"
"$OUT/ithz-native" --version
"$OUT/ithz-native" --self-test
echo "linux_native_ready=$OUT/ithz-native"
