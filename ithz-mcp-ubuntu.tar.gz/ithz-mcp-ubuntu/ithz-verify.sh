#!/usr/bin/env sh
set -eu
if [ "$#" -lt 1 ]; then echo "Usage: ithz-verify ARCHIVE.ithz" >&2; exit 2; fi
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ -x "$DIR/ithz-native-resolve.sh" ]; then NATIVE="$($DIR/ithz-native-resolve.sh)"; else NATIVE="$(ithz-native-resolve)"; fi
exec "$NATIVE" --verify "$1" --verify=safe
