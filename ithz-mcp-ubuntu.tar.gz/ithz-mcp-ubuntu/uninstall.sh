#!/usr/bin/env sh
set -eu
PREFIX="${PREFIX:-$HOME/.local/share/ithz-mcp}"
BIN_DIR="${BIN_DIR:-$HOME/.local/bin}"
rm -f "$BIN_DIR/ithz-mcp" "$BIN_DIR/ithz-mcp-server" "$BIN_DIR/ithz-native-resolve" "$BIN_DIR/ithz-verify" "$BIN_DIR/ithz-list" "$BIN_DIR/ithz-extract-here" "$BIN_DIR/ithz-open-temp"
rm -rf "$PREFIX"
echo "Removed ITHZ-MCP user-local install."
