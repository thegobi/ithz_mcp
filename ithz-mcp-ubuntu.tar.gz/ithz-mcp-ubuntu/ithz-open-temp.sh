#!/usr/bin/env sh
set -eu
if [ "$#" -lt 1 ]; then echo "Usage: ithz-open-temp ARCHIVE.ithz" >&2; exit 2; fi
ARCHIVE="$1"
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
if [ -x "$DIR/ithz-native-resolve.sh" ]; then NATIVE="$($DIR/ithz-native-resolve.sh)"; else NATIVE="$(ithz-native-resolve)"; fi
TMP="$(mktemp -d "${TMPDIR:-/tmp}/ithz-open-XXXXXX")"
"$NATIVE" --extract "$ARCHIVE" --output "$TMP"
if command -v xdg-open >/dev/null 2>&1; then xdg-open "$TMP" >/dev/null 2>&1 || true; fi
printf '%s\n' "$TMP"
